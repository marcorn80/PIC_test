from pathlib import Path
from hexfile import read_words
import re
root = Path(__file__).resolve().parents[1]
words=read_words(root/'firmware.hex')
# Numeric file-register operands avoid the disassembler's ambiguous bank aliases.
listing={}
for line in (root/'compact.lst').read_text().splitlines():
    match=re.match(r'^([0-9a-f]{4}):\s+[0-9a-f]{4}\s+(.*)',line)
    if match:
        listing[int(match[1],16)] = match[2]
# Emit original words with their disassembly as comments. This preserves every
# location, including erased words and computed-jump tables; no inferred label
# can change a destination. Human-readable listing remains a separate artifact.
lines=['; Complete lossless recovery, PIC16F917. Word addresses.',
       '    processor 16f917','    radix hex','    org 0']
for address in range(0x2000):
    lines.append(f'    dw 0x{words[address]:04x} ; {address:04x}: {listing.get(address, "")}')
lines+=['    org 0x2000','    dw '+', '.join(f'0x{words[a]:04x}' for a in range(0x2000,0x2004)),
        f'    __config 0x{words[0x2007]:04x}','    org 0x2100']
for address in range(0x2100,0x2200,16):
    lines.append('    de '+', '.join(f'0x{words[a]:02x}' for a in range(address,address+16)))
lines.append('    end')
(root/'recovered_lossless.asm').write_text('\n'.join(lines)+'\n')
# Second source uses real mnemonics and literal 7-bit register operands.
# Never guess bank-qualified SFR names or PCLATH-qualified call destinations.
plain=(root/'build/plain.asm').read_text()
code=plain.split('org     __CODE_START',1)[1].split(';',1)[1].splitlines()[1:]
mnemonics=[]
for line in code:
    stripped=line.strip()
    if stripped.startswith('org') or stripped.startswith('; CONFIG'):
        break
    if stripped and not stripped.startswith(';'):
        mnemonics.append(stripped.split(';')[0].strip())
        if len(mnemonics)==0x2000:
            break
assert len(mnemonics)==0x2000, len(mnemonics)
readable=['; Complete PIC16F917 disassembly; numeric register operands are bank-relative.',
          '    processor 16f917','    radix hex','    org 0']
for address,instruction in enumerate(mnemonics):
    if words[address] == 0x3fff:
        instruction = 'dw 0x3fff ; erased'
    readable.append(f'    {instruction:<32} ; {address:04x}: {words[address]:04x}')
readable.extend(lines[0x2000+4:])
(root/'recovered_readable.asm').write_text('\n'.join(readable)+'\n')
(root/'eeprom.bin').write_bytes(bytes(words[a] for a in range(0x2100,0x2200)))
print('Recovered words:',len(words),'non-erased program words:',sum(v!=0x3fff for a,v in words.items() if a<0x2000))
