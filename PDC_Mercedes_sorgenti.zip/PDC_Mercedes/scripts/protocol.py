#!/usr/bin/env python3
"""Offline encoder/decoder of the format recovered from 0x0438..0x04ca.
No port is opened and no data is transmitted. Examples are synthetic, not a
recorded Mercedes exchange or a claim about physical distances.
"""
import argparse
import json

def encode(header, data):
    if not 0 <= header <= 255 or any(not 0 <= b <= 255 for b in data):
        raise ValueError('Bytes must be 00..FF')
    expected = (header >> 6)+1
    if len(data) != expected:
        raise ValueError(f'Header {header:02X} requires {expected} payload bytes')
    result = bytes([header, *data])
    return result+bytes([sum(result)&255])

def decode(packet):
    if len(packet) < 3:
        raise ValueError('Incomplete packet')
    header = packet[0]
    expected = (header >> 6)+3
    if len(packet) != expected:
        raise ValueError(f'Header requires {expected} total bytes')
    return dict(header=f'{header:02X}', type=header&15, group=(header>>4)&3,
                payload=packet[1:-1].hex(' ').upper(),
                checksum_ok=(sum(packet[:-1])&255)==packet[-1],
                even_parity_bits=[b.bit_count()%2 for b in packet])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('encode');p.add_argument('header',type=lambda s:int(s,16));p.add_argument('data',nargs='+',type=lambda s:int(s,16))
    p=sub.add_parser('decode');p.add_argument('packet',nargs='+',type=lambda s:int(s,16))
    args=parser.parse_args()
    try:
        if args.command=='encode':
            packet=encode(args.header,args.data)
            print(packet.hex(' ').upper())
            print(json.dumps(decode(packet),indent=2))
        else:print(json.dumps(decode(bytes(args.packet)),indent=2))
    except ValueError as error:parser.error(str(error))

if __name__=='__main__':main()
