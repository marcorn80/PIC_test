# Ricostruzione PIC16F917 PDC Mercedes

**Stato: assembly completo recuperato e verificato; traduzione C parziale. Non è
ancora un firmware XC8 completo e non è pronto per essere programmato sulla scheda.**

## File utilizzabili

- `recovered_readable.asm`: sorgente assembly completo con mnemonici, indirizzi
  originali e operandi di registro numerici. Assemblato con gputils 1.5.2: tutti
  i 16.906 byte presenti nell'HEX originale sono riprodotti esattamente.
- `recovered_lossless.asm`: stessa immagine con parole `dw`, utile per conservare
  anche le codifiche non canoniche delle celle cancellate.
- `firmware.hex`: copia con separatori di riga normalizzati, senza cambiare i
  record Intel HEX né i dati. L'originale contiene separatori letterali `\r\n`.
- `eeprom.bin`: i 256 byte EEPROM, estratti dagli indirizzi parola 0x2100..0x21ff.
- `src/pdc_core.c` e `.h`: C99 portabile, utilizzabile come moduli in XC8.
  Implementa parità, parser di pacchetti, dispatch, mappatura LED, PWM software
  della luminosità, lettura ridondante della configurazione e percorso applicativo
  dei messaggi di gruppo 0, inclusa la selezione dell'indice sonoro.
- `src/pdc_xc8.c` e `.h`: integrazione con registri e configuration bits Microchip.
  Non contiene `main` né ISR e **non è stato compilato con XC8**. La preparazione
  hardware mantiene gli interrupt disabilitati: non sostituisce l'avvio originale.
- `scripts/protocol.py`: generatore/decodificatore offline. Non apre porte seriali
  e non trasmette nulla.
- `tests/`: confronto delle routine C con le istruzioni originali mediante un
  modello PIC14 limitato alle prove delle routine; non è un simulatore temporale
  completo della scheda.
- `ANALISI.md`: formato dei messaggi, indirizzi di prova e limiti della ricostruzione.

## Verifiche eseguite

Da questa directory: `make check`.

Servono Python 3.10+, GCC e gputils. In questa istanza gputils è estratto in
`tools/gputils`, da pacchetti Debian 1.5.2-1 verificati tramite metadati firmati;
non è stato installato a livello di sistema. Non servono pacchetti Python.

Per rigenerare gli assembly: `make recover`, poi `make check`.

Risultato: due ricostruzioni HEX esattamente uguali all'input e 9.949 casi di
confronto passati, conteggiati in `build/validation.json`. Il conteggio include
32 confronti diretti delle tabelle, non esecuzioni di routine. Le altre prove
confrontano l'esecuzione isolata di istruzioni originali e funzioni C.

Gli avvisi gpasm sugli indirizzi 0x2000..0x2003 dipendono dalla conservazione
esatta delle parole USER ID lette dal dispositivo. I messaggi sui banchi nel
listing non sono errori di confronto: il codice conserva gli operandi e le
istruzioni originali di selezione banco. Entrambi i risultati sono confrontati
per indirizzo e valore, non per formattazione del file HEX.

## Uso in XC8

In MPLAB X selezionare PIC16F917 e aggiungere i moduli `src/` a un progetto C.
**Si tratta di moduli da integrare**, non di un progetto applicativo completo:
il link senza `main` non deve essere presentato come firmware funzionante.

Non è stato possibile verificare compilazione, occupazione flash/RAM o tempi
con XC8, che non è installato nell'ambiente. I controlli GCC riguardano solo il
modulo portabile, con `-std=c99 -Wall -Wextra -Werror -pedantic`.

Restano da tradurre il resto di `0x08ce..0x0fff` (gruppi 1, 2, 3), il servizio
sonoro/ADC a `0x02f7..0x03fb`, il controllo analogico, i comandi di configurazione
e trasmissione, gli accessi EEPROM in scrittura e lo scheduler/event queue.
L'ISR originale e la sua coda non sono stati integrati nel C. Tutti questi
elementi rimangono disponibili nell'assembly completo.

Per completare e validare il port servono XC8 e infine prove sulla scheda o su
un simulatore di periferiche adeguato. L'assenza del trasmettitore originale non
impedisce la decodifica statica: si possono usare messaggi sintetici. Le prove
fisiche devono verificare livelli, polarità, tempi, watchdog e comportamento
degli altri gruppi, senza presumere equivalenza dalle sole prove delle routine.
