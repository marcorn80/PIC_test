; Complete lossless recovery, PIC16F917. Word addresses.
    processor 16f917
    radix hex
    org 0
    dw 0x3001 ; 0000: movlw   0x01
    dw 0x008a ; 0001: movwf   PCLATH
    dw 0x2910 ; 0002: goto    label_017
    dw 0x3fff ; 0003: addlw   0xff
    dw 0x00f7 ; 0004: movwf   (Common_RAM + 7)
    dw 0x0803 ; 0005: movf    STATUS, W
    dw 0x0183 ; 0006: clrf    STATUS
    dw 0x00e3 ; 0007: movwf   0x63
    dw 0x0804 ; 0008: movf    FSR, W
    dw 0x00e4 ; 0009: movwf   0x64
    dw 0x080a ; 000a: movf    PCLATH, W
    dw 0x00e5 ; 000b: movwf   0x65
    dw 0x018a ; 000c: clrf    PCLATH
    dw 0x0870 ; 000d: movf    Common_RAM, W
    dw 0x00ea ; 000e: movwf   0x6a
    dw 0x0871 ; 000f: movf    (Common_RAM + 1), W
    dw 0x00f8 ; 0010: movwf   (Common_RAM + 8)
    dw 0x0872 ; 0011: movf    (Common_RAM + 2), W
    dw 0x00ef ; 0012: movwf   0x6f
    dw 0x0873 ; 0013: movf    (Common_RAM + 3), W
    dw 0x00ec ; 0014: movwf   0x6c
    dw 0x0874 ; 0015: movf    (Common_RAM + 4), W
    dw 0x00eb ; 0016: movwf   0x6b
    dw 0x0875 ; 0017: movf    (Common_RAM + 5), W
    dw 0x00ee ; 0018: movwf   0x6e
    dw 0x0876 ; 0019: movf    (Common_RAM + 6), W
    dw 0x00ed ; 001a: movwf   0x6d
    dw 0x0866 ; 001b: movf    0x66, W
    dw 0x00e8 ; 001c: movwf   0x68
    dw 0x0867 ; 001d: movf    0x67, W
    dw 0x00e9 ; 001e: movwf   0x69
    dw 0x1a8b ; 001f: btfsc   INTCON, T0IE
    dw 0x1d0b ; 0020: btfss   INTCON, T0IF
    dw 0x2894 ; 0021: goto    label_011
    dw 0x110b ; 0022: bcf     INTCON, T0IF
    dw 0x30ed ; 0023: movlw   0xed
    dw 0x1283 ; 0024: bcf     STATUS, RP0
    dw 0x1303 ; 0025: bcf     STATUS, RP1
    dw 0x0081 ; 0026: movwf   TMR0
    dw 0x1683 ; 0027: bsf     STATUS, RP0
    dw 0x1fce ; 0028: btfss   0x4e, 0x7
    dw 0x2832 ; 0029: goto    label_001
    dw 0x1703 ; 002a: bsf     STATUS, RP1
    dw 0x0a90 ; 002b: incf    T1CON, F
    dw 0x0064 ; 002c: clrwdt
    dw 0x302d ; 002d: movlw   0x2d
    dw 0x0210 ; 002e: subwf   T1CON, W
    dw 0x1303 ; 002f: bcf     STATUS, RP1
    dw 0x1803 ; 0030: btfsc   STATUS, C
    dw 0x13ce ; 0031: bcf     0x4e, 0x7
    dw 0x1303 ; 0032: bcf     STATUS, RP1
    dw 0x1bce ; 0033: btfsc   0x4e, 0x7
    dw 0x283a ; 0034: goto    label_002
    dw 0x160a ; 0035: bsf     PCLATH, 0x4
    dw 0x158a ; 0036: bsf     PCLATH, 0x3
    dw 0x260a ; 0037: call    function_046
    dw 0x120a ; 0038: bcf     PCLATH, 0x4
    dw 0x118a ; 0039: bcf     PCLATH, 0x3
    dw 0x1683 ; 003a: bsf     STATUS, RP0
    dw 0x1c4e ; 003b: btfss   0x4e, 0x0
    dw 0x287f ; 003c: goto    label_009
    dw 0x08d1 ; 003d: movf    0x51, F
    dw 0x1d03 ; 003e: btfss   STATUS, Z
    dw 0x2864 ; 003f: goto    label_006
    dw 0x08c0 ; 0040: movf    0x40, F
    dw 0x1903 ; 0041: btfsc   STATUS, Z
    dw 0x08bf ; 0042: movf    0x3f, F
    dw 0x1903 ; 0043: btfsc   STATUS, Z
    dw 0x2864 ; 0044: goto    label_006
    dw 0x0851 ; 0045: movf    0x51, W
    dw 0x0640 ; 0046: xorwf   0x40, W
    dw 0x1d03 ; 0047: btfss   STATUS, Z
    dw 0x284d ; 0048: goto    label_003
    dw 0x0851 ; 0049: movf    0x51, W
    dw 0x063f ; 004a: xorwf   0x3f, W
    dw 0x1903 ; 004b: btfsc   STATUS, Z
    dw 0x2864 ; 004c: goto    label_006
    dw 0x08c0 ; 004d: movf    0x40, F
    dw 0x1d03 ; 004e: btfss   STATUS, Z
    dw 0x2856 ; 004f: goto    label_004
    dw 0x300f ; 0050: movlw   0x0f
    dw 0x1283 ; 0051: bcf     STATUS, RP0
    dw 0x04b6 ; 0052: iorwf   0x36, F
    dw 0x04b7 ; 0053: iorwf   0x37, F
    dw 0x3099 ; 0054: movlw   0x99
    dw 0x04b8 ; 0055: iorwf   0x38, F
    dw 0x1683 ; 0056: bsf     STATUS, RP0
    dw 0x08bf ; 0057: movf    0x3f, F
    dw 0x1d03 ; 0058: btfss   STATUS, Z
    dw 0x285d ; 0059: goto    label_005
    dw 0x3066 ; 005a: movlw   0x66
    dw 0x1283 ; 005b: bcf     STATUS, RP0
    dw 0x04b8 ; 005c: iorwf   0x38, F
    dw 0x1283 ; 005d: bcf     STATUS, RP0
    dw 0x0836 ; 005e: movf    0x36, W
    dw 0x0086 ; 005f: movwf   PORTB
    dw 0x0837 ; 0060: movf    0x37, W
    dw 0x0087 ; 0061: movwf   PORTC
    dw 0x0838 ; 0062: movf    0x38, W
    dw 0x0088 ; 0063: movwf   PORTD
    dw 0x1683 ; 0064: bsf     STATUS, RP0
    dw 0x0851 ; 0065: movf    0x51, W
    dw 0x0640 ; 0066: xorwf   0x40, W
    dw 0x1d03 ; 0067: btfss   STATUS, Z
    dw 0x286f ; 0068: goto    label_007
    dw 0x300f ; 0069: movlw   0x0f
    dw 0x1283 ; 006a: bcf     STATUS, RP0
    dw 0x0486 ; 006b: iorwf   PORTB, F
    dw 0x0487 ; 006c: iorwf   PORTC, F
    dw 0x3099 ; 006d: movlw   0x99
    dw 0x0488 ; 006e: iorwf   PORTD, F
    dw 0x1683 ; 006f: bsf     STATUS, RP0
    dw 0x0851 ; 0070: movf    0x51, W
    dw 0x063f ; 0071: xorwf   0x3f, W
    dw 0x1d03 ; 0072: btfss   STATUS, Z
    dw 0x2877 ; 0073: goto    label_008
    dw 0x3066 ; 0074: movlw   0x66
    dw 0x1283 ; 0075: bcf     STATUS, RP0
    dw 0x0488 ; 0076: iorwf   PORTD, F
    dw 0x1683 ; 0077: bsf     STATUS, RP0
    dw 0x0ad1 ; 0078: incf    0x51, F
    dw 0x0851 ; 0079: movf    0x51, W
    dw 0x3a0a ; 007a: xorlw   0x0a
    dw 0x1d03 ; 007b: btfss   STATUS, Z
    dw 0x288d ; 007c: goto    label_010
    dw 0x01d1 ; 007d: clrf    0x51
    dw 0x288d ; 007e: goto    label_010
    dw 0x18ce ; 007f: btfsc   0x4e, 0x1
    dw 0x288d ; 0080: goto    label_010
    dw 0x1283 ; 0081: bcf     STATUS, RP0
    dw 0x0806 ; 0082: movf    PORTB, W
    dw 0x00b6 ; 0083: movwf   0x36
    dw 0x0807 ; 0084: movf    PORTC, W
    dw 0x00b7 ; 0085: movwf   0x37
    dw 0x0808 ; 0086: movf    PORTD, W
    dw 0x00b8 ; 0087: movwf   0x38
    dw 0x300f ; 0088: movlw   0x0f
    dw 0x0486 ; 0089: iorwf   PORTB, F
    dw 0x0487 ; 008a: iorwf   PORTC, F
    dw 0x3099 ; 008b: movlw   0x99
    dw 0x0488 ; 008c: iorwf   PORTD, F
    dw 0x1283 ; 008d: bcf     STATUS, RP0
    dw 0x1703 ; 008e: bsf     STATUS, RP1
    dw 0x08c4 ; 008f: movf    0x44, F
    dw 0x1903 ; 0090: btfsc   STATUS, Z
    dw 0x28f3 ; 0091: goto    label_016
    dw 0x0abd ; 0092: incf    0x3d, F
    dw 0x28f3 ; 0093: goto    label_016
    dw 0x1683 ; 0094: bsf     STATUS, RP0
    dw 0x1303 ; 0095: bcf     STATUS, RP1
    dw 0x1e8c ; 0096: btfss   PIE1, RCIE
    dw 0x28e8 ; 0097: goto    label_015
    dw 0x1283 ; 0098: bcf     STATUS, RP0
    dw 0x1e8c ; 0099: btfss   PIR1, RCIF
    dw 0x28e8 ; 009a: goto    label_015
    dw 0x1683 ; 009b: bsf     STATUS, RP0
    dw 0x1b4e ; 009c: btfsc   0x4e, 0x6
    dw 0x28e0 ; 009d: goto    label_014
    dw 0x3006 ; 009e: movlw   0x06
    dw 0x1283 ; 009f: bcf     STATUS, RP0
    dw 0x1703 ; 00a0: bsf     STATUS, RP1
    dw 0x023d ; 00a1: subwf   0x3d, W
    dw 0x1c03 ; 00a2: btfss   STATUS, C
    dw 0x28b2 ; 00a3: goto    label_012
    dw 0x08c4 ; 00a4: movf    0x44, F
    dw 0x1903 ; 00a5: btfsc   STATUS, Z
    dw 0x28b2 ; 00a6: goto    label_012
    dw 0x1683 ; 00a7: bsf     STATUS, RP0
    dw 0x019c ; 00a8: clrf    CCPR2H
    dw 0x019d ; 00a9: clrf    CCP2CON
    dw 0x1283 ; 00aa: bcf     STATUS, RP0
    dw 0x01c4 ; 00ab: clrf    0x44
    dw 0x01be ; 00ac: clrf    0x3e
    dw 0x01c3 ; 00ad: clrf    0x43
    dw 0x1303 ; 00ae: bcf     STATUS, RP1
    dw 0x01bb ; 00af: clrf    0x3b
    dw 0x01b9 ; 00b0: clrf    0x39
    dw 0x28dd ; 00b1: goto    label_013
    dw 0x1303 ; 00b2: bcf     STATUS, RP1
    dw 0x0ab9 ; 00b3: incf    0x39, F
    dw 0x3000 ; 00b4: movlw   0x00
    dw 0x1918 ; 00b5: btfsc   RCSTA, FERR
    dw 0x3001 ; 00b6: movlw   0x01
    dw 0x00f0 ; 00b7: movwf   Common_RAM
    dw 0x0ef0 ; 00b8: swapf   Common_RAM, F
    dw 0x1683 ; 00b9: bsf     STATUS, RP0
    dw 0x0858 ; 00ba: movf    0x58, W
    dw 0x0670 ; 00bb: xorwf   0x70, W
    dw 0x39ef ; 00bc: andlw   0xef
    dw 0x0670 ; 00bd: xorwf   0x70, W
    dw 0x00d8 ; 00be: movwf   0x58
    dw 0x1283 ; 00bf: bcf     STATUS, RP0
    dw 0x081a ; 00c0: movf    RCREG, W
    dw 0x00f0 ; 00c1: movwf   Common_RAM
    dw 0x01f1 ; 00c2: clrf    (Common_RAM + 1)
    dw 0x083b ; 00c3: movf    0x3b, W
    dw 0x073b ; 00c4: addwf   0x3b, W
    dw 0x3e9c ; 00c5: addlw   0x9c
    dw 0x0084 ; 00c6: movwf   FSR
    dw 0x1783 ; 00c7: bsf     STATUS, IRP
    dw 0x0870 ; 00c8: movf    Common_RAM, W
    dw 0x0080 ; 00c9: movwf   INDF
    dw 0x0a84 ; 00ca: incf    FSR, F
    dw 0x0871 ; 00cb: movf    (Common_RAM + 1), W
    dw 0x0080 ; 00cc: movwf   INDF
    dw 0x3000 ; 00cd: movlw   0x00
    dw 0x1818 ; 00ce: btfsc   RCSTA, RX9D
    dw 0x3001 ; 00cf: movlw   0x01
    dw 0x00f1 ; 00d0: movwf   (Common_RAM + 1)
    dw 0x01f0 ; 00d1: clrf    Common_RAM
    dw 0x083b ; 00d2: movf    0x3b, W
    dw 0x073b ; 00d3: addwf   0x3b, W
    dw 0x3e9c ; 00d4: addlw   0x9c
    dw 0x0084 ; 00d5: movwf   FSR
    dw 0x1783 ; 00d6: bsf     STATUS, IRP
    dw 0x0870 ; 00d7: movf    Common_RAM, W
    dw 0x0480 ; 00d8: iorwf   INDF, F
    dw 0x0a84 ; 00d9: incf    FSR, F
    dw 0x0871 ; 00da: movf    (Common_RAM + 1), W
    dw 0x0480 ; 00db: iorwf   INDF, F
    dw 0x0abb ; 00dc: incf    0x3b, F
    dw 0x1703 ; 00dd: bsf     STATUS, RP1
    dw 0x01bd ; 00de: clrf    0x3d
    dw 0x28f3 ; 00df: goto    label_016
    dw 0x1283 ; 00e0: bcf     STATUS, RP0
    dw 0x081a ; 00e1: movf    RCREG, W
    dw 0x1703 ; 00e2: bsf     STATUS, RP1
    dw 0x00bf ; 00e3: movwf   0x3f
    dw 0x1683 ; 00e4: bsf     STATUS, RP0
    dw 0x1303 ; 00e5: bcf     STATUS, RP1
    dw 0x134e ; 00e6: bcf     0x4e, 0x6
    dw 0x28f3 ; 00e7: goto    label_016
    dw 0x1683 ; 00e8: bsf     STATUS, RP0
    dw 0x1e98 ; 00e9: btfss   RCSTA, SREN
    dw 0x28f3 ; 00ea: goto    label_016
    dw 0x1283 ; 00eb: bcf     STATUS, RP0
    dw 0x1e0c ; 00ec: btfss   PIR1, TXIF
    dw 0x28f3 ; 00ed: goto    label_016
    dw 0x1283 ; 00ee: bcf     STATUS, RP0
    dw 0x01ba ; 00ef: clrf    0x3a
    dw 0x0aba ; 00f0: incf    0x3a, F
    dw 0x1683 ; 00f1: bsf     STATUS, RP0
    dw 0x120c ; 00f2: bcf     PIR1, TXIF
    dw 0x1303 ; 00f3: bcf     STATUS, RP1
    dw 0x1283 ; 00f4: bcf     STATUS, RP0
    dw 0x086a ; 00f5: movf    0x6a, W
    dw 0x00f0 ; 00f6: movwf   Common_RAM
    dw 0x0878 ; 00f7: movf    (Common_RAM + 8), W
    dw 0x00f1 ; 00f8: movwf   (Common_RAM + 1)
    dw 0x086f ; 00f9: movf    0x6f, W
    dw 0x00f2 ; 00fa: movwf   (Common_RAM + 2)
    dw 0x086c ; 00fb: movf    0x6c, W
    dw 0x00f3 ; 00fc: movwf   (Common_RAM + 3)
    dw 0x086b ; 00fd: movf    0x6b, W
    dw 0x00f4 ; 00fe: movwf   (Common_RAM + 4)
    dw 0x086e ; 00ff: movf    0x6e, W
    dw 0x00f5 ; 0100: movwf   (Common_RAM + 5)
    dw 0x086d ; 0101: movf    0x6d, W
    dw 0x00f6 ; 0102: movwf   (Common_RAM + 6)
    dw 0x0868 ; 0103: movf    0x68, W
    dw 0x00e6 ; 0104: movwf   0x66
    dw 0x0869 ; 0105: movf    0x69, W
    dw 0x00e7 ; 0106: movwf   0x67
    dw 0x0864 ; 0107: movf    0x64, W
    dw 0x0084 ; 0108: movwf   FSR
    dw 0x0865 ; 0109: movf    0x65, W
    dw 0x008a ; 010a: movwf   PCLATH
    dw 0x0863 ; 010b: movf    0x63, W
    dw 0x0083 ; 010c: movwf   STATUS
    dw 0x0ef7 ; 010d: swapf   (Common_RAM + 7), F
    dw 0x0e77 ; 010e: swapf   (Common_RAM + 7), W
    dw 0x0009 ; 010f: retfie
    dw 0x3020 ; 0110: movlw   0x20
    dw 0x0084 ; 0111: movwf   FSR
    dw 0x305f ; 0112: movlw   0x5f
    dw 0x2137 ; 0113: call    function_001
    dw 0x3007 ; 0114: movlw   0x07
    dw 0x00e7 ; 0115: movwf   0x67
    dw 0x30fc ; 0116: movlw   0xfc
    dw 0x00e6 ; 0117: movwf   0x66
    dw 0x305f ; 0118: movlw   0x5f
    dw 0x0084 ; 0119: movwf   FSR
    dw 0x3063 ; 011a: movlw   0x63
    dw 0x213c ; 011b: call    function_002
    dw 0x30a0 ; 011c: movlw   0xa0
    dw 0x0084 ; 011d: movwf   FSR
    dw 0x30db ; 011e: movlw   0xdb
    dw 0x2137 ; 011f: call    function_001
    dw 0x3007 ; 0120: movlw   0x07
    dw 0x00e7 ; 0121: movwf   0x67
    dw 0x30f8 ; 0122: movlw   0xf8
    dw 0x00e6 ; 0123: movwf   0x66
    dw 0x30db ; 0124: movlw   0xdb
    dw 0x0084 ; 0125: movwf   FSR
    dw 0x30df ; 0126: movlw   0xdf
    dw 0x213c ; 0127: call    function_002
    dw 0x1783 ; 0128: bsf     STATUS, IRP
    dw 0x3020 ; 0129: movlw   0x20
    dw 0x0084 ; 012a: movwf   FSR
    dw 0x304b ; 012b: movlw   0x4b
    dw 0x2137 ; 012c: call    function_001
    dw 0x3090 ; 012d: movlw   0x90
    dw 0x0084 ; 012e: movwf   FSR
    dw 0x30c5 ; 012f: movlw   0xc5
    dw 0x2137 ; 0130: call    function_001
    dw 0x120a ; 0131: bcf     PCLATH, 0x4
    dw 0x118a ; 0132: bcf     PCLATH, 0x3
    dw 0x2949 ; 0133: goto    label_020
    dw 0x0604 ; 0134: xorwf   FSR, W
    dw 0x0180 ; 0135: clrf    INDF
    dw 0x0a84 ; 0136: incf    FSR, F
    dw 0x0604 ; 0137: xorwf   FSR, W
    dw 0x1d03 ; 0138: btfss   STATUS, Z
    dw 0x2934 ; 0139: goto    label_018
    dw 0x0064 ; 013a: clrwdt
    dw 0x3400 ; 013b: retlw   0x00
    dw 0x00f0 ; 013c: movwf   Common_RAM
    dw 0x120a ; 013d: bcf     PCLATH, 0x4
    dw 0x118a ; 013e: bcf     PCLATH, 0x3
    dw 0x21ea ; 013f: call    function_004
    dw 0x120a ; 0140: bcf     PCLATH, 0x4
    dw 0x118a ; 0141: bcf     PCLATH, 0x3
    dw 0x0080 ; 0142: movwf   INDF
    dw 0x0a84 ; 0143: incf    FSR, F
    dw 0x0804 ; 0144: movf    FSR, W
    dw 0x0670 ; 0145: xorwf   Common_RAM, W
    dw 0x1903 ; 0146: btfsc   STATUS, Z
    dw 0x3400 ; 0147: retlw   0x00
    dw 0x293d ; 0148: goto    label_019
    dw 0x160a ; 0149: bsf     PCLATH, 0x4
    dw 0x118a ; 014a: bcf     PCLATH, 0x3
    dw 0x2484 ; 014b: call    function_032
    dw 0x1683 ; 014c: bsf     STATUS, RP0
    dw 0x104e ; 014d: bcf     0x4e, 0x0
    dw 0x1283 ; 014e: bcf     STATUS, RP0
    dw 0x1703 ; 014f: bsf     STATUS, RP1
    dw 0x01a1 ; 0150: clrf    0x21
    dw 0x0aa1 ; 0151: incf    0x21, F
    dw 0x120a ; 0152: bcf     PCLATH, 0x4
    dw 0x118a ; 0153: bcf     PCLATH, 0x3
    dw 0x23fc ; 0154: call    function_006
    dw 0x3045 ; 0155: movlw   0x45
    dw 0x00bc ; 0156: movwf   0x3c
    dw 0x3018 ; 0157: movlw   0x18
    dw 0x00bd ; 0158: movwf   0x3d
    dw 0x3002 ; 0159: movlw   0x02
    dw 0x00be ; 015a: movwf   0x3e
    dw 0x160a ; 015b: bsf     PCLATH, 0x4
    dw 0x118a ; 015c: bcf     PCLATH, 0x3
    dw 0x20b3 ; 015d: call    function_025
    dw 0x303c ; 015e: movlw   0x3c
    dw 0x00bc ; 015f: movwf   0x3c
    dw 0x3018 ; 0160: movlw   0x18
    dw 0x00bd ; 0161: movwf   0x3d
    dw 0x01be ; 0162: clrf    0x3e
    dw 0x0abe ; 0163: incf    0x3e, F
    dw 0x160a ; 0164: bsf     PCLATH, 0x4
    dw 0x118a ; 0165: bcf     PCLATH, 0x3
    dw 0x2407 ; 0166: call    function_031
    dw 0x120a ; 0167: bcf     PCLATH, 0x4
    dw 0x118a ; 0168: bcf     PCLATH, 0x3
    dw 0x2741 ; 0169: call    function_015
    dw 0x1683 ; 016a: bsf     STATUS, RP0
    dw 0x1703 ; 016b: bsf     STATUS, RP1
    dw 0x0843 ; 016c: movf    0x43, W
    dw 0x1283 ; 016d: bcf     STATUS, RP0
    dw 0x1303 ; 016e: bcf     STATUS, RP1
    dw 0x00d6 ; 016f: movwf   0x56
    dw 0x1683 ; 0170: bsf     STATUS, RP0
    dw 0x1703 ; 0171: bsf     STATUS, RP1
    dw 0x0842 ; 0172: movf    0x42, W
    dw 0x160a ; 0173: bsf     PCLATH, 0x4
    dw 0x118a ; 0174: bcf     PCLATH, 0x3
    dw 0x21e7 ; 0175: call    function_028
    dw 0x1683 ; 0176: bsf     STATUS, RP0
    dw 0x1703 ; 0177: bsf     STATUS, RP1
    dw 0x083b ; 0178: movf    0x3b, W
    dw 0x1283 ; 0179: bcf     STATUS, RP0
    dw 0x00a0 ; 017a: movwf   0x20
    dw 0x300a ; 017b: movlw   0x0a
    dw 0x1683 ; 017c: bsf     STATUS, RP0
    dw 0x1303 ; 017d: bcf     STATUS, RP1
    dw 0x00d9 ; 017e: movwf   0x59
    dw 0x01da ; 017f: clrf    0x5a
    dw 0x1283 ; 0180: bcf     STATUS, RP0
    dw 0x1703 ; 0181: bsf     STATUS, RP1
    dw 0x0820 ; 0182: movf    0x20, W
    dw 0x120a ; 0183: bcf     PCLATH, 0x4
    dw 0x158a ; 0184: bsf     PCLATH, 0x3
    dw 0x2046 ; 0185: call    function_019
    dw 0x1683 ; 0186: bsf     STATUS, RP0
    dw 0x01d1 ; 0187: clrf    0x51
    dw 0x3000 ; 0188: movlw   0x00
    dw 0x160a ; 0189: bsf     PCLATH, 0x4
    dw 0x158a ; 018a: bsf     PCLATH, 0x3
    dw 0x27d5 ; 018b: call    function_081
    dw 0x3000 ; 018c: movlw   0x00
    dw 0x160a ; 018d: bsf     PCLATH, 0x4
    dw 0x158a ; 018e: bsf     PCLATH, 0x3
    dw 0x27aa ; 018f: call    function_080
    dw 0x300f ; 0190: movlw   0x0f
    dw 0x0486 ; 0191: iorwf   PORTB, F
    dw 0x0487 ; 0192: iorwf   PORTC, F
    dw 0x30ff ; 0193: movlw   0xff
    dw 0x0088 ; 0194: movwf   PORTD
    dw 0x160a ; 0195: bsf     PCLATH, 0x4
    dw 0x158a ; 0196: bsf     PCLATH, 0x3
    dw 0x26c6 ; 0197: call    function_072
    dw 0x120a ; 0198: bcf     PCLATH, 0x4
    dw 0x118a ; 0199: bcf     PCLATH, 0x3
    dw 0x01bb ; 019a: clrf    0x3b
    dw 0x1683 ; 019b: bsf     STATUS, RP0
    dw 0x168c ; 019c: bsf     PIR1, RCIF
    dw 0x1283 ; 019d: bcf     STATUS, RP0
    dw 0x1618 ; 019e: bsf     RCSTA, CREN
    dw 0x3003 ; 019f: movlw   0x03
    dw 0x0228 ; 01a0: subwf   0x28, W
    dw 0x1803 ; 01a1: btfsc   STATUS, C
    dw 0x29ad ; 01a2: goto    label_022
    dw 0x08b9 ; 01a3: movf    0x39, F
    dw 0x1903 ; 01a4: btfsc   STATUS, Z
    dw 0x29ad ; 01a5: goto    label_022
    dw 0x03b9 ; 01a6: decf    0x39, F
    dw 0x3001 ; 01a7: movlw   0x01
    dw 0x160a ; 01a8: bsf     PCLATH, 0x4
    dw 0x118a ; 01a9: bcf     PCLATH, 0x3
    dw 0x20f7 ; 01aa: call    function_026
    dw 0x120a ; 01ab: bcf     PCLATH, 0x4
    dw 0x118a ; 01ac: bcf     PCLATH, 0x3
    dw 0x0b3a ; 01ad: decfsz  0x3a, W
    dw 0x29b4 ; 01ae: goto    label_023
    dw 0x01ba ; 01af: clrf    0x3a
    dw 0x3002 ; 01b0: movlw   0x02
    dw 0x160a ; 01b1: bsf     PCLATH, 0x4
    dw 0x118a ; 01b2: bcf     PCLATH, 0x3
    dw 0x20f7 ; 01b3: call    function_026
    dw 0x0064 ; 01b4: clrwdt
    dw 0x160a ; 01b5: bsf     PCLATH, 0x4
    dw 0x118a ; 01b6: bcf     PCLATH, 0x3
    dw 0x2795 ; 01b7: call    function_041
    dw 0x160a ; 01b8: bsf     PCLATH, 0x4
    dw 0x118a ; 01b9: bcf     PCLATH, 0x3
    dw 0x26e8 ; 01ba: call    function_037
    dw 0x120a ; 01bb: bcf     PCLATH, 0x4
    dw 0x118a ; 01bc: bcf     PCLATH, 0x3
    dw 0x1703 ; 01bd: bsf     STATUS, RP1
    dw 0x08a1 ; 01be: movf    0x21, F
    dw 0x1d03 ; 01bf: btfss   STATUS, Z
    dw 0x29d2 ; 01c0: goto    label_025
    dw 0x120a ; 01c1: bcf     PCLATH, 0x4
    dw 0x118a ; 01c2: bcf     PCLATH, 0x3
    dw 0x221e ; 01c3: call    function_005
    dw 0x120a ; 01c4: bcf     PCLATH, 0x4
    dw 0x118a ; 01c5: bcf     PCLATH, 0x3
    dw 0x3800 ; 01c6: iorlw   0x00
    dw 0x1903 ; 01c7: btfsc   STATUS, Z
    dw 0x29cf ; 01c8: goto    label_024
    dw 0x120a ; 01c9: bcf     PCLATH, 0x4
    dw 0x118a ; 01ca: bcf     PCLATH, 0x3
    dw 0x2535 ; 01cb: call    function_009
    dw 0x120a ; 01cc: bcf     PCLATH, 0x4
    dw 0x158a ; 01cd: bsf     PCLATH, 0x3
    dw 0x20ce ; 01ce: call    function_020
    dw 0x1703 ; 01cf: bsf     STATUS, RP1
    dw 0x01a1 ; 01d0: clrf    0x21
    dw 0x0aa1 ; 01d1: incf    0x21, F
    dw 0x160a ; 01d2: bsf     PCLATH, 0x4
    dw 0x118a ; 01d3: bcf     PCLATH, 0x3
    dw 0x2393 ; 01d4: call    function_030
    dw 0x120a ; 01d5: bcf     PCLATH, 0x4
    dw 0x118a ; 01d6: bcf     PCLATH, 0x3
    dw 0x25e4 ; 01d7: call    function_010
    dw 0x3003 ; 01d8: movlw   0x03
    dw 0x160a ; 01d9: bsf     PCLATH, 0x4
    dw 0x158a ; 01da: bsf     PCLATH, 0x3
    dw 0x2741 ; 01db: call    function_078
    dw 0x3001 ; 01dc: movlw   0x01
    dw 0x160a ; 01dd: bsf     PCLATH, 0x4
    dw 0x158a ; 01de: bsf     PCLATH, 0x3
    dw 0x2741 ; 01df: call    function_078
    dw 0x3002 ; 01e0: movlw   0x02
    dw 0x160a ; 01e1: bsf     PCLATH, 0x4
    dw 0x158a ; 01e2: bsf     PCLATH, 0x3
    dw 0x2741 ; 01e3: call    function_078
    dw 0x120a ; 01e4: bcf     PCLATH, 0x4
    dw 0x118a ; 01e5: bcf     PCLATH, 0x3
    dw 0x299f ; 01e6: goto    label_021
    dw 0x1283 ; 01e7: bcf     STATUS, RP0
    dw 0x1303 ; 01e8: bcf     STATUS, RP1
    dw 0x00e6 ; 01e9: movwf   0x66
    dw 0x1be7 ; 01ea: btfsc   0x67, 0x7
    dw 0x29f5 ; 01eb: goto    label_026
    dw 0x1b67 ; 01ec: btfsc   0x67, 0x6
    dw 0x29fd ; 01ed: goto    label_027
    dw 0x0867 ; 01ee: movf    0x67, W
    dw 0x008a ; 01ef: movwf   PCLATH
    dw 0x0866 ; 01f0: movf    0x66, W
    dw 0x0ae6 ; 01f1: incf    0x66, F
    dw 0x1903 ; 01f2: btfsc   STATUS, Z
    dw 0x0ae7 ; 01f3: incf    0x67, F
    dw 0x0082 ; 01f4: movwf   PCL
    dw 0x1383 ; 01f5: bcf     STATUS, IRP
    dw 0x1867 ; 01f6: btfsc   0x67, 0x0
    dw 0x1783 ; 01f7: bsf     STATUS, IRP
    dw 0x0866 ; 01f8: movf    0x66, W
    dw 0x0ae6 ; 01f9: incf    0x66, F
    dw 0x0084 ; 01fa: movwf   FSR
    dw 0x0800 ; 01fb: movf    INDF, W
    dw 0x0008 ; 01fc: return
    dw 0x3064 ; 01fd: movlw   0x64
    dw 0x00f2 ; 01fe: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 01ff: clrf    (Common_RAM + 3)
    dw 0x1283 ; 0200: bcf     STATUS, RP0
    dw 0x1303 ; 0201: bcf     STATUS, RP1
    dw 0x0821 ; 0202: movf    0x21, W
    dw 0x00f1 ; 0203: movwf   (Common_RAM + 1)
    dw 0x0820 ; 0204: movf    0x20, W
    dw 0x00f0 ; 0205: movwf   Common_RAM
    dw 0x160a ; 0206: bsf     PCLATH, 0x4
    dw 0x158a ; 0207: bsf     PCLATH, 0x3
    dw 0x26ee ; 0208: call    function_076
    dw 0x0874 ; 0209: movf    (Common_RAM + 4), W
    dw 0x00f0 ; 020a: movwf   Common_RAM
    dw 0x0875 ; 020b: movf    (Common_RAM + 5), W
    dw 0x00f1 ; 020c: movwf   (Common_RAM + 1)
    dw 0x0823 ; 020d: movf    0x23, W
    dw 0x00f3 ; 020e: movwf   (Common_RAM + 3)
    dw 0x0822 ; 020f: movf    0x22, W
    dw 0x00f2 ; 0210: movwf   (Common_RAM + 2)
    dw 0x0820 ; 0211: movf    0x20, W
    dw 0x07f2 ; 0212: addwf   (Common_RAM + 2), F
    dw 0x1803 ; 0213: btfsc   STATUS, C
    dw 0x0af3 ; 0214: incf    (Common_RAM + 3), F
    dw 0x0821 ; 0215: movf    0x21, W
    dw 0x07f3 ; 0216: addwf   (Common_RAM + 3), F
    dw 0x120a ; 0217: bcf     PCLATH, 0x4
    dw 0x118a ; 0218: bcf     PCLATH, 0x3
    dw 0x27be ; 0219: call    function_017
    dw 0x120a ; 021a: bcf     PCLATH, 0x4
    dw 0x118a ; 021b: bcf     PCLATH, 0x3
    dw 0x0874 ; 021c: movf    (Common_RAM + 4), W
    dw 0x0008 ; 021d: return
    dw 0x160a ; 021e: bsf     PCLATH, 0x4
    dw 0x158a ; 021f: bsf     PCLATH, 0x3
    dw 0x26bd ; 0220: call    function_071
    dw 0x00be ; 0221: movwf   0x3e
    dw 0x160a ; 0222: bsf     PCLATH, 0x4
    dw 0x158a ; 0223: bsf     PCLATH, 0x3
    dw 0x2685 ; 0224: call    function_063
    dw 0x00bc ; 0225: movwf   0x3c
    dw 0x160a ; 0226: bsf     PCLATH, 0x4
    dw 0x158a ; 0227: bsf     PCLATH, 0x3
    dw 0x2673 ; 0228: call    function_060
    dw 0x120a ; 0229: bcf     PCLATH, 0x4
    dw 0x118a ; 022a: bcf     PCLATH, 0x3
    dw 0x00bf ; 022b: movwf   0x3f
    dw 0x08bf ; 022c: movf    0x3f, F
    dw 0x1903 ; 022d: btfsc   STATUS, Z
    dw 0x2af4 ; 022e: goto    label_043
    dw 0x1703 ; 022f: bsf     STATUS, RP1
    dw 0x0822 ; 0230: movf    0x22, W
    dw 0x3a02 ; 0231: xorlw   0x02
    dw 0x1903 ; 0232: btfsc   STATUS, Z
    dw 0x2a49 ; 0233: goto    label_031
    dw 0x0822 ; 0234: movf    0x22, W
    dw 0x3a04 ; 0235: xorlw   0x04
    dw 0x1903 ; 0236: btfsc   STATUS, Z
    dw 0x2a49 ; 0237: goto    label_031
    dw 0x0822 ; 0238: movf    0x22, W
    dw 0x3a06 ; 0239: xorlw   0x06
    dw 0x1d03 ; 023a: btfss   STATUS, Z
    dw 0x2af4 ; 023b: goto    label_043
    dw 0x2a49 ; 023c: goto    label_031
    dw 0x1703 ; 023d: bsf     STATUS, RP1
    dw 0x0822 ; 023e: movf    0x22, W
    dw 0x3a02 ; 023f: xorlw   0x02
    dw 0x2a67 ; 0240: goto    label_032
    dw 0x1703 ; 0241: bsf     STATUS, RP1
    dw 0x0822 ; 0242: movf    0x22, W
    dw 0x3a04 ; 0243: xorlw   0x04
    dw 0x2a67 ; 0244: goto    label_032
    dw 0x1703 ; 0245: bsf     STATUS, RP1
    dw 0x0822 ; 0246: movf    0x22, W
    dw 0x3a06 ; 0247: xorlw   0x06
    dw 0x2a67 ; 0248: goto    label_032
    dw 0x1303 ; 0249: bcf     STATUS, RP1
    dw 0x083f ; 024a: movf    0x3f, W
    dw 0x3a01 ; 024b: xorlw   0x01
    dw 0x1903 ; 024c: btfsc   STATUS, Z
    dw 0x2ae7 ; 024d: goto    label_042
    dw 0x3a03 ; 024e: xorlw   0x03
    dw 0x1903 ; 024f: btfsc   STATUS, Z
    dw 0x2a3d ; 0250: goto    label_028
    dw 0x3a01 ; 0251: xorlw   0x01
    dw 0x1903 ; 0252: btfsc   STATUS, Z
    dw 0x2a3d ; 0253: goto    label_028
    dw 0x3a07 ; 0254: xorlw   0x07
    dw 0x1903 ; 0255: btfsc   STATUS, Z
    dw 0x2a41 ; 0256: goto    label_029
    dw 0x3a01 ; 0257: xorlw   0x01
    dw 0x1903 ; 0258: btfsc   STATUS, Z
    dw 0x2a41 ; 0259: goto    label_029
    dw 0x3a03 ; 025a: xorlw   0x03
    dw 0x1903 ; 025b: btfsc   STATUS, Z
    dw 0x2a45 ; 025c: goto    label_030
    dw 0x3a01 ; 025d: xorlw   0x01
    dw 0x1903 ; 025e: btfsc   STATUS, Z
    dw 0x2a45 ; 025f: goto    label_030
    dw 0x3a0a ; 0260: xorlw   0x0a
    dw 0x1903 ; 0261: btfsc   STATUS, Z
    dw 0x2ae7 ; 0262: goto    label_042
    dw 0x3a03 ; 0263: xorlw   0x03
    dw 0x1903 ; 0264: btfsc   STATUS, Z
    dw 0x2ae7 ; 0265: goto    label_042
    dw 0x3a01 ; 0266: xorlw   0x01
    dw 0x1903 ; 0267: btfsc   STATUS, Z
    dw 0x2ae7 ; 0268: goto    label_042
    dw 0x2af4 ; 0269: goto    label_043
    dw 0x083e ; 026a: movf    0x3e, W
    dw 0x3a03 ; 026b: xorlw   0x03
    dw 0x1d03 ; 026c: btfss   STATUS, Z
    dw 0x2af4 ; 026d: goto    label_043
    dw 0x1683 ; 026e: bsf     STATUS, RP0
    dw 0x1703 ; 026f: bsf     STATUS, RP1
    dw 0x0813 ; 0270: movf    0x13, W
    dw 0x1283 ; 0271: bcf     STATUS, RP0
    dw 0x00ad ; 0272: movwf   0x2d
    dw 0x1683 ; 0273: bsf     STATUS, RP0
    dw 0x0814 ; 0274: movf    0x14, W
    dw 0x1283 ; 0275: bcf     STATUS, RP0
    dw 0x00ae ; 0276: movwf   0x2e
    dw 0x1683 ; 0277: bsf     STATUS, RP0
    dw 0x0815 ; 0278: movf    0x15, W
    dw 0x1283 ; 0279: bcf     STATUS, RP0
    dw 0x00af ; 027a: movwf   0x2f
    dw 0x1683 ; 027b: bsf     STATUS, RP0
    dw 0x0816 ; 027c: movf    0x16, W
    dw 0x1283 ; 027d: bcf     STATUS, RP0
    dw 0x00b0 ; 027e: movwf   0x30
    dw 0x2adb ; 027f: goto    label_040
    dw 0x083e ; 0280: movf    0x3e, W
    dw 0x3a03 ; 0281: xorlw   0x03
    dw 0x1d03 ; 0282: btfss   STATUS, Z
    dw 0x2af4 ; 0283: goto    label_043
    dw 0x3008 ; 0284: movlw   0x08
    dw 0x023f ; 0285: subwf   0x3f, W
    dw 0x1803 ; 0286: btfsc   STATUS, C
    dw 0x2af4 ; 0287: goto    label_043
    dw 0x1683 ; 0288: bsf     STATUS, RP0
    dw 0x1703 ; 0289: bsf     STATUS, RP1
    dw 0x0812 ; 028a: movf    0x12, W
    dw 0x1283 ; 028b: bcf     STATUS, RP0
    dw 0x1303 ; 028c: bcf     STATUS, RP1
    dw 0x00bd ; 028d: movwf   0x3d
    dw 0x1683 ; 028e: bsf     STATUS, RP0
    dw 0x1703 ; 028f: bsf     STATUS, RP1
    dw 0x0813 ; 0290: movf    0x13, W
    dw 0x1283 ; 0291: bcf     STATUS, RP0
    dw 0x00b9 ; 0292: movwf   0x39
    dw 0x1683 ; 0293: bsf     STATUS, RP0
    dw 0x0814 ; 0294: movf    0x14, W
    dw 0x1283 ; 0295: bcf     STATUS, RP0
    dw 0x00ba ; 0296: movwf   0x3a
    dw 0x1683 ; 0297: bsf     STATUS, RP0
    dw 0x0815 ; 0298: movf    0x15, W
    dw 0x1283 ; 0299: bcf     STATUS, RP0
    dw 0x00bb ; 029a: movwf   0x3b
    dw 0x1683 ; 029b: bsf     STATUS, RP0
    dw 0x0816 ; 029c: movf    0x16, W
    dw 0x1283 ; 029d: bcf     STATUS, RP0
    dw 0x00bc ; 029e: movwf   0x3c
    dw 0x2adb ; 029f: goto    label_040
    dw 0x08be ; 02a0: movf    0x3e, F
    dw 0x1d03 ; 02a1: btfss   STATUS, Z
    dw 0x2af4 ; 02a2: goto    label_043
    dw 0x3008 ; 02a3: movlw   0x08
    dw 0x023f ; 02a4: subwf   0x3f, W
    dw 0x1803 ; 02a5: btfsc   STATUS, C
    dw 0x2af4 ; 02a6: goto    label_043
    dw 0x1683 ; 02a7: bsf     STATUS, RP0
    dw 0x1703 ; 02a8: bsf     STATUS, RP1
    dw 0x0813 ; 02a9: movf    0x13, W
    dw 0x1283 ; 02aa: bcf     STATUS, RP0
    dw 0x00a8 ; 02ab: movwf   0x28
    dw 0x2adb ; 02ac: goto    label_040
    dw 0x0b3f ; 02ad: decfsz  0x3f, W
    dw 0x2af4 ; 02ae: goto    label_043
    dw 0x2add ; 02af: goto    label_041
    dw 0x1683 ; 02b0: bsf     STATUS, RP0
    dw 0x1703 ; 02b1: bsf     STATUS, RP1
    dw 0x0813 ; 02b2: movf    0x13, W
    dw 0x1283 ; 02b3: bcf     STATUS, RP0
    dw 0x00ab ; 02b4: movwf   0x2b
    dw 0x1683 ; 02b5: bsf     STATUS, RP0
    dw 0x0814 ; 02b6: movf    0x14, W
    dw 0x1283 ; 02b7: bcf     STATUS, RP0
    dw 0x00ac ; 02b8: movwf   0x2c
    dw 0x2adb ; 02b9: goto    label_040
    dw 0x1683 ; 02ba: bsf     STATUS, RP0
    dw 0x0812 ; 02bb: movf    T2CON, W
    dw 0x1283 ; 02bc: bcf     STATUS, RP0
    dw 0x1303 ; 02bd: bcf     STATUS, RP1
    dw 0x00bd ; 02be: movwf   0x3d
    dw 0x1683 ; 02bf: bsf     STATUS, RP0
    dw 0x1703 ; 02c0: bsf     STATUS, RP1
    dw 0x0813 ; 02c1: movf    0x13, W
    dw 0x1283 ; 02c2: bcf     STATUS, RP0
    dw 0x00a9 ; 02c3: movwf   0x29
    dw 0x2adb ; 02c4: goto    label_040
    dw 0x1683 ; 02c5: bsf     STATUS, RP0
    dw 0x0812 ; 02c6: movf    T2CON, W
    dw 0x1283 ; 02c7: bcf     STATUS, RP0
    dw 0x1303 ; 02c8: bcf     STATUS, RP1
    dw 0x00bd ; 02c9: movwf   0x3d
    dw 0x1683 ; 02ca: bsf     STATUS, RP0
    dw 0x1703 ; 02cb: bsf     STATUS, RP1
    dw 0x0813 ; 02cc: movf    0x13, W
    dw 0x1283 ; 02cd: bcf     STATUS, RP0
    dw 0x00b5 ; 02ce: movwf   0x35
    dw 0x1683 ; 02cf: bsf     STATUS, RP0
    dw 0x0814 ; 02d0: movf    0x14, W
    dw 0x1283 ; 02d1: bcf     STATUS, RP0
    dw 0x00b6 ; 02d2: movwf   0x36
    dw 0x1683 ; 02d3: bsf     STATUS, RP0
    dw 0x0815 ; 02d4: movf    0x15, W
    dw 0x1283 ; 02d5: bcf     STATUS, RP0
    dw 0x00b7 ; 02d6: movwf   0x37
    dw 0x1683 ; 02d7: bsf     STATUS, RP0
    dw 0x0816 ; 02d8: movf    0x16, W
    dw 0x1283 ; 02d9: bcf     STATUS, RP0
    dw 0x00b8 ; 02da: movwf   0x38
    dw 0x3001 ; 02db: movlw   0x01
    dw 0x2af5 ; 02dc: goto    label_044
    dw 0x083e ; 02dd: movf    0x3e, W
    dw 0x1903 ; 02de: btfsc   STATUS, Z
    dw 0x2aba ; 02df: goto    label_038
    dw 0x3a01 ; 02e0: xorlw   0x01
    dw 0x1903 ; 02e1: btfsc   STATUS, Z
    dw 0x2ab0 ; 02e2: goto    label_037
    dw 0x3a02 ; 02e3: xorlw   0x02
    dw 0x1903 ; 02e4: btfsc   STATUS, Z
    dw 0x2ac5 ; 02e5: goto    label_039
    dw 0x2af4 ; 02e6: goto    label_043
    dw 0x1303 ; 02e7: bcf     STATUS, RP1
    dw 0x083c ; 02e8: movf    0x3c, W
    dw 0x1903 ; 02e9: btfsc   STATUS, Z
    dw 0x2a6a ; 02ea: goto    label_033
    dw 0x3a01 ; 02eb: xorlw   0x01
    dw 0x1903 ; 02ec: btfsc   STATUS, Z
    dw 0x2a80 ; 02ed: goto    label_034
    dw 0x3a03 ; 02ee: xorlw   0x03
    dw 0x1903 ; 02ef: btfsc   STATUS, Z
    dw 0x2aa0 ; 02f0: goto    label_035
    dw 0x3a01 ; 02f1: xorlw   0x01
    dw 0x1903 ; 02f2: btfsc   STATUS, Z
    dw 0x2aad ; 02f3: goto    label_036
    dw 0x3000 ; 02f4: movlw   0x00
    dw 0x1303 ; 02f5: bcf     STATUS, RP1
    dw 0x0008 ; 02f6: return
    dw 0x0183 ; 02f7: clrf    STATUS
    dw 0x1d12 ; 02f8: btfss   T2CON, TMR2ON
    dw 0x2b6f ; 02f9: goto    label_050
    dw 0x1683 ; 02fa: bsf     STATUS, RP0
    dw 0x0857 ; 02fb: movf    0x57, W
    dw 0x0456 ; 02fc: iorwf   0x56, W
    dw 0x1903 ; 02fd: btfsc   STATUS, Z
    dw 0x2b40 ; 02fe: goto    label_048
    dw 0x08d6 ; 02ff: movf    0x56, F
    dw 0x1903 ; 0300: btfsc   STATUS, Z
    dw 0x03d7 ; 0301: decf    0x57, F
    dw 0x03d6 ; 0302: decf    0x56, F
    dw 0x1283 ; 0303: bcf     STATUS, RP0
    dw 0x1703 ; 0304: bsf     STATUS, RP1
    dw 0x08c6 ; 0305: movf    0x46, F
    dw 0x1903 ; 0306: btfsc   STATUS, Z
    dw 0x2b0a ; 0307: goto    label_046
    dw 0x03c6 ; 0308: decf    0x46, F
    dw 0x2b79 ; 0309: goto    label_052
    dw 0x1683 ; 030a: bsf     STATUS, RP0
    dw 0x1303 ; 030b: bcf     STATUS, RP1
    dw 0x1687 ; 030c: bsf     TRISC, TRISC5
    dw 0x30f0 ; 030d: movlw   0xf0
    dw 0x1283 ; 030e: bcf     STATUS, RP0
    dw 0x0597 ; 030f: andwf   CCP1CON, F
    dw 0x1683 ; 0310: bsf     STATUS, RP0
    dw 0x1703 ; 0311: bsf     STATUS, RP1
    dw 0x11b2 ; 0312: bcf     0x32, 0x3
    dw 0x1eb2 ; 0313: btfss   0x32, 0x5
    dw 0x2b22 ; 0314: goto    label_047
    dw 0x12b2 ; 0315: bcf     0x32, 0x5
    dw 0x0843 ; 0316: movf    0x43, W
    dw 0x1283 ; 0317: bcf     STATUS, RP0
    dw 0x1303 ; 0318: bcf     STATUS, RP1
    dw 0x00d6 ; 0319: movwf   0x56
    dw 0x1683 ; 031a: bsf     STATUS, RP0
    dw 0x1703 ; 031b: bsf     STATUS, RP1
    dw 0x0842 ; 031c: movf    0x42, W
    dw 0x160a ; 031d: bsf     PCLATH, 0x4
    dw 0x118a ; 031e: bcf     PCLATH, 0x3
    dw 0x21e7 ; 031f: call    function_028
    dw 0x120a ; 0320: bcf     PCLATH, 0x4
    dw 0x118a ; 0321: bcf     PCLATH, 0x3
    dw 0x1683 ; 0322: bsf     STATUS, RP0
    dw 0x1703 ; 0323: bsf     STATUS, RP1
    dw 0x1e32 ; 0324: btfss   0x32, 0x4
    dw 0x2b79 ; 0325: goto    label_052
    dw 0x1232 ; 0326: bcf     0x32, 0x4
    dw 0x3018 ; 0327: movlw   0x18
    dw 0x008a ; 0328: movwf   PCLATH
    dw 0x1303 ; 0329: bcf     STATUS, RP1
    dw 0x0852 ; 032a: movf    0x52, W
    dw 0x0752 ; 032b: addwf   0x52, W
    dw 0x00f0 ; 032c: movwf   Common_RAM
    dw 0x2000 ; 032d: call    vector_reset
    dw 0x00d6 ; 032e: movwf   0x56
    dw 0x0a70 ; 032f: incf    Common_RAM, W
    dw 0x2000 ; 0330: call    vector_reset
    dw 0x00d7 ; 0331: movwf   0x57
    dw 0x120a ; 0332: bcf     PCLATH, 0x4
    dw 0x118a ; 0333: bcf     PCLATH, 0x3
    dw 0x3003 ; 0334: movlw   0x03
    dw 0x0257 ; 0335: subwf   0x57, W
    dw 0x30e9 ; 0336: movlw   0xe9
    dw 0x1903 ; 0337: btfsc   STATUS, Z
    dw 0x0256 ; 0338: subwf   0x56, W
    dw 0x1803 ; 0339: btfsc   STATUS, C
    dw 0x2b77 ; 033a: goto    label_051
    dw 0x30ea ; 033b: movlw   0xea
    dw 0x07d6 ; 033c: addwf   0x56, F
    dw 0x1c03 ; 033d: btfss   STATUS, C
    dw 0x03d7 ; 033e: decf    0x57, F
    dw 0x2b79 ; 033f: goto    label_052
    dw 0x3018 ; 0340: movlw   0x18
    dw 0x008a ; 0341: movwf   PCLATH
    dw 0x0852 ; 0342: movf    0x52, W
    dw 0x0752 ; 0343: addwf   0x52, W
    dw 0x00f0 ; 0344: movwf   Common_RAM
    dw 0x2000 ; 0345: call    vector_reset
    dw 0x00d6 ; 0346: movwf   0x56
    dw 0x0a70 ; 0347: incf    Common_RAM, W
    dw 0x2000 ; 0348: call    vector_reset
    dw 0x00d7 ; 0349: movwf   0x57
    dw 0x120a ; 034a: bcf     PCLATH, 0x4
    dw 0x118a ; 034b: bcf     PCLATH, 0x3
    dw 0x3016 ; 034c: movlw   0x16
    dw 0x1283 ; 034d: bcf     STATUS, RP0
    dw 0x1703 ; 034e: bsf     STATUS, RP1
    dw 0x00c6 ; 034f: movwf   0x46
    dw 0x1683 ; 0350: bsf     STATUS, RP0
    dw 0x1303 ; 0351: bcf     STATUS, RP1
    dw 0x0857 ; 0352: movf    0x57, W
    dw 0x0456 ; 0353: iorwf   0x56, W
    dw 0x1903 ; 0354: btfsc   STATUS, Z
    dw 0x2b66 ; 0355: goto    label_049
    dw 0x1287 ; 0356: bcf     PORTC, RC5
    dw 0x300c ; 0357: movlw   0x0c
    dw 0x1283 ; 0358: bcf     STATUS, RP0
    dw 0x0497 ; 0359: iorwf   CCP1CON, F
    dw 0x1683 ; 035a: bsf     STATUS, RP0
    dw 0x1703 ; 035b: bsf     STATUS, RP1
    dw 0x15b2 ; 035c: bsf     0x32, 0x3
    dw 0x3003 ; 035d: movlw   0x03
    dw 0x1303 ; 035e: bcf     STATUS, RP1
    dw 0x0257 ; 035f: subwf   0x57, W
    dw 0x30e9 ; 0360: movlw   0xe9
    dw 0x1903 ; 0361: btfsc   STATUS, Z
    dw 0x0256 ; 0362: subwf   0x56, W
    dw 0x1c03 ; 0363: btfss   STATUS, C
    dw 0x2b79 ; 0364: goto    label_052
    dw 0x2b77 ; 0365: goto    label_051
    dw 0x1687 ; 0366: bsf     PORTC, RC5
    dw 0x30f0 ; 0367: movlw   0xf0
    dw 0x1283 ; 0368: bcf     STATUS, RP0
    dw 0x0597 ; 0369: andwf   CCP1CON, F
    dw 0x1112 ; 036a: bcf     T2CON, TMR2ON
    dw 0x1683 ; 036b: bsf     STATUS, RP0
    dw 0x1703 ; 036c: bsf     STATUS, RP1
    dw 0x01b2 ; 036d: clrf    0x32
    dw 0x2b79 ; 036e: goto    label_052
    dw 0x1683 ; 036f: bsf     STATUS, RP0
    dw 0x1a87 ; 0370: btfsc   PORTC, RC5
    dw 0x2b79 ; 0371: goto    label_052
    dw 0x1687 ; 0372: bsf     PORTC, RC5
    dw 0x30f0 ; 0373: movlw   0xf0
    dw 0x1283 ; 0374: bcf     STATUS, RP0
    dw 0x0597 ; 0375: andwf   CCP1CON, F
    dw 0x1683 ; 0376: bsf     STATUS, RP0
    dw 0x01d6 ; 0377: clrf    0x56
    dw 0x01d7 ; 0378: clrf    0x57
    dw 0x1683 ; 0379: bsf     STATUS, RP0
    dw 0x1703 ; 037a: bsf     STATUS, RP1
    dw 0x08c4 ; 037b: movf    0x44, F
    dw 0x1903 ; 037c: btfsc   STATUS, Z
    dw 0x2bf8 ; 037d: goto    label_061
    dw 0x01c4 ; 037e: clrf    0x44
    dw 0x1303 ; 037f: bcf     STATUS, RP1
    dw 0x084f ; 0380: movf    0x4f, W
    dw 0x3a32 ; 0381: xorlw   0x32
    dw 0x1d03 ; 0382: btfss   STATUS, Z
    dw 0x2bd0 ; 0383: goto    label_058
    dw 0x3032 ; 0384: movlw   0x32
    dw 0x00f2 ; 0385: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 0386: clrf    (Common_RAM + 3)
    dw 0x0855 ; 0387: movf    0x55, W
    dw 0x00f1 ; 0388: movwf   (Common_RAM + 1)
    dw 0x0854 ; 0389: movf    0x54, W
    dw 0x00f0 ; 038a: movwf   Common_RAM
    dw 0x120a ; 038b: bcf     PCLATH, 0x4
    dw 0x118a ; 038c: bcf     PCLATH, 0x3
    dw 0x27be ; 038d: call    function_017
    dw 0x120a ; 038e: bcf     PCLATH, 0x4
    dw 0x118a ; 038f: bcf     PCLATH, 0x3
    dw 0x0874 ; 0390: movf    (Common_RAM + 4), W
    dw 0x1283 ; 0391: bcf     STATUS, RP0
    dw 0x1703 ; 0392: bsf     STATUS, RP1
    dw 0x00c7 ; 0393: movwf   0x47
    dw 0x0875 ; 0394: movf    0x75, W
    dw 0x00c8 ; 0395: movwf   0x48
    dw 0x084a ; 0396: movf    0x4a, W
    dw 0x00f1 ; 0397: movwf   0x71
    dw 0x0849 ; 0398: movf    0x49, W
    dw 0x00f0 ; 0399: movwf   0x70
    dw 0x3005 ; 039a: movlw   0x05
    dw 0x07f0 ; 039b: addwf   0x70, F
    dw 0x1803 ; 039c: btfsc   STATUS, C
    dw 0x0af1 ; 039d: incf    0x71, F
    dw 0x0848 ; 039e: movf    0x48, W
    dw 0x0271 ; 039f: subwf   0x71, W
    dw 0x1d03 ; 03a0: btfss   STATUS, Z
    dw 0x2ba4 ; 03a1: goto    label_053
    dw 0x0847 ; 03a2: movf    0x47, W
    dw 0x0270 ; 03a3: subwf   Common_RAM, W
    dw 0x1803 ; 03a4: btfsc   STATUS, C
    dw 0x2bac ; 03a5: goto    label_054
    dw 0x1683 ; 03a6: bsf     STATUS, RP0
    dw 0x1303 ; 03a7: bcf     STATUS, RP1
    dw 0x084e ; 03a8: movf    0x4e, W
    dw 0x39f3 ; 03a9: andlw   0xf3
    dw 0x3804 ; 03aa: iorlw   0x04
    dw 0x2bc3 ; 03ab: goto    label_056
    dw 0x084a ; 03ac: movf    0x4a, W
    dw 0x00f1 ; 03ad: movwf   (Common_RAM + 1)
    dw 0x0849 ; 03ae: movf    0x49, W
    dw 0x00f0 ; 03af: movwf   Common_RAM
    dw 0x30fb ; 03b0: movlw   0xfb
    dw 0x07f0 ; 03b1: addwf   Common_RAM, F
    dw 0x1803 ; 03b2: btfsc   STATUS, C
    dw 0x0af1 ; 03b3: incf    (Common_RAM + 1), F
    dw 0x30ff ; 03b4: movlw   0xff
    dw 0x07f1 ; 03b5: addwf   (Common_RAM + 1), F
    dw 0x0871 ; 03b6: movf    (Common_RAM + 1), W
    dw 0x0248 ; 03b7: subwf   0x48, W
    dw 0x1d03 ; 03b8: btfss   STATUS, Z
    dw 0x2bbc ; 03b9: goto    label_055
    dw 0x0870 ; 03ba: movf    Common_RAM, W
    dw 0x0247 ; 03bb: subwf   0x47, W
    dw 0x1683 ; 03bc: bsf     STATUS, RP0
    dw 0x1303 ; 03bd: bcf     STATUS, RP1
    dw 0x1803 ; 03be: btfsc   STATUS, C
    dw 0x2bcc ; 03bf: goto    label_057
    dw 0x084e ; 03c0: movf    0x4e, W
    dw 0x39f3 ; 03c1: andlw   0xf3
    dw 0x3808 ; 03c2: iorlw   0x08
    dw 0x00ce ; 03c3: movwf   0x4e
    dw 0x1283 ; 03c4: bcf     STATUS, RP0
    dw 0x1703 ; 03c5: bsf     STATUS, RP1
    dw 0x0847 ; 03c6: movf    0x47, W
    dw 0x00c9 ; 03c7: movwf   0x49
    dw 0x0848 ; 03c8: movf    0x48, W
    dw 0x00ca ; 03c9: movwf   0x4a
    dw 0x1683 ; 03ca: bsf     STATUS, RP0
    dw 0x1303 ; 03cb: bcf     STATUS, RP1
    dw 0x01cf ; 03cc: clrf    0x4f
    dw 0x01d4 ; 03cd: clrf    0x54
    dw 0x01d5 ; 03ce: clrf    0x55
    dw 0x2bde ; 03cf: goto    label_059
    dw 0x3004 ; 03d0: movlw   0x04
    dw 0x160a ; 03d1: bsf     PCLATH, 0x4
    dw 0x118a ; 03d2: bcf     PCLATH, 0x3
    dw 0x2000 ; 03d3: call    function_021
    dw 0x120a ; 03d4: bcf     PCLATH, 0x4
    dw 0x118a ; 03d5: bcf     PCLATH, 0x3
    dw 0x0870 ; 03d6: movf    Common_RAM, W
    dw 0x1683 ; 03d7: bsf     STATUS, RP0
    dw 0x07d4 ; 03d8: addwf   0x54, F
    dw 0x1803 ; 03d9: btfsc   STATUS, C
    dw 0x0ad5 ; 03da: incf    0x55, F
    dw 0x0871 ; 03db: movf    (Common_RAM + 1), W
    dw 0x07d5 ; 03dc: addwf   0x55, F
    dw 0x0acf ; 03dd: incf    0x4f, F
    dw 0x30ff ; 03de: movlw   0xff
    dw 0x07dd ; 03df: addwf   0x5d, F
    dw 0x1c03 ; 03e0: btfss   STATUS, C
    dw 0x03de ; 03e1: decf    0x5e, F
    dw 0x085e ; 03e2: movf    0x5e, W
    dw 0x045d ; 03e3: iorwf   0x5d, W
    dw 0x1d03 ; 03e4: btfss   STATUS, Z
    dw 0x2bfa ; 03e5: goto    label_062
    dw 0x3032 ; 03e6: movlw   0x32
    dw 0x00dd ; 03e7: movwf   0x5d
    dw 0x01de ; 03e8: clrf    0x5e
    dw 0x08d3 ; 03e9: movf    0x53, F
    dw 0x1903 ; 03ea: btfsc   STATUS, Z
    dw 0x2bfa ; 03eb: goto    label_062
    dw 0x03d3 ; 03ec: decf    0x53, F
    dw 0x0853 ; 03ed: movf    0x53, W
    dw 0x3a27 ; 03ee: xorlw   0x27
    dw 0x1d03 ; 03ef: btfss   STATUS, Z
    dw 0x2bf3 ; 03f0: goto    label_060
    dw 0x1458 ; 03f1: bsf     0x58, 0x0
    dw 0x2bfa ; 03f2: goto    label_062
    dw 0x08d3 ; 03f3: movf    0x53, F
    dw 0x1d03 ; 03f4: btfss   STATUS, Z
    dw 0x2bfa ; 03f5: goto    label_062
    dw 0x14d8 ; 03f6: bsf     0x58, 0x1
    dw 0x2bfa ; 03f7: goto    label_062
    dw 0x01c4 ; 03f8: clrf    0x44
    dw 0x0ac4 ; 03f9: incf    0x44, F
    dw 0x0183 ; 03fa: clrf    STATUS
    dw 0x0008 ; 03fb: return
    dw 0x30fa ; 03fc: movlw   0xfa
    dw 0x1683 ; 03fd: bsf     STATUS, RP0
    dw 0x1703 ; 03fe: bsf     STATUS, RP1
    dw 0x0091 ; 03ff: movwf   0x11
    dw 0x2c02 ; 0400: goto    label_064
    dw 0x0391 ; 0401: decf    TMR2, F
    dw 0x0891 ; 0402: movf    TMR2, F
    dw 0x1d03 ; 0403: btfss   STATUS, Z
    dw 0x2c01 ; 0404: goto    label_063
    dw 0x1283 ; 0405: bcf     STATUS, RP0
    dw 0x1303 ; 0406: bcf     STATUS, RP1
    dw 0x1606 ; 0407: bsf     PORTB, RB4
    dw 0x30fa ; 0408: movlw   0xfa
    dw 0x1683 ; 0409: bsf     STATUS, RP0
    dw 0x1703 ; 040a: bsf     STATUS, RP1
    dw 0x0091 ; 040b: movwf   0x11
    dw 0x0891 ; 040c: movf    TMR2, F
    dw 0x1903 ; 040d: btfsc   STATUS, Z
    dw 0x2c11 ; 040e: goto    label_066
    dw 0x0391 ; 040f: decf    TMR2, F
    dw 0x2c0c ; 0410: goto    label_065
    dw 0x1283 ; 0411: bcf     STATUS, RP0
    dw 0x1303 ; 0412: bcf     STATUS, RP1
    dw 0x1206 ; 0413: bcf     PORTB, RB4
    dw 0x30fa ; 0414: movlw   0xfa
    dw 0x1683 ; 0415: bsf     STATUS, RP0
    dw 0x1703 ; 0416: bsf     STATUS, RP1
    dw 0x0091 ; 0417: movwf   0x11
    dw 0x0891 ; 0418: movf    TMR2, F
    dw 0x1903 ; 0419: btfsc   STATUS, Z
    dw 0x2c1d ; 041a: goto    label_068
    dw 0x0391 ; 041b: decf    TMR2, F
    dw 0x2c18 ; 041c: goto    label_067
    dw 0x1283 ; 041d: bcf     STATUS, RP0
    dw 0x1303 ; 041e: bcf     STATUS, RP1
    dw 0x1606 ; 041f: bsf     PORTB, RB4
    dw 0x0008 ; 0420: return
    dw 0x0183 ; 0421: clrf    STATUS
    dw 0x00c2 ; 0422: movwf   0x42
    dw 0x01c3 ; 0423: clrf    0x43
    dw 0x01c4 ; 0424: clrf    0x44
    dw 0x0ac4 ; 0425: incf    0x44, F
    dw 0x0842 ; 0426: movf    0x42, W
    dw 0x0084 ; 0427: movwf   FSR
    dw 0x0800 ; 0428: movf    INDF, W
    dw 0x0544 ; 0429: andwf   0x44, W
    dw 0x1903 ; 042a: btfsc   STATUS, Z
    dw 0x2c31 ; 042b: goto    label_070
    dw 0x08c3 ; 042c: movf    0x43, F
    dw 0x3000 ; 042d: movlw   0x00
    dw 0x1903 ; 042e: btfsc   STATUS, Z
    dw 0x3001 ; 042f: movlw   0x01
    dw 0x00c3 ; 0430: movwf   0x43
    dw 0x1003 ; 0431: bcf     STATUS, C
    dw 0x0dc4 ; 0432: rlf     0x44, F
    dw 0x08c4 ; 0433: movf    0x44, F
    dw 0x1d03 ; 0434: btfss   STATUS, Z
    dw 0x2c26 ; 0435: goto    label_069
    dw 0x0843 ; 0436: movf    0x43, W
    dw 0x0008 ; 0437: return
    dw 0x138b ; 0438: bcf     INTCON, GIE
    dw 0x1283 ; 0439: bcf     STATUS, RP0
    dw 0x1303 ; 043a: bcf     STATUS, RP1
    dw 0x08bb ; 043b: movf    0x3b, F
    dw 0x1903 ; 043c: btfsc   STATUS, Z
    dw 0x2cc7 ; 043d: goto    label_076
    dw 0x1703 ; 043e: bsf     STATUS, RP1
    dw 0x0844 ; 043f: movf    0x44, W
    dw 0x3e92 ; 0440: addlw   0x92
    dw 0x0084 ; 0441: movwf   FSR
    dw 0x1783 ; 0442: bsf     STATUS, IRP
    dw 0x1683 ; 0443: bsf     STATUS, RP0
    dw 0x081c ; 0444: movf    0x1c, W
    dw 0x0080 ; 0445: movwf   INDF
    dw 0x081c ; 0446: movf    0x1c, W
    dw 0x1283 ; 0447: bcf     STATUS, RP0
    dw 0x1303 ; 0448: bcf     STATUS, RP1
    dw 0x00c0 ; 0449: movwf   0x40
    dw 0x1683 ; 044a: bsf     STATUS, RP0
    dw 0x1703 ; 044b: bsf     STATUS, RP1
    dw 0x081d ; 044c: movf    0x1d, W
    dw 0x1283 ; 044d: bcf     STATUS, RP0
    dw 0x1303 ; 044e: bcf     STATUS, RP1
    dw 0x00bf ; 044f: movwf   0x3f
    dw 0x3040 ; 0450: movlw   0x40
    dw 0x2421 ; 0451: call    function_007
    dw 0x063f ; 0452: xorwf   0x3f, W
    dw 0x1683 ; 0453: bsf     STATUS, RP0
    dw 0x1d03 ; 0454: btfss   STATUS, Z
    dw 0x16d8 ; 0455: bsf     0x58, 0x5
    dw 0x1703 ; 0456: bsf     STATUS, RP1
    dw 0x081e ; 0457: movf    0x1e, W
    dw 0x009c ; 0458: movwf   0x1c
    dw 0x081f ; 0459: movf    0x1f, W
    dw 0x009d ; 045a: movwf   0x1d
    dw 0x0820 ; 045b: movf    0x20, W
    dw 0x009e ; 045c: movwf   0x1e
    dw 0x0821 ; 045d: movf    0x21, W
    dw 0x009f ; 045e: movwf   0x1f
    dw 0x0822 ; 045f: movf    0x22, W
    dw 0x00a0 ; 0460: movwf   0x20
    dw 0x0823 ; 0461: movf    0x23, W
    dw 0x00a1 ; 0462: movwf   0x21
    dw 0x0824 ; 0463: movf    0x24, W
    dw 0x00a2 ; 0464: movwf   0x22
    dw 0x0825 ; 0465: movf    0x25, W
    dw 0x00a3 ; 0466: movwf   0x23
    dw 0x0826 ; 0467: movf    0x26, W
    dw 0x00a4 ; 0468: movwf   0x24
    dw 0x0827 ; 0469: movf    0x27, W
    dw 0x00a5 ; 046a: movwf   0x25
    dw 0x0828 ; 046b: movf    0x28, W
    dw 0x00a6 ; 046c: movwf   0x26
    dw 0x0829 ; 046d: movf    0x29, W
    dw 0x00a7 ; 046e: movwf   0x27
    dw 0x082a ; 046f: movf    0x2a, W
    dw 0x00a8 ; 0470: movwf   0x28
    dw 0x082b ; 0471: movf    0x2b, W
    dw 0x00a9 ; 0472: movwf   0x29
    dw 0x082c ; 0473: movf    0x2c, W
    dw 0x00aa ; 0474: movwf   0x2a
    dw 0x082d ; 0475: movf    0x2d, W
    dw 0x00ab ; 0476: movwf   0x2b
    dw 0x082e ; 0477: movf    0x2e, W
    dw 0x00ac ; 0478: movwf   0x2c
    dw 0x082f ; 0479: movf    0x2f, W
    dw 0x00ad ; 047a: movwf   0x2d
    dw 0x01ae ; 047b: clrf    0x2e
    dw 0x01af ; 047c: clrf    0x2f
    dw 0x1283 ; 047d: bcf     STATUS, RP0
    dw 0x1303 ; 047e: bcf     STATUS, RP1
    dw 0x03bb ; 047f: decf    0x3b, F
    dw 0x1703 ; 0480: bsf     STATUS, RP1
    dw 0x08c3 ; 0481: movf    0x43, F
    dw 0x1d03 ; 0482: btfss   STATUS, Z
    dw 0x2c92 ; 0483: goto    label_072
    dw 0x0844 ; 0484: movf    0x44, W
    dw 0x3e92 ; 0485: addlw   0x92
    dw 0x0084 ; 0486: movwf   FSR
    dw 0x1783 ; 0487: bsf     STATUS, IRP
    dw 0x0800 ; 0488: movf    INDF, W
    dw 0x00a7 ; 0489: movwf   0x27
    dw 0x0e27 ; 048a: swapf   0x27, W
    dw 0x00f0 ; 048b: movwf   Common_RAM
    dw 0x0cf0 ; 048c: rrf     Common_RAM, F
    dw 0x0c70 ; 048d: rrf     Common_RAM, W
    dw 0x3903 ; 048e: andlw   0x03
    dw 0x00f0 ; 048f: movwf   Common_RAM
    dw 0x0a70 ; 0490: incf    Common_RAM, W
    dw 0x00c3 ; 0491: movwf   0x43
    dw 0x0844 ; 0492: movf    0x44, W
    dw 0x0243 ; 0493: subwf   0x43, W
    dw 0x0844 ; 0494: movf    0x44, W
    dw 0x1c03 ; 0495: btfss   STATUS, C
    dw 0x2c9e ; 0496: goto    label_073
    dw 0x3e92 ; 0497: addlw   0x92
    dw 0x0084 ; 0498: movwf   FSR
    dw 0x1783 ; 0499: bsf     STATUS, IRP
    dw 0x0800 ; 049a: movf    INDF, W
    dw 0x07be ; 049b: addwf   0x3e, F
    dw 0x0ac4 ; 049c: incf    0x44, F
    dw 0x2cc8 ; 049d: goto    label_077
    dw 0x3e92 ; 049e: addlw   0x92
    dw 0x0084 ; 049f: movwf   FSR
    dw 0x1783 ; 04a0: bsf     STATUS, IRP
    dw 0x0800 ; 04a1: movf    INDF, W
    dw 0x063e ; 04a2: xorwf   0x3e, W
    dw 0x1903 ; 04a3: btfsc   STATUS, Z
    dw 0x2ca8 ; 04a4: goto    label_074
    dw 0x1683 ; 04a5: bsf     STATUS, RP0
    dw 0x1303 ; 04a6: bcf     STATUS, RP1
    dw 0x1558 ; 04a7: bsf     0x58, 0x2
    dw 0x1283 ; 04a8: bcf     STATUS, RP0
    dw 0x1703 ; 04a9: bsf     STATUS, RP1
    dw 0x01c4 ; 04aa: clrf    0x44
    dw 0x01be ; 04ab: clrf    0x3e
    dw 0x01c3 ; 04ac: clrf    0x43
    dw 0x1303 ; 04ad: bcf     STATUS, RP1
    dw 0x01bb ; 04ae: clrf    0x3b
    dw 0x01b9 ; 04af: clrf    0x39
    dw 0x1683 ; 04b0: bsf     STATUS, RP0
    dw 0x1d58 ; 04b1: btfss   0x58, 0x2
    dw 0x1a58 ; 04b2: btfsc   0x58, 0x4
    dw 0x2cbe ; 04b3: goto    label_075
    dw 0x1283 ; 04b4: bcf     STATUS, RP0
    dw 0x1898 ; 04b5: btfsc   RCSTA, OERR
    dw 0x2cbe ; 04b6: goto    label_075
    dw 0x1683 ; 04b7: bsf     STATUS, RP0
    dw 0x1ad8 ; 04b8: btfsc   0x58, 0x5
    dw 0x2cbe ; 04b9: goto    label_075
    dw 0x1283 ; 04ba: bcf     STATUS, RP0
    dw 0x1703 ; 04bb: bsf     STATUS, RP1
    dw 0x01a1 ; 04bc: clrf    0x21
    dw 0x2cc8 ; 04bd: goto    label_077
    dw 0x1683 ; 04be: bsf     STATUS, RP0
    dw 0x1158 ; 04bf: bcf     0x58, 0x2
    dw 0x12d8 ; 04c0: bcf     0x58, 0x5
    dw 0x1283 ; 04c1: bcf     STATUS, RP0
    dw 0x1c98 ; 04c2: btfss   RCSTA, OERR
    dw 0x2cc8 ; 04c3: goto    label_077
    dw 0x1218 ; 04c4: bcf     RCSTA, CREN
    dw 0x1618 ; 04c5: bsf     RCSTA, CREN
    dw 0x2cc8 ; 04c6: goto    label_077
    dw 0x0000 ; 04c7: nop
    dw 0x178b ; 04c8: bsf     INTCON, GIE
    dw 0x1303 ; 04c9: bcf     STATUS, RP1
    dw 0x0008 ; 04ca: return
    dw 0x0183 ; 04cb: clrf    STATUS
    dw 0x01bf ; 04cc: clrf    0x3f
    dw 0x01c0 ; 04cd: clrf    0x40
    dw 0x30c4 ; 04ce: movlw   0xc4
    dw 0x1683 ; 04cf: bsf     STATUS, RP0
    dw 0x00c3 ; 04d0: movwf   0x43
    dw 0x0844 ; 04d1: movf    0x44, W
    dw 0x1283 ; 04d2: bcf     STATUS, RP0
    dw 0x1703 ; 04d3: bsf     STATUS, RP1
    dw 0x00a7 ; 04d4: movwf   0x27
    dw 0x0e27 ; 04d5: swapf   0x27, W
    dw 0x00f0 ; 04d6: movwf   0x70
    dw 0x0cf0 ; 04d7: rrf     0x70, F
    dw 0x0c70 ; 04d8: rrf     0x70, W
    dw 0x3903 ; 04d9: andlw   0x03
    dw 0x3e03 ; 04da: addlw   0x03
    dw 0x1303 ; 04db: bcf     STATUS, RP1
    dw 0x00bf ; 04dc: movwf   0x3f
    dw 0x00c1 ; 04dd: movwf   0x41
    dw 0x08c1 ; 04de: movf    0x41, F
    dw 0x1903 ; 04df: btfsc   STATUS, Z
    dw 0x2d15 ; 04e0: goto    label_086
    dw 0x1e0c ; 04e1: btfss   PIR1, TXIF
    dw 0x2ce1 ; 04e2: goto    label_079
    dw 0x1683 ; 04e3: bsf     STATUS, RP0
    dw 0x174e ; 04e4: bsf     0x4e, 0x6
    dw 0x30ff ; 04e5: movlw   0xff
    dw 0x1703 ; 04e6: bsf     STATUS, RP1
    dw 0x0091 ; 04e7: movwf   0x11
    dw 0x1303 ; 04e8: bcf     STATUS, RP1
    dw 0x0843 ; 04e9: movf    0x43, W
    dw 0x2421 ; 04ea: call    function_007
    dw 0x00f0 ; 04eb: movwf   Common_RAM
    dw 0x0c70 ; 04ec: rrf     Common_RAM, W
    dw 0x1683 ; 04ed: bsf     STATUS, RP0
    dw 0x1c03 ; 04ee: btfss   STATUS, C
    dw 0x2cf2 ; 04ef: goto    label_080
    dw 0x1418 ; 04f0: bsf     RCSTA, RX9D
    dw 0x2cf3 ; 04f1: goto    label_081
    dw 0x1018 ; 04f2: bcf     RCSTA, RX9D
    dw 0x0843 ; 04f3: movf    0x43, W
    dw 0x0084 ; 04f4: movwf   FSR
    dw 0x1383 ; 04f5: bcf     STATUS, IRP
    dw 0x0800 ; 04f6: movf    INDF, W
    dw 0x1283 ; 04f7: bcf     STATUS, RP0
    dw 0x0099 ; 04f8: movwf   TXREG
    dw 0x1683 ; 04f9: bsf     STATUS, RP0
    dw 0x1898 ; 04fa: btfsc   RCSTA, OERR
    dw 0x2cff ; 04fb: goto    label_084
    dw 0x2cf9 ; 04fc: goto    label_082
    dw 0x1703 ; 04fd: bsf     STATUS, RP1
    dw 0x0391 ; 04fe: decf    TMR2, F
    dw 0x1303 ; 04ff: bcf     STATUS, RP1
    dw 0x1f4e ; 0500: btfss   0x4e, 0x6
    dw 0x2d06 ; 0501: goto    label_085
    dw 0x1703 ; 0502: bsf     STATUS, RP1
    dw 0x0891 ; 0503: movf    TMR2, F
    dw 0x1d03 ; 0504: btfss   STATUS, Z
    dw 0x2cfd ; 0505: goto    label_083
    dw 0x1303 ; 0506: bcf     STATUS, RP1
    dw 0x0843 ; 0507: movf    0x43, W
    dw 0x0084 ; 0508: movwf   FSR
    dw 0x0800 ; 0509: movf    INDF, W
    dw 0x1283 ; 050a: bcf     STATUS, RP0
    dw 0x1703 ; 050b: bsf     STATUS, RP1
    dw 0x063f ; 050c: xorwf   0x3f, W
    dw 0x1303 ; 050d: bcf     STATUS, RP1
    dw 0x1d03 ; 050e: btfss   STATUS, Z
    dw 0x0ac0 ; 050f: incf    0x40, F
    dw 0x1683 ; 0510: bsf     STATUS, RP0
    dw 0x0ac3 ; 0511: incf    0x43, F
    dw 0x1283 ; 0512: bcf     STATUS, RP0
    dw 0x0bc1 ; 0513: decfsz  0x41, F
    dw 0x2ce1 ; 0514: goto    label_079
    dw 0x08c0 ; 0515: movf    0x40, F
    dw 0x1903 ; 0516: btfsc   STATUS, Z
    dw 0x2d1d ; 0517: goto    label_087
    dw 0x23fc ; 0518: call    function_006
    dw 0x01ba ; 0519: clrf    0x3a
    dw 0x0aba ; 051a: incf    0x3a, F
    dw 0x1683 ; 051b: bsf     STATUS, RP0
    dw 0x120c ; 051c: bcf     PIR1, TXIF
    dw 0x1283 ; 051d: bcf     STATUS, RP0
    dw 0x1218 ; 051e: bcf     RCSTA, CREN
    dw 0x1618 ; 051f: bsf     RCSTA, CREN
    dw 0x0008 ; 0520: return
    dw 0x3000 ; 0521: movlw   0x00
    dw 0x160a ; 0522: bsf     PCLATH, 0x4
    dw 0x158a ; 0523: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0524: call    function_081
    dw 0x3000 ; 0525: movlw   0x00
    dw 0x160a ; 0526: bsf     PCLATH, 0x4
    dw 0x158a ; 0527: bsf     PCLATH, 0x3
    dw 0x27aa ; 0528: call    function_080
    dw 0x120a ; 0529: bcf     PCLATH, 0x4
    dw 0x118a ; 052a: bcf     PCLATH, 0x3
    dw 0x0836 ; 052b: movf    0x36, W
    dw 0x0086 ; 052c: movwf   PORTB
    dw 0x0837 ; 052d: movf    0x37, W
    dw 0x0087 ; 052e: movwf   PORTC
    dw 0x0838 ; 052f: movf    0x38, W
    dw 0x0088 ; 0530: movwf   PORTD
    dw 0x1683 ; 0531: bsf     STATUS, RP0
    dw 0x104e ; 0532: bcf     0x4e, 0x0
    dw 0x1283 ; 0533: bcf     STATUS, RP0
    dw 0x0008 ; 0534: return
    dw 0x160a ; 0535: bsf     PCLATH, 0x4
    dw 0x158a ; 0536: bsf     PCLATH, 0x3
    dw 0x2673 ; 0537: call    function_060
    dw 0x120a ; 0538: bcf     PCLATH, 0x4
    dw 0x118a ; 0539: bcf     PCLATH, 0x3
    dw 0x00bd ; 053a: movwf   0x3d
    dw 0x01be ; 053b: clrf    0x3e
    dw 0x0abe ; 053c: incf    0x3e, F
    dw 0x2d64 ; 053d: goto    label_097
    dw 0x1703 ; 053e: bsf     STATUS, RP1
    dw 0x0822 ; 053f: movf    0x22, W
    dw 0x3a04 ; 0540: xorlw   0x04
    dw 0x1903 ; 0541: btfsc   STATUS, Z
    dw 0x2d60 ; 0542: goto    label_095
    dw 0x0822 ; 0543: movf    0x22, W
    dw 0x3a06 ; 0544: xorlw   0x06
    dw 0x1d03 ; 0545: btfss   STATUS, Z
    dw 0x2d4d ; 0546: goto    label_090
    dw 0x2d60 ; 0547: goto    label_095
    dw 0x1703 ; 0548: bsf     STATUS, RP1
    dw 0x0822 ; 0549: movf    0x22, W
    dw 0x3a02 ; 054a: xorlw   0x02
    dw 0x3000 ; 054b: movlw   0x00
    dw 0x1d03 ; 054c: btfss   STATUS, Z
    dw 0x3001 ; 054d: movlw   0x01
    dw 0x2d61 ; 054e: goto    label_096
    dw 0x1703 ; 054f: bsf     STATUS, RP1
    dw 0x0822 ; 0550: movf    0x22, W
    dw 0x3a04 ; 0551: xorlw   0x04
    dw 0x2d58 ; 0552: goto    label_094
    dw 0x01be ; 0553: clrf    0x3e
    dw 0x2d77 ; 0554: goto    label_098
    dw 0x1703 ; 0555: bsf     STATUS, RP1
    dw 0x0822 ; 0556: movf    0x22, W
    dw 0x3a06 ; 0557: xorlw   0x06
    dw 0x1903 ; 0558: btfsc   STATUS, Z
    dw 0x2d60 ; 0559: goto    label_095
    dw 0x0822 ; 055a: movf    0x22, W
    dw 0x3a02 ; 055b: xorlw   0x02
    dw 0x1903 ; 055c: btfsc   STATUS, Z
    dw 0x2d60 ; 055d: goto    label_095
    dw 0x3001 ; 055e: movlw   0x01
    dw 0x2d61 ; 055f: goto    label_096
    dw 0x3000 ; 0560: movlw   0x00
    dw 0x1303 ; 0561: bcf     STATUS, RP1
    dw 0x00be ; 0562: movwf   0x3e
    dw 0x2d77 ; 0563: goto    label_098
    dw 0x083d ; 0564: movf    0x3d, W
    dw 0x3a02 ; 0565: xorlw   0x02
    dw 0x1903 ; 0566: btfsc   STATUS, Z
    dw 0x2d3e ; 0567: goto    label_088
    dw 0x3a01 ; 0568: xorlw   0x01
    dw 0x1903 ; 0569: btfsc   STATUS, Z
    dw 0x2d53 ; 056a: goto    label_092
    dw 0x3a07 ; 056b: xorlw   0x07
    dw 0x1903 ; 056c: btfsc   STATUS, Z
    dw 0x2d48 ; 056d: goto    label_089
    dw 0x3a01 ; 056e: xorlw   0x01
    dw 0x1903 ; 056f: btfsc   STATUS, Z
    dw 0x2d4f ; 0570: goto    label_091
    dw 0x3a03 ; 0571: xorlw   0x03
    dw 0x1903 ; 0572: btfsc   STATUS, Z
    dw 0x2d48 ; 0573: goto    label_089
    dw 0x3a01 ; 0574: xorlw   0x01
    dw 0x1903 ; 0575: btfsc   STATUS, Z
    dw 0x2d55 ; 0576: goto    label_093
    dw 0x08be ; 0577: movf    0x3e, F
    dw 0x1903 ; 0578: btfsc   STATUS, Z
    dw 0x2dac ; 0579: goto    label_108
    dw 0x1683 ; 057a: bsf     STATUS, RP0
    dw 0x1c58 ; 057b: btfss   0x58, 0x0
    dw 0x2dac ; 057c: goto    label_108
    dw 0x3000 ; 057d: movlw   0x00
    dw 0x160a ; 057e: bsf     PCLATH, 0x4
    dw 0x158a ; 057f: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0580: call    function_081
    dw 0x3000 ; 0581: movlw   0x00
    dw 0x160a ; 0582: bsf     PCLATH, 0x4
    dw 0x158a ; 0583: bsf     PCLATH, 0x3
    dw 0x27aa ; 0584: call    function_080
    dw 0x120a ; 0585: bcf     PCLATH, 0x4
    dw 0x118a ; 0586: bcf     PCLATH, 0x3
    dw 0x2dac ; 0587: goto    label_108
    dw 0x01be ; 0588: clrf    0x3e
    dw 0x2dc0 ; 0589: goto    label_109
    dw 0x1703 ; 058a: bsf     STATUS, RP1
    dw 0x0822 ; 058b: movf    0x22, W
    dw 0x3a02 ; 058c: xorlw   0x02
    dw 0x3000 ; 058d: movlw   0x00
    dw 0x1d03 ; 058e: btfss   STATUS, Z
    dw 0x3001 ; 058f: movlw   0x01
    dw 0x2da9 ; 0590: goto    label_107
    dw 0x1703 ; 0591: bsf     STATUS, RP1
    dw 0x0822 ; 0592: movf    0x22, W
    dw 0x3a04 ; 0593: xorlw   0x04
    dw 0x2da0 ; 0594: goto    label_104
    dw 0x1703 ; 0595: bsf     STATUS, RP1
    dw 0x0822 ; 0596: movf    0x22, W
    dw 0x3a04 ; 0597: xorlw   0x04
    dw 0x1903 ; 0598: btfsc   STATUS, Z
    dw 0x2da8 ; 0599: goto    label_106
    dw 0x0822 ; 059a: movf    0x22, W
    dw 0x3a02 ; 059b: xorlw   0x02
    dw 0x2da4 ; 059c: goto    label_105
    dw 0x1703 ; 059d: bsf     STATUS, RP1
    dw 0x0822 ; 059e: movf    0x22, W
    dw 0x3a02 ; 059f: xorlw   0x02
    dw 0x1903 ; 05a0: btfsc   STATUS, Z
    dw 0x2da8 ; 05a1: goto    label_106
    dw 0x0822 ; 05a2: movf    0x22, W
    dw 0x3a06 ; 05a3: xorlw   0x06
    dw 0x1903 ; 05a4: btfsc   STATUS, Z
    dw 0x2da8 ; 05a5: goto    label_106
    dw 0x3001 ; 05a6: movlw   0x01
    dw 0x2da9 ; 05a7: goto    label_107
    dw 0x3000 ; 05a8: movlw   0x00
    dw 0x1303 ; 05a9: bcf     STATUS, RP1
    dw 0x00be ; 05aa: movwf   0x3e
    dw 0x2dc0 ; 05ab: goto    label_109
    dw 0x1283 ; 05ac: bcf     STATUS, RP0
    dw 0x083d ; 05ad: movf    0x3d, W
    dw 0x3a02 ; 05ae: xorlw   0x02
    dw 0x1903 ; 05af: btfsc   STATUS, Z
    dw 0x2d88 ; 05b0: goto    label_099
    dw 0x3a01 ; 05b1: xorlw   0x01
    dw 0x1903 ; 05b2: btfsc   STATUS, Z
    dw 0x2d91 ; 05b3: goto    label_101
    dw 0x3a07 ; 05b4: xorlw   0x07
    dw 0x1903 ; 05b5: btfsc   STATUS, Z
    dw 0x2d95 ; 05b6: goto    label_102
    dw 0x3a01 ; 05b7: xorlw   0x01
    dw 0x1903 ; 05b8: btfsc   STATUS, Z
    dw 0x2d8a ; 05b9: goto    label_100
    dw 0x3a03 ; 05ba: xorlw   0x03
    dw 0x1903 ; 05bb: btfsc   STATUS, Z
    dw 0x2d9d ; 05bc: goto    label_103
    dw 0x3a01 ; 05bd: xorlw   0x01
    dw 0x1903 ; 05be: btfsc   STATUS, Z
    dw 0x2d95 ; 05bf: goto    label_102
    dw 0x08be ; 05c0: movf    0x3e, F
    dw 0x1903 ; 05c1: btfsc   STATUS, Z
    dw 0x2dce ; 05c2: goto    label_110
    dw 0x1683 ; 05c3: bsf     STATUS, RP0
    dw 0x1c58 ; 05c4: btfss   0x58, 0x0
    dw 0x2dce ; 05c5: goto    label_110
    dw 0x3000 ; 05c6: movlw   0x00
    dw 0x160a ; 05c7: bsf     PCLATH, 0x4
    dw 0x158a ; 05c8: bsf     PCLATH, 0x3
    dw 0x27d5 ; 05c9: call    function_081
    dw 0x3000 ; 05ca: movlw   0x00
    dw 0x160a ; 05cb: bsf     PCLATH, 0x4
    dw 0x158a ; 05cc: bsf     PCLATH, 0x3
    dw 0x27aa ; 05cd: call    function_080
    dw 0x160a ; 05ce: bsf     PCLATH, 0x4
    dw 0x158a ; 05cf: bsf     PCLATH, 0x3
    dw 0x2685 ; 05d0: call    function_063
    dw 0x120a ; 05d1: bcf     PCLATH, 0x4
    dw 0x118a ; 05d2: bcf     PCLATH, 0x3
    dw 0x3800 ; 05d3: iorlw   0x00
    dw 0x1683 ; 05d4: bsf     STATUS, RP0
    dw 0x1d03 ; 05d5: btfss   STATUS, Z
    dw 0x2dde ; 05d6: goto    label_112
    dw 0x1cd8 ; 05d7: btfss   0x58, 0x1
    dw 0x2ddd ; 05d8: goto    label_111
    dw 0x1703 ; 05d9: bsf     STATUS, RP1
    dw 0x083b ; 05da: movf    0x3b, W
    dw 0x1283 ; 05db: bcf     STATUS, RP0
    dw 0x00a0 ; 05dc: movwf   0x20
    dw 0x1683 ; 05dd: bsf     STATUS, RP0
    dw 0x1303 ; 05de: bcf     STATUS, RP1
    dw 0x1058 ; 05df: bcf     0x58, 0x0
    dw 0x10d8 ; 05e0: bcf     0x58, 0x1
    dw 0x160a ; 05e1: bsf     PCLATH, 0x4
    dw 0x158a ; 05e2: bsf     PCLATH, 0x3
    dw 0x2ec6 ; 05e3: goto    function_072
    dw 0x3007 ; 05e4: movlw   0x07
    dw 0x160a ; 05e5: bsf     PCLATH, 0x4
    dw 0x118a ; 05e6: bcf     PCLATH, 0x3
    dw 0x2000 ; 05e7: call    function_021
    dw 0x0870 ; 05e8: movf    Common_RAM, W
    dw 0x00bc ; 05e9: movwf   0x3c
    dw 0x3007 ; 05ea: movlw   0x07
    dw 0x160a ; 05eb: bsf     PCLATH, 0x4
    dw 0x118a ; 05ec: bcf     PCLATH, 0x3
    dw 0x2000 ; 05ed: call    function_021
    dw 0x120a ; 05ee: bcf     PCLATH, 0x4
    dw 0x118a ; 05ef: bcf     PCLATH, 0x3
    dw 0x1683 ; 05f0: bsf     STATUS, RP0
    dw 0x1703 ; 05f1: bsf     STATUS, RP1
    dw 0x083d ; 05f2: movf    0x3d, W
    dw 0x00f2 ; 05f3: movwf   0x72
    dw 0x01f3 ; 05f4: clrf    0x73
    dw 0x1003 ; 05f5: bcf     STATUS, C
    dw 0x0df2 ; 05f6: rlf     0x72, F
    dw 0x0df3 ; 05f7: rlf     0x73, F
    dw 0x0871 ; 05f8: movf    0x71, W
    dw 0x0273 ; 05f9: subwf   0x73, W
    dw 0x1d03 ; 05fa: btfss   STATUS, Z
    dw 0x2dfe ; 05fb: goto    label_113
    dw 0x0870 ; 05fc: movf    Common_RAM, W
    dw 0x0272 ; 05fd: subwf   (Common_RAM + 2), W
    dw 0x1803 ; 05fe: btfsc   STATUS, C
    dw 0x2e0a ; 05ff: goto    label_115
    dw 0x1283 ; 0600: bcf     STATUS, RP0
    dw 0x1303 ; 0601: bcf     STATUS, RP1
    dw 0x1e18 ; 0602: btfss   RCSTA, CREN
    dw 0x2e2e ; 0603: goto    label_117
    dw 0x1218 ; 0604: bcf     RCSTA, CREN
    dw 0x1683 ; 0605: bsf     STATUS, RP0
    dw 0x1458 ; 0606: bsf     0x58, 0x0
    dw 0x10d8 ; 0607: bcf     0x58, 0x1
    dw 0x01d3 ; 0608: clrf    0x53
    dw 0x2e2e ; 0609: goto    label_117
    dw 0x3007 ; 060a: movlw   0x07
    dw 0x160a ; 060b: bsf     PCLATH, 0x4
    dw 0x118a ; 060c: bcf     PCLATH, 0x3
    dw 0x2000 ; 060d: call    function_021
    dw 0x120a ; 060e: bcf     PCLATH, 0x4
    dw 0x118a ; 060f: bcf     PCLATH, 0x3
    dw 0x1683 ; 0610: bsf     STATUS, RP0
    dw 0x1703 ; 0611: bsf     STATUS, RP1
    dw 0x083d ; 0612: movf    0x3d, W
    dw 0x00f2 ; 0613: movwf   0x72
    dw 0x01f3 ; 0614: clrf    0x73
    dw 0x1003 ; 0615: bcf     STATUS, C
    dw 0x0df2 ; 0616: rlf     0x72, F
    dw 0x0df3 ; 0617: rlf     0x73, F
    dw 0x30ce ; 0618: movlw   0xce
    dw 0x07f2 ; 0619: addwf   0x72, F
    dw 0x1803 ; 061a: btfsc   STATUS, C
    dw 0x0af3 ; 061b: incf    0x73, F
    dw 0x30ff ; 061c: movlw   0xff
    dw 0x07f3 ; 061d: addwf   0x73, F
    dw 0x0873 ; 061e: movf    0x73, W
    dw 0x0271 ; 061f: subwf   0x71, W
    dw 0x1d03 ; 0620: btfss   STATUS, Z
    dw 0x2e24 ; 0621: goto    label_116
    dw 0x0872 ; 0622: movf    (Common_RAM + 2), W
    dw 0x0270 ; 0623: subwf   Common_RAM, W
    dw 0x1803 ; 0624: btfsc   STATUS, C
    dw 0x2e2e ; 0625: goto    label_117
    dw 0x1283 ; 0626: bcf     STATUS, RP0
    dw 0x1303 ; 0627: bcf     STATUS, RP1
    dw 0x1a18 ; 0628: btfsc   RCSTA, CREN
    dw 0x2e2e ; 0629: goto    label_117
    dw 0x1618 ; 062a: bsf     RCSTA, CREN
    dw 0x2535 ; 062b: call    function_009
    dw 0x120a ; 062c: bcf     PCLATH, 0x4
    dw 0x118a ; 062d: bcf     PCLATH, 0x3
    dw 0x1683 ; 062e: bsf     STATUS, RP0
    dw 0x1303 ; 062f: bcf     STATUS, RP1
    dw 0x1cd8 ; 0630: btfss   0x58, 0x1
    dw 0x2e36 ; 0631: goto    label_118
    dw 0x2521 ; 0632: call    function_008
    dw 0x120a ; 0633: bcf     PCLATH, 0x4
    dw 0x118a ; 0634: bcf     PCLATH, 0x3
    dw 0x2e55 ; 0635: goto    label_120
    dw 0x1c58 ; 0636: btfss   0x58, 0x0
    dw 0x2e55 ; 0637: goto    label_120
    dw 0x144e ; 0638: bsf     0x4e, 0x0
    dw 0x1283 ; 0639: bcf     STATUS, RP0
    dw 0x1703 ; 063a: bsf     STATUS, RP1
    dw 0x08a0 ; 063b: movf    0x20, F
    dw 0x1d03 ; 063c: btfss   STATUS, Z
    dw 0x2e42 ; 063d: goto    label_119
    dw 0x303c ; 063e: movlw   0x3c
    dw 0x120a ; 063f: bcf     PCLATH, 0x4
    dw 0x158a ; 0640: bsf     PCLATH, 0x3
    dw 0x2046 ; 0641: call    function_019
    dw 0x30c0 ; 0642: movlw   0xc0
    dw 0x160a ; 0643: bsf     PCLATH, 0x4
    dw 0x158a ; 0644: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0645: call    function_081
    dw 0x30c0 ; 0646: movlw   0xc0
    dw 0x160a ; 0647: bsf     PCLATH, 0x4
    dw 0x158a ; 0648: bsf     PCLATH, 0x3
    dw 0x27aa ; 0649: call    function_080
    dw 0x120a ; 064a: bcf     PCLATH, 0x4
    dw 0x118a ; 064b: bcf     PCLATH, 0x3
    dw 0x1683 ; 064c: bsf     STATUS, RP0
    dw 0x144e ; 064d: bsf     0x4e, 0x0
    dw 0x1283 ; 064e: bcf     STATUS, RP0
    dw 0x1112 ; 064f: bcf     T2CON, TMR2ON
    dw 0x1683 ; 0650: bsf     STATUS, RP0
    dw 0x01d6 ; 0651: clrf    0x56
    dw 0x01d7 ; 0652: clrf    0x57
    dw 0x1703 ; 0653: bsf     STATUS, RP1
    dw 0x01b2 ; 0654: clrf    0x32
    dw 0x0183 ; 0655: clrf    STATUS
    dw 0x0008 ; 0656: return
    dw 0x0183 ; 0657: clrf    STATUS
    dw 0x00dc ; 0658: movwf   0x5c
    dw 0x30c4 ; 0659: movlw   0xc4
    dw 0x00dd ; 065a: movwf   0x5d
    dw 0x3009 ; 065b: movlw   0x09
    dw 0x00de ; 065c: movwf   0x5e
    dw 0x2e6a ; 065d: goto    label_122
    dw 0x1283 ; 065e: bcf     STATUS, RP0
    dw 0x1303 ; 065f: bcf     STATUS, RP1
    dw 0x08dd ; 0660: movf    0x5d, F
    dw 0x1903 ; 0661: btfsc   STATUS, Z
    dw 0x03de ; 0662: decf    0x5e, F
    dw 0x03dd ; 0663: decf    0x5d, F
    dw 0x085e ; 0664: movf    0x5e, W
    dw 0x045d ; 0665: iorwf   0x5d, W
    dw 0x1d03 ; 0666: btfss   STATUS, Z
    dw 0x2e6a ; 0667: goto    label_122
    dw 0x30ff ; 0668: movlw   0xff
    dw 0x2e78 ; 0669: goto    label_123
    dw 0x1683 ; 066a: bsf     STATUS, RP0
    dw 0x1703 ; 066b: bsf     STATUS, RP1
    dw 0x188c ; 066c: btfsc   EECON1, WR
    dw 0x2e5e ; 066d: goto    label_121
    dw 0x1283 ; 066e: bcf     STATUS, RP0
    dw 0x1303 ; 066f: bcf     STATUS, RP1
    dw 0x085c ; 0670: movf    0x5c, W
    dw 0x1703 ; 0671: bsf     STATUS, RP1
    dw 0x008d ; 0672: movwf   EEADRL
    dw 0x1683 ; 0673: bsf     STATUS, RP0
    dw 0x138c ; 0674: bcf     EECON1, EEPGD
    dw 0x140c ; 0675: bsf     EECON1, RD
    dw 0x1283 ; 0676: bcf     STATUS, RP0
    dw 0x080c ; 0677: movf    EEDATA, W
    dw 0x1303 ; 0678: bcf     STATUS, RP1
    dw 0x0008 ; 0679: return
    dw 0x0183 ; 067a: clrf    STATUS
    dw 0x00da ; 067b: movwf   0x5a
    dw 0x3011 ; 067c: movlw   0x11
    dw 0x025a ; 067d: subwf   0x5a, W
    dw 0x085a ; 067e: movf    0x5a, W
    dw 0x1803 ; 067f: btfsc   STATUS, C
    dw 0x2e95 ; 0680: goto    label_124
    dw 0x2657 ; 0681: call    function_011
    dw 0x00d8 ; 0682: movwf   0x58
    dw 0x085a ; 0683: movf    0x5a, W
    dw 0x3e64 ; 0684: addlw   0x64
    dw 0x2657 ; 0685: call    function_011
    dw 0x00d9 ; 0686: movwf   0x59
    dw 0x085a ; 0687: movf    0x5a, W
    dw 0x3ec8 ; 0688: addlw   0xc8
    dw 0x2657 ; 0689: call    function_011
    dw 0x00d6 ; 068a: movwf   0x56
    dw 0x0858 ; 068b: movf    0x58, W
    dw 0x0659 ; 068c: xorwf   0x59, W
    dw 0x1d03 ; 068d: btfss   STATUS, Z
    dw 0x34ff ; 068e: retlw   0xff
    dw 0x0859 ; 068f: movf    0x59, W
    dw 0x0656 ; 0690: xorwf   0x56, W
    dw 0x1d03 ; 0691: btfss   STATUS, Z
    dw 0x34ff ; 0692: retlw   0xff
    dw 0x0858 ; 0693: movf    0x58, W
    dw 0x0008 ; 0694: return
    dw 0x2657 ; 0695: call    function_011
    dw 0x00d7 ; 0696: movwf   0x57
    dw 0x0008 ; 0697: return
    dw 0x0183 ; 0698: clrf    STATUS
    dw 0x00d9 ; 0699: movwf   0x59
    dw 0x2657 ; 069a: call    function_011
    dw 0x00db ; 069b: movwf   0x5b
    dw 0x0859 ; 069c: movf    0x59, W
    dw 0x3e64 ; 069d: addlw   0x64
    dw 0x2657 ; 069e: call    function_011
    dw 0x00da ; 069f: movwf   0x5a
    dw 0x065b ; 06a0: xorwf   0x5b, W
    dw 0x1d03 ; 06a1: btfss   STATUS, Z
    dw 0x2ea5 ; 06a2: goto    label_125
    dw 0x085b ; 06a3: movf    0x5b, W
    dw 0x0008 ; 06a4: return
    dw 0x0859 ; 06a5: movf    0x59, W
    dw 0x3ec8 ; 06a6: addlw   0xc8
    dw 0x2657 ; 06a7: call    function_011
    dw 0x00d8 ; 06a8: movwf   0x58
    dw 0x065b ; 06a9: xorwf   0x5b, W
    dw 0x1d03 ; 06aa: btfss   STATUS, Z
    dw 0x2eae ; 06ab: goto    label_126
    dw 0x085b ; 06ac: movf    0x5b, W
    dw 0x0008 ; 06ad: return
    dw 0x085a ; 06ae: movf    0x5a, W
    dw 0x0658 ; 06af: xorwf   0x58, W
    dw 0x1d03 ; 06b0: btfss   STATUS, Z
    dw 0x2eba ; 06b1: goto    label_129
    dw 0x085a ; 06b2: movf    0x5a, W
    dw 0x0008 ; 06b3: return
    dw 0x160a ; 06b4: bsf     PCLATH, 0x4
    dw 0x158a ; 06b5: bsf     PCLATH, 0x3
    dw 0x2604 ; 06b6: call    function_045
    dw 0x120a ; 06b7: bcf     PCLATH, 0x4
    dw 0x118a ; 06b8: bcf     PCLATH, 0x3
    dw 0x3400 ; 06b9: retlw   0x00
    dw 0x0859 ; 06ba: movf    0x59, W
    dw 0x00f0 ; 06bb: movwf   Common_RAM
    dw 0x3eef ; 06bc: addlw   0xef
    dw 0x1803 ; 06bd: btfsc   STATUS, C
    dw 0x3400 ; 06be: retlw   0x00
    dw 0x3e11 ; 06bf: addlw   0x11
    dw 0x3000 ; 06c0: movlw   0x00
    dw 0x1c03 ; 06c1: btfss   STATUS, C
    dw 0x0008 ; 06c2: return
    dw 0x3006 ; 06c3: movlw   0x06
    dw 0x008a ; 06c4: movwf   PCLATH
    dw 0x30ca ; 06c5: movlw   0xca
    dw 0x0770 ; 06c6: addwf   Common_RAM, W
    dw 0x1803 ; 06c7: btfsc   STATUS, C
    dw 0x0a8a ; 06c8: incf    PCLATH, F
    dw 0x0082 ; 06c9: movwf   PCL
    dw 0x3402 ; 06ca: retlw   0x02
    dw 0x3402 ; 06cb: retlw   0x02
    dw 0x3401 ; 06cc: retlw   0x01
    dw 0x3400 ; 06cd: retlw   0x00
    dw 0x343c ; 06ce: retlw   0x3c
    dw 0x2eb4 ; 06cf: goto    label_128
    dw 0x3408 ; 06d0: retlw   0x08
    dw 0x3409 ; 06d1: retlw   0x09
    dw 0x3403 ; 06d2: retlw   0x03
    dw 0x3406 ; 06d3: retlw   0x06
    dw 0x345d ; 06d4: retlw   0x5d
    dw 0x3470 ; 06d5: retlw   0x70
    dw 0x3400 ; 06d6: retlw   0x00
    dw 0x3400 ; 06d7: retlw   0x00
    dw 0x3464 ; 06d8: retlw   0x64
    dw 0x34c8 ; 06d9: retlw   0xc8
    dw 0x34ff ; 06da: retlw   0xff
    dw 0x3000 ; 06db: movlw   0x00
    dw 0x2698 ; 06dc: call    function_013
    dw 0x120a ; 06dd: bcf     PCLATH, 0x4
    dw 0x118a ; 06de: bcf     PCLATH, 0x3
    dw 0x00d7 ; 06df: movwf   0x57
    dw 0x3001 ; 06e0: movlw   0x01
    dw 0x2698 ; 06e1: call    function_013
    dw 0x120a ; 06e2: bcf     PCLATH, 0x4
    dw 0x118a ; 06e3: bcf     PCLATH, 0x3
    dw 0x07d7 ; 06e4: addwf   0x57, F
    dw 0x3002 ; 06e5: movlw   0x02
    dw 0x2698 ; 06e6: call    function_013
    dw 0x120a ; 06e7: bcf     PCLATH, 0x4
    dw 0x118a ; 06e8: bcf     PCLATH, 0x3
    dw 0x07d7 ; 06e9: addwf   0x57, F
    dw 0x3003 ; 06ea: movlw   0x03
    dw 0x2698 ; 06eb: call    function_013
    dw 0x120a ; 06ec: bcf     PCLATH, 0x4
    dw 0x118a ; 06ed: bcf     PCLATH, 0x3
    dw 0x07d7 ; 06ee: addwf   0x57, F
    dw 0x1683 ; 06ef: bsf     STATUS, RP0
    dw 0x1703 ; 06f0: bsf     STATUS, RP1
    dw 0x083b ; 06f1: movf    0x3b, W
    dw 0x1283 ; 06f2: bcf     STATUS, RP0
    dw 0x1303 ; 06f3: bcf     STATUS, RP1
    dw 0x07d7 ; 06f4: addwf   0x57, F
    dw 0x1703 ; 06f5: bsf     STATUS, RP1
    dw 0x0822 ; 06f6: movf    0x22, W
    dw 0x1303 ; 06f7: bcf     STATUS, RP1
    dw 0x07d7 ; 06f8: addwf   0x57, F
    dw 0x3006 ; 06f9: movlw   0x06
    dw 0x2698 ; 06fa: call    function_013
    dw 0x120a ; 06fb: bcf     PCLATH, 0x4
    dw 0x118a ; 06fc: bcf     PCLATH, 0x3
    dw 0x07d7 ; 06fd: addwf   0x57, F
    dw 0x3007 ; 06fe: movlw   0x07
    dw 0x2698 ; 06ff: call    function_013
    dw 0x120a ; 0700: bcf     PCLATH, 0x4
    dw 0x118a ; 0701: bcf     PCLATH, 0x3
    dw 0x07d7 ; 0702: addwf   0x57, F
    dw 0x1683 ; 0703: bsf     STATUS, RP0
    dw 0x1703 ; 0704: bsf     STATUS, RP1
    dw 0x083f ; 0705: movf    0x3f, W
    dw 0x1283 ; 0706: bcf     STATUS, RP0
    dw 0x1303 ; 0707: bcf     STATUS, RP1
    dw 0x07d7 ; 0708: addwf   0x57, F
    dw 0x1683 ; 0709: bsf     STATUS, RP0
    dw 0x1703 ; 070a: bsf     STATUS, RP1
    dw 0x0840 ; 070b: movf    0x40, W
    dw 0x1283 ; 070c: bcf     STATUS, RP0
    dw 0x1303 ; 070d: bcf     STATUS, RP1
    dw 0x07d7 ; 070e: addwf   0x57, F
    dw 0x1683 ; 070f: bsf     STATUS, RP0
    dw 0x1703 ; 0710: bsf     STATUS, RP1
    dw 0x0841 ; 0711: movf    0x41, W
    dw 0x1283 ; 0712: bcf     STATUS, RP0
    dw 0x1303 ; 0713: bcf     STATUS, RP1
    dw 0x07d7 ; 0714: addwf   0x57, F
    dw 0x1683 ; 0715: bsf     STATUS, RP0
    dw 0x1703 ; 0716: bsf     STATUS, RP1
    dw 0x083e ; 0717: movf    0x3e, W
    dw 0x1283 ; 0718: bcf     STATUS, RP0
    dw 0x1303 ; 0719: bcf     STATUS, RP1
    dw 0x07d7 ; 071a: addwf   0x57, F
    dw 0x1683 ; 071b: bsf     STATUS, RP0
    dw 0x1703 ; 071c: bsf     STATUS, RP1
    dw 0x0830 ; 071d: movf    0x30, W
    dw 0x1283 ; 071e: bcf     STATUS, RP0
    dw 0x1303 ; 071f: bcf     STATUS, RP1
    dw 0x07d7 ; 0720: addwf   0x57, F
    dw 0x1683 ; 0721: bsf     STATUS, RP0
    dw 0x1703 ; 0722: bsf     STATUS, RP1
    dw 0x0831 ; 0723: movf    0x31, W
    dw 0x1283 ; 0724: bcf     STATUS, RP0
    dw 0x1303 ; 0725: bcf     STATUS, RP1
    dw 0x07d7 ; 0726: addwf   0x57, F
    dw 0x1683 ; 0727: bsf     STATUS, RP0
    dw 0x1703 ; 0728: bsf     STATUS, RP1
    dw 0x0833 ; 0729: movf    0x33, W
    dw 0x1283 ; 072a: bcf     STATUS, RP0
    dw 0x1303 ; 072b: bcf     STATUS, RP1
    dw 0x07d7 ; 072c: addwf   0x57, F
    dw 0x1683 ; 072d: bsf     STATUS, RP0
    dw 0x1703 ; 072e: bsf     STATUS, RP1
    dw 0x083d ; 072f: movf    0x3d, W
    dw 0x1283 ; 0730: bcf     STATUS, RP0
    dw 0x1303 ; 0731: bcf     STATUS, RP1
    dw 0x07d7 ; 0732: addwf   0x57, F
    dw 0x3010 ; 0733: movlw   0x10
    dw 0x2698 ; 0734: call    function_013
    dw 0x120a ; 0735: bcf     PCLATH, 0x4
    dw 0x118a ; 0736: bcf     PCLATH, 0x3
    dw 0x00d6 ; 0737: movwf   0x56
    dw 0x0657 ; 0738: xorwf   0x57, W
    dw 0x1683 ; 0739: bsf     STATUS, RP0
    dw 0x1d03 ; 073a: btfss   STATUS, Z
    dw 0x2f3e ; 073b: goto    label_134
    dw 0x11d8 ; 073c: bcf     0x58, 0x3
    dw 0x2f3f ; 073d: goto    label_135
    dw 0x15d8 ; 073e: bsf     0x58, 0x3
    dw 0x1283 ; 073f: bcf     STATUS, RP0
    dw 0x0008 ; 0740: return
    dw 0x3005 ; 0741: movlw   0x05
    dw 0x2698 ; 0742: call    function_013
    dw 0x120a ; 0743: bcf     PCLATH, 0x4
    dw 0x118a ; 0744: bcf     PCLATH, 0x3
    dw 0x1703 ; 0745: bsf     STATUS, RP1
    dw 0x00a2 ; 0746: movwf   0x22
    dw 0x3a02 ; 0747: xorlw   0x02
    dw 0x1d03 ; 0748: btfss   STATUS, Z
    dw 0x2f53 ; 0749: goto    label_136
    dw 0x3000 ; 074a: movlw   0x00
    dw 0x2698 ; 074b: call    function_013
    dw 0x120a ; 074c: bcf     PCLATH, 0x4
    dw 0x118a ; 074d: bcf     PCLATH, 0x3
    dw 0x1683 ; 074e: bsf     STATUS, RP0
    dw 0x1703 ; 074f: bsf     STATUS, RP1
    dw 0x00c3 ; 0750: movwf   0x43
    dw 0x3002 ; 0751: movlw   0x02
    dw 0x2f5b ; 0752: goto    label_137
    dw 0x3001 ; 0753: movlw   0x01
    dw 0x2698 ; 0754: call    function_013
    dw 0x120a ; 0755: bcf     PCLATH, 0x4
    dw 0x118a ; 0756: bcf     PCLATH, 0x3
    dw 0x1683 ; 0757: bsf     STATUS, RP0
    dw 0x1703 ; 0758: bsf     STATUS, RP1
    dw 0x00c3 ; 0759: movwf   0x43
    dw 0x3003 ; 075a: movlw   0x03
    dw 0x2698 ; 075b: call    function_013
    dw 0x120a ; 075c: bcf     PCLATH, 0x4
    dw 0x118a ; 075d: bcf     PCLATH, 0x3
    dw 0x1683 ; 075e: bsf     STATUS, RP0
    dw 0x1703 ; 075f: bsf     STATUS, RP1
    dw 0x00c2 ; 0760: movwf   0x42
    dw 0x3004 ; 0761: movlw   0x04
    dw 0x2698 ; 0762: call    function_013
    dw 0x120a ; 0763: bcf     PCLATH, 0x4
    dw 0x118a ; 0764: bcf     PCLATH, 0x3
    dw 0x1683 ; 0765: bsf     STATUS, RP0
    dw 0x1703 ; 0766: bsf     STATUS, RP1
    dw 0x00bb ; 0767: movwf   0x3b
    dw 0x3008 ; 0768: movlw   0x08
    dw 0x2698 ; 0769: call    function_013
    dw 0x120a ; 076a: bcf     PCLATH, 0x4
    dw 0x118a ; 076b: bcf     PCLATH, 0x3
    dw 0x1683 ; 076c: bsf     STATUS, RP0
    dw 0x1703 ; 076d: bsf     STATUS, RP1
    dw 0x00bf ; 076e: movwf   0x3f
    dw 0x3009 ; 076f: movlw   0x09
    dw 0x2698 ; 0770: call    function_013
    dw 0x120a ; 0771: bcf     PCLATH, 0x4
    dw 0x118a ; 0772: bcf     PCLATH, 0x3
    dw 0x1683 ; 0773: bsf     STATUS, RP0
    dw 0x1703 ; 0774: bsf     STATUS, RP1
    dw 0x00c0 ; 0775: movwf   0x40
    dw 0x300a ; 0776: movlw   0x0a
    dw 0x2698 ; 0777: call    function_013
    dw 0x120a ; 0778: bcf     PCLATH, 0x4
    dw 0x118a ; 0779: bcf     PCLATH, 0x3
    dw 0x1683 ; 077a: bsf     STATUS, RP0
    dw 0x1703 ; 077b: bsf     STATUS, RP1
    dw 0x00c1 ; 077c: movwf   0x41
    dw 0x300b ; 077d: movlw   0x0b
    dw 0x2698 ; 077e: call    function_013
    dw 0x120a ; 077f: bcf     PCLATH, 0x4
    dw 0x118a ; 0780: bcf     PCLATH, 0x3
    dw 0x1683 ; 0781: bsf     STATUS, RP0
    dw 0x1703 ; 0782: bsf     STATUS, RP1
    dw 0x00be ; 0783: movwf   0x3e
    dw 0x300c ; 0784: movlw   0x0c
    dw 0x2698 ; 0785: call    function_013
    dw 0x120a ; 0786: bcf     PCLATH, 0x4
    dw 0x118a ; 0787: bcf     PCLATH, 0x3
    dw 0x1683 ; 0788: bsf     STATUS, RP0
    dw 0x1703 ; 0789: bsf     STATUS, RP1
    dw 0x00b0 ; 078a: movwf   0x30
    dw 0x300d ; 078b: movlw   0x0d
    dw 0x2698 ; 078c: call    function_013
    dw 0x120a ; 078d: bcf     PCLATH, 0x4
    dw 0x118a ; 078e: bcf     PCLATH, 0x3
    dw 0x1683 ; 078f: bsf     STATUS, RP0
    dw 0x1703 ; 0790: bsf     STATUS, RP1
    dw 0x00b1 ; 0791: movwf   0x31
    dw 0x300e ; 0792: movlw   0x0e
    dw 0x2698 ; 0793: call    function_013
    dw 0x120a ; 0794: bcf     PCLATH, 0x4
    dw 0x118a ; 0795: bcf     PCLATH, 0x3
    dw 0x1683 ; 0796: bsf     STATUS, RP0
    dw 0x1703 ; 0797: bsf     STATUS, RP1
    dw 0x00b3 ; 0798: movwf   0x33
    dw 0x300f ; 0799: movlw   0x0f
    dw 0x2698 ; 079a: call    function_013
    dw 0x120a ; 079b: bcf     PCLATH, 0x4
    dw 0x118a ; 079c: bcf     PCLATH, 0x3
    dw 0x1683 ; 079d: bsf     STATUS, RP0
    dw 0x1703 ; 079e: bsf     STATUS, RP1
    dw 0x00bd ; 079f: movwf   0x3d
    dw 0x3010 ; 07a0: movlw   0x10
    dw 0x2698 ; 07a1: call    function_013
    dw 0x120a ; 07a2: bcf     PCLATH, 0x4
    dw 0x118a ; 07a3: bcf     PCLATH, 0x3
    dw 0x1683 ; 07a4: bsf     STATUS, RP0
    dw 0x1703 ; 07a5: bsf     STATUS, RP1
    dw 0x00bc ; 07a6: movwf   0x3c
    dw 0x0183 ; 07a7: clrf    STATUS
    dw 0x0008 ; 07a8: return
    dw 0x01f6 ; 07a9: clrf    (Common_RAM + 6)
    dw 0x1ff1 ; 07aa: btfss   (Common_RAM + 1), 0x7
    dw 0x2fb3 ; 07ab: goto    label_138
    dw 0x09f0 ; 07ac: comf    Common_RAM, F
    dw 0x0af0 ; 07ad: incf    Common_RAM, F
    dw 0x1903 ; 07ae: btfsc   STATUS, Z
    dw 0x03f1 ; 07af: decf    (Common_RAM + 1), F
    dw 0x09f1 ; 07b0: comf    (Common_RAM + 1), F
    dw 0x1776 ; 07b1: bsf     (Common_RAM + 6), 0x6
    dw 0x17f6 ; 07b2: bsf     (Common_RAM + 6), 0x7
    dw 0x0873 ; 07b3: movf    (Common_RAM + 3), W
    dw 0x3980 ; 07b4: andlw   0x80
    dw 0x06f6 ; 07b5: xorwf   (Common_RAM + 6), F
    dw 0x1ff3 ; 07b6: btfss   (Common_RAM + 3), 0x7
    dw 0x2fbf ; 07b7: goto    label_139
    dw 0x09f2 ; 07b8: comf    (Common_RAM + 2), F
    dw 0x0af2 ; 07b9: incf    (Common_RAM + 2), F
    dw 0x1903 ; 07ba: btfsc   STATUS, Z
    dw 0x03f3 ; 07bb: decf    (Common_RAM + 3), F
    dw 0x09f3 ; 07bc: comf    (Common_RAM + 3), F
    dw 0x2fbf ; 07bd: goto    label_139
    dw 0x01f6 ; 07be: clrf    (Common_RAM + 6)
    dw 0x01f4 ; 07bf: clrf    (Common_RAM + 4)
    dw 0x01f5 ; 07c0: clrf    (Common_RAM + 5)
    dw 0x0872 ; 07c1: movf    (Common_RAM + 2), W
    dw 0x0473 ; 07c2: iorwf   (Common_RAM + 3), W
    dw 0x1d03 ; 07c3: btfss   STATUS, Z
    dw 0x2fc8 ; 07c4: goto    label_140
    dw 0x01f0 ; 07c5: clrf    Common_RAM
    dw 0x01f1 ; 07c6: clrf    (Common_RAM + 1)
    dw 0x3400 ; 07c7: retlw   0x00
    dw 0x301f ; 07c8: movlw   0x1f
    dw 0x04f6 ; 07c9: iorwf   (Common_RAM + 6), F
    dw 0x1003 ; 07ca: bcf     STATUS, C
    dw 0x0af6 ; 07cb: incf    (Common_RAM + 6), F
    dw 0x0df2 ; 07cc: rlf     (Common_RAM + 2), F
    dw 0x0df3 ; 07cd: rlf     (Common_RAM + 3), F
    dw 0x1c03 ; 07ce: btfss   STATUS, C
    dw 0x2fcb ; 07cf: goto    label_141
    dw 0x0cf3 ; 07d0: rrf     (Common_RAM + 3), F
    dw 0x0cf2 ; 07d1: rrf     (Common_RAM + 2), F
    dw 0x0873 ; 07d2: movf    (Common_RAM + 3), W
    dw 0x0271 ; 07d3: subwf   (Common_RAM + 1), W
    dw 0x1d03 ; 07d4: btfss   STATUS, Z
    dw 0x2fd8 ; 07d5: goto    label_143
    dw 0x0872 ; 07d6: movf    (Common_RAM + 2), W
    dw 0x0270 ; 07d7: subwf   Common_RAM, W
    dw 0x1c03 ; 07d8: btfss   STATUS, C
    dw 0x2fe0 ; 07d9: goto    label_144
    dw 0x0872 ; 07da: movf    (Common_RAM + 2), W
    dw 0x02f0 ; 07db: subwf   Common_RAM, F
    dw 0x0873 ; 07dc: movf    (Common_RAM + 3), W
    dw 0x1c03 ; 07dd: btfss   STATUS, C
    dw 0x0a73 ; 07de: incf    (Common_RAM + 3), W
    dw 0x02f1 ; 07df: subwf   (Common_RAM + 1), F
    dw 0x0df4 ; 07e0: rlf     (Common_RAM + 4), F
    dw 0x0df5 ; 07e1: rlf     (Common_RAM + 5), F
    dw 0x0bf6 ; 07e2: decfsz  (Common_RAM + 6), F
    dw 0x1af6 ; 07e3: btfsc   (Common_RAM + 6), 0x5
    dw 0x2fd0 ; 07e4: goto    label_142
    dw 0x1ff6 ; 07e5: btfss   (Common_RAM + 6), 0x7
    dw 0x2fec ; 07e6: goto    label_145
    dw 0x09f4 ; 07e7: comf    (Common_RAM + 4), F
    dw 0x0af4 ; 07e8: incf    (Common_RAM + 4), F
    dw 0x1903 ; 07e9: btfsc   STATUS, Z
    dw 0x03f5 ; 07ea: decf    (Common_RAM + 5), F
    dw 0x09f5 ; 07eb: comf    (Common_RAM + 5), F
    dw 0x0874 ; 07ec: movf    (Common_RAM + 4), W
    dw 0x00f2 ; 07ed: movwf   (Common_RAM + 2)
    dw 0x0875 ; 07ee: movf    (Common_RAM + 5), W
    dw 0x00f3 ; 07ef: movwf   (Common_RAM + 3)
    dw 0x1f76 ; 07f0: btfss   (Common_RAM + 6), 0x6
    dw 0x3400 ; 07f1: retlw   0x00
    dw 0x09f0 ; 07f2: comf    Common_RAM, F
    dw 0x0af0 ; 07f3: incf    Common_RAM, F
    dw 0x1903 ; 07f4: btfsc   STATUS, Z
    dw 0x03f1 ; 07f5: decf    (Common_RAM + 1), F
    dw 0x09f1 ; 07f6: comf    (Common_RAM + 1), F
    dw 0x3400 ; 07f7: retlw   0x00
    dw 0x345a ; 07f8: retlw   0x5a
    dw 0x344f ; 07f9: retlw   0x4f
    dw 0x3432 ; 07fa: retlw   0x32
    dw 0x3400 ; 07fb: retlw   0x00
    dw 0x3400 ; 07fc: retlw   0x00
    dw 0x3400 ; 07fd: retlw   0x00
    dw 0x3400 ; 07fe: retlw   0x00
    dw 0x3400 ; 07ff: retlw   0x00
    dw 0x3fff ; 0800: addlw   0xff
    dw 0x0183 ; 0801: clrf    STATUS
    dw 0x00bd ; 0802: movwf   0x3d
    dw 0x3003 ; 0803: movlw   0x03
    dw 0x023d ; 0804: subwf   0x3d, W
    dw 0x1803 ; 0805: btfsc   STATUS, C
    dw 0x3402 ; 0806: retlw   0x02
    dw 0x160a ; 0807: bsf     PCLATH, 0x4
    dw 0x158a ; 0808: bsf     PCLATH, 0x3
    dw 0x26d8 ; 0809: call    function_074
    dw 0x120a ; 080a: bcf     PCLATH, 0x4
    dw 0x158a ; 080b: bsf     PCLATH, 0x3
    dw 0x083d ; 080c: movf    0x3d, W
    dw 0x043c ; 080d: iorwf   0x3c, W
    dw 0x3003 ; 080e: movlw   0x03
    dw 0x00f1 ; 080f: movwf   (Common_RAM + 1)
    dw 0x1d03 ; 0810: btfss   STATUS, Z
    dw 0x2820 ; 0811: goto    label_148
    dw 0x083d ; 0812: movf    0x3d, W
    dw 0x160a ; 0813: bsf     PCLATH, 0x4
    dw 0x158a ; 0814: bsf     PCLATH, 0x3
    dw 0x26e2 ; 0815: call    function_075
    dw 0x3e02 ; 0816: addlw   0x02
    dw 0x3eac ; 0817: addlw   0xac
    dw 0x0084 ; 0818: movwf   FSR
    dw 0x1383 ; 0819: bcf     STATUS, IRP
    dw 0x0800 ; 081a: movf    INDF, W
    dw 0x160a ; 081b: bsf     PCLATH, 0x4
    dw 0x118a ; 081c: bcf     PCLATH, 0x3
    dw 0x2716 ; 081d: call    function_039
    dw 0x3003 ; 081e: movlw   0x03
    dw 0x00f1 ; 081f: movwf   (Common_RAM + 1)
    dw 0x083d ; 0820: movf    0x3d, W
    dw 0x160a ; 0821: bsf     PCLATH, 0x4
    dw 0x158a ; 0822: bsf     PCLATH, 0x3
    dw 0x26e2 ; 0823: call    function_075
    dw 0x3eac ; 0824: addlw   0xac
    dw 0x0084 ; 0825: movwf   FSR
    dw 0x1383 ; 0826: bcf     STATUS, IRP
    dw 0x083c ; 0827: movf    0x3c, W
    dw 0x0080 ; 0828: movwf   INDF
    dw 0x0a84 ; 0829: incf    FSR, F
    dw 0x083d ; 082a: movf    0x3d, W
    dw 0x0080 ; 082b: movwf   INDF
    dw 0x3003 ; 082c: movlw   0x03
    dw 0x00f1 ; 082d: movwf   (Common_RAM + 1)
    dw 0x083d ; 082e: movf    0x3d, W
    dw 0x160a ; 082f: bsf     PCLATH, 0x4
    dw 0x158a ; 0830: bsf     PCLATH, 0x3
    dw 0x26e2 ; 0831: call    function_075
    dw 0x120a ; 0832: bcf     PCLATH, 0x4
    dw 0x158a ; 0833: bsf     PCLATH, 0x3
    dw 0x3e02 ; 0834: addlw   0x02
    dw 0x3eac ; 0835: addlw   0xac
    dw 0x0084 ; 0836: movwf   FSR
    dw 0x1383 ; 0837: bcf     STATUS, IRP
    dw 0x0880 ; 0838: movf    INDF, F
    dw 0x1d03 ; 0839: btfss   STATUS, Z
    dw 0x283e ; 083a: goto    label_150
    dw 0x3003 ; 083b: movlw   0x03
    dw 0x00bc ; 083c: movwf   0x3c
    dw 0x283f ; 083d: goto    label_151
    dw 0x01bc ; 083e: clrf    0x3c
    dw 0x160a ; 083f: bsf     PCLATH, 0x4
    dw 0x158a ; 0840: bsf     PCLATH, 0x3
    dw 0x26ac ; 0841: call    function_069
    dw 0x120a ; 0842: bcf     PCLATH, 0x4
    dw 0x158a ; 0843: bsf     PCLATH, 0x3
    dw 0x083c ; 0844: movf    0x3c, W
    dw 0x0008 ; 0845: return
    dw 0x0183 ; 0846: clrf    STATUS
    dw 0x00d6 ; 0847: movwf   0x56
    dw 0x1683 ; 0848: bsf     STATUS, RP0
    dw 0x1703 ; 0849: bsf     STATUS, RP1
    dw 0x0830 ; 084a: movf    0x30, W
    dw 0x0730 ; 084b: addwf   0x30, W
    dw 0x3c0a ; 084c: sublw   0x0a
    dw 0x1283 ; 084d: bcf     STATUS, RP0
    dw 0x1303 ; 084e: bcf     STATUS, RP1
    dw 0x00d7 ; 084f: movwf   0x57
    dw 0x300b ; 0850: movlw   0x0b
    dw 0x0257 ; 0851: subwf   0x57, W
    dw 0x1803 ; 0852: btfsc   STATUS, C
    dw 0x2856 ; 0853: goto    label_152
    dw 0x0857 ; 0854: movf    0x57, W
    dw 0x2857 ; 0855: goto    label_153
    dw 0x300a ; 0856: movlw   0x0a
    dw 0x00d7 ; 0857: movwf   0x57
    dw 0x138b ; 0858: bcf     INTCON, GIE
    dw 0x00f2 ; 0859: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 085a: clrf    (Common_RAM + 3)
    dw 0x0856 ; 085b: movf    0x56, W
    dw 0x00f0 ; 085c: movwf   Common_RAM
    dw 0x01f1 ; 085d: clrf    (Common_RAM + 1)
    dw 0x160a ; 085e: bsf     PCLATH, 0x4
    dw 0x158a ; 085f: bsf     PCLATH, 0x3
    dw 0x26ee ; 0860: call    function_076
    dw 0x3032 ; 0861: movlw   0x32
    dw 0x07f4 ; 0862: addwf   (Common_RAM + 4), F
    dw 0x1803 ; 0863: btfsc   STATUS, C
    dw 0x0af5 ; 0864: incf    (Common_RAM + 5), F
    dw 0x0874 ; 0865: movf    (Common_RAM + 4), W
    dw 0x00f0 ; 0866: movwf   Common_RAM
    dw 0x0875 ; 0867: movf    (Common_RAM + 5), W
    dw 0x00f1 ; 0868: movwf   (Common_RAM + 1)
    dw 0x3064 ; 0869: movlw   0x64
    dw 0x00f2 ; 086a: movwf   (Common_RAM + 2)
    dw 0x3000 ; 086b: movlw   0x00
    dw 0x01f3 ; 086c: clrf    (Common_RAM + 3)
    dw 0x120a ; 086d: bcf     PCLATH, 0x4
    dw 0x118a ; 086e: bcf     PCLATH, 0x3
    dw 0x27a9 ; 086f: call    function_016
    dw 0x120a ; 0870: bcf     PCLATH, 0x4
    dw 0x158a ; 0871: bsf     PCLATH, 0x3
    dw 0x0874 ; 0872: movf    (Common_RAM + 4), W
    dw 0x1683 ; 0873: bsf     STATUS, RP0
    dw 0x00bf ; 0874: movwf   0x3f
    dw 0x00f0 ; 0875: movwf   Common_RAM
    dw 0x01f1 ; 0876: clrf    (Common_RAM + 1)
    dw 0x0871 ; 0877: movf    (Common_RAM + 1), W
    dw 0x025a ; 0878: subwf   0x5a, W
    dw 0x1d03 ; 0879: btfss   STATUS, Z
    dw 0x287d ; 087a: goto    label_154
    dw 0x0870 ; 087b: movf    Common_RAM, W
    dw 0x0259 ; 087c: subwf   0x59, W
    dw 0x1c03 ; 087d: btfss   STATUS, C
    dw 0x2881 ; 087e: goto    label_155
    dw 0x083f ; 087f: movf    0x3f, W
    dw 0x2883 ; 0880: goto    label_156
    dw 0x1303 ; 0881: bcf     STATUS, RP1
    dw 0x0859 ; 0882: movf    0x59, W
    dw 0x1303 ; 0883: bcf     STATUS, RP1
    dw 0x00bf ; 0884: movwf   0x3f
    dw 0x178b ; 0885: bsf     INTCON, GIE
    dw 0x1703 ; 0886: bsf     STATUS, RP1
    dw 0x0831 ; 0887: movf    0x31, W
    dw 0x0731 ; 0888: addwf   0x31, W
    dw 0x3c0a ; 0889: sublw   0x0a
    dw 0x1283 ; 088a: bcf     STATUS, RP0
    dw 0x1303 ; 088b: bcf     STATUS, RP1
    dw 0x00d7 ; 088c: movwf   0x57
    dw 0x300b ; 088d: movlw   0x0b
    dw 0x0257 ; 088e: subwf   0x57, W
    dw 0x1803 ; 088f: btfsc   STATUS, C
    dw 0x2893 ; 0890: goto    label_157
    dw 0x0857 ; 0891: movf    0x57, W
    dw 0x2894 ; 0892: goto    label_158
    dw 0x300a ; 0893: movlw   0x0a
    dw 0x00d7 ; 0894: movwf   0x57
    dw 0x138b ; 0895: bcf     INTCON, GIE
    dw 0x00f2 ; 0896: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 0897: clrf    (Common_RAM + 3)
    dw 0x0856 ; 0898: movf    0x56, W
    dw 0x00f0 ; 0899: movwf   Common_RAM
    dw 0x01f1 ; 089a: clrf    (Common_RAM + 1)
    dw 0x160a ; 089b: bsf     PCLATH, 0x4
    dw 0x158a ; 089c: bsf     PCLATH, 0x3
    dw 0x26ee ; 089d: call    function_076
    dw 0x3032 ; 089e: movlw   0x32
    dw 0x07f4 ; 089f: addwf   (Common_RAM + 4), F
    dw 0x1803 ; 08a0: btfsc   STATUS, C
    dw 0x0af5 ; 08a1: incf    (Common_RAM + 5), F
    dw 0x0874 ; 08a2: movf    (Common_RAM + 4), W
    dw 0x00f0 ; 08a3: movwf   Common_RAM
    dw 0x0875 ; 08a4: movf    (Common_RAM + 5), W
    dw 0x00f1 ; 08a5: movwf   (Common_RAM + 1)
    dw 0x3064 ; 08a6: movlw   0x64
    dw 0x00f2 ; 08a7: movwf   (Common_RAM + 2)
    dw 0x3000 ; 08a8: movlw   0x00
    dw 0x01f3 ; 08a9: clrf    (Common_RAM + 3)
    dw 0x120a ; 08aa: bcf     PCLATH, 0x4
    dw 0x118a ; 08ab: bcf     PCLATH, 0x3
    dw 0x27a9 ; 08ac: call    function_016
    dw 0x120a ; 08ad: bcf     PCLATH, 0x4
    dw 0x158a ; 08ae: bsf     PCLATH, 0x3
    dw 0x0874 ; 08af: movf    (Common_RAM + 4), W
    dw 0x1683 ; 08b0: bsf     STATUS, RP0
    dw 0x00c0 ; 08b1: movwf   0x40
    dw 0x00f0 ; 08b2: movwf   Common_RAM
    dw 0x01f1 ; 08b3: clrf    (Common_RAM + 1)
    dw 0x0871 ; 08b4: movf    (Common_RAM + 1), W
    dw 0x025a ; 08b5: subwf   0x5a, W
    dw 0x1d03 ; 08b6: btfss   STATUS, Z
    dw 0x28ba ; 08b7: goto    label_159
    dw 0x0870 ; 08b8: movf    Common_RAM, W
    dw 0x0259 ; 08b9: subwf   0x59, W
    dw 0x1c03 ; 08ba: btfss   STATUS, C
    dw 0x28be ; 08bb: goto    label_160
    dw 0x0840 ; 08bc: movf    0x40, W
    dw 0x28c0 ; 08bd: goto    label_161
    dw 0x1303 ; 08be: bcf     STATUS, RP1
    dw 0x0859 ; 08bf: movf    0x59, W
    dw 0x1303 ; 08c0: bcf     STATUS, RP1
    dw 0x00c0 ; 08c1: movwf   0x40
    dw 0x178b ; 08c2: bsf     INTCON, GIE
    dw 0x08bf ; 08c3: movf    0x3f, F
    dw 0x1903 ; 08c4: btfsc   STATUS, Z
    dw 0x28cb ; 08c5: goto    label_162
    dw 0x08c0 ; 08c6: movf    0x40, F
    dw 0x1903 ; 08c7: btfsc   STATUS, Z
    dw 0x28cb ; 08c8: goto    label_162
    dw 0x3001 ; 08c9: movlw   0x01
    dw 0x28cc ; 08ca: goto    label_163
    dw 0x3000 ; 08cb: movlw   0x00
    dw 0x1283 ; 08cc: bcf     STATUS, RP0
    dw 0x0008 ; 08cd: return
    dw 0x0183 ; 08ce: clrf    STATUS
    dw 0x01bd ; 08cf: clrf    0x3d
    dw 0x2fed ; 08d0: goto    label_304
    dw 0x160a ; 08d1: bsf     PCLATH, 0x4
    dw 0x158a ; 08d2: bsf     PCLATH, 0x3
    dw 0x266d ; 08d3: call    function_059
    dw 0x00cf ; 08d4: movwf   0x4f
    dw 0x01d0 ; 08d5: clrf    0x50
    dw 0x160a ; 08d6: bsf     PCLATH, 0x4
    dw 0x158a ; 08d7: bsf     PCLATH, 0x3
    dw 0x2643 ; 08d8: call    function_053
    dw 0x120a ; 08d9: bcf     PCLATH, 0x4
    dw 0x158a ; 08da: bsf     PCLATH, 0x3
    dw 0x28e6 ; 08db: goto    label_166
    dw 0x160a ; 08dc: bsf     PCLATH, 0x4
    dw 0x158a ; 08dd: bsf     PCLATH, 0x3
    dw 0x264f ; 08de: call    function_055
    dw 0x00cf ; 08df: movwf   0x4f
    dw 0x01d0 ; 08e0: clrf    0x50
    dw 0x160a ; 08e1: bsf     PCLATH, 0x4
    dw 0x158a ; 08e2: bsf     PCLATH, 0x3
    dw 0x2649 ; 08e3: call    function_054
    dw 0x120a ; 08e4: bcf     PCLATH, 0x4
    dw 0x158a ; 08e5: bsf     PCLATH, 0x3
    dw 0x00d1 ; 08e6: movwf   0x51
    dw 0x01d2 ; 08e7: clrf    0x52
    dw 0x28f4 ; 08e8: goto    label_168
    dw 0x1703 ; 08e9: bsf     STATUS, RP1
    dw 0x0822 ; 08ea: movf    0x22, W
    dw 0x3a02 ; 08eb: xorlw   0x02
    dw 0x1903 ; 08ec: btfsc   STATUS, Z
    dw 0x28dc ; 08ed: goto    label_165
    dw 0x3a06 ; 08ee: xorlw   0x06
    dw 0x1903 ; 08ef: btfsc   STATUS, Z
    dw 0x28d1 ; 08f0: goto    label_164
    dw 0x3a02 ; 08f1: xorlw   0x02
    dw 0x1903 ; 08f2: btfsc   STATUS, Z
    dw 0x28d1 ; 08f3: goto    label_164
    dw 0x1703 ; 08f4: bsf     STATUS, RP1
    dw 0x0820 ; 08f5: movf    0x20, W
    dw 0x2046 ; 08f6: call    function_019
    dw 0x3018 ; 08f7: movlw   0x18
    dw 0x008a ; 08f8: movwf   PCLATH
    dw 0x084f ; 08f9: movf    0x4f, W
    dw 0x2021 ; 08fa: call    function_018
    dw 0x00d3 ; 08fb: movwf   0x53
    dw 0x01d4 ; 08fc: clrf    0x54
    dw 0x00cf ; 08fd: movwf   0x4f
    dw 0x0854 ; 08fe: movf    0x54, W
    dw 0x00d0 ; 08ff: movwf   0x50
    dw 0x3018 ; 0900: movlw   0x18
    dw 0x008a ; 0901: movwf   PCLATH
    dw 0x0851 ; 0902: movf    0x51, W
    dw 0x2021 ; 0903: call    function_018
    dw 0x00d3 ; 0904: movwf   0x53
    dw 0x01d4 ; 0905: clrf    0x54
    dw 0x00d1 ; 0906: movwf   0x51
    dw 0x0854 ; 0907: movf    0x54, W
    dw 0x00d2 ; 0908: movwf   0x52
    dw 0x160a ; 0909: bsf     PCLATH, 0x4
    dw 0x158a ; 090a: bsf     PCLATH, 0x3
    dw 0x2673 ; 090b: call    function_060
    dw 0x120a ; 090c: bcf     PCLATH, 0x4
    dw 0x158a ; 090d: bsf     PCLATH, 0x3
    dw 0x3a0e ; 090e: xorlw   0x0e
    dw 0x1d03 ; 090f: btfss   STATUS, Z
    dw 0x2916 ; 0910: goto    label_169
    dw 0x1703 ; 0911: bsf     STATUS, RP1
    dw 0x0822 ; 0912: movf    0x22, W
    dw 0x3a06 ; 0913: xorlw   0x06
    dw 0x1903 ; 0914: btfsc   STATUS, Z
    dw 0x2991 ; 0915: goto    label_178
    dw 0x160a ; 0916: bsf     PCLATH, 0x4
    dw 0x158a ; 0917: bsf     PCLATH, 0x3
    dw 0x2673 ; 0918: call    function_060
    dw 0x120a ; 0919: bcf     PCLATH, 0x4
    dw 0x158a ; 091a: bsf     PCLATH, 0x3
    dw 0x3a0f ; 091b: xorlw   0x0f
    dw 0x1d03 ; 091c: btfss   STATUS, Z
    dw 0x2923 ; 091d: goto    label_170
    dw 0x1703 ; 091e: bsf     STATUS, RP1
    dw 0x0822 ; 091f: movf    0x22, W
    dw 0x3a04 ; 0920: xorlw   0x04
    dw 0x1903 ; 0921: btfsc   STATUS, Z
    dw 0x2991 ; 0922: goto    label_178
    dw 0x160a ; 0923: bsf     PCLATH, 0x4
    dw 0x158a ; 0924: bsf     PCLATH, 0x3
    dw 0x2673 ; 0925: call    function_060
    dw 0x120a ; 0926: bcf     PCLATH, 0x4
    dw 0x158a ; 0927: bsf     PCLATH, 0x3
    dw 0x00d3 ; 0928: movwf   0x53
    dw 0x01d4 ; 0929: clrf    0x54
    dw 0x138b ; 092a: bcf     INTCON, GIE
    dw 0x3a02 ; 092b: xorlw   0x02
    dw 0x0454 ; 092c: iorwf   0x54, W
    dw 0x1903 ; 092d: btfsc   STATUS, Z
    dw 0x294c ; 092e: goto    label_171
    dw 0x0853 ; 092f: movf    0x53, W
    dw 0x3a04 ; 0930: xorlw   0x04
    dw 0x0454 ; 0931: iorwf   0x54, W
    dw 0x1903 ; 0932: btfsc   STATUS, Z
    dw 0x294c ; 0933: goto    label_171
    dw 0x0853 ; 0934: movf    0x53, W
    dw 0x3a06 ; 0935: xorlw   0x06
    dw 0x0454 ; 0936: iorwf   0x54, W
    dw 0x1903 ; 0937: btfsc   STATUS, Z
    dw 0x294c ; 0938: goto    label_171
    dw 0x0853 ; 0939: movf    0x53, W
    dw 0x3a0d ; 093a: xorlw   0x0d
    dw 0x0454 ; 093b: iorwf   0x54, W
    dw 0x1903 ; 093c: btfsc   STATUS, Z
    dw 0x294c ; 093d: goto    label_171
    dw 0x0853 ; 093e: movf    0x53, W
    dw 0x3a0e ; 093f: xorlw   0x0e
    dw 0x0454 ; 0940: iorwf   0x54, W
    dw 0x1903 ; 0941: btfsc   STATUS, Z
    dw 0x294c ; 0942: goto    label_171
    dw 0x0853 ; 0943: movf    0x53, W
    dw 0x3a0f ; 0944: xorlw   0x0f
    dw 0x0454 ; 0945: iorwf   0x54, W
    dw 0x1903 ; 0946: btfsc   STATUS, Z
    dw 0x294c ; 0947: goto    label_171
    dw 0x0353 ; 0948: decf    0x53, W
    dw 0x0454 ; 0949: iorwf   0x54, W
    dw 0x1d03 ; 094a: btfss   STATUS, Z
    dw 0x2952 ; 094b: goto    label_172
    dw 0x0851 ; 094c: movf    0x51, W
    dw 0x160a ; 094d: bsf     PCLATH, 0x4
    dw 0x158a ; 094e: bsf     PCLATH, 0x3
    dw 0x27d5 ; 094f: call    function_081
    dw 0x120a ; 0950: bcf     PCLATH, 0x4
    dw 0x158a ; 0951: bsf     PCLATH, 0x3
    dw 0x0853 ; 0952: movf    0x53, W
    dw 0x3a03 ; 0953: xorlw   0x03
    dw 0x0454 ; 0954: iorwf   0x54, W
    dw 0x1903 ; 0955: btfsc   STATUS, Z
    dw 0x2974 ; 0956: goto    label_173
    dw 0x0853 ; 0957: movf    0x53, W
    dw 0x3a05 ; 0958: xorlw   0x05
    dw 0x0454 ; 0959: iorwf   0x54, W
    dw 0x1903 ; 095a: btfsc   STATUS, Z
    dw 0x2974 ; 095b: goto    label_173
    dw 0x0853 ; 095c: movf    0x53, W
    dw 0x3a07 ; 095d: xorlw   0x07
    dw 0x0454 ; 095e: iorwf   0x54, W
    dw 0x1903 ; 095f: btfsc   STATUS, Z
    dw 0x2974 ; 0960: goto    label_173
    dw 0x0853 ; 0961: movf    0x53, W
    dw 0x3a0d ; 0962: xorlw   0x0d
    dw 0x0454 ; 0963: iorwf   0x54, W
    dw 0x1903 ; 0964: btfsc   STATUS, Z
    dw 0x2974 ; 0965: goto    label_173
    dw 0x0853 ; 0966: movf    0x53, W
    dw 0x3a0e ; 0967: xorlw   0x0e
    dw 0x0454 ; 0968: iorwf   0x54, W
    dw 0x1903 ; 0969: btfsc   STATUS, Z
    dw 0x2974 ; 096a: goto    label_173
    dw 0x0853 ; 096b: movf    0x53, W
    dw 0x3a0f ; 096c: xorlw   0x0f
    dw 0x0454 ; 096d: iorwf   0x54, W
    dw 0x1903 ; 096e: btfsc   STATUS, Z
    dw 0x2974 ; 096f: goto    label_173
    dw 0x0353 ; 0970: decf    0x53, W
    dw 0x0454 ; 0971: iorwf   0x54, W
    dw 0x1d03 ; 0972: btfss   STATUS, Z
    dw 0x297a ; 0973: goto    label_174
    dw 0x084f ; 0974: movf    0x4f, W
    dw 0x160a ; 0975: bsf     PCLATH, 0x4
    dw 0x158a ; 0976: bsf     PCLATH, 0x3
    dw 0x27aa ; 0977: call    function_080
    dw 0x120a ; 0978: bcf     PCLATH, 0x4
    dw 0x158a ; 0979: bsf     PCLATH, 0x3
    dw 0x0850 ; 097a: movf    0x50, W
    dw 0x044f ; 097b: iorwf   0x4f, W
    dw 0x1d03 ; 097c: btfss   STATUS, Z
    dw 0x2988 ; 097d: goto    label_175
    dw 0x0852 ; 097e: movf    0x52, W
    dw 0x0451 ; 097f: iorwf   0x51, W
    dw 0x1903 ; 0980: btfsc   STATUS, Z
    dw 0x1888 ; 0981: btfsc   PORTD, RD1
    dw 0x2988 ; 0982: goto    label_175
    dw 0x1d08 ; 0983: btfss   PORTD, RD2
    dw 0x1b08 ; 0984: btfsc   PORTD, RD6
    dw 0x2988 ; 0985: goto    label_175
    dw 0x1e88 ; 0986: btfss   PORTD, RD5
    dw 0x298b ; 0987: goto    label_176
    dw 0x1683 ; 0988: bsf     STATUS, RP0
    dw 0x144e ; 0989: bsf     0x4e, 0x0
    dw 0x2990 ; 098a: goto    label_177
    dw 0x120a ; 098b: bcf     PCLATH, 0x4
    dw 0x118a ; 098c: bcf     PCLATH, 0x3
    dw 0x2521 ; 098d: call    function_008
    dw 0x120a ; 098e: bcf     PCLATH, 0x4
    dw 0x158a ; 098f: bsf     PCLATH, 0x3
    dw 0x178b ; 0990: bsf     INTCON, GIE
    dw 0x1283 ; 0991: bcf     STATUS, RP0
    dw 0x1703 ; 0992: bsf     STATUS, RP1
    dw 0x0822 ; 0993: movf    0x22, W
    dw 0x3a02 ; 0994: xorlw   0x02
    dw 0x1903 ; 0995: btfsc   STATUS, Z
    dw 0x29d2 ; 0996: goto    label_182
    dw 0x0822 ; 0997: movf    0x22, W
    dw 0x3a04 ; 0998: xorlw   0x04
    dw 0x1d03 ; 0999: btfss   STATUS, Z
    dw 0x29c3 ; 099a: goto    label_180
    dw 0x160a ; 099b: bsf     PCLATH, 0x4
    dw 0x158a ; 099c: bsf     PCLATH, 0x3
    dw 0x2673 ; 099d: call    function_060
    dw 0x120a ; 099e: bcf     PCLATH, 0x4
    dw 0x158a ; 099f: bsf     PCLATH, 0x3
    dw 0x3a0d ; 09a0: xorlw   0x0d
    dw 0x1903 ; 09a1: btfsc   STATUS, Z
    dw 0x29cf ; 09a2: goto    label_181
    dw 0x160a ; 09a3: bsf     PCLATH, 0x4
    dw 0x158a ; 09a4: bsf     PCLATH, 0x3
    dw 0x2673 ; 09a5: call    function_060
    dw 0x120a ; 09a6: bcf     PCLATH, 0x4
    dw 0x158a ; 09a7: bsf     PCLATH, 0x3
    dw 0x3a0f ; 09a8: xorlw   0x0f
    dw 0x1903 ; 09a9: btfsc   STATUS, Z
    dw 0x29cf ; 09aa: goto    label_181
    dw 0x160a ; 09ab: bsf     PCLATH, 0x4
    dw 0x158a ; 09ac: bsf     PCLATH, 0x3
    dw 0x2661 ; 09ad: call    function_058
    dw 0x00d5 ; 09ae: movwf   0x55
    dw 0x160a ; 09af: bsf     PCLATH, 0x4
    dw 0x158a ; 09b0: bsf     PCLATH, 0x3
    dw 0x268b ; 09b1: call    function_064
    dw 0x120a ; 09b2: bcf     PCLATH, 0x4
    dw 0x158a ; 09b3: bsf     PCLATH, 0x3
    dw 0x0255 ; 09b4: subwf   0x55, W
    dw 0x1803 ; 09b5: btfsc   STATUS, C
    dw 0x29bd ; 09b6: goto    label_179
    dw 0x160a ; 09b7: bsf     PCLATH, 0x4
    dw 0x158a ; 09b8: bsf     PCLATH, 0x3
    dw 0x268b ; 09b9: call    function_064
    dw 0x120a ; 09ba: bcf     PCLATH, 0x4
    dw 0x158a ; 09bb: bsf     PCLATH, 0x3
    dw 0x29e9 ; 09bc: goto    label_184
    dw 0x160a ; 09bd: bsf     PCLATH, 0x4
    dw 0x158a ; 09be: bsf     PCLATH, 0x3
    dw 0x2661 ; 09bf: call    function_058
    dw 0x120a ; 09c0: bcf     PCLATH, 0x4
    dw 0x158a ; 09c1: bsf     PCLATH, 0x3
    dw 0x29e9 ; 09c2: goto    label_184
    dw 0x0822 ; 09c3: movf    0x22, W
    dw 0x3a06 ; 09c4: xorlw   0x06
    dw 0x1d03 ; 09c5: btfss   STATUS, Z
    dw 0x29eb ; 09c6: goto    label_185
    dw 0x160a ; 09c7: bsf     PCLATH, 0x4
    dw 0x158a ; 09c8: bsf     PCLATH, 0x3
    dw 0x2673 ; 09c9: call    function_060
    dw 0x120a ; 09ca: bcf     PCLATH, 0x4
    dw 0x158a ; 09cb: bsf     PCLATH, 0x3
    dw 0x3a0e ; 09cc: xorlw   0x0e
    dw 0x1d03 ; 09cd: btfss   STATUS, Z
    dw 0x29d2 ; 09ce: goto    label_182
    dw 0x1683 ; 09cf: bsf     STATUS, RP0
    dw 0x01d2 ; 09d0: clrf    0x52
    dw 0x29eb ; 09d1: goto    label_185
    dw 0x160a ; 09d2: bsf     PCLATH, 0x4
    dw 0x158a ; 09d3: bsf     PCLATH, 0x3
    dw 0x2655 ; 09d4: call    function_056
    dw 0x00d5 ; 09d5: movwf   0x55
    dw 0x160a ; 09d6: bsf     PCLATH, 0x4
    dw 0x158a ; 09d7: bsf     PCLATH, 0x3
    dw 0x265b ; 09d8: call    function_057
    dw 0x120a ; 09d9: bcf     PCLATH, 0x4
    dw 0x158a ; 09da: bsf     PCLATH, 0x3
    dw 0x0255 ; 09db: subwf   0x55, W
    dw 0x1803 ; 09dc: btfsc   STATUS, C
    dw 0x29e4 ; 09dd: goto    label_183
    dw 0x160a ; 09de: bsf     PCLATH, 0x4
    dw 0x158a ; 09df: bsf     PCLATH, 0x3
    dw 0x265b ; 09e0: call    function_057
    dw 0x120a ; 09e1: bcf     PCLATH, 0x4
    dw 0x158a ; 09e2: bsf     PCLATH, 0x3
    dw 0x29e9 ; 09e3: goto    label_184
    dw 0x160a ; 09e4: bsf     PCLATH, 0x4
    dw 0x158a ; 09e5: bsf     PCLATH, 0x3
    dw 0x2655 ; 09e6: call    function_056
    dw 0x120a ; 09e7: bcf     PCLATH, 0x4
    dw 0x158a ; 09e8: bsf     PCLATH, 0x3
    dw 0x1683 ; 09e9: bsf     STATUS, RP0
    dw 0x00d2 ; 09ea: movwf   0x52
    dw 0x1683 ; 09eb: bsf     STATUS, RP0
    dw 0x1303 ; 09ec: bcf     STATUS, RP1
    dw 0x08d2 ; 09ed: movf    0x52, F
    dw 0x1903 ; 09ee: btfsc   STATUS, Z
    dw 0x29f7 ; 09ef: goto    label_186
    dw 0x1283 ; 09f0: bcf     STATUS, RP0
    dw 0x1912 ; 09f1: btfsc   T2CON, TMR2ON
    dw 0x29f7 ; 09f2: goto    label_186
    dw 0x1512 ; 09f3: bsf     T2CON, TMR2ON
    dw 0x1683 ; 09f4: bsf     STATUS, RP0
    dw 0x1703 ; 09f5: bsf     STATUS, RP1
    dw 0x01b2 ; 09f6: clrf    0x32
    dw 0x1683 ; 09f7: bsf     STATUS, RP0
    dw 0x1303 ; 09f8: bcf     STATUS, RP1
    dw 0x0852 ; 09f9: movf    0x52, W
    dw 0x3a0f ; 09fa: xorlw   0x0f
    dw 0x1703 ; 09fb: bsf     STATUS, RP1
    dw 0x1d03 ; 09fc: btfss   STATUS, Z
    dw 0x2a00 ; 09fd: goto    label_187
    dw 0x1732 ; 09fe: bsf     0x32, 0x6
    dw 0x2a01 ; 09ff: goto    label_188
    dw 0x1332 ; 0a00: bcf     0x32, 0x6
    dw 0x0834 ; 0a01: movf    0x34, W
    dw 0x1303 ; 0a02: bcf     STATUS, RP1
    dw 0x0652 ; 0a03: xorwf   0x52, W
    dw 0x1903 ; 0a04: btfsc   STATUS, Z
    dw 0x2a14 ; 0a05: goto    label_191
    dw 0x08d2 ; 0a06: movf    0x52, F
    dw 0x1703 ; 0a07: bsf     STATUS, RP1
    dw 0x1d03 ; 0a08: btfss   STATUS, Z
    dw 0x2a0d ; 0a09: goto    label_189
    dw 0x08b4 ; 0a0a: movf    0x34, F
    dw 0x1d03 ; 0a0b: btfss   STATUS, Z
    dw 0x2a14 ; 0a0c: goto    label_191
    dw 0x1db2 ; 0a0d: btfss   0x32, 0x3
    dw 0x2a11 ; 0a0e: goto    label_190
    dw 0x1632 ; 0a0f: bsf     0x32, 0x4
    dw 0x2a14 ; 0a10: goto    label_191
    dw 0x1303 ; 0a11: bcf     STATUS, RP1
    dw 0x01d6 ; 0a12: clrf    0x56
    dw 0x01d7 ; 0a13: clrf    0x57
    dw 0x1303 ; 0a14: bcf     STATUS, RP1
    dw 0x0852 ; 0a15: movf    0x52, W
    dw 0x1703 ; 0a16: bsf     STATUS, RP1
    dw 0x00b4 ; 0a17: movwf   0x34
    dw 0x2ffe ; 0a18: goto    label_305
    dw 0x160a ; 0a19: bsf     PCLATH, 0x4
    dw 0x158a ; 0a1a: bsf     PCLATH, 0x3
    dw 0x2625 ; 0a1b: call    function_048
    dw 0x00d3 ; 0a1c: movwf   0x53
    dw 0x01d4 ; 0a1d: clrf    0x54
    dw 0x00d1 ; 0a1e: movwf   0x51
    dw 0x0854 ; 0a1f: movf    0x54, W
    dw 0x00d2 ; 0a20: movwf   0x52
    dw 0x0851 ; 0a21: movf    0x51, W
    dw 0x00cf ; 0a22: movwf   0x4f
    dw 0x0852 ; 0a23: movf    0x52, W
    dw 0x00d0 ; 0a24: movwf   0x50
    dw 0x160a ; 0a25: bsf     PCLATH, 0x4
    dw 0x158a ; 0a26: bsf     PCLATH, 0x3
    dw 0x2673 ; 0a27: call    function_060
    dw 0x120a ; 0a28: bcf     PCLATH, 0x4
    dw 0x158a ; 0a29: bsf     PCLATH, 0x3
    dw 0x00d3 ; 0a2a: movwf   0x53
    dw 0x01d4 ; 0a2b: clrf    0x54
    dw 0x3a02 ; 0a2c: xorlw   0x02
    dw 0x0454 ; 0a2d: iorwf   0x54, W
    dw 0x1903 ; 0a2e: btfsc   STATUS, Z
    dw 0x2a3a ; 0a2f: goto    label_193
    dw 0x0853 ; 0a30: movf    0x53, W
    dw 0x3a04 ; 0a31: xorlw   0x04
    dw 0x0454 ; 0a32: iorwf   0x54, W
    dw 0x1903 ; 0a33: btfsc   STATUS, Z
    dw 0x2a3a ; 0a34: goto    label_193
    dw 0x0853 ; 0a35: movf    0x53, W
    dw 0x3a06 ; 0a36: xorlw   0x06
    dw 0x0454 ; 0a37: iorwf   0x54, W
    dw 0x1d03 ; 0a38: btfss   STATUS, Z
    dw 0x2a47 ; 0a39: goto    label_194
    dw 0x160a ; 0a3a: bsf     PCLATH, 0x4
    dw 0x158a ; 0a3b: bsf     PCLATH, 0x3
    dw 0x2697 ; 0a3c: call    function_066
    dw 0x3800 ; 0a3d: iorlw   0x00
    dw 0x1d03 ; 0a3e: btfss   STATUS, Z
    dw 0x1451 ; 0a3f: bsf     0x51, 0x0
    dw 0x0851 ; 0a40: movf    0x51, W
    dw 0x160a ; 0a41: bsf     PCLATH, 0x4
    dw 0x158a ; 0a42: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0a43: call    function_081
    dw 0x120a ; 0a44: bcf     PCLATH, 0x4
    dw 0x158a ; 0a45: bsf     PCLATH, 0x3
    dw 0x2a7c ; 0a46: goto    label_200
    dw 0x0853 ; 0a47: movf    0x53, W
    dw 0x3a03 ; 0a48: xorlw   0x03
    dw 0x0454 ; 0a49: iorwf   0x54, W
    dw 0x1903 ; 0a4a: btfsc   STATUS, Z
    dw 0x2a56 ; 0a4b: goto    label_195
    dw 0x0853 ; 0a4c: movf    0x53, W
    dw 0x3a05 ; 0a4d: xorlw   0x05
    dw 0x0454 ; 0a4e: iorwf   0x54, W
    dw 0x1903 ; 0a4f: btfsc   STATUS, Z
    dw 0x2a56 ; 0a50: goto    label_195
    dw 0x0853 ; 0a51: movf    0x53, W
    dw 0x3a07 ; 0a52: xorlw   0x07
    dw 0x0454 ; 0a53: iorwf   0x54, W
    dw 0x1d03 ; 0a54: btfss   STATUS, Z
    dw 0x2a5f ; 0a55: goto    label_196
    dw 0x160a ; 0a56: bsf     PCLATH, 0x4
    dw 0x158a ; 0a57: bsf     PCLATH, 0x3
    dw 0x2697 ; 0a58: call    function_066
    dw 0x120a ; 0a59: bcf     PCLATH, 0x4
    dw 0x158a ; 0a5a: bsf     PCLATH, 0x3
    dw 0x3800 ; 0a5b: iorlw   0x00
    dw 0x1d03 ; 0a5c: btfss   STATUS, Z
    dw 0x144f ; 0a5d: bsf     0x4f, 0x0
    dw 0x2a76 ; 0a5e: goto    label_199
    dw 0x0353 ; 0a5f: decf    0x53, W
    dw 0x0454 ; 0a60: iorwf   0x54, W
    dw 0x1903 ; 0a61: btfsc   STATUS, Z
    dw 0x2a68 ; 0a62: goto    label_197
    dw 0x0853 ; 0a63: movf    0x53, W
    dw 0x3a0d ; 0a64: xorlw   0x0d
    dw 0x0454 ; 0a65: iorwf   0x54, W
    dw 0x1d03 ; 0a66: btfss   STATUS, Z
    dw 0x2a7c ; 0a67: goto    label_200
    dw 0x160a ; 0a68: bsf     PCLATH, 0x4
    dw 0x158a ; 0a69: bsf     PCLATH, 0x3
    dw 0x2697 ; 0a6a: call    function_066
    dw 0x120a ; 0a6b: bcf     PCLATH, 0x4
    dw 0x158a ; 0a6c: bsf     PCLATH, 0x3
    dw 0x3800 ; 0a6d: iorlw   0x00
    dw 0x1903 ; 0a6e: btfsc   STATUS, Z
    dw 0x2a72 ; 0a6f: goto    label_198
    dw 0x1451 ; 0a70: bsf     0x51, 0x0
    dw 0x144f ; 0a71: bsf     0x4f, 0x0
    dw 0x0851 ; 0a72: movf    0x51, W
    dw 0x160a ; 0a73: bsf     PCLATH, 0x4
    dw 0x158a ; 0a74: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0a75: call    function_081
    dw 0x084f ; 0a76: movf    0x4f, W
    dw 0x160a ; 0a77: bsf     PCLATH, 0x4
    dw 0x158a ; 0a78: bsf     PCLATH, 0x3
    dw 0x27aa ; 0a79: call    function_080
    dw 0x120a ; 0a7a: bcf     PCLATH, 0x4
    dw 0x158a ; 0a7b: bsf     PCLATH, 0x3
    dw 0x0850 ; 0a7c: movf    0x50, W
    dw 0x044f ; 0a7d: iorwf   0x4f, W
    dw 0x1d03 ; 0a7e: btfss   STATUS, Z
    dw 0x2a8c ; 0a7f: goto    label_201
    dw 0x0852 ; 0a80: movf    0x52, W
    dw 0x0451 ; 0a81: iorwf   0x51, W
    dw 0x1d03 ; 0a82: btfss   STATUS, Z
    dw 0x2a8c ; 0a83: goto    label_201
    dw 0x160a ; 0a84: bsf     PCLATH, 0x4
    dw 0x158a ; 0a85: bsf     PCLATH, 0x3
    dw 0x2697 ; 0a86: call    function_066
    dw 0x120a ; 0a87: bcf     PCLATH, 0x4
    dw 0x158a ; 0a88: bsf     PCLATH, 0x3
    dw 0x3800 ; 0a89: iorlw   0x00
    dw 0x1903 ; 0a8a: btfsc   STATUS, Z
    dw 0x2a8f ; 0a8b: goto    label_202
    dw 0x1683 ; 0a8c: bsf     STATUS, RP0
    dw 0x144e ; 0a8d: bsf     0x4e, 0x0
    dw 0x2a94 ; 0a8e: goto    label_203
    dw 0x120a ; 0a8f: bcf     PCLATH, 0x4
    dw 0x118a ; 0a90: bcf     PCLATH, 0x3
    dw 0x2521 ; 0a91: call    function_008
    dw 0x120a ; 0a92: bcf     PCLATH, 0x4
    dw 0x158a ; 0a93: bsf     PCLATH, 0x3
    dw 0x1283 ; 0a94: bcf     STATUS, RP0
    dw 0x1703 ; 0a95: bsf     STATUS, RP1
    dw 0x0822 ; 0a96: movf    0x22, W
    dw 0x3a02 ; 0a97: xorlw   0x02
    dw 0x1903 ; 0a98: btfsc   STATUS, Z
    dw 0x2a9e ; 0a99: goto    label_204
    dw 0x0822 ; 0a9a: movf    0x22, W
    dw 0x3a03 ; 0a9b: xorlw   0x03
    dw 0x1d03 ; 0a9c: btfss   STATUS, Z
    dw 0x2aad ; 0a9d: goto    label_205
    dw 0x083a ; 0a9e: movf    0x3a, W
    dw 0x390f ; 0a9f: andlw   0x0f
    dw 0x1683 ; 0aa0: bsf     STATUS, RP0
    dw 0x1303 ; 0aa1: bcf     STATUS, RP1
    dw 0x00d2 ; 0aa2: movwf   0x52
    dw 0x160a ; 0aa3: bsf     PCLATH, 0x4
    dw 0x158a ; 0aa4: bsf     PCLATH, 0x3
    dw 0x263d ; 0aa5: call    function_052
    dw 0x00d6 ; 0aa6: movwf   0x56
    dw 0x160a ; 0aa7: bsf     PCLATH, 0x4
    dw 0x158a ; 0aa8: bsf     PCLATH, 0x3
    dw 0x26a5 ; 0aa9: call    function_068
    dw 0x120a ; 0aaa: bcf     PCLATH, 0x4
    dw 0x158a ; 0aab: bsf     PCLATH, 0x3
    dw 0x2ac1 ; 0aac: goto    label_207
    dw 0x0822 ; 0aad: movf    0x22, W
    dw 0x3a04 ; 0aae: xorlw   0x04
    dw 0x1903 ; 0aaf: btfsc   STATUS, Z
    dw 0x2ab5 ; 0ab0: goto    label_206
    dw 0x0822 ; 0ab1: movf    0x22, W
    dw 0x3a05 ; 0ab2: xorlw   0x05
    dw 0x1d03 ; 0ab3: btfss   STATUS, Z
    dw 0x2ad1 ; 0ab4: goto    label_208
    dw 0x083a ; 0ab5: movf    0x3a, W
    dw 0x390f ; 0ab6: andlw   0x0f
    dw 0x1683 ; 0ab7: bsf     STATUS, RP0
    dw 0x1303 ; 0ab8: bcf     STATUS, RP1
    dw 0x00d2 ; 0ab9: movwf   0x52
    dw 0x160a ; 0aba: bsf     PCLATH, 0x4
    dw 0x158a ; 0abb: bsf     PCLATH, 0x3
    dw 0x2637 ; 0abc: call    function_051
    dw 0x00d6 ; 0abd: movwf   0x56
    dw 0x160a ; 0abe: bsf     PCLATH, 0x4
    dw 0x158a ; 0abf: bsf     PCLATH, 0x3
    dw 0x26b4 ; 0ac0: call    function_070
    dw 0x160a ; 0ac1: bsf     PCLATH, 0x4
    dw 0x118a ; 0ac2: bcf     PCLATH, 0x3
    dw 0x21e7 ; 0ac3: call    function_028
    dw 0x120a ; 0ac4: bcf     PCLATH, 0x4
    dw 0x158a ; 0ac5: bsf     PCLATH, 0x3
    dw 0x1683 ; 0ac6: bsf     STATUS, RP0
    dw 0x08d2 ; 0ac7: movf    0x52, F
    dw 0x1903 ; 0ac8: btfsc   STATUS, Z
    dw 0x2ad1 ; 0ac9: goto    label_208
    dw 0x1283 ; 0aca: bcf     STATUS, RP0
    dw 0x1912 ; 0acb: btfsc   T2CON, TMR2ON
    dw 0x2ad1 ; 0acc: goto    label_208
    dw 0x1512 ; 0acd: bsf     T2CON, TMR2ON
    dw 0x1683 ; 0ace: bsf     STATUS, RP0
    dw 0x1703 ; 0acf: bsf     STATUS, RP1
    dw 0x01b2 ; 0ad0: clrf    0x32
    dw 0x160a ; 0ad1: bsf     PCLATH, 0x4
    dw 0x158a ; 0ad2: bsf     PCLATH, 0x3
    dw 0x262b ; 0ad3: call    function_049
    dw 0x120a ; 0ad4: bcf     PCLATH, 0x4
    dw 0x158a ; 0ad5: bsf     PCLATH, 0x3
    dw 0x2046 ; 0ad6: call    function_019
    dw 0x2ffe ; 0ad7: goto    label_305
    dw 0x160a ; 0ad8: bsf     PCLATH, 0x4
    dw 0x158a ; 0ad9: bsf     PCLATH, 0x3
    dw 0x2673 ; 0ada: call    function_060
    dw 0x120a ; 0adb: bcf     PCLATH, 0x4
    dw 0x158a ; 0adc: bsf     PCLATH, 0x3
    dw 0x00d3 ; 0add: movwf   0x53
    dw 0x01d4 ; 0ade: clrf    0x54
    dw 0x0854 ; 0adf: movf    0x54, W
    dw 0x3a80 ; 0ae0: xorlw   0x80
    dw 0x00f0 ; 0ae1: movwf   Common_RAM
    dw 0x3080 ; 0ae2: movlw   0x80
    dw 0x0270 ; 0ae3: subwf   Common_RAM, W
    dw 0x3002 ; 0ae4: movlw   0x02
    dw 0x1903 ; 0ae5: btfsc   STATUS, Z
    dw 0x0253 ; 0ae6: subwf   0x53, W
    dw 0x1c03 ; 0ae7: btfss   STATUS, C
    dw 0x2af3 ; 0ae8: goto    label_210
    dw 0x0854 ; 0ae9: movf    0x54, W
    dw 0x3a80 ; 0aea: xorlw   0x80
    dw 0x00f0 ; 0aeb: movwf   Common_RAM
    dw 0x3080 ; 0aec: movlw   0x80
    dw 0x0270 ; 0aed: subwf   Common_RAM, W
    dw 0x3008 ; 0aee: movlw   0x08
    dw 0x1903 ; 0aef: btfsc   STATUS, Z
    dw 0x0253 ; 0af0: subwf   0x53, W
    dw 0x1c03 ; 0af1: btfss   STATUS, C
    dw 0x2e08 ; 0af2: goto    label_278
    dw 0x0353 ; 0af3: decf    0x53, W
    dw 0x0454 ; 0af4: iorwf   0x54, W
    dw 0x1d03 ; 0af5: btfss   STATUS, Z
    dw 0x2ffe ; 0af6: goto    label_305
    dw 0x160a ; 0af7: bsf     PCLATH, 0x4
    dw 0x158a ; 0af8: bsf     PCLATH, 0x3
    dw 0x2613 ; 0af9: call    function_047
    dw 0x120a ; 0afa: bcf     PCLATH, 0x4
    dw 0x158a ; 0afb: bsf     PCLATH, 0x3
    dw 0x3a01 ; 0afc: xorlw   0x01
    dw 0x1d03 ; 0afd: btfss   STATUS, Z
    dw 0x2ffe ; 0afe: goto    label_305
    dw 0x2e08 ; 0aff: goto    label_278
    dw 0x1703 ; 0b00: bsf     STATUS, RP1
    dw 0x0827 ; 0b01: movf    0x27, W
    dw 0x39cf ; 0b02: andlw   0xcf
    dw 0x3820 ; 0b03: iorlw   0x20
    dw 0x00a7 ; 0b04: movwf   0x27
    dw 0x393f ; 0b05: andlw   0x3f
    dw 0x00a7 ; 0b06: movwf   0x27
    dw 0x1683 ; 0b07: bsf     STATUS, RP0
    dw 0x1303 ; 0b08: bcf     STATUS, RP1
    dw 0x00c4 ; 0b09: movwf   0x44
    dw 0x2b37 ; 0b0a: goto    label_218
    dw 0x160a ; 0b0b: bsf     PCLATH, 0x4
    dw 0x158a ; 0b0c: bsf     PCLATH, 0x3
    dw 0x2673 ; 0b0d: call    function_060
    dw 0x120a ; 0b0e: bcf     PCLATH, 0x4
    dw 0x158a ; 0b0f: bsf     PCLATH, 0x3
    dw 0x3a02 ; 0b10: xorlw   0x02
    dw 0x2b1f ; 0b11: goto    label_215
    dw 0x160a ; 0b12: bsf     PCLATH, 0x4
    dw 0x158a ; 0b13: bsf     PCLATH, 0x3
    dw 0x2673 ; 0b14: call    function_060
    dw 0x120a ; 0b15: bcf     PCLATH, 0x4
    dw 0x158a ; 0b16: bsf     PCLATH, 0x3
    dw 0x3a04 ; 0b17: xorlw   0x04
    dw 0x2b1f ; 0b18: goto    label_215
    dw 0x160a ; 0b19: bsf     PCLATH, 0x4
    dw 0x158a ; 0b1a: bsf     PCLATH, 0x3
    dw 0x2673 ; 0b1b: call    function_060
    dw 0x120a ; 0b1c: bcf     PCLATH, 0x4
    dw 0x158a ; 0b1d: bsf     PCLATH, 0x3
    dw 0x3a06 ; 0b1e: xorlw   0x06
    dw 0x1683 ; 0b1f: bsf     STATUS, RP0
    dw 0x1703 ; 0b20: bsf     STATUS, RP1
    dw 0x1d03 ; 0b21: btfss   STATUS, Z
    dw 0x2b2a ; 0b22: goto    label_216
    dw 0x0839 ; 0b23: movf    0x39, W
    dw 0x1303 ; 0b24: bcf     STATUS, RP1
    dw 0x00c5 ; 0b25: movwf   0x45
    dw 0x1703 ; 0b26: bsf     STATUS, RP1
    dw 0x1139 ; 0b27: bcf     0x39, 0x2
    dw 0x11b9 ; 0b28: bcf     0x39, 0x3
    dw 0x2b30 ; 0b29: goto    label_217
    dw 0x083a ; 0b2a: movf    0x3a, W
    dw 0x1303 ; 0b2b: bcf     STATUS, RP1
    dw 0x00c5 ; 0b2c: movwf   0x45
    dw 0x1703 ; 0b2d: bsf     STATUS, RP1
    dw 0x113a ; 0b2e: bcf     0x3a, 0x2
    dw 0x11ba ; 0b2f: bcf     0x3a, 0x3
    dw 0x1303 ; 0b30: bcf     STATUS, RP1
    dw 0x01c6 ; 0b31: clrf    0x46
    dw 0x0844 ; 0b32: movf    0x44, W
    dw 0x07c6 ; 0b33: addwf   0x46, F
    dw 0x0845 ; 0b34: movf    0x45, W
    dw 0x07c6 ; 0b35: addwf   0x46, F
    dw 0x2deb ; 0b36: goto    label_269
    dw 0x1283 ; 0b37: bcf     STATUS, RP0
    dw 0x1703 ; 0b38: bsf     STATUS, RP1
    dw 0x0822 ; 0b39: movf    0x22, W
    dw 0x3a02 ; 0b3a: xorlw   0x02
    dw 0x1903 ; 0b3b: btfsc   STATUS, Z
    dw 0x2b0b ; 0b3c: goto    label_212
    dw 0x3a06 ; 0b3d: xorlw   0x06
    dw 0x1903 ; 0b3e: btfsc   STATUS, Z
    dw 0x2b12 ; 0b3f: goto    label_213
    dw 0x3a02 ; 0b40: xorlw   0x02
    dw 0x1903 ; 0b41: btfsc   STATUS, Z
    dw 0x2b19 ; 0b42: goto    label_214
    dw 0x2e28 ; 0b43: goto    label_279
    dw 0x1683 ; 0b44: bsf     STATUS, RP0
    dw 0x14ce ; 0b45: bsf     0x4e, 0x1
    dw 0x120a ; 0b46: bcf     PCLATH, 0x4
    dw 0x118a ; 0b47: bcf     PCLATH, 0x3
    dw 0x2521 ; 0b48: call    function_008
    dw 0x1683 ; 0b49: bsf     STATUS, RP0
    dw 0x1703 ; 0b4a: bsf     STATUS, RP1
    dw 0x01b5 ; 0b4b: clrf    0x35
    dw 0x01b6 ; 0b4c: clrf    0x36
    dw 0x01b7 ; 0b4d: clrf    0x37
    dw 0x01b8 ; 0b4e: clrf    0x38
    dw 0x01b9 ; 0b4f: clrf    0x39
    dw 0x01ba ; 0b50: clrf    0x3a
    dw 0x1539 ; 0b51: bsf     0x39, 0x2
    dw 0x153a ; 0b52: bsf     0x3a, 0x2
    dw 0x1303 ; 0b53: bcf     STATUS, RP1
    dw 0x17ce ; 0b54: bsf     0x4e, 0x7
    dw 0x1703 ; 0b55: bsf     STATUS, RP1
    dw 0x0190 ; 0b56: clrf    0x10
    dw 0x1283 ; 0b57: bcf     STATUS, RP0
    dw 0x1303 ; 0b58: bcf     STATUS, RP1
    dw 0x01bf ; 0b59: clrf    0x3f
    dw 0x3000 ; 0b5a: movlw   0x00
    dw 0x160a ; 0b5b: bsf     PCLATH, 0x4
    dw 0x158a ; 0b5c: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0b5d: call    function_081
    dw 0x3000 ; 0b5e: movlw   0x00
    dw 0x160a ; 0b5f: bsf     PCLATH, 0x4
    dw 0x158a ; 0b60: bsf     PCLATH, 0x3
    dw 0x27aa ; 0b61: call    function_080
    dw 0x120a ; 0b62: bcf     PCLATH, 0x4
    dw 0x158a ; 0b63: bsf     PCLATH, 0x3
    dw 0x0836 ; 0b64: movf    0x36, W
    dw 0x0086 ; 0b65: movwf   PORTB
    dw 0x0837 ; 0b66: movf    0x37, W
    dw 0x0087 ; 0b67: movwf   PORTC
    dw 0x0838 ; 0b68: movf    0x38, W
    dw 0x0088 ; 0b69: movwf   PORTD
    dw 0x01bd ; 0b6a: clrf    0x3d
    dw 0x01c0 ; 0b6b: clrf    0x40
    dw 0x0ac0 ; 0b6c: incf    0x40, F
    dw 0x302a ; 0b6d: movlw   0x2a
    dw 0x0240 ; 0b6e: subwf   0x40, W
    dw 0x1c03 ; 0b6f: btfss   STATUS, C
    dw 0x2b6c ; 0b70: goto    label_221
    dw 0x01be ; 0b71: clrf    0x3e
    dw 0x0abe ; 0b72: incf    0x3e, F
    dw 0x08bd ; 0b73: movf    0x3d, F
    dw 0x1903 ; 0b74: btfsc   STATUS, Z
    dw 0x2b7d ; 0b75: goto    label_223
    dw 0x01bd ; 0b76: clrf    0x3d
    dw 0x083e ; 0b77: movf    0x3e, W
    dw 0x3a80 ; 0b78: xorlw   0x80
    dw 0x1903 ; 0b79: btfsc   STATUS, Z
    dw 0x2b7d ; 0b7a: goto    label_223
    dw 0x1003 ; 0b7b: bcf     STATUS, C
    dw 0x0cbe ; 0b7c: rrf     0x3e, F
    dw 0x3007 ; 0b7d: movlw   0x07
    dw 0x160a ; 0b7e: bsf     PCLATH, 0x4
    dw 0x118a ; 0b7f: bcf     PCLATH, 0x3
    dw 0x2000 ; 0b80: call    function_021
    dw 0x120a ; 0b81: bcf     PCLATH, 0x4
    dw 0x158a ; 0b82: bsf     PCLATH, 0x3
    dw 0x0870 ; 0b83: movf    Common_RAM, W
    dw 0x00cd ; 0b84: movwf   0x4d
    dw 0x0871 ; 0b85: movf    (Common_RAM + 1), W
    dw 0x00ce ; 0b86: movwf   0x4e
    dw 0x3000 ; 0b87: movlw   0x00
    dw 0x024e ; 0b88: subwf   0x4e, W
    dw 0x3095 ; 0b89: movlw   0x95
    dw 0x1903 ; 0b8a: btfsc   STATUS, Z
    dw 0x024d ; 0b8b: subwf   0x4d, W
    dw 0x1803 ; 0b8c: btfsc   STATUS, C
    dw 0x2b94 ; 0b8d: goto    label_225
    dw 0x01c0 ; 0b8e: clrf    0x40
    dw 0x0ac0 ; 0b8f: incf    0x40, F
    dw 0x3069 ; 0b90: movlw   0x69
    dw 0x0240 ; 0b91: subwf   0x40, W
    dw 0x1c03 ; 0b92: btfss   STATUS, C
    dw 0x2b8f ; 0b93: goto    label_224
    dw 0x3000 ; 0b94: movlw   0x00
    dw 0x024e ; 0b95: subwf   0x4e, W
    dw 0x3095 ; 0b96: movlw   0x95
    dw 0x1903 ; 0b97: btfsc   STATUS, Z
    dw 0x024d ; 0b98: subwf   0x4d, W
    dw 0x1683 ; 0b99: bsf     STATUS, RP0
    dw 0x1803 ; 0b9a: btfsc   STATUS, C
    dw 0x2b9e ; 0b9b: goto    label_226
    dw 0x1bce ; 0b9c: btfsc   0x4e, 0x7
    dw 0x2b7d ; 0b9d: goto    label_223
    dw 0x1fce ; 0b9e: btfss   0x4e, 0x7
    dw 0x2c75 ; 0b9f: goto    label_242
    dw 0x3005 ; 0ba0: movlw   0x05
    dw 0x160a ; 0ba1: bsf     PCLATH, 0x4
    dw 0x118a ; 0ba2: bcf     PCLATH, 0x3
    dw 0x2000 ; 0ba3: call    function_021
    dw 0x120a ; 0ba4: bcf     PCLATH, 0x4
    dw 0x158a ; 0ba5: bsf     PCLATH, 0x3
    dw 0x0870 ; 0ba6: movf    Common_RAM, W
    dw 0x00c9 ; 0ba7: movwf   0x49
    dw 0x0871 ; 0ba8: movf    (Common_RAM + 1), W
    dw 0x00ca ; 0ba9: movwf   0x4a
    dw 0x08bf ; 0baa: movf    0x3f, F
    dw 0x1903 ; 0bab: btfsc   STATUS, Z
    dw 0x2bb4 ; 0bac: goto    label_227
    dw 0x083e ; 0bad: movf    0x3e, W
    dw 0x160a ; 0bae: bsf     PCLATH, 0x4
    dw 0x158a ; 0baf: bsf     PCLATH, 0x3
    dw 0x27aa ; 0bb0: call    function_080
    dw 0x120a ; 0bb1: bcf     PCLATH, 0x4
    dw 0x158a ; 0bb2: bsf     PCLATH, 0x3
    dw 0x2bba ; 0bb3: goto    label_228
    dw 0x083e ; 0bb4: movf    0x3e, W
    dw 0x160a ; 0bb5: bsf     PCLATH, 0x4
    dw 0x158a ; 0bb6: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0bb7: call    function_081
    dw 0x120a ; 0bb8: bcf     PCLATH, 0x4
    dw 0x158a ; 0bb9: bsf     PCLATH, 0x3
    dw 0x3094 ; 0bba: movlw   0x94
    dw 0x009f ; 0bbb: movwf   ADCON0
    dw 0x1683 ; 0bbc: bsf     STATUS, RP0
    dw 0x019f ; 0bbd: clrf    ADCON0
    dw 0x1283 ; 0bbe: bcf     STATUS, RP0
    dw 0x141f ; 0bbf: bsf     ADCON0, ADON
    dw 0x130c ; 0bc0: bcf     PIR1, ADIF
    dw 0x0836 ; 0bc1: movf    0x36, W
    dw 0x0086 ; 0bc2: movwf   PORTB
    dw 0x0837 ; 0bc3: movf    0x37, W
    dw 0x0087 ; 0bc4: movwf   PORTC
    dw 0x0838 ; 0bc5: movf    0x38, W
    dw 0x0088 ; 0bc6: movwf   PORTD
    dw 0x01c0 ; 0bc7: clrf    0x40
    dw 0x0ac0 ; 0bc8: incf    0x40, F
    dw 0x3003 ; 0bc9: movlw   0x03
    dw 0x0240 ; 0bca: subwf   0x40, W
    dw 0x1c03 ; 0bcb: btfss   STATUS, C
    dw 0x2bc8 ; 0bcc: goto    label_229
    dw 0x149f ; 0bcd: bsf     ADCON0, GO
    dw 0x1f0c ; 0bce: btfss   PIR1, ADIF
    dw 0x2bce ; 0bcf: goto    label_230
    dw 0x300f ; 0bd0: movlw   0x0f
    dw 0x0486 ; 0bd1: iorwf   PORTB, F
    dw 0x0487 ; 0bd2: iorwf   PORTC, F
    dw 0x30ff ; 0bd3: movlw   0xff
    dw 0x0088 ; 0bd4: movwf   PORTD
    dw 0x081e ; 0bd5: movf    ADRESH, W
    dw 0x00c6 ; 0bd6: movwf   0x46
    dw 0x1683 ; 0bd7: bsf     STATUS, RP0
    dw 0x081e ; 0bd8: movf    ADRESH, W
    dw 0x1283 ; 0bd9: bcf     STATUS, RP0
    dw 0x00c5 ; 0bda: movwf   0x45
    dw 0x130c ; 0bdb: bcf     PIR1, ADIF
    dw 0x3050 ; 0bdc: movlw   0x50
    dw 0x1683 ; 0bdd: bsf     STATUS, RP0
    dw 0x009f ; 0bde: movwf   ADCON0
    dw 0x3000 ; 0bdf: movlw   0x00
    dw 0x160a ; 0be0: bsf     PCLATH, 0x4
    dw 0x158a ; 0be1: bsf     PCLATH, 0x3
    dw 0x27d5 ; 0be2: call    function_081
    dw 0x3000 ; 0be3: movlw   0x00
    dw 0x160a ; 0be4: bsf     PCLATH, 0x4
    dw 0x158a ; 0be5: bsf     PCLATH, 0x3
    dw 0x27aa ; 0be6: call    function_080
    dw 0x120a ; 0be7: bcf     PCLATH, 0x4
    dw 0x158a ; 0be8: bsf     PCLATH, 0x3
    dw 0x0836 ; 0be9: movf    0x36, W
    dw 0x0086 ; 0bea: movwf   PORTB
    dw 0x0837 ; 0beb: movf    0x37, W
    dw 0x0087 ; 0bec: movwf   PORTC
    dw 0x0838 ; 0bed: movf    0x38, W
    dw 0x0088 ; 0bee: movwf   PORTD
    dw 0x01c0 ; 0bef: clrf    0x40
    dw 0x0ac0 ; 0bf0: incf    0x40, F
    dw 0x3002 ; 0bf1: movlw   0x02
    dw 0x0240 ; 0bf2: subwf   0x40, W
    dw 0x1c03 ; 0bf3: btfss   STATUS, C
    dw 0x2bf0 ; 0bf4: goto    label_231
    dw 0x3005 ; 0bf5: movlw   0x05
    dw 0x160a ; 0bf6: bsf     PCLATH, 0x4
    dw 0x118a ; 0bf7: bcf     PCLATH, 0x3
    dw 0x2000 ; 0bf8: call    function_021
    dw 0x0870 ; 0bf9: movf    Common_RAM, W
    dw 0x00cb ; 0bfa: movwf   0x4b
    dw 0x0871 ; 0bfb: movf    (Common_RAM + 1), W
    dw 0x00cc ; 0bfc: movwf   0x4c
    dw 0x3007 ; 0bfd: movlw   0x07
    dw 0x160a ; 0bfe: bsf     PCLATH, 0x4
    dw 0x118a ; 0bff: bcf     PCLATH, 0x3
    dw 0x2000 ; 0c00: call    function_021
    dw 0x120a ; 0c01: bcf     PCLATH, 0x4
    dw 0x158a ; 0c02: bsf     PCLATH, 0x3
    dw 0x0870 ; 0c03: movf    Common_RAM, W
    dw 0x00cd ; 0c04: movwf   0x4d
    dw 0x0871 ; 0c05: movf    (Common_RAM + 1), W
    dw 0x00ce ; 0c06: movwf   0x4e
    dw 0x084a ; 0c07: movf    0x4a, W
    dw 0x024c ; 0c08: subwf   0x4c, W
    dw 0x1d03 ; 0c09: btfss   STATUS, Z
    dw 0x2c0d ; 0c0a: goto    label_232
    dw 0x0849 ; 0c0b: movf    0x49, W
    dw 0x024b ; 0c0c: subwf   0x4b, W
    dw 0x1803 ; 0c0d: btfsc   STATUS, C
    dw 0x2c1b ; 0c0e: goto    label_233
    dw 0x084b ; 0c0f: movf    0x4b, W
    dw 0x0249 ; 0c10: subwf   0x49, W
    dw 0x00c1 ; 0c11: movwf   0x41
    dw 0x084c ; 0c12: movf    0x4c, W
    dw 0x1c03 ; 0c13: btfss   STATUS, C
    dw 0x0a4c ; 0c14: incf    0x4c, W
    dw 0x024a ; 0c15: subwf   0x4a, W
    dw 0x00c2 ; 0c16: movwf   0x42
    dw 0x0849 ; 0c17: movf    0x49, W
    dw 0x00c7 ; 0c18: movwf   0x47
    dw 0x084a ; 0c19: movf    0x4a, W
    dw 0x2c26 ; 0c1a: goto    label_234
    dw 0x0849 ; 0c1b: movf    0x49, W
    dw 0x024b ; 0c1c: subwf   0x4b, W
    dw 0x00c1 ; 0c1d: movwf   0x41
    dw 0x084a ; 0c1e: movf    0x4a, W
    dw 0x1c03 ; 0c1f: btfss   STATUS, C
    dw 0x0a4a ; 0c20: incf    0x4a, W
    dw 0x024c ; 0c21: subwf   0x4c, W
    dw 0x00c2 ; 0c22: movwf   0x42
    dw 0x084b ; 0c23: movf    0x4b, W
    dw 0x00c7 ; 0c24: movwf   0x47
    dw 0x084c ; 0c25: movf    0x4c, W
    dw 0x00c8 ; 0c26: movwf   0x48
    dw 0x0246 ; 0c27: subwf   0x46, W
    dw 0x1d03 ; 0c28: btfss   STATUS, Z
    dw 0x2c2c ; 0c29: goto    label_235
    dw 0x0847 ; 0c2a: movf    0x47, W
    dw 0x0245 ; 0c2b: subwf   0x45, W
    dw 0x1803 ; 0c2c: btfsc   STATUS, C
    dw 0x2c36 ; 0c2d: goto    label_236
    dw 0x0845 ; 0c2e: movf    0x45, W
    dw 0x0247 ; 0c2f: subwf   0x47, W
    dw 0x00c3 ; 0c30: movwf   0x43
    dw 0x0846 ; 0c31: movf    0x46, W
    dw 0x1c03 ; 0c32: btfss   STATUS, C
    dw 0x0a46 ; 0c33: incf    0x46, W
    dw 0x0248 ; 0c34: subwf   0x48, W
    dw 0x2c3d ; 0c35: goto    label_237
    dw 0x0847 ; 0c36: movf    0x47, W
    dw 0x0245 ; 0c37: subwf   0x45, W
    dw 0x00c3 ; 0c38: movwf   0x43
    dw 0x0848 ; 0c39: movf    0x48, W
    dw 0x1c03 ; 0c3a: btfss   STATUS, C
    dw 0x0a48 ; 0c3b: incf    0x48, W
    dw 0x0246 ; 0c3c: subwf   0x46, W
    dw 0x00c4 ; 0c3d: movwf   0x44
    dw 0x3000 ; 0c3e: movlw   0x00
    dw 0x024e ; 0c3f: subwf   0x4e, W
    dw 0x3096 ; 0c40: movlw   0x96
    dw 0x1903 ; 0c41: btfsc   STATUS, Z
    dw 0x024d ; 0c42: subwf   0x4d, W
    dw 0x1c03 ; 0c43: btfss   STATUS, C
    dw 0x2c6d ; 0c44: goto    label_240
    dw 0x3000 ; 0c45: movlw   0x00
    dw 0x0242 ; 0c46: subwf   0x42, W
    dw 0x300b ; 0c47: movlw   0x0b
    dw 0x1903 ; 0c48: btfsc   STATUS, Z
    dw 0x0241 ; 0c49: subwf   0x41, W
    dw 0x01bd ; 0c4a: clrf    0x3d
    dw 0x1803 ; 0c4b: btfsc   STATUS, C
    dw 0x2c6e ; 0c4c: goto    label_241
    dw 0x1683 ; 0c4d: bsf     STATUS, RP0
    dw 0x1703 ; 0c4e: bsf     STATUS, RP1
    dw 0x0833 ; 0c4f: movf    0x33, W
    dw 0x00f0 ; 0c50: movwf   0x70
    dw 0x01f1 ; 0c51: clrf    0x71
    dw 0x1283 ; 0c52: bcf     STATUS, RP0
    dw 0x1303 ; 0c53: bcf     STATUS, RP1
    dw 0x0844 ; 0c54: movf    0x44, W
    dw 0x3a80 ; 0c55: xorlw   0x80
    dw 0x00f2 ; 0c56: movwf   (Common_RAM + 2)
    dw 0x0871 ; 0c57: movf    (Common_RAM + 1), W
    dw 0x3a80 ; 0c58: xorlw   0x80
    dw 0x0272 ; 0c59: subwf   (Common_RAM + 2), W
    dw 0x1d03 ; 0c5a: btfss   STATUS, Z
    dw 0x2c5e ; 0c5b: goto    label_238
    dw 0x0870 ; 0c5c: movf    Common_RAM, W
    dw 0x0243 ; 0c5d: subwf   0x43, W
    dw 0x1803 ; 0c5e: btfsc   STATUS, C
    dw 0x2c75 ; 0c5f: goto    label_242
    dw 0x08bf ; 0c60: movf    0x3f, F
    dw 0x1903 ; 0c61: btfsc   STATUS, Z
    dw 0x2c68 ; 0c62: goto    label_239
    dw 0x083e ; 0c63: movf    0x3e, W
    dw 0x1683 ; 0c64: bsf     STATUS, RP0
    dw 0x1703 ; 0c65: bsf     STATUS, RP1
    dw 0x04b7 ; 0c66: iorwf   0x37, F
    dw 0x2c75 ; 0c67: goto    label_242
    dw 0x083e ; 0c68: movf    0x3e, W
    dw 0x1683 ; 0c69: bsf     STATUS, RP0
    dw 0x1703 ; 0c6a: bsf     STATUS, RP1
    dw 0x04b5 ; 0c6b: iorwf   0x35, F
    dw 0x2c75 ; 0c6c: goto    label_242
    dw 0x01bd ; 0c6d: clrf    0x3d
    dw 0x0abd ; 0c6e: incf    0x3d, F
    dw 0x083e ; 0c6f: movf    0x3e, W
    dw 0x3a80 ; 0c70: xorlw   0x80
    dw 0x1d03 ; 0c71: btfss   STATUS, Z
    dw 0x2c75 ; 0c72: goto    label_242
    dw 0x3040 ; 0c73: movlw   0x40
    dw 0x00be ; 0c74: movwf   0x3e
    dw 0x1003 ; 0c75: bcf     STATUS, C
    dw 0x1283 ; 0c76: bcf     STATUS, RP0
    dw 0x1303 ; 0c77: bcf     STATUS, RP1
    dw 0x0dbe ; 0c78: rlf     0x3e, F
    dw 0x08be ; 0c79: movf    0x3e, F
    dw 0x1d03 ; 0c7a: btfss   STATUS, Z
    dw 0x2b73 ; 0c7b: goto    label_222
    dw 0x0abf ; 0c7c: incf    0x3f, F
    dw 0x3002 ; 0c7d: movlw   0x02
    dw 0x023f ; 0c7e: subwf   0x3f, W
    dw 0x1c03 ; 0c7f: btfss   STATUS, C
    dw 0x2b5a ; 0c80: goto    label_220
    dw 0x3007 ; 0c81: movlw   0x07
    dw 0x160a ; 0c82: bsf     PCLATH, 0x4
    dw 0x118a ; 0c83: bcf     PCLATH, 0x3
    dw 0x2000 ; 0c84: call    function_021
    dw 0x120a ; 0c85: bcf     PCLATH, 0x4
    dw 0x158a ; 0c86: bsf     PCLATH, 0x3
    dw 0x0870 ; 0c87: movf    Common_RAM, W
    dw 0x00cd ; 0c88: movwf   0x4d
    dw 0x0871 ; 0c89: movf    (Common_RAM + 1), W
    dw 0x00ce ; 0c8a: movwf   0x4e
    dw 0x3000 ; 0c8b: movlw   0x00
    dw 0x024e ; 0c8c: subwf   0x4e, W
    dw 0x3095 ; 0c8d: movlw   0x95
    dw 0x1903 ; 0c8e: btfsc   STATUS, Z
    dw 0x024d ; 0c8f: subwf   0x4d, W
    dw 0x1803 ; 0c90: btfsc   STATUS, C
    dw 0x2c98 ; 0c91: goto    label_245
    dw 0x01c0 ; 0c92: clrf    0x40
    dw 0x0ac0 ; 0c93: incf    0x40, F
    dw 0x3069 ; 0c94: movlw   0x69
    dw 0x0240 ; 0c95: subwf   0x40, W
    dw 0x1c03 ; 0c96: btfss   STATUS, C
    dw 0x2c93 ; 0c97: goto    label_244
    dw 0x3000 ; 0c98: movlw   0x00
    dw 0x024e ; 0c99: subwf   0x4e, W
    dw 0x3095 ; 0c9a: movlw   0x95
    dw 0x1903 ; 0c9b: btfsc   STATUS, Z
    dw 0x024d ; 0c9c: subwf   0x4d, W
    dw 0x1683 ; 0c9d: bsf     STATUS, RP0
    dw 0x1803 ; 0c9e: btfsc   STATUS, C
    dw 0x2ca2 ; 0c9f: goto    label_246
    dw 0x1bce ; 0ca0: btfsc   0x4e, 0x7
    dw 0x2c81 ; 0ca1: goto    label_243
    dw 0x1fce ; 0ca2: btfss   0x4e, 0x7
    dw 0x2cc3 ; 0ca3: goto    label_248
    dw 0x1283 ; 0ca4: bcf     STATUS, RP0
    dw 0x0817 ; 0ca5: movf    CCP1CON, W
    dw 0x00bc ; 0ca6: movwf   0x3c
    dw 0x0197 ; 0ca7: clrf    CCP1CON
    dw 0x3006 ; 0ca8: movlw   0x06
    dw 0x160a ; 0ca9: bsf     PCLATH, 0x4
    dw 0x118a ; 0caa: bcf     PCLATH, 0x3
    dw 0x2000 ; 0cab: call    function_021
    dw 0x120a ; 0cac: bcf     PCLATH, 0x4
    dw 0x158a ; 0cad: bsf     PCLATH, 0x3
    dw 0x0870 ; 0cae: movf    Common_RAM, W
    dw 0x00d3 ; 0caf: movwf   0x53
    dw 0x0871 ; 0cb0: movf    (Common_RAM + 1), W
    dw 0x00d4 ; 0cb1: movwf   0x54
    dw 0x3a80 ; 0cb2: xorlw   0x80
    dw 0x00f0 ; 0cb3: movwf   Common_RAM
    dw 0x3080 ; 0cb4: movlw   0x80
    dw 0x0270 ; 0cb5: subwf   Common_RAM, W
    dw 0x30a5 ; 0cb6: movlw   0xa5
    dw 0x1903 ; 0cb7: btfsc   STATUS, Z
    dw 0x0253 ; 0cb8: subwf   0x53, W
    dw 0x1803 ; 0cb9: btfsc   STATUS, C
    dw 0x2cbf ; 0cba: goto    label_247
    dw 0x1683 ; 0cbb: bsf     STATUS, RP0
    dw 0x1703 ; 0cbc: bsf     STATUS, RP1
    dw 0x1436 ; 0cbd: bsf     0x36, 0x0
    dw 0x1438 ; 0cbe: bsf     0x38, 0x0
    dw 0x1283 ; 0cbf: bcf     STATUS, RP0
    dw 0x1303 ; 0cc0: bcf     STATUS, RP1
    dw 0x083c ; 0cc1: movf    0x3c, W
    dw 0x0097 ; 0cc2: movwf   CCP1CON
    dw 0x120a ; 0cc3: bcf     PCLATH, 0x4
    dw 0x118a ; 0cc4: bcf     PCLATH, 0x3
    dw 0x26db ; 0cc5: call    function_014
    dw 0x120a ; 0cc6: bcf     PCLATH, 0x4
    dw 0x158a ; 0cc7: bsf     PCLATH, 0x3
    dw 0x1683 ; 0cc8: bsf     STATUS, RP0
    dw 0x19d8 ; 0cc9: btfsc   0x58, 0x3
    dw 0x2ccd ; 0cca: goto    label_249
    dw 0x1bce ; 0ccb: btfsc   0x4e, 0x7
    dw 0x2cd7 ; 0ccc: goto    label_250
    dw 0x1703 ; 0ccd: bsf     STATUS, RP1
    dw 0x14b9 ; 0cce: bsf     0x39, 0x1
    dw 0x1739 ; 0ccf: bsf     0x39, 0x6
    dw 0x17b9 ; 0cd0: bsf     0x39, 0x7
    dw 0x1439 ; 0cd1: bsf     0x39, 0x0
    dw 0x14ba ; 0cd2: bsf     0x3a, 0x1
    dw 0x173a ; 0cd3: bsf     0x3a, 0x6
    dw 0x17ba ; 0cd4: bsf     0x3a, 0x7
    dw 0x143a ; 0cd5: bsf     0x3a, 0x0
    dw 0x2d87 ; 0cd6: goto    label_265
    dw 0x1283 ; 0cd7: bcf     STATUS, RP0
    dw 0x01bf ; 0cd8: clrf    0x3f
    dw 0x08bf ; 0cd9: movf    0x3f, F
    dw 0x1683 ; 0cda: bsf     STATUS, RP0
    dw 0x1703 ; 0cdb: bsf     STATUS, RP1
    dw 0x1903 ; 0cdc: btfsc   STATUS, Z
    dw 0x2ce2 ; 0cdd: goto    label_252
    dw 0x0838 ; 0cde: movf    0x38, W
    dw 0x00f1 ; 0cdf: movwf   (Common_RAM + 1)
    dw 0x0837 ; 0ce0: movf    0x37, W
    dw 0x2ce5 ; 0ce1: goto    label_253
    dw 0x0836 ; 0ce2: movf    0x36, W
    dw 0x00f1 ; 0ce3: movwf   (Common_RAM + 1)
    dw 0x0835 ; 0ce4: movf    0x35, W
    dw 0x00f0 ; 0ce5: movwf   Common_RAM
    dw 0x01f1 ; 0ce6: clrf    (Common_RAM + 1)
    dw 0x1283 ; 0ce7: bcf     STATUS, RP0
    dw 0x1303 ; 0ce8: bcf     STATUS, RP1
    dw 0x00d3 ; 0ce9: movwf   0x53
    dw 0x0871 ; 0cea: movf    (Common_RAM + 1), W
    dw 0x00d4 ; 0ceb: movwf   0x54
    dw 0x3a80 ; 0cec: xorlw   0x80
    dw 0x00f0 ; 0ced: movwf   Common_RAM
    dw 0x3080 ; 0cee: movlw   0x80
    dw 0x0270 ; 0cef: subwf   Common_RAM, W
    dw 0x3031 ; 0cf0: movlw   0x31
    dw 0x1903 ; 0cf1: btfsc   STATUS, Z
    dw 0x0253 ; 0cf2: subwf   0x53, W
    dw 0x1c03 ; 0cf3: btfss   STATUS, C
    dw 0x2cfc ; 0cf4: goto    label_255
    dw 0x2d3f ; 0cf5: goto    label_258
    dw 0x083f ; 0cf6: movf    0x3f, W
    dw 0x3eb9 ; 0cf7: addlw   0xb9
    dw 0x0084 ; 0cf8: movwf   FSR
    dw 0x1783 ; 0cf9: bsf     STATUS, IRP
    dw 0x1300 ; 0cfa: bcf     INDF, 0x6
    dw 0x2d44 ; 0cfb: goto    label_259
    dw 0x0854 ; 0cfc: movf    0x54, W
    dw 0x00f3 ; 0cfd: movwf   (Common_RAM + 3)
    dw 0x0853 ; 0cfe: movf    0x53, W
    dw 0x00f2 ; 0cff: movwf   (Common_RAM + 2)
    dw 0x2d3b ; 0d00: goto    label_257
    dw 0x0872 ; 0d01: movf    (Common_RAM + 2), W
    dw 0x00f0 ; 0d02: movwf   Common_RAM
    dw 0x3ed0 ; 0d03: addlw   0xd0
    dw 0x1803 ; 0d04: btfsc   STATUS, C
    dw 0x2cf6 ; 0d05: goto    label_254
    dw 0x3e29 ; 0d06: addlw   0x29
    dw 0x1c03 ; 0d07: btfss   STATUS, C
    dw 0x2cf6 ; 0d08: goto    label_254
    dw 0x3007 ; 0d09: movlw   0x07
    dw 0x02f0 ; 0d0a: subwf   Common_RAM, F
    dw 0x300d ; 0d0b: movlw   0x0d
    dw 0x008a ; 0d0c: movwf   PCLATH
    dw 0x3012 ; 0d0d: movlw   0x12
    dw 0x0770 ; 0d0e: addwf   Common_RAM, W
    dw 0x1803 ; 0d0f: btfsc   STATUS, C
    dw 0x0a8a ; 0d10: incf    PCLATH, F
    dw 0x0082 ; 0d11: movwf   PCL
    dw 0x2d3f ; 0d12: goto    label_258
    dw 0x2cf6 ; 0d13: goto    label_254
    dw 0x2cf6 ; 0d14: goto    label_254
    dw 0x2cf6 ; 0d15: goto    label_254
    dw 0x2d3f ; 0d16: goto    label_258
    dw 0x2cf6 ; 0d17: goto    label_254
    dw 0x2d3f ; 0d18: goto    label_258
    dw 0x2d3f ; 0d19: goto    label_258
    dw 0x2d3f ; 0d1a: goto    label_258
    dw 0x2cf6 ; 0d1b: goto    label_254
    dw 0x2cf6 ; 0d1c: goto    label_254
    dw 0x2cf6 ; 0d1d: goto    label_254
    dw 0x2d3f ; 0d1e: goto    label_258
    dw 0x2cf6 ; 0d1f: goto    label_254
    dw 0x2d3f ; 0d20: goto    label_258
    dw 0x2d3f ; 0d21: goto    label_258
    dw 0x2d3f ; 0d22: goto    label_258
    dw 0x2cf6 ; 0d23: goto    label_254
    dw 0x2d3f ; 0d24: goto    label_258
    dw 0x2d3f ; 0d25: goto    label_258
    dw 0x2d3f ; 0d26: goto    label_258
    dw 0x2d3f ; 0d27: goto    label_258
    dw 0x2d3f ; 0d28: goto    label_258
    dw 0x2d3f ; 0d29: goto    label_258
    dw 0x2d3f ; 0d2a: goto    label_258
    dw 0x2cf6 ; 0d2b: goto    label_254
    dw 0x2cf6 ; 0d2c: goto    label_254
    dw 0x2cf6 ; 0d2d: goto    label_254
    dw 0x2d3f ; 0d2e: goto    label_258
    dw 0x2cf6 ; 0d2f: goto    label_254
    dw 0x2d3f ; 0d30: goto    label_258
    dw 0x2d3f ; 0d31: goto    label_258
    dw 0x2d3f ; 0d32: goto    label_258
    dw 0x2cf6 ; 0d33: goto    label_254
    dw 0x2d3f ; 0d34: goto    label_258
    dw 0x2d3f ; 0d35: goto    label_258
    dw 0x2d3f ; 0d36: goto    label_258
    dw 0x2d3f ; 0d37: goto    label_258
    dw 0x2d3f ; 0d38: goto    label_258
    dw 0x2d3f ; 0d39: goto    label_258
    dw 0x2d3f ; 0d3a: goto    label_258
    dw 0x0873 ; 0d3b: movf    (Common_RAM + 3), W
    dw 0x1903 ; 0d3c: btfsc   STATUS, Z
    dw 0x2d01 ; 0d3d: goto    label_256
    dw 0x2cf6 ; 0d3e: goto    label_254
    dw 0x083f ; 0d3f: movf    0x3f, W
    dw 0x3eb9 ; 0d40: addlw   0xb9
    dw 0x0084 ; 0d41: movwf   FSR
    dw 0x1783 ; 0d42: bsf     STATUS, IRP
    dw 0x1700 ; 0d43: bsf     INDF, 0x6
    dw 0x08bf ; 0d44: movf    0x3f, F
    dw 0x1683 ; 0d45: bsf     STATUS, RP0
    dw 0x1703 ; 0d46: bsf     STATUS, RP1
    dw 0x1903 ; 0d47: btfsc   STATUS, Z
    dw 0x2d51 ; 0d48: goto    label_260
    dw 0x0837 ; 0d49: movf    0x37, W
    dw 0x1283 ; 0d4a: bcf     STATUS, RP0
    dw 0x1303 ; 0d4b: bcf     STATUS, RP1
    dw 0x00d3 ; 0d4c: movwf   0x53
    dw 0x1683 ; 0d4d: bsf     STATUS, RP0
    dw 0x1703 ; 0d4e: bsf     STATUS, RP1
    dw 0x0838 ; 0d4f: movf    0x38, W
    dw 0x2d58 ; 0d50: goto    label_261
    dw 0x0835 ; 0d51: movf    0x35, W
    dw 0x1283 ; 0d52: bcf     STATUS, RP0
    dw 0x1303 ; 0d53: bcf     STATUS, RP1
    dw 0x00d3 ; 0d54: movwf   0x53
    dw 0x1683 ; 0d55: bsf     STATUS, RP0
    dw 0x1703 ; 0d56: bsf     STATUS, RP1
    dw 0x0836 ; 0d57: movf    0x36, W
    dw 0x1283 ; 0d58: bcf     STATUS, RP0
    dw 0x1303 ; 0d59: bcf     STATUS, RP1
    dw 0x00d4 ; 0d5a: movwf   0x54
    dw 0x0453 ; 0d5b: iorwf   0x53, W
    dw 0x1903 ; 0d5c: btfsc   STATUS, Z
    dw 0x2d82 ; 0d5d: goto    label_264
    dw 0x1683 ; 0d5e: bsf     STATUS, RP0
    dw 0x1703 ; 0d5f: bsf     STATUS, RP1
    dw 0x1c36 ; 0d60: btfss   0x36, 0x0
    dw 0x2d6e ; 0d61: goto    label_262
    dw 0x1283 ; 0d62: bcf     STATUS, RP0
    dw 0x1303 ; 0d63: bcf     STATUS, RP1
    dw 0x083f ; 0d64: movf    0x3f, W
    dw 0x3eb9 ; 0d65: addlw   0xb9
    dw 0x0084 ; 0d66: movwf   FSR
    dw 0x1783 ; 0d67: bsf     STATUS, IRP
    dw 0x1480 ; 0d68: bsf     INDF, 0x1
    dw 0x083f ; 0d69: movf    0x3f, W
    dw 0x3eb9 ; 0d6a: addlw   0xb9
    dw 0x0084 ; 0d6b: movwf   FSR
    dw 0x1783 ; 0d6c: bsf     STATUS, IRP
    dw 0x1700 ; 0d6d: bsf     INDF, 0x6
    dw 0x1283 ; 0d6e: bcf     STATUS, RP0
    dw 0x1303 ; 0d6f: bcf     STATUS, RP1
    dw 0x0854 ; 0d70: movf    0x54, W
    dw 0x00f1 ; 0d71: movwf   (Common_RAM + 1)
    dw 0x0853 ; 0d72: movf    0x53, W
    dw 0x00f0 ; 0d73: movwf   Common_RAM
    dw 0x01f1 ; 0d74: clrf    (Common_RAM + 1)
    dw 0x0471 ; 0d75: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 0d76: btfsc   STATUS, Z
    dw 0x2d7d ; 0d77: goto    label_263
    dw 0x083f ; 0d78: movf    0x3f, W
    dw 0x3eb9 ; 0d79: addlw   0xb9
    dw 0x0084 ; 0d7a: movwf   FSR
    dw 0x1783 ; 0d7b: bsf     STATUS, IRP
    dw 0x1400 ; 0d7c: bsf     INDF, 0x0
    dw 0x083f ; 0d7d: movf    0x3f, W
    dw 0x3eb9 ; 0d7e: addlw   0xb9
    dw 0x0084 ; 0d7f: movwf   FSR
    dw 0x1783 ; 0d80: bsf     STATUS, IRP
    dw 0x1780 ; 0d81: bsf     INDF, 0x7
    dw 0x0abf ; 0d82: incf    0x3f, F
    dw 0x3002 ; 0d83: movlw   0x02
    dw 0x023f ; 0d84: subwf   0x3f, W
    dw 0x1c03 ; 0d85: btfss   STATUS, C
    dw 0x2cd9 ; 0d86: goto    label_251
    dw 0x1683 ; 0d87: bsf     STATUS, RP0
    dw 0x1303 ; 0d88: bcf     STATUS, RP1
    dw 0x1fce ; 0d89: btfss   0x4e, 0x7
    dw 0x2d8f ; 0d8a: goto    label_266
    dw 0x1703 ; 0d8b: bsf     STATUS, RP1
    dw 0x11b9 ; 0d8c: bcf     0x39, 0x3
    dw 0x11ba ; 0d8d: bcf     0x3a, 0x3
    dw 0x2d92 ; 0d8e: goto    label_267
    dw 0x1703 ; 0d8f: bsf     STATUS, RP1
    dw 0x15b9 ; 0d90: bsf     0x39, 0x3
    dw 0x15ba ; 0d91: bsf     0x3a, 0x3
    dw 0x1303 ; 0d92: bcf     STATUS, RP1
    dw 0x10ce ; 0d93: bcf     0x4e, 0x1
    dw 0x144e ; 0d94: bsf     0x4e, 0x0
    dw 0x13ce ; 0d95: bcf     0x4e, 0x7
    dw 0x2e28 ; 0d96: goto    label_279
    dw 0x1703 ; 0d97: bsf     STATUS, RP1
    dw 0x0827 ; 0d98: movf    0x27, W
    dw 0x39cf ; 0d99: andlw   0xcf
    dw 0x3820 ; 0d9a: iorlw   0x20
    dw 0x00a7 ; 0d9b: movwf   0x27
    dw 0x393f ; 0d9c: andlw   0x3f
    dw 0x38c0 ; 0d9d: iorlw   0xc0
    dw 0x00a7 ; 0d9e: movwf   0x27
    dw 0x160a ; 0d9f: bsf     PCLATH, 0x4
    dw 0x158a ; 0da0: bsf     PCLATH, 0x3
    dw 0x204c ; 0da1: call    function_042
    dw 0x00f0 ; 0da2: movwf   Common_RAM
    dw 0x0631 ; 0da3: xorwf   0x31, W
    dw 0x3900 ; 0da4: andlw   0x00
    dw 0x0670 ; 0da5: xorwf   Common_RAM, W
    dw 0x00b1 ; 0da6: movwf   0x31
    dw 0x160a ; 0da7: bsf     PCLATH, 0x4
    dw 0x158a ; 0da8: bsf     PCLATH, 0x3
    dw 0x204f ; 0da9: call    function_043
    dw 0x00f0 ; 0daa: movwf   Common_RAM
    dw 0x0632 ; 0dab: xorwf   0x32, W
    dw 0x3900 ; 0dac: andlw   0x00
    dw 0x0670 ; 0dad: xorwf   Common_RAM, W
    dw 0x00b2 ; 0dae: movwf   0x32
    dw 0x3006 ; 0daf: movlw   0x06
    dw 0x120a ; 0db0: bcf     PCLATH, 0x4
    dw 0x118a ; 0db1: bcf     PCLATH, 0x3
    dw 0x2698 ; 0db2: call    function_013
    dw 0x00f0 ; 0db3: movwf   Common_RAM
    dw 0x1703 ; 0db4: bsf     STATUS, RP1
    dw 0x0633 ; 0db5: xorwf   0x33, W
    dw 0x3900 ; 0db6: andlw   0x00
    dw 0x0670 ; 0db7: xorwf   Common_RAM, W
    dw 0x00b3 ; 0db8: movwf   0x33
    dw 0x3007 ; 0db9: movlw   0x07
    dw 0x120a ; 0dba: bcf     PCLATH, 0x4
    dw 0x118a ; 0dbb: bcf     PCLATH, 0x3
    dw 0x2698 ; 0dbc: call    function_013
    dw 0x120a ; 0dbd: bcf     PCLATH, 0x4
    dw 0x158a ; 0dbe: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0dbf: movwf   Common_RAM
    dw 0x1703 ; 0dc0: bsf     STATUS, RP1
    dw 0x0634 ; 0dc1: xorwf   0x34, W
    dw 0x3900 ; 0dc2: andlw   0x00
    dw 0x0670 ; 0dc3: xorwf   Common_RAM, W
    dw 0x00b4 ; 0dc4: movwf   0x34
    dw 0x0827 ; 0dc5: movf    0x27, W
    dw 0x1683 ; 0dc6: bsf     STATUS, RP0
    dw 0x1303 ; 0dc7: bcf     STATUS, RP1
    dw 0x00c4 ; 0dc8: movwf   0x44
    dw 0x1283 ; 0dc9: bcf     STATUS, RP0
    dw 0x1703 ; 0dca: bsf     STATUS, RP1
    dw 0x0831 ; 0dcb: movf    0x31, W
    dw 0x1683 ; 0dcc: bsf     STATUS, RP0
    dw 0x1303 ; 0dcd: bcf     STATUS, RP1
    dw 0x00c5 ; 0dce: movwf   0x45
    dw 0x1283 ; 0dcf: bcf     STATUS, RP0
    dw 0x1703 ; 0dd0: bsf     STATUS, RP1
    dw 0x0832 ; 0dd1: movf    0x32, W
    dw 0x1683 ; 0dd2: bsf     STATUS, RP0
    dw 0x1303 ; 0dd3: bcf     STATUS, RP1
    dw 0x00c6 ; 0dd4: movwf   0x46
    dw 0x1283 ; 0dd5: bcf     STATUS, RP0
    dw 0x1703 ; 0dd6: bsf     STATUS, RP1
    dw 0x0833 ; 0dd7: movf    0x33, W
    dw 0x1683 ; 0dd8: bsf     STATUS, RP0
    dw 0x1303 ; 0dd9: bcf     STATUS, RP1
    dw 0x00c7 ; 0dda: movwf   0x47
    dw 0x1283 ; 0ddb: bcf     STATUS, RP0
    dw 0x1703 ; 0ddc: bsf     STATUS, RP1
    dw 0x0834 ; 0ddd: movf    0x34, W
    dw 0x1683 ; 0dde: bsf     STATUS, RP0
    dw 0x1303 ; 0ddf: bcf     STATUS, RP1
    dw 0x00c8 ; 0de0: movwf   0x48
    dw 0x01c9 ; 0de1: clrf    0x49
    dw 0x07c9 ; 0de2: addwf   0x49, F
    dw 0x0847 ; 0de3: movf    0x47, W
    dw 0x07c9 ; 0de4: addwf   0x49, F
    dw 0x0846 ; 0de5: movf    0x46, W
    dw 0x07c9 ; 0de6: addwf   0x49, F
    dw 0x0845 ; 0de7: movf    0x45, W
    dw 0x07c9 ; 0de8: addwf   0x49, F
    dw 0x0844 ; 0de9: movf    0x44, W
    dw 0x07c9 ; 0dea: addwf   0x49, F
    dw 0x160c ; 0deb: bsf     PIR1, TXIF
    dw 0x1698 ; 0dec: bsf     RCSTA, SREN
    dw 0x2e28 ; 0ded: goto    label_279
    dw 0x1703 ; 0dee: bsf     STATUS, RP1
    dw 0x0847 ; 0def: movf    0x47, W
    dw 0x1303 ; 0df0: bcf     STATUS, RP1
    dw 0x00d3 ; 0df1: movwf   0x53
    dw 0x1703 ; 0df2: bsf     STATUS, RP1
    dw 0x0848 ; 0df3: movf    0x48, W
    dw 0x1303 ; 0df4: bcf     STATUS, RP1
    dw 0x2e05 ; 0df5: goto    label_276
    dw 0x3007 ; 0df6: movlw   0x07
    dw 0x2dfd ; 0df7: goto    label_275
    dw 0x3005 ; 0df8: movlw   0x05
    dw 0x2dfd ; 0df9: goto    label_275
    dw 0x3006 ; 0dfa: movlw   0x06
    dw 0x2dfd ; 0dfb: goto    label_275
    dw 0x3000 ; 0dfc: movlw   0x00
    dw 0x160a ; 0dfd: bsf     PCLATH, 0x4
    dw 0x118a ; 0dfe: bcf     PCLATH, 0x3
    dw 0x2000 ; 0dff: call    function_021
    dw 0x120a ; 0e00: bcf     PCLATH, 0x4
    dw 0x158a ; 0e01: bsf     PCLATH, 0x3
    dw 0x0870 ; 0e02: movf    Common_RAM, W
    dw 0x00d3 ; 0e03: movwf   0x53
    dw 0x0871 ; 0e04: movf    (Common_RAM + 1), W
    dw 0x00d4 ; 0e05: movwf   0x54
    dw 0x2e28 ; 0e06: goto    label_279
    dw 0x2e07 ; 0e07: goto    label_277
    dw 0x160a ; 0e08: bsf     PCLATH, 0x4
    dw 0x158a ; 0e09: bsf     PCLATH, 0x3
    dw 0x2613 ; 0e0a: call    function_047
    dw 0x120a ; 0e0b: bcf     PCLATH, 0x4
    dw 0x158a ; 0e0c: bsf     PCLATH, 0x3
    dw 0x3a00 ; 0e0d: xorlw   0x00
    dw 0x1903 ; 0e0e: btfsc   STATUS, Z
    dw 0x2b00 ; 0e0f: goto    label_211
    dw 0x3a01 ; 0e10: xorlw   0x01
    dw 0x1903 ; 0e11: btfsc   STATUS, Z
    dw 0x2b44 ; 0e12: goto    label_219
    dw 0x3a05 ; 0e13: xorlw   0x05
    dw 0x1903 ; 0e14: btfsc   STATUS, Z
    dw 0x2dee ; 0e15: goto    label_270
    dw 0x3a0c ; 0e16: xorlw   0x0c
    dw 0x1903 ; 0e17: btfsc   STATUS, Z
    dw 0x2df6 ; 0e18: goto    label_271
    dw 0x3a04 ; 0e19: xorlw   0x04
    dw 0x1903 ; 0e1a: btfsc   STATUS, Z
    dw 0x2df8 ; 0e1b: goto    label_272
    dw 0x3a1c ; 0e1c: xorlw   0x1c
    dw 0x1903 ; 0e1d: btfsc   STATUS, Z
    dw 0x2dfa ; 0e1e: goto    label_273
    dw 0x3a04 ; 0e1f: xorlw   0x04
    dw 0x1903 ; 0e20: btfsc   STATUS, Z
    dw 0x2e07 ; 0e21: goto    label_277
    dw 0x3a0c ; 0e22: xorlw   0x0c
    dw 0x1903 ; 0e23: btfsc   STATUS, Z
    dw 0x2dfc ; 0e24: goto    label_274
    dw 0x3a98 ; 0e25: xorlw   0x98
    dw 0x1903 ; 0e26: btfsc   STATUS, Z
    dw 0x2d97 ; 0e27: goto    label_268
    dw 0x160a ; 0e28: bsf     PCLATH, 0x4
    dw 0x158a ; 0e29: bsf     PCLATH, 0x3
    dw 0x2613 ; 0e2a: call    function_047
    dw 0x120a ; 0e2b: bcf     PCLATH, 0x4
    dw 0x158a ; 0e2c: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0e2d: movwf   Common_RAM
    dw 0x3002 ; 0e2e: movlw   0x02
    dw 0x0270 ; 0e2f: subwf   Common_RAM, W
    dw 0x1c03 ; 0e30: btfss   STATUS, C
    dw 0x2ffe ; 0e31: goto    label_305
    dw 0x160a ; 0e32: bsf     PCLATH, 0x4
    dw 0x158a ; 0e33: bsf     PCLATH, 0x3
    dw 0x2613 ; 0e34: call    function_047
    dw 0x120a ; 0e35: bcf     PCLATH, 0x4
    dw 0x158a ; 0e36: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0e37: movwf   Common_RAM
    dw 0x3080 ; 0e38: movlw   0x80
    dw 0x0270 ; 0e39: subwf   Common_RAM, W
    dw 0x1803 ; 0e3a: btfsc   STATUS, C
    dw 0x2ffe ; 0e3b: goto    label_305
    dw 0x1703 ; 0e3c: bsf     STATUS, RP1
    dw 0x0827 ; 0e3d: movf    0x27, W
    dw 0x39cf ; 0e3e: andlw   0xcf
    dw 0x3820 ; 0e3f: iorlw   0x20
    dw 0x00a7 ; 0e40: movwf   0x27
    dw 0x393f ; 0e41: andlw   0x3f
    dw 0x38c0 ; 0e42: iorlw   0xc0
    dw 0x00a7 ; 0e43: movwf   0x27
    dw 0x1303 ; 0e44: bcf     STATUS, RP1
    dw 0x0854 ; 0e45: movf    0x54, W
    dw 0x00f0 ; 0e46: movwf   Common_RAM
    dw 0x1703 ; 0e47: bsf     STATUS, RP1
    dw 0x0631 ; 0e48: xorwf   0x31, W
    dw 0x3900 ; 0e49: andlw   0x00
    dw 0x0670 ; 0e4a: xorwf   Common_RAM, W
    dw 0x00b1 ; 0e4b: movwf   0x31
    dw 0x0832 ; 0e4c: movf    0x32, W
    dw 0x1303 ; 0e4d: bcf     STATUS, RP1
    dw 0x0653 ; 0e4e: xorwf   0x53, W
    dw 0x3900 ; 0e4f: andlw   0x00
    dw 0x0653 ; 0e50: xorwf   0x53, W
    dw 0x1703 ; 0e51: bsf     STATUS, RP1
    dw 0x00b2 ; 0e52: movwf   0x32
    dw 0x0833 ; 0e53: movf    0x33, W
    dw 0x3900 ; 0e54: andlw   0x00
    dw 0x00b3 ; 0e55: movwf   0x33
    dw 0x0834 ; 0e56: movf    0x34, W
    dw 0x3900 ; 0e57: andlw   0x00
    dw 0x00b4 ; 0e58: movwf   0x34
    dw 0x0827 ; 0e59: movf    0x27, W
    dw 0x1683 ; 0e5a: bsf     STATUS, RP0
    dw 0x1303 ; 0e5b: bcf     STATUS, RP1
    dw 0x00c4 ; 0e5c: movwf   0x44
    dw 0x1283 ; 0e5d: bcf     STATUS, RP0
    dw 0x1703 ; 0e5e: bsf     STATUS, RP1
    dw 0x0831 ; 0e5f: movf    0x31, W
    dw 0x1683 ; 0e60: bsf     STATUS, RP0
    dw 0x1303 ; 0e61: bcf     STATUS, RP1
    dw 0x00c5 ; 0e62: movwf   0x45
    dw 0x1283 ; 0e63: bcf     STATUS, RP0
    dw 0x1703 ; 0e64: bsf     STATUS, RP1
    dw 0x0832 ; 0e65: movf    0x32, W
    dw 0x1683 ; 0e66: bsf     STATUS, RP0
    dw 0x1303 ; 0e67: bcf     STATUS, RP1
    dw 0x00c6 ; 0e68: movwf   0x46
    dw 0x1283 ; 0e69: bcf     STATUS, RP0
    dw 0x1703 ; 0e6a: bsf     STATUS, RP1
    dw 0x0833 ; 0e6b: movf    0x33, W
    dw 0x1683 ; 0e6c: bsf     STATUS, RP0
    dw 0x1303 ; 0e6d: bcf     STATUS, RP1
    dw 0x00c7 ; 0e6e: movwf   0x47
    dw 0x1283 ; 0e6f: bcf     STATUS, RP0
    dw 0x1703 ; 0e70: bsf     STATUS, RP1
    dw 0x0834 ; 0e71: movf    0x34, W
    dw 0x1683 ; 0e72: bsf     STATUS, RP0
    dw 0x1303 ; 0e73: bcf     STATUS, RP1
    dw 0x00c8 ; 0e74: movwf   0x48
    dw 0x01c9 ; 0e75: clrf    0x49
    dw 0x07c9 ; 0e76: addwf   0x49, F
    dw 0x0847 ; 0e77: movf    0x47, W
    dw 0x07c9 ; 0e78: addwf   0x49, F
    dw 0x0846 ; 0e79: movf    0x46, W
    dw 0x07c9 ; 0e7a: addwf   0x49, F
    dw 0x0845 ; 0e7b: movf    0x45, W
    dw 0x07c9 ; 0e7c: addwf   0x49, F
    dw 0x0844 ; 0e7d: movf    0x44, W
    dw 0x07c9 ; 0e7e: addwf   0x49, F
    dw 0x160c ; 0e7f: bsf     PIE1, TXIE
    dw 0x1698 ; 0e80: bsf     TXSTA, TXEN
    dw 0x2ffe ; 0e81: goto    label_305
    dw 0x160a ; 0e82: bsf     PCLATH, 0x4
    dw 0x158a ; 0e83: bsf     PCLATH, 0x3
    dw 0x26bd ; 0e84: call    function_071
    dw 0x120a ; 0e85: bcf     PCLATH, 0x4
    dw 0x158a ; 0e86: bsf     PCLATH, 0x3
    dw 0x3a01 ; 0e87: xorlw   0x01
    dw 0x1d03 ; 0e88: btfss   STATUS, Z
    dw 0x2fd3 ; 0e89: goto    label_301
    dw 0x160a ; 0e8a: bsf     PCLATH, 0x4
    dw 0x158a ; 0e8b: bsf     PCLATH, 0x3
    dw 0x2673 ; 0e8c: call    function_060
    dw 0x120a ; 0e8d: bcf     PCLATH, 0x4
    dw 0x158a ; 0e8e: bsf     PCLATH, 0x3
    dw 0x3a01 ; 0e8f: xorlw   0x01
    dw 0x1d03 ; 0e90: btfss   STATUS, Z
    dw 0x2ffe ; 0e91: goto    label_305
    dw 0x160a ; 0e92: bsf     PCLATH, 0x4
    dw 0x158a ; 0e93: bsf     PCLATH, 0x3
    dw 0x267f ; 0e94: call    function_062
    dw 0x120a ; 0e95: bcf     PCLATH, 0x4
    dw 0x158a ; 0e96: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0e97: movwf   Common_RAM
    dw 0x3065 ; 0e98: movlw   0x65
    dw 0x0270 ; 0e99: subwf   Common_RAM, W
    dw 0x1803 ; 0e9a: btfsc   STATUS, C
    dw 0x2ea2 ; 0e9b: goto    label_281
    dw 0x160a ; 0e9c: bsf     PCLATH, 0x4
    dw 0x158a ; 0e9d: bsf     PCLATH, 0x3
    dw 0x267f ; 0e9e: call    function_062
    dw 0x120a ; 0e9f: bcf     PCLATH, 0x4
    dw 0x158a ; 0ea0: bsf     PCLATH, 0x3
    dw 0x2ea3 ; 0ea1: goto    label_282
    dw 0x3064 ; 0ea2: movlw   0x64
    dw 0x1703 ; 0ea3: bsf     STATUS, RP1
    dw 0x00a0 ; 0ea4: movwf   0x20
    dw 0x2046 ; 0ea5: call    function_019
    dw 0x160a ; 0ea6: bsf     PCLATH, 0x4
    dw 0x158a ; 0ea7: bsf     PCLATH, 0x3
    dw 0x2631 ; 0ea8: call    function_050
    dw 0x120a ; 0ea9: bcf     PCLATH, 0x4
    dw 0x158a ; 0eaa: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0eab: movwf   Common_RAM
    dw 0x3004 ; 0eac: movlw   0x04
    dw 0x0270 ; 0ead: subwf   Common_RAM, W
    dw 0x1803 ; 0eae: btfsc   STATUS, C
    dw 0x2eb6 ; 0eaf: goto    label_283
    dw 0x160a ; 0eb0: bsf     PCLATH, 0x4
    dw 0x158a ; 0eb1: bsf     PCLATH, 0x3
    dw 0x2631 ; 0eb2: call    function_050
    dw 0x120a ; 0eb3: bcf     PCLATH, 0x4
    dw 0x158a ; 0eb4: bsf     PCLATH, 0x3
    dw 0x2eb7 ; 0eb5: goto    label_284
    dw 0x3003 ; 0eb6: movlw   0x03
    dw 0x1703 ; 0eb7: bsf     STATUS, RP1
    dw 0x00a5 ; 0eb8: movwf   0x25
    dw 0x160a ; 0eb9: bsf     PCLATH, 0x4
    dw 0x158a ; 0eba: bsf     PCLATH, 0x3
    dw 0x2679 ; 0ebb: call    function_061
    dw 0x120a ; 0ebc: bcf     PCLATH, 0x4
    dw 0x158a ; 0ebd: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0ebe: movwf   Common_RAM
    dw 0x3004 ; 0ebf: movlw   0x04
    dw 0x0270 ; 0ec0: subwf   Common_RAM, W
    dw 0x1803 ; 0ec1: btfsc   STATUS, C
    dw 0x2ec9 ; 0ec2: goto    label_285
    dw 0x160a ; 0ec3: bsf     PCLATH, 0x4
    dw 0x158a ; 0ec4: bsf     PCLATH, 0x3
    dw 0x2679 ; 0ec5: call    function_061
    dw 0x120a ; 0ec6: bcf     PCLATH, 0x4
    dw 0x158a ; 0ec7: bsf     PCLATH, 0x3
    dw 0x2eca ; 0ec8: goto    label_286
    dw 0x3003 ; 0ec9: movlw   0x03
    dw 0x1703 ; 0eca: bsf     STATUS, RP1
    dw 0x00a6 ; 0ecb: movwf   0x26
    dw 0x160a ; 0ecc: bsf     PCLATH, 0x4
    dw 0x158a ; 0ecd: bsf     PCLATH, 0x3
    dw 0x269e ; 0ece: call    function_067
    dw 0x1703 ; 0ecf: bsf     STATUS, RP1
    dw 0x00a3 ; 0ed0: movwf   0x23
    dw 0x160a ; 0ed1: bsf     PCLATH, 0x4
    dw 0x158a ; 0ed2: bsf     PCLATH, 0x3
    dw 0x26cf ; 0ed3: call    function_073
    dw 0x120a ; 0ed4: bcf     PCLATH, 0x4
    dw 0x158a ; 0ed5: bsf     PCLATH, 0x3
    dw 0x1703 ; 0ed6: bsf     STATUS, RP1
    dw 0x00a4 ; 0ed7: movwf   0x24
    dw 0x2eeb ; 0ed8: goto    label_290
    dw 0x0823 ; 0ed9: movf    0x23, W
    dw 0x1683 ; 0eda: bsf     STATUS, RP0
    dw 0x00c2 ; 0edb: movwf   0x42
    dw 0x1283 ; 0edc: bcf     STATUS, RP0
    dw 0x0825 ; 0edd: movf    0x25, W
    dw 0x2ee4 ; 0ede: goto    label_289
    dw 0x0824 ; 0edf: movf    0x24, W
    dw 0x1683 ; 0ee0: bsf     STATUS, RP0
    dw 0x00c2 ; 0ee1: movwf   0x42
    dw 0x1283 ; 0ee2: bcf     STATUS, RP0
    dw 0x0826 ; 0ee3: movf    0x26, W
    dw 0x1683 ; 0ee4: bsf     STATUS, RP0
    dw 0x00c3 ; 0ee5: movwf   0x43
    dw 0x19b2 ; 0ee6: btfsc   0x32, 0x3
    dw 0x1b32 ; 0ee7: btfsc   0x32, 0x6
    dw 0x2fe0 ; 0ee8: goto    label_303
    dw 0x16b2 ; 0ee9: bsf     0x32, 0x5
    dw 0x2ffe ; 0eea: goto    label_305
    dw 0x0822 ; 0eeb: movf    0x22, W
    dw 0x3a02 ; 0eec: xorlw   0x02
    dw 0x1903 ; 0eed: btfsc   STATUS, Z
    dw 0x2ed9 ; 0eee: goto    label_287
    dw 0x3a06 ; 0eef: xorlw   0x06
    dw 0x1903 ; 0ef0: btfsc   STATUS, Z
    dw 0x2edf ; 0ef1: goto    label_288
    dw 0x3a02 ; 0ef2: xorlw   0x02
    dw 0x1903 ; 0ef3: btfsc   STATUS, Z
    dw 0x2ed9 ; 0ef4: goto    label_287
    dw 0x2ffe ; 0ef5: goto    label_305
    dw 0x160a ; 0ef6: bsf     PCLATH, 0x4
    dw 0x158a ; 0ef7: bsf     PCLATH, 0x3
    dw 0x2691 ; 0ef8: call    function_065
    dw 0x120a ; 0ef9: bcf     PCLATH, 0x4
    dw 0x158a ; 0efa: bsf     PCLATH, 0x3
    dw 0x3a02 ; 0efb: xorlw   0x02
    dw 0x1903 ; 0efc: btfsc   STATUS, Z
    dw 0x2f0e ; 0efd: goto    label_292
    dw 0x160a ; 0efe: bsf     PCLATH, 0x4
    dw 0x158a ; 0eff: bsf     PCLATH, 0x3
    dw 0x2691 ; 0f00: call    function_065
    dw 0x120a ; 0f01: bcf     PCLATH, 0x4
    dw 0x158a ; 0f02: bsf     PCLATH, 0x3
    dw 0x3a04 ; 0f03: xorlw   0x04
    dw 0x1903 ; 0f04: btfsc   STATUS, Z
    dw 0x2f0e ; 0f05: goto    label_292
    dw 0x160a ; 0f06: bsf     PCLATH, 0x4
    dw 0x158a ; 0f07: bsf     PCLATH, 0x3
    dw 0x2691 ; 0f08: call    function_065
    dw 0x120a ; 0f09: bcf     PCLATH, 0x4
    dw 0x158a ; 0f0a: bsf     PCLATH, 0x3
    dw 0x3a06 ; 0f0b: xorlw   0x06
    dw 0x1d03 ; 0f0c: btfss   STATUS, Z
    dw 0x2f15 ; 0f0d: goto    label_293
    dw 0x160a ; 0f0e: bsf     PCLATH, 0x4
    dw 0x158a ; 0f0f: bsf     PCLATH, 0x3
    dw 0x2691 ; 0f10: call    function_065
    dw 0x120a ; 0f11: bcf     PCLATH, 0x4
    dw 0x158a ; 0f12: bsf     PCLATH, 0x3
    dw 0x1703 ; 0f13: bsf     STATUS, RP1
    dw 0x00a2 ; 0f14: movwf   0x22
    dw 0x1703 ; 0f15: bsf     STATUS, RP1
    dw 0x0822 ; 0f16: movf    0x22, W
    dw 0x1303 ; 0f17: bcf     STATUS, RP1
    dw 0x00d7 ; 0f18: movwf   0x57
    dw 0x3005 ; 0f19: movlw   0x05
    dw 0x2f59 ; 0f1a: goto    label_297
    dw 0x0837 ; 0f1b: movf    0x37, W
    dw 0x39ff ; 0f1c: andlw   0xff
    dw 0x1303 ; 0f1d: bcf     STATUS, RP1
    dw 0x00d7 ; 0f1e: movwf   0x57
    dw 0x1703 ; 0f1f: bsf     STATUS, RP1
    dw 0x0836 ; 0f20: movf    0x36, W
    dw 0x39ff ; 0f21: andlw   0xff
    dw 0x2f59 ; 0f22: goto    label_297
    dw 0x0827 ; 0f23: movf    0x27, W
    dw 0x39cf ; 0f24: andlw   0xcf
    dw 0x3820 ; 0f25: iorlw   0x20
    dw 0x00a7 ; 0f26: movwf   0x27
    dw 0x393f ; 0f27: andlw   0x3f
    dw 0x00a7 ; 0f28: movwf   0x27
    dw 0x0836 ; 0f29: movf    0x36, W
    dw 0x39ff ; 0f2a: andlw   0xff
    dw 0x120a ; 0f2b: bcf     PCLATH, 0x4
    dw 0x118a ; 0f2c: bcf     PCLATH, 0x3
    dw 0x267a ; 0f2d: call    function_012
    dw 0x120a ; 0f2e: bcf     PCLATH, 0x4
    dw 0x158a ; 0f2f: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0f30: movwf   Common_RAM
    dw 0x1703 ; 0f31: bsf     STATUS, RP1
    dw 0x0631 ; 0f32: xorwf   0x31, W
    dw 0x3900 ; 0f33: andlw   0x00
    dw 0x0670 ; 0f34: xorwf   Common_RAM, W
    dw 0x00b1 ; 0f35: movwf   0x31
    dw 0x0827 ; 0f36: movf    0x27, W
    dw 0x1683 ; 0f37: bsf     STATUS, RP0
    dw 0x1303 ; 0f38: bcf     STATUS, RP1
    dw 0x00c4 ; 0f39: movwf   0x44
    dw 0x1283 ; 0f3a: bcf     STATUS, RP0
    dw 0x1703 ; 0f3b: bsf     STATUS, RP1
    dw 0x0831 ; 0f3c: movf    0x31, W
    dw 0x1683 ; 0f3d: bsf     STATUS, RP0
    dw 0x1303 ; 0f3e: bcf     STATUS, RP1
    dw 0x00c5 ; 0f3f: movwf   0x45
    dw 0x01c6 ; 0f40: clrf    0x46
    dw 0x07c6 ; 0f41: addwf   0x46, F
    dw 0x0844 ; 0f42: movf    0x44, W
    dw 0x07c6 ; 0f43: addwf   0x46, F
    dw 0x2fc1 ; 0f44: goto    label_299
    dw 0x0837 ; 0f45: movf    0x37, W
    dw 0x39ff ; 0f46: andlw   0xff
    dw 0x1303 ; 0f47: bcf     STATUS, RP1
    dw 0x00d7 ; 0f48: movwf   0x57
    dw 0x1703 ; 0f49: bsf     STATUS, RP1
    dw 0x0836 ; 0f4a: movf    0x36, W
    dw 0x39ff ; 0f4b: andlw   0xff
    dw 0x160a ; 0f4c: bsf     PCLATH, 0x4
    dw 0x118a ; 0f4d: bcf     PCLATH, 0x3
    dw 0x25cc ; 0f4e: call    function_034
    dw 0x1703 ; 0f4f: bsf     STATUS, RP1
    dw 0x0838 ; 0f50: movf    0x38, W
    dw 0x39ff ; 0f51: andlw   0xff
    dw 0x1303 ; 0f52: bcf     STATUS, RP1
    dw 0x00d7 ; 0f53: movwf   0x57
    dw 0x1703 ; 0f54: bsf     STATUS, RP1
    dw 0x0836 ; 0f55: movf    0x36, W
    dw 0x39ff ; 0f56: andlw   0xff
    dw 0x00f0 ; 0f57: movwf   Common_RAM
    dw 0x0a70 ; 0f58: incf    Common_RAM, W
    dw 0x160a ; 0f59: bsf     PCLATH, 0x4
    dw 0x118a ; 0f5a: bcf     PCLATH, 0x3
    dw 0x25cc ; 0f5b: call    function_034
    dw 0x160a ; 0f5c: bsf     PCLATH, 0x4
    dw 0x118a ; 0f5d: bcf     PCLATH, 0x3
    dw 0x224b ; 0f5e: call    function_029
    dw 0x120a ; 0f5f: bcf     PCLATH, 0x4
    dw 0x158a ; 0f60: bsf     PCLATH, 0x3
    dw 0x2fde ; 0f61: goto    label_302
    dw 0x0827 ; 0f62: movf    0x27, W
    dw 0x39cf ; 0f63: andlw   0xcf
    dw 0x3820 ; 0f64: iorlw   0x20
    dw 0x00a7 ; 0f65: movwf   0x27
    dw 0x393f ; 0f66: andlw   0x3f
    dw 0x38c0 ; 0f67: iorlw   0xc0
    dw 0x00a7 ; 0f68: movwf   0x27
    dw 0x0836 ; 0f69: movf    0x36, W
    dw 0x39ff ; 0f6a: andlw   0xff
    dw 0x120a ; 0f6b: bcf     PCLATH, 0x4
    dw 0x118a ; 0f6c: bcf     PCLATH, 0x3
    dw 0x267a ; 0f6d: call    function_012
    dw 0x00f0 ; 0f6e: movwf   Common_RAM
    dw 0x1703 ; 0f6f: bsf     STATUS, RP1
    dw 0x0631 ; 0f70: xorwf   0x31, W
    dw 0x3900 ; 0f71: andlw   0x00
    dw 0x0670 ; 0f72: xorwf   Common_RAM, W
    dw 0x00b1 ; 0f73: movwf   0x31
    dw 0x0836 ; 0f74: movf    0x36, W
    dw 0x39ff ; 0f75: andlw   0xff
    dw 0x00f0 ; 0f76: movwf   Common_RAM
    dw 0x0a70 ; 0f77: incf    Common_RAM, W
    dw 0x120a ; 0f78: bcf     PCLATH, 0x4
    dw 0x118a ; 0f79: bcf     PCLATH, 0x3
    dw 0x267a ; 0f7a: call    function_012
    dw 0x00f0 ; 0f7b: movwf   Common_RAM
    dw 0x1703 ; 0f7c: bsf     STATUS, RP1
    dw 0x0632 ; 0f7d: xorwf   0x32, W
    dw 0x3900 ; 0f7e: andlw   0x00
    dw 0x0670 ; 0f7f: xorwf   Common_RAM, W
    dw 0x00b2 ; 0f80: movwf   0x32
    dw 0x0836 ; 0f81: movf    0x36, W
    dw 0x39ff ; 0f82: andlw   0xff
    dw 0x3e02 ; 0f83: addlw   0x02
    dw 0x120a ; 0f84: bcf     PCLATH, 0x4
    dw 0x118a ; 0f85: bcf     PCLATH, 0x3
    dw 0x267a ; 0f86: call    function_012
    dw 0x00f0 ; 0f87: movwf   Common_RAM
    dw 0x1703 ; 0f88: bsf     STATUS, RP1
    dw 0x0633 ; 0f89: xorwf   0x33, W
    dw 0x3900 ; 0f8a: andlw   0x00
    dw 0x0670 ; 0f8b: xorwf   Common_RAM, W
    dw 0x00b3 ; 0f8c: movwf   0x33
    dw 0x0836 ; 0f8d: movf    0x36, W
    dw 0x39ff ; 0f8e: andlw   0xff
    dw 0x3e03 ; 0f8f: addlw   0x03
    dw 0x120a ; 0f90: bcf     PCLATH, 0x4
    dw 0x118a ; 0f91: bcf     PCLATH, 0x3
    dw 0x267a ; 0f92: call    function_012
    dw 0x120a ; 0f93: bcf     PCLATH, 0x4
    dw 0x158a ; 0f94: bsf     PCLATH, 0x3
    dw 0x00f0 ; 0f95: movwf   Common_RAM
    dw 0x1703 ; 0f96: bsf     STATUS, RP1
    dw 0x0634 ; 0f97: xorwf   0x34, W
    dw 0x3900 ; 0f98: andlw   0x00
    dw 0x0670 ; 0f99: xorwf   Common_RAM, W
    dw 0x00b4 ; 0f9a: movwf   0x34
    dw 0x0827 ; 0f9b: movf    0x27, W
    dw 0x1683 ; 0f9c: bsf     STATUS, RP0
    dw 0x1303 ; 0f9d: bcf     STATUS, RP1
    dw 0x00c4 ; 0f9e: movwf   0x44
    dw 0x1283 ; 0f9f: bcf     STATUS, RP0
    dw 0x1703 ; 0fa0: bsf     STATUS, RP1
    dw 0x0831 ; 0fa1: movf    0x31, W
    dw 0x1683 ; 0fa2: bsf     STATUS, RP0
    dw 0x1303 ; 0fa3: bcf     STATUS, RP1
    dw 0x00c5 ; 0fa4: movwf   0x45
    dw 0x1283 ; 0fa5: bcf     STATUS, RP0
    dw 0x1703 ; 0fa6: bsf     STATUS, RP1
    dw 0x0832 ; 0fa7: movf    0x32, W
    dw 0x1683 ; 0fa8: bsf     STATUS, RP0
    dw 0x1303 ; 0fa9: bcf     STATUS, RP1
    dw 0x00c6 ; 0faa: movwf   0x46
    dw 0x1283 ; 0fab: bcf     STATUS, RP0
    dw 0x1703 ; 0fac: bsf     STATUS, RP1
    dw 0x0833 ; 0fad: movf    0x33, W
    dw 0x1683 ; 0fae: bsf     STATUS, RP0
    dw 0x1303 ; 0faf: bcf     STATUS, RP1
    dw 0x00c7 ; 0fb0: movwf   0x47
    dw 0x1283 ; 0fb1: bcf     STATUS, RP0
    dw 0x1703 ; 0fb2: bsf     STATUS, RP1
    dw 0x0834 ; 0fb3: movf    0x34, W
    dw 0x1683 ; 0fb4: bsf     STATUS, RP0
    dw 0x1303 ; 0fb5: bcf     STATUS, RP1
    dw 0x00c8 ; 0fb6: movwf   0x48
    dw 0x01c9 ; 0fb7: clrf    0x49
    dw 0x07c9 ; 0fb8: addwf   0x49, F
    dw 0x0847 ; 0fb9: movf    0x47, W
    dw 0x07c9 ; 0fba: addwf   0x49, F
    dw 0x0846 ; 0fbb: movf    0x46, W
    dw 0x07c9 ; 0fbc: addwf   0x49, F
    dw 0x0845 ; 0fbd: movf    0x45, W
    dw 0x07c9 ; 0fbe: addwf   0x49, F
    dw 0x0844 ; 0fbf: movf    0x44, W
    dw 0x07c9 ; 0fc0: addwf   0x49, F
    dw 0x160c ; 0fc1: bsf     PIR1, TXIF
    dw 0x1698 ; 0fc2: bsf     RCSTA, SREN
    dw 0x2fde ; 0fc3: goto    label_302
    dw 0x1703 ; 0fc4: bsf     STATUS, RP1
    dw 0x0835 ; 0fc5: movf    0x35, W
    dw 0x39ff ; 0fc6: andlw   0xff
    dw 0x1903 ; 0fc7: btfsc   STATUS, Z
    dw 0x2f1b ; 0fc8: goto    label_294
    dw 0x3a01 ; 0fc9: xorlw   0x01
    dw 0x1903 ; 0fca: btfsc   STATUS, Z
    dw 0x2f23 ; 0fcb: goto    label_295
    dw 0x3a03 ; 0fcc: xorlw   0x03
    dw 0x1903 ; 0fcd: btfsc   STATUS, Z
    dw 0x2f45 ; 0fce: goto    label_296
    dw 0x3a01 ; 0fcf: xorlw   0x01
    dw 0x1903 ; 0fd0: btfsc   STATUS, Z
    dw 0x2f62 ; 0fd1: goto    label_298
    dw 0x2fde ; 0fd2: goto    label_302
    dw 0x160a ; 0fd3: bsf     PCLATH, 0x4
    dw 0x158a ; 0fd4: bsf     PCLATH, 0x3
    dw 0x26bd ; 0fd5: call    function_071
    dw 0x120a ; 0fd6: bcf     PCLATH, 0x4
    dw 0x158a ; 0fd7: bsf     PCLATH, 0x3
    dw 0x3a00 ; 0fd8: xorlw   0x00
    dw 0x1903 ; 0fd9: btfsc   STATUS, Z
    dw 0x2ef6 ; 0fda: goto    label_291
    dw 0x3a03 ; 0fdb: xorlw   0x03
    dw 0x1903 ; 0fdc: btfsc   STATUS, Z
    dw 0x2fc4 ; 0fdd: goto    label_300
    dw 0x1683 ; 0fde: bsf     STATUS, RP0
    dw 0x1703 ; 0fdf: bsf     STATUS, RP1
    dw 0x0843 ; 0fe0: movf    0x43, W
    dw 0x1283 ; 0fe1: bcf     STATUS, RP0
    dw 0x1303 ; 0fe2: bcf     STATUS, RP1
    dw 0x00d6 ; 0fe3: movwf   0x56
    dw 0x1683 ; 0fe4: bsf     STATUS, RP0
    dw 0x1703 ; 0fe5: bsf     STATUS, RP1
    dw 0x0842 ; 0fe6: movf    0x42, W
    dw 0x160a ; 0fe7: bsf     PCLATH, 0x4
    dw 0x118a ; 0fe8: bcf     PCLATH, 0x3
    dw 0x21e7 ; 0fe9: call    function_028
    dw 0x120a ; 0fea: bcf     PCLATH, 0x4
    dw 0x158a ; 0feb: bsf     PCLATH, 0x3
    dw 0x2ffe ; 0fec: goto    label_305
    dw 0x160a ; 0fed: bsf     PCLATH, 0x4
    dw 0x158a ; 0fee: bsf     PCLATH, 0x3
    dw 0x2685 ; 0fef: call    function_063
    dw 0x120a ; 0ff0: bcf     PCLATH, 0x4
    dw 0x158a ; 0ff1: bsf     PCLATH, 0x3
    dw 0x3a00 ; 0ff2: xorlw   0x00
    dw 0x1903 ; 0ff3: btfsc   STATUS, Z
    dw 0x28e9 ; 0ff4: goto    label_167
    dw 0x3a01 ; 0ff5: xorlw   0x01
    dw 0x1903 ; 0ff6: btfsc   STATUS, Z
    dw 0x2a19 ; 0ff7: goto    label_192
    dw 0x3a03 ; 0ff8: xorlw   0x03
    dw 0x1903 ; 0ff9: btfsc   STATUS, Z
    dw 0x2ad8 ; 0ffa: goto    label_209
    dw 0x3a01 ; 0ffb: xorlw   0x01
    dw 0x1903 ; 0ffc: btfsc   STATUS, Z
    dw 0x2e82 ; 0ffd: goto    label_280
    dw 0x0183 ; 0ffe: clrf    STATUS
    dw 0x0008 ; 0fff: return
    dw 0x0183 ; 1000: clrf    STATUS
    dw 0x00d6 ; 1001: movwf   0x56
    dw 0x1003 ; 1002: bcf     STATUS, C
    dw 0x0dd6 ; 1003: rlf     0x56, F
    dw 0x1003 ; 1004: bcf     STATUS, C
    dw 0x0dd6 ; 1005: rlf     0x56, F
    dw 0x30e3 ; 1006: movlw   0xe3
    dw 0x059f ; 1007: andwf   ADCON0, F
    dw 0x0856 ; 1008: movf    0x56, W
    dw 0x049f ; 1009: iorwf   ADCON0, F
    dw 0x141f ; 100a: bsf     ADCON0, ADON
    dw 0x01d7 ; 100b: clrf    0x57
    dw 0x0000 ; 100c: nop
    dw 0x0ad7 ; 100d: incf    0x57, F
    dw 0x3005 ; 100e: movlw   0x05
    dw 0x0257 ; 100f: subwf   0x57, W
    dw 0x1c03 ; 1010: btfss   STATUS, C
    dw 0x280c ; 1011: goto    label_146
    dw 0x149f ; 1012: bsf     ADCON0, GO
    dw 0x189f ; 1013: btfsc   ADCON0, GO
    dw 0x2813 ; 1014: goto    label_147
    dw 0x101f ; 1015: bcf     ADCON0, ADON
    dw 0x081e ; 1016: movf    ADRESH, W
    dw 0x00f1 ; 1017: movwf   (Common_RAM + 1)
    dw 0x01f0 ; 1018: clrf    Common_RAM
    dw 0x1683 ; 1019: bsf     STATUS, RP0
    dw 0x081e ; 101a: movf    ADRESH, W
    dw 0x04f0 ; 101b: iorwf   Common_RAM, F
    dw 0x1283 ; 101c: bcf     STATUS, RP0
    dw 0x0008 ; 101d: return
    dw 0x0183 ; 101e: clrf    STATUS
    dw 0x00cc ; 101f: movwf   0x4c
    dw 0x3005 ; 1020: movlw   0x05
    dw 0x024c ; 1021: subwf   0x4c, W
    dw 0x1803 ; 1022: btfsc   STATUS, C
    dw 0x3401 ; 1023: retlw   0x01
    dw 0x084b ; 1024: movf    0x4b, W
    dw 0x044a ; 1025: iorwf   0x4a, W
    dw 0x1903 ; 1026: btfsc   STATUS, Z
    dw 0x283a ; 1027: goto    label_149
    dw 0x084a ; 1028: movf    0x4a, W
    dw 0x00cd ; 1029: movwf   0x4d
    dw 0x084b ; 102a: movf    0x4b, W
    dw 0x00ce ; 102b: movwf   0x4e
    dw 0x084c ; 102c: movf    0x4c, W
    dw 0x00cf ; 102d: movwf   0x4f
    dw 0x01d0 ; 102e: clrf    0x50
    dw 0x0ad0 ; 102f: incf    0x50, F
    dw 0x160a ; 1030: bsf     PCLATH, 0x4
    dw 0x158a ; 1031: bsf     PCLATH, 0x3
    dw 0x25fe ; 1032: call    function_044
    dw 0x160a ; 1033: bsf     PCLATH, 0x4
    dw 0x118a ; 1034: bcf     PCLATH, 0x3
    dw 0x00f0 ; 1035: movwf   Common_RAM
    dw 0x01f1 ; 1036: clrf    (Common_RAM + 1)
    dw 0x0471 ; 1037: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 1038: btfsc   STATUS, Z
    dw 0x3407 ; 1039: retlw   0x07
    dw 0x160a ; 103a: bsf     PCLATH, 0x4
    dw 0x158a ; 103b: bsf     PCLATH, 0x3
    dw 0x26d8 ; 103c: call    function_074
    dw 0x084c ; 103d: movf    0x4c, W
    dw 0x074c ; 103e: addwf   0x4c, W
    dw 0x3eb5 ; 103f: addlw   0xb5
    dw 0x0084 ; 1040: movwf   FSR
    dw 0x1383 ; 1041: bcf     STATUS, IRP
    dw 0x084a ; 1042: movf    0x4a, W
    dw 0x0080 ; 1043: movwf   INDF
    dw 0x0a84 ; 1044: incf    FSR, F
    dw 0x084b ; 1045: movf    0x4b, W
    dw 0x0080 ; 1046: movwf   INDF
    dw 0x160a ; 1047: bsf     PCLATH, 0x4
    dw 0x158a ; 1048: bsf     PCLATH, 0x3
    dw 0x26ac ; 1049: call    function_069
    dw 0x160a ; 104a: bsf     PCLATH, 0x4
    dw 0x118a ; 104b: bcf     PCLATH, 0x3
    dw 0x3400 ; 104c: retlw   0x00
    dw 0x0183 ; 104d: clrf    STATUS
    dw 0x00bd ; 104e: movwf   0x3d
    dw 0x01bc ; 104f: clrf    0x3c
    dw 0x3004 ; 1050: movlw   0x04
    dw 0x0ab5 ; 1051: incf    0x35, F
    dw 0x0235 ; 1052: subwf   0x35, W
    dw 0x1803 ; 1053: btfsc   STATUS, C
    dw 0x2872 ; 1054: goto    label_309
    dw 0x08bd ; 1055: movf    0x3d, F
    dw 0x1d03 ; 1056: btfss   STATUS, Z
    dw 0x286a ; 1057: goto    label_307
    dw 0x160a ; 1058: bsf     PCLATH, 0x4
    dw 0x118a ; 1059: bcf     PCLATH, 0x3
    dw 0x26e8 ; 105a: call    function_037
    dw 0x160a ; 105b: bsf     PCLATH, 0x4
    dw 0x118a ; 105c: bcf     PCLATH, 0x3
    dw 0x286d ; 105d: goto    label_308
    dw 0x160a ; 105e: bsf     PCLATH, 0x4
    dw 0x118a ; 105f: bcf     PCLATH, 0x3
    dw 0x26e8 ; 1060: call    function_037
    dw 0x160a ; 1061: bsf     PCLATH, 0x4
    dw 0x118a ; 1062: bcf     PCLATH, 0x3
    dw 0x2795 ; 1063: call    function_041
    dw 0x160a ; 1064: bsf     PCLATH, 0x4
    dw 0x118a ; 1065: bcf     PCLATH, 0x3
    dw 0x3a05 ; 1066: xorlw   0x05
    dw 0x1903 ; 1067: btfsc   STATUS, Z
    dw 0x286d ; 1068: goto    label_308
    dw 0x03bd ; 1069: decf    0x3d, F
    dw 0x08bd ; 106a: movf    0x3d, F
    dw 0x1d03 ; 106b: btfss   STATUS, Z
    dw 0x285e ; 106c: goto    label_306
    dw 0x08bd ; 106d: movf    0x3d, F
    dw 0x1d03 ; 106e: btfss   STATUS, Z
    dw 0x2879 ; 106f: goto    label_311
    dw 0x3005 ; 1070: movlw   0x05
    dw 0x2878 ; 1071: goto    label_310
    dw 0x160a ; 1072: bsf     PCLATH, 0x4
    dw 0x118a ; 1073: bcf     PCLATH, 0x3
    dw 0x26e8 ; 1074: call    function_037
    dw 0x160a ; 1075: bsf     PCLATH, 0x4
    dw 0x118a ; 1076: bcf     PCLATH, 0x3
    dw 0x3006 ; 1077: movlw   0x06
    dw 0x00bc ; 1078: movwf   0x3c
    dw 0x03b5 ; 1079: decf    0x35, F
    dw 0x0860 ; 107a: movf    0x60, W
    dw 0x083c ; 107b: movf    0x3c, W
    dw 0x0008 ; 107c: return
    dw 0x0183 ; 107d: clrf    STATUS
    dw 0x00c6 ; 107e: movwf   0x46
    dw 0x0843 ; 107f: movf    0x43, W
    dw 0x160a ; 1080: bsf     PCLATH, 0x4
    dw 0x158a ; 1081: bsf     PCLATH, 0x3
    dw 0x2741 ; 1082: call    function_078
    dw 0x160a ; 1083: bsf     PCLATH, 0x4
    dw 0x118a ; 1084: bcf     PCLATH, 0x3
    dw 0x0870 ; 1085: movf    Common_RAM, W
    dw 0x00c8 ; 1086: movwf   0x48
    dw 0x0871 ; 1087: movf    (Common_RAM + 1), W
    dw 0x00c9 ; 1088: movwf   0x49
    dw 0x28a2 ; 1089: goto    label_314
    dw 0x0843 ; 108a: movf    0x43, W
    dw 0x00ca ; 108b: movwf   0x4a
    dw 0x0846 ; 108c: movf    0x46, W
    dw 0x160a ; 108d: bsf     PCLATH, 0x4
    dw 0x158a ; 108e: bsf     PCLATH, 0x3
    dw 0x2722 ; 108f: call    function_077
    dw 0x160a ; 1090: bsf     PCLATH, 0x4
    dw 0x118a ; 1091: bcf     PCLATH, 0x3
    dw 0x00c7 ; 1092: movwf   0x47
    dw 0x3a02 ; 1093: xorlw   0x02
    dw 0x1d03 ; 1094: btfss   STATUS, Z
    dw 0x28a0 ; 1095: goto    label_313
    dw 0x0848 ; 1096: movf    0x48, W
    dw 0x00ca ; 1097: movwf   0x4a
    dw 0x0849 ; 1098: movf    0x49, W
    dw 0x00cb ; 1099: movwf   0x4b
    dw 0x0843 ; 109a: movf    0x43, W
    dw 0x160a ; 109b: bsf     PCLATH, 0x4
    dw 0x118a ; 109c: bcf     PCLATH, 0x3
    dw 0x201e ; 109d: call    function_022
    dw 0x160a ; 109e: bsf     PCLATH, 0x4
    dw 0x118a ; 109f: bcf     PCLATH, 0x3
    dw 0x0847 ; 10a0: movf    0x47, W
    dw 0x0008 ; 10a1: return
    dw 0x0844 ; 10a2: movf    0x44, W
    dw 0x00ca ; 10a3: movwf   0x4a
    dw 0x0845 ; 10a4: movf    0x45, W
    dw 0x00cb ; 10a5: movwf   0x4b
    dw 0x0843 ; 10a6: movf    0x43, W
    dw 0x160a ; 10a7: bsf     PCLATH, 0x4
    dw 0x118a ; 10a8: bcf     PCLATH, 0x3
    dw 0x201e ; 10a9: call    function_022
    dw 0x160a ; 10aa: bsf     PCLATH, 0x4
    dw 0x118a ; 10ab: bcf     PCLATH, 0x3
    dw 0x3a00 ; 10ac: xorlw   0x00
    dw 0x1903 ; 10ad: btfsc   STATUS, Z
    dw 0x288a ; 10ae: goto    label_312
    dw 0x3a01 ; 10af: xorlw   0x01
    dw 0x1903 ; 10b0: btfsc   STATUS, Z
    dw 0x3401 ; 10b1: retlw   0x01
    dw 0x3402 ; 10b2: retlw   0x02
    dw 0x0183 ; 10b3: clrf    STATUS
    dw 0x01bf ; 10b4: clrf    0x3f
    dw 0x28f2 ; 10b5: goto    label_316
    dw 0x3003 ; 10b6: movlw   0x03
    dw 0x00f2 ; 10b7: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 10b8: clrf    (Common_RAM + 3)
    dw 0x083f ; 10b9: movf    0x3f, W
    dw 0x00f0 ; 10ba: movwf   Common_RAM
    dw 0x01f1 ; 10bb: clrf    (Common_RAM + 1)
    dw 0x160a ; 10bc: bsf     PCLATH, 0x4
    dw 0x158a ; 10bd: bsf     PCLATH, 0x3
    dw 0x26ee ; 10be: call    function_076
    dw 0x083c ; 10bf: movf    0x3c, W
    dw 0x07f4 ; 10c0: addwf   (Common_RAM + 4), F
    dw 0x1803 ; 10c1: btfsc   STATUS, C
    dw 0x0af5 ; 10c2: incf    (Common_RAM + 5), F
    dw 0x083d ; 10c3: movf    0x3d, W
    dw 0x07f5 ; 10c4: addwf   (Common_RAM + 5), F
    dw 0x0875 ; 10c5: movf    (Common_RAM + 5), W
    dw 0x00e7 ; 10c6: movwf   0x67
    dw 0x0874 ; 10c7: movf    (Common_RAM + 4), W
    dw 0x3e01 ; 10c8: addlw   0x01
    dw 0x1803 ; 10c9: btfsc   STATUS, C
    dw 0x0ae7 ; 10ca: incf    0x67, F
    dw 0x120a ; 10cb: bcf     PCLATH, 0x4
    dw 0x118a ; 10cc: bcf     PCLATH, 0x3
    dw 0x21e7 ; 10cd: call    function_003
    dw 0x00f0 ; 10ce: movwf   Common_RAM
    dw 0x120a ; 10cf: bcf     PCLATH, 0x4
    dw 0x118a ; 10d0: bcf     PCLATH, 0x3
    dw 0x21ea ; 10d1: call    function_004
    dw 0x00f1 ; 10d2: movwf   (Common_RAM + 1)
    dw 0x0870 ; 10d3: movf    Common_RAM, W
    dw 0x00ca ; 10d4: movwf   0x4a
    dw 0x0871 ; 10d5: movf    (Common_RAM + 1), W
    dw 0x00cb ; 10d6: movwf   0x4b
    dw 0x3003 ; 10d7: movlw   0x03
    dw 0x00f2 ; 10d8: movwf   (Common_RAM + 2)
    dw 0x01f3 ; 10d9: clrf    (Common_RAM + 3)
    dw 0x083f ; 10da: movf    0x3f, W
    dw 0x00f0 ; 10db: movwf   Common_RAM
    dw 0x01f1 ; 10dc: clrf    (Common_RAM + 1)
    dw 0x160a ; 10dd: bsf     PCLATH, 0x4
    dw 0x158a ; 10de: bsf     PCLATH, 0x3
    dw 0x26ee ; 10df: call    function_076
    dw 0x0875 ; 10e0: movf    (Common_RAM + 5), W
    dw 0x073d ; 10e1: addwf   0x3d, W
    dw 0x00e7 ; 10e2: movwf   0x67
    dw 0x0874 ; 10e3: movf    (Common_RAM + 4), W
    dw 0x073c ; 10e4: addwf   0x3c, W
    dw 0x1803 ; 10e5: btfsc   STATUS, C
    dw 0x0ae7 ; 10e6: incf    0x67, F
    dw 0x120a ; 10e7: bcf     PCLATH, 0x4
    dw 0x118a ; 10e8: bcf     PCLATH, 0x3
    dw 0x21e7 ; 10e9: call    function_003
    dw 0x160a ; 10ea: bsf     PCLATH, 0x4
    dw 0x118a ; 10eb: bcf     PCLATH, 0x3
    dw 0x201e ; 10ec: call    function_022
    dw 0x160a ; 10ed: bsf     PCLATH, 0x4
    dw 0x118a ; 10ee: bcf     PCLATH, 0x3
    dw 0x00f0 ; 10ef: movwf   Common_RAM
    dw 0x01f1 ; 10f0: clrf    (Common_RAM + 1)
    dw 0x0abf ; 10f1: incf    0x3f, F
    dw 0x083e ; 10f2: movf    0x3e, W
    dw 0x023f ; 10f3: subwf   0x3f, W
    dw 0x1803 ; 10f4: btfsc   STATUS, C
    dw 0x0008 ; 10f5: return
    dw 0x28b6 ; 10f6: goto    label_315
    dw 0x0183 ; 10f7: clrf    STATUS
    dw 0x00be ; 10f8: movwf   0x3e
    dw 0x3005 ; 10f9: movlw   0x05
    dw 0x023e ; 10fa: subwf   0x3e, W
    dw 0x1803 ; 10fb: btfsc   STATUS, C
    dw 0x3401 ; 10fc: retlw   0x01
    dw 0x083e ; 10fd: movf    0x3e, W
    dw 0x073e ; 10fe: addwf   0x3e, W
    dw 0x3eb5 ; 10ff: addlw   0xb5
    dw 0x0084 ; 1100: movwf   FSR
    dw 0x1383 ; 1101: bcf     STATUS, IRP
    dw 0x0800 ; 1102: movf    INDF, W
    dw 0x00f0 ; 1103: movwf   Common_RAM
    dw 0x0a84 ; 1104: incf    FSR, F
    dw 0x0800 ; 1105: movf    INDF, W
    dw 0x00f1 ; 1106: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1107: iorwf   Common_RAM, W
    dw 0x1903 ; 1108: btfsc   STATUS, Z
    dw 0x3403 ; 1109: retlw   0x03
    dw 0x083e ; 110a: movf    0x3e, W
    dw 0x3ea2 ; 110b: addlw   0xa2
    dw 0x0084 ; 110c: movwf   FSR
    dw 0x0f00 ; 110d: incfsz  INDF, W
    dw 0x2910 ; 110e: goto    label_317
    dw 0x3404 ; 110f: retlw   0x04
    dw 0x0000 ; 1110: nop
    dw 0x1283 ; 1111: bcf     STATUS, RP0
    dw 0x1303 ; 1112: bcf     STATUS, RP1
    dw 0x0aa9 ; 1113: incf    0x29, F
    dw 0x0b29 ; 1114: decfsz  0x29, W
    dw 0x291a ; 1115: goto    label_318
    dw 0x080b ; 1116: movf    INTCON, W
    dw 0x3980 ; 1117: andlw   0x80
    dw 0x00aa ; 1118: movwf   0x2a
    dw 0x138b ; 1119: bcf     INTCON, GIE
    dw 0x1683 ; 111a: bsf     STATUS, RP0
    dw 0x0aa0 ; 111b: incf    0x20, F
    dw 0x1283 ; 111c: bcf     STATUS, RP0
    dw 0x083e ; 111d: movf    0x3e, W
    dw 0x00f0 ; 111e: movwf   Common_RAM
    dw 0x1003 ; 111f: bcf     STATUS, C
    dw 0x0cf0 ; 1120: rrf     Common_RAM, F
    dw 0x1003 ; 1121: bcf     STATUS, C
    dw 0x0cf0 ; 1122: rrf     Common_RAM, F
    dw 0x1003 ; 1123: bcf     STATUS, C
    dw 0x0c70 ; 1124: rrf     Common_RAM, W
    dw 0x3ea1 ; 1125: addlw   0xa1
    dw 0x0084 ; 1126: movwf   FSR
    dw 0x3018 ; 1127: movlw   0x18
    dw 0x008a ; 1128: movwf   PCLATH
    dw 0x083e ; 1129: movf    0x3e, W
    dw 0x3907 ; 112a: andlw   0x07
    dw 0x2032 ; 112b: call    function_023
    dw 0x160a ; 112c: bsf     PCLATH, 0x4
    dw 0x118a ; 112d: bcf     PCLATH, 0x3
    dw 0x0480 ; 112e: iorwf   INDF, F
    dw 0x083e ; 112f: movf    0x3e, W
    dw 0x3ea2 ; 1130: addlw   0xa2
    dw 0x0084 ; 1131: movwf   FSR
    dw 0x1383 ; 1132: bcf     STATUS, IRP
    dw 0x0a80 ; 1133: incf    INDF, F
    dw 0x083e ; 1134: movf    0x3e, W
    dw 0x3ea2 ; 1135: addlw   0xa2
    dw 0x0084 ; 1136: movwf   FSR
    dw 0x0800 ; 1137: movf    INDF, W
    dw 0x00a8 ; 1138: movwf   0x28
    dw 0x1283 ; 1139: bcf     STATUS, RP0
    dw 0x1303 ; 113a: bcf     STATUS, RP1
    dw 0x0ba9 ; 113b: decfsz  0x29, F
    dw 0x3400 ; 113c: retlw   0x00
    dw 0x082a ; 113d: movf    0x2a, W
    dw 0x1d03 ; 113e: btfss   STATUS, Z
    dw 0x178b ; 113f: bsf     INTCON, GIE
    dw 0x3400 ; 1140: retlw   0x00
    dw 0x0183 ; 1141: clrf    STATUS
    dw 0x083d ; 1142: movf    0x3d, W
    dw 0x00e7 ; 1143: movwf   0x67
    dw 0x083c ; 1144: movf    0x3c, W
    dw 0x3e02 ; 1145: addlw   0x02
    dw 0x1803 ; 1146: btfsc   STATUS, C
    dw 0x0ae7 ; 1147: incf    0x67, F
    dw 0x120a ; 1148: bcf     PCLATH, 0x4
    dw 0x118a ; 1149: bcf     PCLATH, 0x3
    dw 0x21e7 ; 114a: call    function_003
    dw 0x00f0 ; 114b: movwf   Common_RAM
    dw 0x120a ; 114c: bcf     PCLATH, 0x4
    dw 0x118a ; 114d: bcf     PCLATH, 0x3
    dw 0x21ea ; 114e: call    function_004
    dw 0x160a ; 114f: bsf     PCLATH, 0x4
    dw 0x118a ; 1150: bcf     PCLATH, 0x3
    dw 0x00f1 ; 1151: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1152: iorwf   Common_RAM, W
    dw 0x1903 ; 1153: btfsc   STATUS, Z
    dw 0x3402 ; 1154: retlw   0x02
    dw 0x083d ; 1155: movf    0x3d, W
    dw 0x00e7 ; 1156: movwf   0x67
    dw 0x083c ; 1157: movf    0x3c, W
    dw 0x3e02 ; 1158: addlw   0x02
    dw 0x1803 ; 1159: btfsc   STATUS, C
    dw 0x0ae7 ; 115a: incf    0x67, F
    dw 0x120a ; 115b: bcf     PCLATH, 0x4
    dw 0x118a ; 115c: bcf     PCLATH, 0x3
    dw 0x21e7 ; 115d: call    function_003
    dw 0x00f0 ; 115e: movwf   Common_RAM
    dw 0x120a ; 115f: bcf     PCLATH, 0x4
    dw 0x118a ; 1160: bcf     PCLATH, 0x3
    dw 0x21ea ; 1161: call    function_004
    dw 0x00f1 ; 1162: movwf   (Common_RAM + 1)
    dw 0x0870 ; 1163: movf    Common_RAM, W
    dw 0x00bc ; 1164: movwf   0x3c
    dw 0x0871 ; 1165: movf    (Common_RAM + 1), W
    dw 0x00bd ; 1166: movwf   0x3d
    dw 0x00e7 ; 1167: movwf   0x67
    dw 0x30ff ; 1168: movlw   0xff
    dw 0x073c ; 1169: addwf   0x3c, W
    dw 0x1c03 ; 116a: btfss   STATUS, C
    dw 0x03e7 ; 116b: decf    0x67, F
    dw 0x120a ; 116c: bcf     PCLATH, 0x4
    dw 0x118a ; 116d: bcf     PCLATH, 0x3
    dw 0x21e7 ; 116e: call    function_003
    dw 0x0084 ; 116f: movwf   FSR
    dw 0x1383 ; 1170: bcf     STATUS, IRP
    dw 0x083e ; 1171: movf    0x3e, W
    dw 0x0080 ; 1172: movwf   INDF
    dw 0x0a84 ; 1173: incf    FSR, F
    dw 0x083f ; 1174: movf    0x3f, W
    dw 0x0080 ; 1175: movwf   INDF
    dw 0x083d ; 1176: movf    0x3d, W
    dw 0x00e7 ; 1177: movwf   0x67
    dw 0x30ff ; 1178: movlw   0xff
    dw 0x073c ; 1179: addwf   0x3c, W
    dw 0x1c03 ; 117a: btfss   STATUS, C
    dw 0x03e7 ; 117b: decf    0x67, F
    dw 0x120a ; 117c: bcf     PCLATH, 0x4
    dw 0x118a ; 117d: bcf     PCLATH, 0x3
    dw 0x21e7 ; 117e: call    function_003
    dw 0x3e02 ; 117f: addlw   0x02
    dw 0x0084 ; 1180: movwf   FSR
    dw 0x1383 ; 1181: bcf     STATUS, IRP
    dw 0x0840 ; 1182: movf    0x40, W
    dw 0x0080 ; 1183: movwf   INDF
    dw 0x083d ; 1184: movf    0x3d, W
    dw 0x00e7 ; 1185: movwf   0x67
    dw 0x083c ; 1186: movf    0x3c, W
    dw 0x120a ; 1187: bcf     PCLATH, 0x4
    dw 0x118a ; 1188: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1189: call    function_003
    dw 0x160a ; 118a: bsf     PCLATH, 0x4
    dw 0x118a ; 118b: bcf     PCLATH, 0x3
    dw 0x00f0 ; 118c: movwf   Common_RAM
    dw 0x01f1 ; 118d: clrf    (Common_RAM + 1)
    dw 0x0370 ; 118e: decf    Common_RAM, W
    dw 0x0471 ; 118f: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 1190: btfsc   STATUS, Z
    dw 0x3400 ; 1191: retlw   0x00
    dw 0x3401 ; 1192: retlw   0x01
    dw 0x0183 ; 1193: clrf    STATUS
    dw 0x00c8 ; 1194: movwf   0x48
    dw 0x3001 ; 1195: movlw   0x01
    dw 0x0248 ; 1196: subwf   0x48, W
    dw 0x1803 ; 1197: btfsc   STATUS, C
    dw 0x3402 ; 1198: retlw   0x02
    dw 0x160a ; 1199: bsf     PCLATH, 0x4
    dw 0x158a ; 119a: bsf     PCLATH, 0x3
    dw 0x26d8 ; 119b: call    function_074
    dw 0x160a ; 119c: bsf     PCLATH, 0x4
    dw 0x118a ; 119d: bcf     PCLATH, 0x3
    dw 0x0844 ; 119e: movf    0x44, W
    dw 0x0443 ; 119f: iorwf   0x43, W
    dw 0x3005 ; 11a0: movlw   0x05
    dw 0x00f1 ; 11a1: movwf   (Common_RAM + 1)
    dw 0x1d03 ; 11a2: btfss   STATUS, Z
    dw 0x29b2 ; 11a3: goto    label_319
    dw 0x0848 ; 11a4: movf    0x48, W
    dw 0x160a ; 11a5: bsf     PCLATH, 0x4
    dw 0x158a ; 11a6: bsf     PCLATH, 0x3
    dw 0x26e2 ; 11a7: call    function_075
    dw 0x3e02 ; 11a8: addlw   0x02
    dw 0x3ea7 ; 11a9: addlw   0xa7
    dw 0x0084 ; 11aa: movwf   FSR
    dw 0x1383 ; 11ab: bcf     STATUS, IRP
    dw 0x0800 ; 11ac: movf    INDF, W
    dw 0x160a ; 11ad: bsf     PCLATH, 0x4
    dw 0x118a ; 11ae: bcf     PCLATH, 0x3
    dw 0x2716 ; 11af: call    function_039
    dw 0x3005 ; 11b0: movlw   0x05
    dw 0x00f1 ; 11b1: movwf   (Common_RAM + 1)
    dw 0x0848 ; 11b2: movf    0x48, W
    dw 0x160a ; 11b3: bsf     PCLATH, 0x4
    dw 0x158a ; 11b4: bsf     PCLATH, 0x3
    dw 0x26e2 ; 11b5: call    function_075
    dw 0x3ea7 ; 11b6: addlw   0xa7
    dw 0x0084 ; 11b7: movwf   FSR
    dw 0x1383 ; 11b8: bcf     STATUS, IRP
    dw 0x0843 ; 11b9: movf    0x43, W
    dw 0x0080 ; 11ba: movwf   INDF
    dw 0x0a84 ; 11bb: incf    FSR, F
    dw 0x0844 ; 11bc: movf    0x44, W
    dw 0x0080 ; 11bd: movwf   INDF
    dw 0x3005 ; 11be: movlw   0x05
    dw 0x00f1 ; 11bf: movwf   (Common_RAM + 1)
    dw 0x0848 ; 11c0: movf    0x48, W
    dw 0x160a ; 11c1: bsf     PCLATH, 0x4
    dw 0x158a ; 11c2: bsf     PCLATH, 0x3
    dw 0x26e2 ; 11c3: call    function_075
    dw 0x3e03 ; 11c4: addlw   0x03
    dw 0x3ea7 ; 11c5: addlw   0xa7
    dw 0x0084 ; 11c6: movwf   FSR
    dw 0x1383 ; 11c7: bcf     STATUS, IRP
    dw 0x0845 ; 11c8: movf    0x45, W
    dw 0x0080 ; 11c9: movwf   INDF
    dw 0x0a84 ; 11ca: incf    FSR, F
    dw 0x0846 ; 11cb: movf    0x46, W
    dw 0x0080 ; 11cc: movwf   INDF
    dw 0x3005 ; 11cd: movlw   0x05
    dw 0x00f1 ; 11ce: movwf   (Common_RAM + 1)
    dw 0x0848 ; 11cf: movf    0x48, W
    dw 0x160a ; 11d0: bsf     PCLATH, 0x4
    dw 0x158a ; 11d1: bsf     PCLATH, 0x3
    dw 0x26e2 ; 11d2: call    function_075
    dw 0x160a ; 11d3: bsf     PCLATH, 0x4
    dw 0x118a ; 11d4: bcf     PCLATH, 0x3
    dw 0x3e02 ; 11d5: addlw   0x02
    dw 0x3ea7 ; 11d6: addlw   0xa7
    dw 0x0084 ; 11d7: movwf   FSR
    dw 0x1383 ; 11d8: bcf     STATUS, IRP
    dw 0x0880 ; 11d9: movf    INDF, F
    dw 0x1d03 ; 11da: btfss   STATUS, Z
    dw 0x29df ; 11db: goto    label_320
    dw 0x3003 ; 11dc: movlw   0x03
    dw 0x00c7 ; 11dd: movwf   0x47
    dw 0x29e0 ; 11de: goto    label_321
    dw 0x01c7 ; 11df: clrf    0x47
    dw 0x160a ; 11e0: bsf     PCLATH, 0x4
    dw 0x158a ; 11e1: bsf     PCLATH, 0x3
    dw 0x26ac ; 11e2: call    function_069
    dw 0x160a ; 11e3: bsf     PCLATH, 0x4
    dw 0x118a ; 11e4: bcf     PCLATH, 0x3
    dw 0x0847 ; 11e5: movf    0x47, W
    dw 0x0008 ; 11e6: return
    dw 0x0183 ; 11e7: clrf    STATUS
    dw 0x00d7 ; 11e8: movwf   0x57
    dw 0x08d7 ; 11e9: movf    0x57, F
    dw 0x1683 ; 11ea: bsf     STATUS, RP0
    dw 0x1903 ; 11eb: btfsc   STATUS, Z
    dw 0x29f3 ; 11ec: goto    label_322
    dw 0x0812 ; 11ed: movf    T2CON, W
    dw 0x3a4f ; 11ee: xorlw   0x4f
    dw 0x1903 ; 11ef: btfsc   STATUS, Z
    dw 0x2a0d ; 11f0: goto    label_329
    dw 0x304f ; 11f1: movlw   0x4f
    dw 0x29f8 ; 11f2: goto    label_323
    dw 0x0812 ; 11f3: movf    T2CON, W
    dw 0x3a5a ; 11f4: xorlw   0x5a
    dw 0x1903 ; 11f5: btfsc   STATUS, Z
    dw 0x2a0d ; 11f6: goto    label_329
    dw 0x305a ; 11f7: movlw   0x5a
    dw 0x0092 ; 11f8: movwf   T2CON
    dw 0x2a0d ; 11f9: goto    label_329
    dw 0x1683 ; 11fa: bsf     STATUS, RP0
    dw 0x1703 ; 11fb: bsf     STATUS, RP1
    dw 0x083f ; 11fc: movf    0x3f, W
    dw 0x2a09 ; 11fd: goto    label_328
    dw 0x1683 ; 11fe: bsf     STATUS, RP0
    dw 0x1703 ; 11ff: bsf     STATUS, RP1
    dw 0x0840 ; 1200: movf    0x40, W
    dw 0x2a09 ; 1201: goto    label_328
    dw 0x1683 ; 1202: bsf     STATUS, RP0
    dw 0x1703 ; 1203: bsf     STATUS, RP1
    dw 0x0841 ; 1204: movf    0x41, W
    dw 0x2a09 ; 1205: goto    label_328
    dw 0x1683 ; 1206: bsf     STATUS, RP0
    dw 0x1703 ; 1207: bsf     STATUS, RP1
    dw 0x083e ; 1208: movf    0x3e, W
    dw 0x1283 ; 1209: bcf     STATUS, RP0
    dw 0x1303 ; 120a: bcf     STATUS, RP1
    dw 0x00d8 ; 120b: movwf   0x58
    dw 0x2a1a ; 120c: goto    label_330
    dw 0x1283 ; 120d: bcf     STATUS, RP0
    dw 0x0856 ; 120e: movf    0x56, W
    dw 0x1903 ; 120f: btfsc   STATUS, Z
    dw 0x29fa ; 1210: goto    label_324
    dw 0x3a01 ; 1211: xorlw   0x01
    dw 0x1903 ; 1212: btfsc   STATUS, Z
    dw 0x29fe ; 1213: goto    label_325
    dw 0x3a03 ; 1214: xorlw   0x03
    dw 0x1903 ; 1215: btfsc   STATUS, Z
    dw 0x2a02 ; 1216: goto    label_326
    dw 0x3a01 ; 1217: xorlw   0x01
    dw 0x1903 ; 1218: btfsc   STATUS, Z
    dw 0x2a06 ; 1219: goto    label_327
    dw 0x0858 ; 121a: movf    0x58, W
    dw 0x00f0 ; 121b: movwf   Common_RAM
    dw 0x1003 ; 121c: bcf     STATUS, C
    dw 0x0cf0 ; 121d: rrf     Common_RAM, F
    dw 0x1003 ; 121e: bcf     STATUS, C
    dw 0x0c70 ; 121f: rrf     Common_RAM, W
    dw 0x0615 ; 1220: xorwf   CCPR1L, W
    dw 0x1d03 ; 1221: btfss   STATUS, Z
    dw 0x2a39 ; 1222: goto    label_331
    dw 0x0858 ; 1223: movf    0x58, W
    dw 0x3901 ; 1224: andlw   0x01
    dw 0x00f0 ; 1225: movwf   Common_RAM
    dw 0x01f1 ; 1226: clrf    (Common_RAM + 1)
    dw 0x3000 ; 1227: movlw   0x00
    dw 0x1a17 ; 1228: btfsc   CCP1CON, CCP1Y
    dw 0x3001 ; 1229: movlw   0x01
    dw 0x0670 ; 122a: xorwf   Common_RAM, W
    dw 0x0471 ; 122b: iorwf   (Common_RAM + 1), W
    dw 0x1d03 ; 122c: btfss   STATUS, Z
    dw 0x2a39 ; 122d: goto    label_331
    dw 0x0858 ; 122e: movf    0x58, W
    dw 0x3902 ; 122f: andlw   0x02
    dw 0x00f0 ; 1230: movwf   Common_RAM
    dw 0x01f1 ; 1231: clrf    (Common_RAM + 1)
    dw 0x3000 ; 1232: movlw   0x00
    dw 0x1a97 ; 1233: btfsc   CCP1CON, CCP1X
    dw 0x3001 ; 1234: movlw   0x01
    dw 0x0670 ; 1235: xorwf   Common_RAM, W
    dw 0x0471 ; 1236: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 1237: btfsc   STATUS, Z
    dw 0x0008 ; 1238: return
    dw 0x0858 ; 1239: movf    0x58, W
    dw 0x00f0 ; 123a: movwf   Common_RAM
    dw 0x1003 ; 123b: bcf     STATUS, C
    dw 0x0cf0 ; 123c: rrf     Common_RAM, F
    dw 0x1003 ; 123d: bcf     STATUS, C
    dw 0x0c70 ; 123e: rrf     Common_RAM, W
    dw 0x0095 ; 123f: movwf   CCPR1L
    dw 0x1c58 ; 1240: btfss   0x58, 0x0
    dw 0x2a44 ; 1241: goto    label_332
    dw 0x1617 ; 1242: bsf     CCP1CON, CCP1Y
    dw 0x2a45 ; 1243: goto    label_333
    dw 0x1217 ; 1244: bcf     CCP1CON, CCP1Y
    dw 0x1cd8 ; 1245: btfss   0x58, 0x1
    dw 0x2a49 ; 1246: goto    label_334
    dw 0x1697 ; 1247: bsf     CCP1CON, CCP1X
    dw 0x0008 ; 1248: return
    dw 0x1297 ; 1249: bcf     CCP1CON, CCP1X
    dw 0x0008 ; 124a: return
    dw 0x120a ; 124b: bcf     PCLATH, 0x4
    dw 0x118a ; 124c: bcf     PCLATH, 0x3
    dw 0x2741 ; 124d: call    function_015
    dw 0x3000 ; 124e: movlw   0x00
    dw 0x120a ; 124f: bcf     PCLATH, 0x4
    dw 0x118a ; 1250: bcf     PCLATH, 0x3
    dw 0x2698 ; 1251: call    function_013
    dw 0x00d6 ; 1252: movwf   0x56
    dw 0x3001 ; 1253: movlw   0x01
    dw 0x120a ; 1254: bcf     PCLATH, 0x4
    dw 0x118a ; 1255: bcf     PCLATH, 0x3
    dw 0x2698 ; 1256: call    function_013
    dw 0x07d6 ; 1257: addwf   0x56, F
    dw 0x3002 ; 1258: movlw   0x02
    dw 0x120a ; 1259: bcf     PCLATH, 0x4
    dw 0x118a ; 125a: bcf     PCLATH, 0x3
    dw 0x2698 ; 125b: call    function_013
    dw 0x07d6 ; 125c: addwf   0x56, F
    dw 0x3003 ; 125d: movlw   0x03
    dw 0x120a ; 125e: bcf     PCLATH, 0x4
    dw 0x118a ; 125f: bcf     PCLATH, 0x3
    dw 0x2698 ; 1260: call    function_013
    dw 0x07d6 ; 1261: addwf   0x56, F
    dw 0x1683 ; 1262: bsf     STATUS, RP0
    dw 0x1703 ; 1263: bsf     STATUS, RP1
    dw 0x083b ; 1264: movf    0x3b, W
    dw 0x1283 ; 1265: bcf     STATUS, RP0
    dw 0x1303 ; 1266: bcf     STATUS, RP1
    dw 0x07d6 ; 1267: addwf   0x56, F
    dw 0x1703 ; 1268: bsf     STATUS, RP1
    dw 0x0822 ; 1269: movf    0x22, W
    dw 0x1303 ; 126a: bcf     STATUS, RP1
    dw 0x07d6 ; 126b: addwf   0x56, F
    dw 0x3006 ; 126c: movlw   0x06
    dw 0x120a ; 126d: bcf     PCLATH, 0x4
    dw 0x118a ; 126e: bcf     PCLATH, 0x3
    dw 0x2698 ; 126f: call    function_013
    dw 0x07d6 ; 1270: addwf   0x56, F
    dw 0x3007 ; 1271: movlw   0x07
    dw 0x120a ; 1272: bcf     PCLATH, 0x4
    dw 0x118a ; 1273: bcf     PCLATH, 0x3
    dw 0x2698 ; 1274: call    function_013
    dw 0x160a ; 1275: bsf     PCLATH, 0x4
    dw 0x118a ; 1276: bcf     PCLATH, 0x3
    dw 0x07d6 ; 1277: addwf   0x56, F
    dw 0x1683 ; 1278: bsf     STATUS, RP0
    dw 0x1703 ; 1279: bsf     STATUS, RP1
    dw 0x083f ; 127a: movf    0x3f, W
    dw 0x1283 ; 127b: bcf     STATUS, RP0
    dw 0x1303 ; 127c: bcf     STATUS, RP1
    dw 0x07d6 ; 127d: addwf   0x56, F
    dw 0x1683 ; 127e: bsf     STATUS, RP0
    dw 0x1703 ; 127f: bsf     STATUS, RP1
    dw 0x0840 ; 1280: movf    0x40, W
    dw 0x1283 ; 1281: bcf     STATUS, RP0
    dw 0x1303 ; 1282: bcf     STATUS, RP1
    dw 0x07d6 ; 1283: addwf   0x56, F
    dw 0x1683 ; 1284: bsf     STATUS, RP0
    dw 0x1703 ; 1285: bsf     STATUS, RP1
    dw 0x0841 ; 1286: movf    0x41, W
    dw 0x1283 ; 1287: bcf     STATUS, RP0
    dw 0x1303 ; 1288: bcf     STATUS, RP1
    dw 0x07d6 ; 1289: addwf   0x56, F
    dw 0x1683 ; 128a: bsf     STATUS, RP0
    dw 0x1703 ; 128b: bsf     STATUS, RP1
    dw 0x083e ; 128c: movf    0x3e, W
    dw 0x1283 ; 128d: bcf     STATUS, RP0
    dw 0x1303 ; 128e: bcf     STATUS, RP1
    dw 0x07d6 ; 128f: addwf   0x56, F
    dw 0x1683 ; 1290: bsf     STATUS, RP0
    dw 0x1703 ; 1291: bsf     STATUS, RP1
    dw 0x0830 ; 1292: movf    0x30, W
    dw 0x1283 ; 1293: bcf     STATUS, RP0
    dw 0x1303 ; 1294: bcf     STATUS, RP1
    dw 0x07d6 ; 1295: addwf   0x56, F
    dw 0x1683 ; 1296: bsf     STATUS, RP0
    dw 0x1703 ; 1297: bsf     STATUS, RP1
    dw 0x0831 ; 1298: movf    0x31, W
    dw 0x1283 ; 1299: bcf     STATUS, RP0
    dw 0x1303 ; 129a: bcf     STATUS, RP1
    dw 0x07d6 ; 129b: addwf   0x56, F
    dw 0x1683 ; 129c: bsf     STATUS, RP0
    dw 0x1703 ; 129d: bsf     STATUS, RP1
    dw 0x0833 ; 129e: movf    0x33, W
    dw 0x1283 ; 129f: bcf     STATUS, RP0
    dw 0x1303 ; 12a0: bcf     STATUS, RP1
    dw 0x07d6 ; 12a1: addwf   0x56, F
    dw 0x1683 ; 12a2: bsf     STATUS, RP0
    dw 0x1703 ; 12a3: bsf     STATUS, RP1
    dw 0x083d ; 12a4: movf    0x3d, W
    dw 0x1283 ; 12a5: bcf     STATUS, RP0
    dw 0x1303 ; 12a6: bcf     STATUS, RP1
    dw 0x07d6 ; 12a7: addwf   0x56, F
    dw 0x0856 ; 12a8: movf    0x56, W
    dw 0x1683 ; 12a9: bsf     STATUS, RP0
    dw 0x1703 ; 12aa: bsf     STATUS, RP1
    dw 0x00bc ; 12ab: movwf   0x3c
    dw 0x1283 ; 12ac: bcf     STATUS, RP0
    dw 0x1303 ; 12ad: bcf     STATUS, RP1
    dw 0x0856 ; 12ae: movf    0x56, W
    dw 0x00d7 ; 12af: movwf   0x57
    dw 0x3010 ; 12b0: movlw   0x10
    dw 0x160a ; 12b1: bsf     PCLATH, 0x4
    dw 0x118a ; 12b2: bcf     PCLATH, 0x3
    dw 0x2dcc ; 12b3: goto    function_034
    dw 0x0183 ; 12b4: clrf    STATUS
    dw 0x083d ; 12b5: movf    0x3d, W
    dw 0x00e7 ; 12b6: movwf   0x67
    dw 0x083c ; 12b7: movf    0x3c, W
    dw 0x120a ; 12b8: bcf     PCLATH, 0x4
    dw 0x118a ; 12b9: bcf     PCLATH, 0x3
    dw 0x21e7 ; 12ba: call    function_003
    dw 0x160a ; 12bb: bsf     PCLATH, 0x4
    dw 0x118a ; 12bc: bcf     PCLATH, 0x3
    dw 0x00bc ; 12bd: movwf   0x3c
    dw 0x01be ; 12be: clrf    0x3e
    dw 0x2b1b ; 12bf: goto    label_337
    dw 0x083d ; 12c0: movf    0x3d, W
    dw 0x00e7 ; 12c1: movwf   0x67
    dw 0x083c ; 12c2: movf    0x3c, W
    dw 0x3e01 ; 12c3: addlw   0x01
    dw 0x1803 ; 12c4: btfsc   STATUS, C
    dw 0x0ae7 ; 12c5: incf    0x67, F
    dw 0x120a ; 12c6: bcf     PCLATH, 0x4
    dw 0x118a ; 12c7: bcf     PCLATH, 0x3
    dw 0x21e7 ; 12c8: call    function_003
    dw 0x160a ; 12c9: bsf     PCLATH, 0x4
    dw 0x118a ; 12ca: bcf     PCLATH, 0x3
    dw 0x00f0 ; 12cb: movwf   Common_RAM
    dw 0x083e ; 12cc: movf    0x3e, W
    dw 0x073e ; 12cd: addwf   0x3e, W
    dw 0x0770 ; 12ce: addwf   Common_RAM, W
    dw 0x0084 ; 12cf: movwf   FSR
    dw 0x1383 ; 12d0: bcf     STATUS, IRP
    dw 0x0800 ; 12d1: movf    INDF, W
    dw 0x00f0 ; 12d2: movwf   Common_RAM
    dw 0x0a84 ; 12d3: incf    FSR, F
    dw 0x0800 ; 12d4: movf    INDF, W
    dw 0x00f1 ; 12d5: movwf   (Common_RAM + 1)
    dw 0x0470 ; 12d6: iorwf   Common_RAM, W
    dw 0x1903 ; 12d7: btfsc   STATUS, Z
    dw 0x2b1a ; 12d8: goto    label_336
    dw 0x083d ; 12d9: movf    0x3d, W
    dw 0x00e7 ; 12da: movwf   0x67
    dw 0x083c ; 12db: movf    0x3c, W
    dw 0x3e01 ; 12dc: addlw   0x01
    dw 0x1803 ; 12dd: btfsc   STATUS, C
    dw 0x0ae7 ; 12de: incf    0x67, F
    dw 0x120a ; 12df: bcf     PCLATH, 0x4
    dw 0x118a ; 12e0: bcf     PCLATH, 0x3
    dw 0x21e7 ; 12e1: call    function_003
    dw 0x00f0 ; 12e2: movwf   Common_RAM
    dw 0x083e ; 12e3: movf    0x3e, W
    dw 0x073e ; 12e4: addwf   0x3e, W
    dw 0x0770 ; 12e5: addwf   Common_RAM, W
    dw 0x0084 ; 12e6: movwf   FSR
    dw 0x1383 ; 12e7: bcf     STATUS, IRP
    dw 0x0800 ; 12e8: movf    INDF, W
    dw 0x00bf ; 12e9: movwf   0x3f
    dw 0x0a84 ; 12ea: incf    FSR, F
    dw 0x0800 ; 12eb: movf    INDF, W
    dw 0x00c0 ; 12ec: movwf   0x40
    dw 0x00e7 ; 12ed: movwf   0x67
    dw 0x30ff ; 12ee: movlw   0xff
    dw 0x073f ; 12ef: addwf   0x3f, W
    dw 0x1c03 ; 12f0: btfss   STATUS, C
    dw 0x03e7 ; 12f1: decf    0x67, F
    dw 0x120a ; 12f2: bcf     PCLATH, 0x4
    dw 0x118a ; 12f3: bcf     PCLATH, 0x3
    dw 0x21e7 ; 12f4: call    function_003
    dw 0x0084 ; 12f5: movwf   FSR
    dw 0x1383 ; 12f6: bcf     STATUS, IRP
    dw 0x083e ; 12f7: movf    0x3e, W
    dw 0x0080 ; 12f8: movwf   INDF
    dw 0x0a84 ; 12f9: incf    FSR, F
    dw 0x083f ; 12fa: movf    0x3f, W
    dw 0x0080 ; 12fb: movwf   INDF
    dw 0x0840 ; 12fc: movf    0x40, W
    dw 0x00e7 ; 12fd: movwf   0x67
    dw 0x30ff ; 12fe: movlw   0xff
    dw 0x073f ; 12ff: addwf   0x3f, W
    dw 0x1c03 ; 1300: btfss   STATUS, C
    dw 0x03e7 ; 1301: decf    0x67, F
    dw 0x120a ; 1302: bcf     PCLATH, 0x4
    dw 0x118a ; 1303: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1304: call    function_003
    dw 0x3e02 ; 1305: addlw   0x02
    dw 0x0084 ; 1306: movwf   FSR
    dw 0x1383 ; 1307: bcf     STATUS, IRP
    dw 0x0840 ; 1308: movf    0x40, W
    dw 0x0080 ; 1309: movwf   INDF
    dw 0x0840 ; 130a: movf    0x40, W
    dw 0x00e7 ; 130b: movwf   0x67
    dw 0x083f ; 130c: movf    0x3f, W
    dw 0x120a ; 130d: bcf     PCLATH, 0x4
    dw 0x118a ; 130e: bcf     PCLATH, 0x3
    dw 0x21e7 ; 130f: call    function_003
    dw 0x160a ; 1310: bsf     PCLATH, 0x4
    dw 0x118a ; 1311: bcf     PCLATH, 0x3
    dw 0x00bd ; 1312: movwf   0x3d
    dw 0x08bd ; 1313: movf    0x3d, F
    dw 0x1903 ; 1314: btfsc   STATUS, Z
    dw 0x2b1a ; 1315: goto    label_336
    dw 0x083d ; 1316: movf    0x3d, W
    dw 0x3a02 ; 1317: xorlw   0x02
    dw 0x1903 ; 1318: btfsc   STATUS, Z
    dw 0x3403 ; 1319: retlw   0x03
    dw 0x0abe ; 131a: incf    0x3e, F
    dw 0x083c ; 131b: movf    0x3c, W
    dw 0x023e ; 131c: subwf   0x3e, W
    dw 0x1803 ; 131d: btfsc   STATUS, C
    dw 0x3400 ; 131e: retlw   0x00
    dw 0x2ac0 ; 131f: goto    label_335
    dw 0x0183 ; 1320: clrf    STATUS
    dw 0x083d ; 1321: movf    0x3d, W
    dw 0x043c ; 1322: iorwf   0x3c, W
    dw 0x1903 ; 1323: btfsc   STATUS, Z
    dw 0x3400 ; 1324: retlw   0x00
    dw 0x160a ; 1325: bsf     PCLATH, 0x4
    dw 0x158a ; 1326: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1327: call    function_074
    dw 0x083d ; 1328: movf    0x3d, W
    dw 0x00e7 ; 1329: movwf   0x67
    dw 0x083c ; 132a: movf    0x3c, W
    dw 0x3e04 ; 132b: addlw   0x04
    dw 0x1803 ; 132c: btfsc   STATUS, C
    dw 0x0ae7 ; 132d: incf    0x67, F
    dw 0x120a ; 132e: bcf     PCLATH, 0x4
    dw 0x118a ; 132f: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1330: call    function_003
    dw 0x160a ; 1331: bsf     PCLATH, 0x4
    dw 0x118a ; 1332: bcf     PCLATH, 0x3
    dw 0x0084 ; 1333: movwf   FSR
    dw 0x1383 ; 1334: bcf     STATUS, IRP
    dw 0x1c00 ; 1335: btfss   INDF, 0x0
    dw 0x2b8d ; 1336: goto    label_339
    dw 0x083d ; 1337: movf    0x3d, W
    dw 0x00e7 ; 1338: movwf   0x67
    dw 0x083c ; 1339: movf    0x3c, W
    dw 0x120a ; 133a: bcf     PCLATH, 0x4
    dw 0x118a ; 133b: bcf     PCLATH, 0x3
    dw 0x21e7 ; 133c: call    function_003
    dw 0x160a ; 133d: bsf     PCLATH, 0x4
    dw 0x118a ; 133e: bcf     PCLATH, 0x3
    dw 0x3800 ; 133f: iorlw   0x00
    dw 0x1903 ; 1340: btfsc   STATUS, Z
    dw 0x2b5d ; 1341: goto    label_338
    dw 0x08be ; 1342: movf    0x3e, F
    dw 0x1903 ; 1343: btfsc   STATUS, Z
    dw 0x2b5d ; 1344: goto    label_338
    dw 0x083d ; 1345: movf    0x3d, W
    dw 0x00e7 ; 1346: movwf   0x67
    dw 0x083c ; 1347: movf    0x3c, W
    dw 0x120a ; 1348: bcf     PCLATH, 0x4
    dw 0x118a ; 1349: bcf     PCLATH, 0x3
    dw 0x21e7 ; 134a: call    function_003
    dw 0x00bc ; 134b: movwf   0x3c
    dw 0x3080 ; 134c: movlw   0x80
    dw 0x00bd ; 134d: movwf   0x3d
    dw 0x083d ; 134e: movf    0x3d, W
    dw 0x00e7 ; 134f: movwf   0x67
    dw 0x083c ; 1350: movf    0x3c, W
    dw 0x3e01 ; 1351: addlw   0x01
    dw 0x1803 ; 1352: btfsc   STATUS, C
    dw 0x0ae7 ; 1353: incf    0x67, F
    dw 0x120a ; 1354: bcf     PCLATH, 0x4
    dw 0x118a ; 1355: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1356: call    function_003
    dw 0x00be ; 1357: movwf   0x3e
    dw 0x01bf ; 1358: clrf    0x3f
    dw 0x083e ; 1359: movf    0x3e, W
    dw 0x160a ; 135a: bsf     PCLATH, 0x4
    dw 0x158a ; 135b: bsf     PCLATH, 0x3
    dw 0x2784 ; 135c: call    function_079
    dw 0x083d ; 135d: movf    0x3d, W
    dw 0x00e7 ; 135e: movwf   0x67
    dw 0x083c ; 135f: movf    0x3c, W
    dw 0x3e04 ; 1360: addlw   0x04
    dw 0x1803 ; 1361: btfsc   STATUS, C
    dw 0x0ae7 ; 1362: incf    0x67, F
    dw 0x120a ; 1363: bcf     PCLATH, 0x4
    dw 0x118a ; 1364: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1365: call    function_003
    dw 0x0084 ; 1366: movwf   FSR
    dw 0x1383 ; 1367: bcf     STATUS, IRP
    dw 0x1000 ; 1368: bcf     INDF, 0x0
    dw 0x160a ; 1369: bsf     PCLATH, 0x4
    dw 0x158a ; 136a: bsf     PCLATH, 0x3
    dw 0x26ac ; 136b: call    function_069
    dw 0x083d ; 136c: movf    0x3d, W
    dw 0x00e7 ; 136d: movwf   0x67
    dw 0x083c ; 136e: movf    0x3c, W
    dw 0x3e03 ; 136f: addlw   0x03
    dw 0x1803 ; 1370: btfsc   STATUS, C
    dw 0x0ae7 ; 1371: incf    0x67, F
    dw 0x120a ; 1372: bcf     PCLATH, 0x4
    dw 0x118a ; 1373: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1374: call    function_003
    dw 0x160a ; 1375: bsf     PCLATH, 0x4
    dw 0x118a ; 1376: bcf     PCLATH, 0x3
    dw 0x3800 ; 1377: iorlw   0x00
    dw 0x1903 ; 1378: btfsc   STATUS, Z
    dw 0x3404 ; 1379: retlw   0x04
    dw 0x083d ; 137a: movf    0x3d, W
    dw 0x00e7 ; 137b: movwf   0x67
    dw 0x083c ; 137c: movf    0x3c, W
    dw 0x3e03 ; 137d: addlw   0x03
    dw 0x1803 ; 137e: btfsc   STATUS, C
    dw 0x0ae7 ; 137f: incf    0x67, F
    dw 0x120a ; 1380: bcf     PCLATH, 0x4
    dw 0x118a ; 1381: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1382: call    function_003
    dw 0x160a ; 1383: bsf     PCLATH, 0x4
    dw 0x118a ; 1384: bcf     PCLATH, 0x3
    dw 0x20f7 ; 1385: call    function_026
    dw 0x160a ; 1386: bsf     PCLATH, 0x4
    dw 0x118a ; 1387: bcf     PCLATH, 0x3
    dw 0x00bc ; 1388: movwf   0x3c
    dw 0x3a03 ; 1389: xorlw   0x03
    dw 0x1903 ; 138a: btfsc   STATUS, Z
    dw 0x3403 ; 138b: retlw   0x03
    dw 0x3400 ; 138c: retlw   0x00
    dw 0x160a ; 138d: bsf     PCLATH, 0x4
    dw 0x158a ; 138e: bsf     PCLATH, 0x3
    dw 0x26ac ; 138f: call    function_069
    dw 0x160a ; 1390: bsf     PCLATH, 0x4
    dw 0x118a ; 1391: bcf     PCLATH, 0x3
    dw 0x3402 ; 1392: retlw   0x02
    dw 0x1683 ; 1393: bsf     STATUS, RP0
    dw 0x1303 ; 1394: bcf     STATUS, RP1
    dw 0x0c4e ; 1395: rrf     0x4e, W
    dw 0x00f0 ; 1396: movwf   0x70
    dw 0x0c70 ; 1397: rrf     0x70, W
    dw 0x3903 ; 1398: andlw   0x03
    dw 0x3a02 ; 1399: xorlw   0x02
    dw 0x1d03 ; 139a: btfss   STATUS, Z
    dw 0x2bc5 ; 139b: goto    label_342
    dw 0x3001 ; 139c: movlw   0x01
    dw 0x1283 ; 139d: bcf     STATUS, RP0
    dw 0x1703 ; 139e: bsf     STATUS, RP1
    dw 0x0248 ; 139f: subwf   0x48, W
    dw 0x303d ; 13a0: movlw   0x3d
    dw 0x1903 ; 13a1: btfsc   STATUS, Z
    dw 0x0247 ; 13a2: subwf   0x47, W
    dw 0x1c03 ; 13a3: btfss   STATUS, C
    dw 0x2bd5 ; 13a4: goto    label_343
    dw 0x3001 ; 13a5: movlw   0x01
    dw 0x0248 ; 13a6: subwf   0x48, W
    dw 0x304a ; 13a7: movlw   0x4a
    dw 0x1903 ; 13a8: btfsc   STATUS, Z
    dw 0x0247 ; 13a9: subwf   0x47, W
    dw 0x3001 ; 13aa: movlw   0x01
    dw 0x1c03 ; 13ab: btfss   STATUS, C
    dw 0x2bb4 ; 13ac: goto    label_340
    dw 0x0248 ; 13ad: subwf   0x48, W
    dw 0x3072 ; 13ae: movlw   0x72
    dw 0x1903 ; 13af: btfsc   STATUS, Z
    dw 0x0247 ; 13b0: subwf   0x47, W
    dw 0x1c03 ; 13b1: btfss   STATUS, C
    dw 0x2be7 ; 13b2: goto    label_345
    dw 0x3001 ; 13b3: movlw   0x01
    dw 0x0248 ; 13b4: subwf   0x48, W
    dw 0x307f ; 13b5: movlw   0x7f
    dw 0x1903 ; 13b6: btfsc   STATUS, Z
    dw 0x0247 ; 13b7: subwf   0x47, W
    dw 0x3001 ; 13b8: movlw   0x01
    dw 0x1c03 ; 13b9: btfss   STATUS, C
    dw 0x2bc2 ; 13ba: goto    label_341
    dw 0x0248 ; 13bb: subwf   0x48, W
    dw 0x3099 ; 13bc: movlw   0x99
    dw 0x1903 ; 13bd: btfsc   STATUS, Z
    dw 0x0247 ; 13be: subwf   0x47, W
    dw 0x1c03 ; 13bf: btfss   STATUS, C
    dw 0x2bf7 ; 13c0: goto    label_348
    dw 0x3001 ; 13c1: movlw   0x01
    dw 0x0248 ; 13c2: subwf   0x48, W
    dw 0x30a6 ; 13c3: movlw   0xa6
    dw 0x2bfc ; 13c4: goto    label_351
    dw 0x0c4e ; 13c5: rrf     0x4e, W
    dw 0x00f0 ; 13c6: movwf   Common_RAM
    dw 0x0c70 ; 13c7: rrf     Common_RAM, W
    dw 0x3903 ; 13c8: andlw   0x03
    dw 0x3a01 ; 13c9: xorlw   0x01
    dw 0x1d03 ; 13ca: btfss   STATUS, Z
    dw 0x2c05 ; 13cb: goto    label_354
    dw 0x3001 ; 13cc: movlw   0x01
    dw 0x1283 ; 13cd: bcf     STATUS, RP0
    dw 0x1703 ; 13ce: bsf     STATUS, RP1
    dw 0x0248 ; 13cf: subwf   0x48, W
    dw 0x3053 ; 13d0: movlw   0x53
    dw 0x1903 ; 13d1: btfsc   STATUS, Z
    dw 0x0247 ; 13d2: subwf   0x47, W
    dw 0x1803 ; 13d3: btfsc   STATUS, C
    dw 0x2bd9 ; 13d4: goto    label_344
    dw 0x1683 ; 13d5: bsf     STATUS, RP0
    dw 0x1303 ; 13d6: bcf     STATUS, RP1
    dw 0x01d9 ; 13d7: clrf    0x59
    dw 0x2c04 ; 13d8: goto    label_353
    dw 0x3001 ; 13d9: movlw   0x01
    dw 0x0248 ; 13da: subwf   0x48, W
    dw 0x3060 ; 13db: movlw   0x60
    dw 0x1903 ; 13dc: btfsc   STATUS, Z
    dw 0x0247 ; 13dd: subwf   0x47, W
    dw 0x3001 ; 13de: movlw   0x01
    dw 0x1c03 ; 13df: btfss   STATUS, C
    dw 0x2bea ; 13e0: goto    label_347
    dw 0x0248 ; 13e1: subwf   0x48, W
    dw 0x3080 ; 13e2: movlw   0x80
    dw 0x1903 ; 13e3: btfsc   STATUS, Z
    dw 0x0247 ; 13e4: subwf   0x47, W
    dw 0x1803 ; 13e5: btfsc   STATUS, C
    dw 0x2be9 ; 13e6: goto    label_346
    dw 0x3003 ; 13e7: movlw   0x03
    dw 0x2c01 ; 13e8: goto    label_352
    dw 0x3001 ; 13e9: movlw   0x01
    dw 0x0248 ; 13ea: subwf   0x48, W
    dw 0x308d ; 13eb: movlw   0x8d
    dw 0x1903 ; 13ec: btfsc   STATUS, Z
    dw 0x0247 ; 13ed: subwf   0x47, W
    dw 0x3001 ; 13ee: movlw   0x01
    dw 0x1c03 ; 13ef: btfss   STATUS, C
    dw 0x2bfa ; 13f0: goto    label_350
    dw 0x0248 ; 13f1: subwf   0x48, W
    dw 0x30a3 ; 13f2: movlw   0xa3
    dw 0x1903 ; 13f3: btfsc   STATUS, Z
    dw 0x0247 ; 13f4: subwf   0x47, W
    dw 0x1803 ; 13f5: btfsc   STATUS, C
    dw 0x2bf9 ; 13f6: goto    label_349
    dw 0x3006 ; 13f7: movlw   0x06
    dw 0x2c01 ; 13f8: goto    label_352
    dw 0x3001 ; 13f9: movlw   0x01
    dw 0x0248 ; 13fa: subwf   0x48, W
    dw 0x30b0 ; 13fb: movlw   0xb0
    dw 0x1903 ; 13fc: btfsc   STATUS, Z
    dw 0x0247 ; 13fd: subwf   0x47, W
    dw 0x1c03 ; 13fe: btfss   STATUS, C
    dw 0x2c05 ; 13ff: goto    label_354
    dw 0x300a ; 1400: movlw   0x0a
    dw 0x1683 ; 1401: bsf     STATUS, RP0
    dw 0x1303 ; 1402: bcf     STATUS, RP1
    dw 0x00d9 ; 1403: movwf   0x59
    dw 0x01da ; 1404: clrf    0x5a
    dw 0x0183 ; 1405: clrf    STATUS
    dw 0x0008 ; 1406: return
    dw 0x0183 ; 1407: clrf    STATUS
    dw 0x01bf ; 1408: clrf    0x3f
    dw 0x2c7f ; 1409: goto    label_357
    dw 0x083f ; 140a: movf    0x3f, W
    dw 0x00f0 ; 140b: movwf   Common_RAM
    dw 0x01f1 ; 140c: clrf    (Common_RAM + 1)
    dw 0x1003 ; 140d: bcf     STATUS, C
    dw 0x0df0 ; 140e: rlf     Common_RAM, F
    dw 0x0df1 ; 140f: rlf     (Common_RAM + 1), F
    dw 0x1003 ; 1410: bcf     STATUS, C
    dw 0x0df0 ; 1411: rlf     Common_RAM, F
    dw 0x0df1 ; 1412: rlf     (Common_RAM + 1), F
    dw 0x1003 ; 1413: bcf     STATUS, C
    dw 0x0df0 ; 1414: rlf     Common_RAM, F
    dw 0x0df1 ; 1415: rlf     (Common_RAM + 1), F
    dw 0x083c ; 1416: movf    0x3c, W
    dw 0x0770 ; 1417: addwf   Common_RAM, W
    dw 0x00c1 ; 1418: movwf   0x41
    dw 0x083d ; 1419: movf    0x3d, W
    dw 0x1803 ; 141a: btfsc   STATUS, C
    dw 0x0a3d ; 141b: incf    0x3d, W
    dw 0x0771 ; 141c: addwf   (Common_RAM + 1), W
    dw 0x00c2 ; 141d: movwf   0x42
    dw 0x00e7 ; 141e: movwf   0x67
    dw 0x0841 ; 141f: movf    0x41, W
    dw 0x120a ; 1420: bcf     PCLATH, 0x4
    dw 0x118a ; 1421: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1422: call    function_003
    dw 0x160a ; 1423: bsf     PCLATH, 0x4
    dw 0x118a ; 1424: bcf     PCLATH, 0x3
    dw 0x00c0 ; 1425: movwf   0x40
    dw 0x3001 ; 1426: movlw   0x01
    dw 0x0240 ; 1427: subwf   0x40, W
    dw 0x1803 ; 1428: btfsc   STATUS, C
    dw 0x2c7e ; 1429: goto    label_356
    dw 0x0842 ; 142a: movf    0x42, W
    dw 0x00e7 ; 142b: movwf   0x67
    dw 0x0841 ; 142c: movf    0x41, W
    dw 0x3e01 ; 142d: addlw   0x01
    dw 0x1803 ; 142e: btfsc   STATUS, C
    dw 0x0ae7 ; 142f: incf    0x67, F
    dw 0x120a ; 1430: bcf     PCLATH, 0x4
    dw 0x118a ; 1431: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1432: call    function_003
    dw 0x00c3 ; 1433: movwf   0x43
    dw 0x0842 ; 1434: movf    0x42, W
    dw 0x00e7 ; 1435: movwf   0x67
    dw 0x0841 ; 1436: movf    0x41, W
    dw 0x3e02 ; 1437: addlw   0x02
    dw 0x1803 ; 1438: btfsc   STATUS, C
    dw 0x0ae7 ; 1439: incf    0x67, F
    dw 0x120a ; 143a: bcf     PCLATH, 0x4
    dw 0x118a ; 143b: bcf     PCLATH, 0x3
    dw 0x21e7 ; 143c: call    function_003
    dw 0x00f0 ; 143d: movwf   Common_RAM
    dw 0x120a ; 143e: bcf     PCLATH, 0x4
    dw 0x118a ; 143f: bcf     PCLATH, 0x3
    dw 0x21ea ; 1440: call    function_004
    dw 0x00f1 ; 1441: movwf   (Common_RAM + 1)
    dw 0x0870 ; 1442: movf    Common_RAM, W
    dw 0x00c4 ; 1443: movwf   0x44
    dw 0x0871 ; 1444: movf    (Common_RAM + 1), W
    dw 0x00c5 ; 1445: movwf   0x45
    dw 0x0840 ; 1446: movf    0x40, W
    dw 0x160a ; 1447: bsf     PCLATH, 0x4
    dw 0x118a ; 1448: bcf     PCLATH, 0x3
    dw 0x207d ; 1449: call    function_024
    dw 0x160a ; 144a: bsf     PCLATH, 0x4
    dw 0x118a ; 144b: bcf     PCLATH, 0x3
    dw 0x00f0 ; 144c: movwf   Common_RAM
    dw 0x01f1 ; 144d: clrf    (Common_RAM + 1)
    dw 0x0471 ; 144e: iorwf   (Common_RAM + 1), W
    dw 0x1d03 ; 144f: btfss   STATUS, Z
    dw 0x2c7e ; 1450: goto    label_356
    dw 0x0842 ; 1451: movf    0x42, W
    dw 0x00e7 ; 1452: movwf   0x67
    dw 0x0841 ; 1453: movf    0x41, W
    dw 0x3e04 ; 1454: addlw   0x04
    dw 0x1803 ; 1455: btfsc   STATUS, C
    dw 0x0ae7 ; 1456: incf    0x67, F
    dw 0x120a ; 1457: bcf     PCLATH, 0x4
    dw 0x118a ; 1458: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1459: call    function_003
    dw 0x00f0 ; 145a: movwf   Common_RAM
    dw 0x120a ; 145b: bcf     PCLATH, 0x4
    dw 0x118a ; 145c: bcf     PCLATH, 0x3
    dw 0x21ea ; 145d: call    function_004
    dw 0x00f1 ; 145e: movwf   (Common_RAM + 1)
    dw 0x0870 ; 145f: movf    Common_RAM, W
    dw 0x00c3 ; 1460: movwf   0x43
    dw 0x0871 ; 1461: movf    (Common_RAM + 1), W
    dw 0x00c4 ; 1462: movwf   0x44
    dw 0x0842 ; 1463: movf    0x42, W
    dw 0x00e7 ; 1464: movwf   0x67
    dw 0x0841 ; 1465: movf    0x41, W
    dw 0x3e06 ; 1466: addlw   0x06
    dw 0x1803 ; 1467: btfsc   STATUS, C
    dw 0x0ae7 ; 1468: incf    0x67, F
    dw 0x120a ; 1469: bcf     PCLATH, 0x4
    dw 0x118a ; 146a: bcf     PCLATH, 0x3
    dw 0x21e7 ; 146b: call    function_003
    dw 0x00f0 ; 146c: movwf   Common_RAM
    dw 0x120a ; 146d: bcf     PCLATH, 0x4
    dw 0x118a ; 146e: bcf     PCLATH, 0x3
    dw 0x21ea ; 146f: call    function_004
    dw 0x00f1 ; 1470: movwf   (Common_RAM + 1)
    dw 0x0870 ; 1471: movf    Common_RAM, W
    dw 0x00c5 ; 1472: movwf   0x45
    dw 0x0871 ; 1473: movf    (Common_RAM + 1), W
    dw 0x00c6 ; 1474: movwf   0x46
    dw 0x0840 ; 1475: movf    0x40, W
    dw 0x160a ; 1476: bsf     PCLATH, 0x4
    dw 0x118a ; 1477: bcf     PCLATH, 0x3
    dw 0x2193 ; 1478: call    function_027
    dw 0x160a ; 1479: bsf     PCLATH, 0x4
    dw 0x118a ; 147a: bcf     PCLATH, 0x3
    dw 0x00f0 ; 147b: movwf   Common_RAM
    dw 0x01f1 ; 147c: clrf    (Common_RAM + 1)
    dw 0x3a02 ; 147d: xorlw   0x02
    dw 0x0abf ; 147e: incf    0x3f, F
    dw 0x083e ; 147f: movf    0x3e, W
    dw 0x023f ; 1480: subwf   0x3f, W
    dw 0x1803 ; 1481: btfsc   STATUS, C
    dw 0x0008 ; 1482: return
    dw 0x2c0a ; 1483: goto    label_355
    dw 0x018b ; 1484: clrf    INTCON
    dw 0x1283 ; 1485: bcf     STATUS, RP0
    dw 0x1703 ; 1486: bsf     STATUS, RP1
    dw 0x1207 ; 1487: bcf     LCDCON, VLCDEN
    dw 0x1387 ; 1488: bcf     LCDCON, LCDEN
    dw 0x1007 ; 1489: bcf     LCDCON, LMUX0
    dw 0x1087 ; 148a: bcf     LCDCON, LMUX1
    dw 0x1303 ; 148b: bcf     STATUS, RP1
    dw 0x1185 ; 148c: bcf     PORTA, RA3
    dw 0x1205 ; 148d: bcf     PORTA, RA4
    dw 0x1085 ; 148e: bcf     PORTA, RA1
    dw 0x1107 ; 148f: bcf     PORTC, RC2
    dw 0x300f ; 1490: movlw   0x0f
    dw 0x0486 ; 1491: iorwf   PORTB, F
    dw 0x0487 ; 1492: iorwf   PORTC, F
    dw 0x30ff ; 1493: movlw   0xff
    dw 0x0088 ; 1494: movwf   PORTD
    dw 0x1683 ; 1495: bsf     STATUS, RP0
    dw 0x1085 ; 1496: bcf     TRISA, TRISA1
    dw 0x1105 ; 1497: bcf     TRISA, TRISA2
    dw 0x1185 ; 1498: bcf     TRISA, TRISA3
    dw 0x1205 ; 1499: bcf     TRISA, TRISA4
    dw 0x1006 ; 149a: bcf     TRISB, TRISB0
    dw 0x1086 ; 149b: bcf     TRISB, TRISB1
    dw 0x1106 ; 149c: bcf     TRISB, TRISB2
    dw 0x1186 ; 149d: bcf     TRISB, TRISB3
    dw 0x1206 ; 149e: bcf     TRISB, TRISB4
    dw 0x1283 ; 149f: bcf     STATUS, RP0
    dw 0x1206 ; 14a0: bcf     PORTB, RB4
    dw 0x1683 ; 14a1: bsf     STATUS, RP0
    dw 0x1686 ; 14a2: bsf     TRISB, TRISB5
    dw 0x1306 ; 14a3: bcf     TRISB, TRISB6
    dw 0x1386 ; 14a4: bcf     TRISB, TRISB7
    dw 0x0195 ; 14a5: clrf    WPU
    dw 0x1007 ; 14a6: bcf     TRISC, TRISC0
    dw 0x1087 ; 14a7: bcf     TRISC, TRISC1
    dw 0x1107 ; 14a8: bcf     TRISC, TRISC2
    dw 0x1187 ; 14a9: bcf     TRISC, TRISC3
    dw 0x1207 ; 14aa: bcf     TRISC, TRISC4
    dw 0x1287 ; 14ab: bcf     TRISC, TRISC5
    dw 0x1283 ; 14ac: bcf     STATUS, RP0
    dw 0x1287 ; 14ad: bcf     PORTC, RC5
    dw 0x1683 ; 14ae: bsf     STATUS, RP0
    dw 0x1307 ; 14af: bcf     TRISC, TRISC6
    dw 0x1787 ; 14b0: bsf     TRISC, TRISC7
    dw 0x1008 ; 14b1: bcf     TRISD, TRISD0
    dw 0x1088 ; 14b2: bcf     TRISD, TRISD1
    dw 0x1108 ; 14b3: bcf     TRISD, TRISD2
    dw 0x1188 ; 14b4: bcf     TRISD, TRISD3
    dw 0x1208 ; 14b5: bcf     TRISD, TRISD4
    dw 0x1288 ; 14b6: bcf     TRISD, TRISD5
    dw 0x1308 ; 14b7: bcf     TRISD, TRISD6
    dw 0x1388 ; 14b8: bcf     TRISD, TRISD7
    dw 0x1283 ; 14b9: bcf     STATUS, RP0
    dw 0x0197 ; 14ba: clrf    CCP1CON
    dw 0x1297 ; 14bb: bcf     CCP1CON, CCP1X
    dw 0x1217 ; 14bc: bcf     CCP1CON, CCP1Y
    dw 0x1492 ; 14bd: bsf     T2CON, T2CKPS1
    dw 0x305a ; 14be: movlw   0x5a
    dw 0x1683 ; 14bf: bsf     STATUS, RP0
    dw 0x0092 ; 14c0: movwf   PR2
    dw 0x3047 ; 14c1: movlw   0x47
    dw 0x1283 ; 14c2: bcf     STATUS, RP0
    dw 0x0095 ; 14c3: movwf   CCPR1L
    dw 0x0181 ; 14c4: clrf    TMR0
    dw 0x018b ; 14c5: clrf    INTCON
    dw 0x1683 ; 14c6: bsf     STATUS, RP0
    dw 0x1781 ; 14c7: bsf     OPTION_REG, NOT_RBPU
    dw 0x1281 ; 14c8: bcf     OPTION_REG, T0CS
    dw 0x1181 ; 14c9: bcf     OPTION_REG, PSA
    dw 0x1501 ; 14ca: bsf     OPTION_REG, PS2
    dw 0x1081 ; 14cb: bcf     OPTION_REG, PS1
    dw 0x1401 ; 14cc: bsf     OPTION_REG, PS0
    dw 0x30ed ; 14cd: movlw   0xed
    dw 0x1283 ; 14ce: bcf     STATUS, RP0
    dw 0x0081 ; 14cf: movwf   TMR0
    dw 0x110b ; 14d0: bcf     INTCON, T0IF
    dw 0x168b ; 14d1: bsf     INTCON, T0IE
    dw 0x1683 ; 14d2: bsf     STATUS, RP0
    dw 0x1007 ; 14d3: bcf     TRISC, TRISC0
    dw 0x303f ; 14d4: movlw   0x3f
    dw 0x0099 ; 14d5: movwf   SPBRG
    dw 0x1518 ; 14d6: bsf     TXSTA, BRGH
    dw 0x1218 ; 14d7: bcf     TXSTA, SYNC
    dw 0x1283 ; 14d8: bcf     STATUS, RP0
    dw 0x1798 ; 14d9: bsf     RCSTA, SPEN
    dw 0x170b ; 14da: bsf     INTCON, PEIE
    dw 0x1198 ; 14db: bcf     RCSTA, ADDEN
    dw 0x1683 ; 14dc: bsf     STATUS, RP0
    dw 0x1718 ; 14dd: bsf     TXSTA, TX9
    dw 0x1283 ; 14de: bcf     STATUS, RP0
    dw 0x1718 ; 14df: bsf     RCSTA, RX9
    dw 0x1683 ; 14e0: bsf     STATUS, RP0
    dw 0x160c ; 14e1: bsf     PIE1, TXIE
    dw 0x1283 ; 14e2: bcf     STATUS, RP0
    dw 0x1703 ; 14e3: bsf     STATUS, RP1
    dw 0x1485 ; 14e4: bsf     WDTCON, WDTPS0
    dw 0x1105 ; 14e5: bcf     WDTCON, WDTPS1
    dw 0x1585 ; 14e6: bsf     WDTCON, WDTPS2
    dw 0x1205 ; 14e7: bcf     WDTCON, WDTPS3
    dw 0x1683 ; 14e8: bsf     STATUS, RP0
    dw 0x1303 ; 14e9: bcf     STATUS, RP1
    dw 0x1409 ; 14ea: bsf     TRISE, TRISE0
    dw 0x1489 ; 14eb: bsf     TRISE, TRISE1
    dw 0x1283 ; 14ec: bcf     STATUS, RP0
    dw 0x1492 ; 14ed: bsf     T2CON, T2CKPS1
    dw 0x1683 ; 14ee: bsf     STATUS, RP0
    dw 0x1509 ; 14ef: bsf     TRISE, TRISE2
    dw 0x1405 ; 14f0: bsf     TRISA, TRISA0
    dw 0x1685 ; 14f1: bsf     TRISA, TRISA5
    dw 0x3050 ; 14f2: movlw   0x50
    dw 0x009f ; 14f3: movwf   ADCON1
    dw 0x1283 ; 14f4: bcf     STATUS, RP0
    dw 0x179f ; 14f5: bsf     ADCON0, ADFM
    dw 0x131f ; 14f6: bcf     ADCON0, VCFG1
    dw 0x129f ; 14f7: bcf     ADCON0, VCFG0
    dw 0x101f ; 14f8: bcf     ADCON0, ADON
    dw 0x1683 ; 14f9: bsf     STATUS, RP0
    dw 0x1411 ; 14fa: bsf     ANSEL, AN0
    dw 0x1091 ; 14fb: bcf     ANSEL, AN1
    dw 0x1111 ; 14fc: bcf     ANSEL, AN2
    dw 0x1191 ; 14fd: bcf     ANSEL, AN3
    dw 0x1611 ; 14fe: bsf     ANSEL, AN4
    dw 0x1691 ; 14ff: bsf     ANSEL, AN5
    dw 0x1711 ; 1500: bsf     ANSEL, AN6
    dw 0x1791 ; 1501: bsf     ANSEL, AN7
    dw 0x1703 ; 1502: bsf     STATUS, RP1
    dw 0x138c ; 1503: bcf     EECON1, EEPGD
    dw 0x1283 ; 1504: bcf     STATUS, RP0
    dw 0x01c3 ; 1505: clrf    0x43
    dw 0x178b ; 1506: bsf     INTCON, GIE
    dw 0x1303 ; 1507: bcf     STATUS, RP1
    dw 0x0008 ; 1508: return
    dw 0x0183 ; 1509: clrf    STATUS
    dw 0x083d ; 150a: movf    0x3d, W
    dw 0x043c ; 150b: iorwf   0x3c, W
    dw 0x1903 ; 150c: btfsc   STATUS, Z
    dw 0x3400 ; 150d: retlw   0x00
    dw 0x160a ; 150e: bsf     PCLATH, 0x4
    dw 0x158a ; 150f: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1510: call    function_074
    dw 0x083d ; 1511: movf    0x3d, W
    dw 0x00e7 ; 1512: movwf   0x67
    dw 0x083c ; 1513: movf    0x3c, W
    dw 0x3e04 ; 1514: addlw   0x04
    dw 0x1803 ; 1515: btfsc   STATUS, C
    dw 0x0ae7 ; 1516: incf    0x67, F
    dw 0x120a ; 1517: bcf     PCLATH, 0x4
    dw 0x118a ; 1518: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1519: call    function_003
    dw 0x160a ; 151a: bsf     PCLATH, 0x4
    dw 0x118a ; 151b: bcf     PCLATH, 0x3
    dw 0x0084 ; 151c: movwf   FSR
    dw 0x1383 ; 151d: bcf     STATUS, IRP
    dw 0x1800 ; 151e: btfsc   INDF, 0x0
    dw 0x2d94 ; 151f: goto    label_360
    dw 0x083d ; 1520: movf    0x3d, W
    dw 0x00e7 ; 1521: movwf   0x67
    dw 0x083c ; 1522: movf    0x3c, W
    dw 0x3e04 ; 1523: addlw   0x04
    dw 0x1803 ; 1524: btfsc   STATUS, C
    dw 0x0ae7 ; 1525: incf    0x67, F
    dw 0x120a ; 1526: bcf     PCLATH, 0x4
    dw 0x118a ; 1527: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1528: call    function_003
    dw 0x0084 ; 1529: movwf   FSR
    dw 0x1383 ; 152a: bcf     STATUS, IRP
    dw 0x1400 ; 152b: bsf     INDF, 0x0
    dw 0x083d ; 152c: movf    0x3d, W
    dw 0x00e7 ; 152d: movwf   0x67
    dw 0x083c ; 152e: movf    0x3c, W
    dw 0x120a ; 152f: bcf     PCLATH, 0x4
    dw 0x118a ; 1530: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1531: call    function_003
    dw 0x160a ; 1532: bsf     PCLATH, 0x4
    dw 0x118a ; 1533: bcf     PCLATH, 0x3
    dw 0x3800 ; 1534: iorlw   0x00
    dw 0x1903 ; 1535: btfsc   STATUS, Z
    dw 0x2d53 ; 1536: goto    label_358
    dw 0x083f ; 1537: movf    0x3f, W
    dw 0x043e ; 1538: iorwf   0x3e, W
    dw 0x1903 ; 1539: btfsc   STATUS, Z
    dw 0x2d53 ; 153a: goto    label_358
    dw 0x083e ; 153b: movf    0x3e, W
    dw 0x00bc ; 153c: movwf   0x3c
    dw 0x083f ; 153d: movf    0x3f, W
    dw 0x00bd ; 153e: movwf   0x3d
    dw 0x083d ; 153f: movf    0x3d, W
    dw 0x00e7 ; 1540: movwf   0x67
    dw 0x083c ; 1541: movf    0x3c, W
    dw 0x3e01 ; 1542: addlw   0x01
    dw 0x1803 ; 1543: btfsc   STATUS, C
    dw 0x0ae7 ; 1544: incf    0x67, F
    dw 0x120a ; 1545: bcf     PCLATH, 0x4
    dw 0x118a ; 1546: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1547: call    function_003
    dw 0x00be ; 1548: movwf   0x3e
    dw 0x01bf ; 1549: clrf    0x3f
    dw 0x083d ; 154a: movf    0x3d, W
    dw 0x00e7 ; 154b: movwf   0x67
    dw 0x083c ; 154c: movf    0x3c, W
    dw 0x120a ; 154d: bcf     PCLATH, 0x4
    dw 0x118a ; 154e: bcf     PCLATH, 0x3
    dw 0x21e7 ; 154f: call    function_003
    dw 0x160a ; 1550: bsf     PCLATH, 0x4
    dw 0x158a ; 1551: bsf     PCLATH, 0x3
    dw 0x2784 ; 1552: call    function_079
    dw 0x160a ; 1553: bsf     PCLATH, 0x4
    dw 0x158a ; 1554: bsf     PCLATH, 0x3
    dw 0x26ac ; 1555: call    function_069
    dw 0x083d ; 1556: movf    0x3d, W
    dw 0x00e7 ; 1557: movwf   0x67
    dw 0x083c ; 1558: movf    0x3c, W
    dw 0x3e02 ; 1559: addlw   0x02
    dw 0x1803 ; 155a: btfsc   STATUS, C
    dw 0x0ae7 ; 155b: incf    0x67, F
    dw 0x120a ; 155c: bcf     PCLATH, 0x4
    dw 0x118a ; 155d: bcf     PCLATH, 0x3
    dw 0x21e7 ; 155e: call    function_003
    dw 0x160a ; 155f: bsf     PCLATH, 0x4
    dw 0x118a ; 1560: bcf     PCLATH, 0x3
    dw 0x3800 ; 1561: iorlw   0x00
    dw 0x1903 ; 1562: btfsc   STATUS, Z
    dw 0x2d85 ; 1563: goto    label_359
    dw 0x083d ; 1564: movf    0x3d, W
    dw 0x00e7 ; 1565: movwf   0x67
    dw 0x083c ; 1566: movf    0x3c, W
    dw 0x3e02 ; 1567: addlw   0x02
    dw 0x1803 ; 1568: btfsc   STATUS, C
    dw 0x0ae7 ; 1569: incf    0x67, F
    dw 0x120a ; 156a: bcf     PCLATH, 0x4
    dw 0x118a ; 156b: bcf     PCLATH, 0x3
    dw 0x21e7 ; 156c: call    function_003
    dw 0x160a ; 156d: bsf     PCLATH, 0x4
    dw 0x118a ; 156e: bcf     PCLATH, 0x3
    dw 0x20f7 ; 156f: call    function_026
    dw 0x160a ; 1570: bsf     PCLATH, 0x4
    dw 0x118a ; 1571: bcf     PCLATH, 0x3
    dw 0x00bc ; 1572: movwf   0x3c
    dw 0x3a03 ; 1573: xorlw   0x03
    dw 0x1d03 ; 1574: btfss   STATUS, Z
    dw 0x3400 ; 1575: retlw   0x00
    dw 0x083d ; 1576: movf    0x3d, W
    dw 0x00e7 ; 1577: movwf   0x67
    dw 0x083c ; 1578: movf    0x3c, W
    dw 0x3e04 ; 1579: addlw   0x04
    dw 0x1803 ; 157a: btfsc   STATUS, C
    dw 0x0ae7 ; 157b: incf    0x67, F
    dw 0x120a ; 157c: bcf     PCLATH, 0x4
    dw 0x118a ; 157d: bcf     PCLATH, 0x3
    dw 0x21e7 ; 157e: call    function_003
    dw 0x160a ; 157f: bsf     PCLATH, 0x4
    dw 0x118a ; 1580: bcf     PCLATH, 0x3
    dw 0x0084 ; 1581: movwf   FSR
    dw 0x1383 ; 1582: bcf     STATUS, IRP
    dw 0x1000 ; 1583: bcf     INDF, 0x0
    dw 0x3403 ; 1584: retlw   0x03
    dw 0x083d ; 1585: movf    0x3d, W
    dw 0x00e7 ; 1586: movwf   0x67
    dw 0x083c ; 1587: movf    0x3c, W
    dw 0x3e04 ; 1588: addlw   0x04
    dw 0x1803 ; 1589: btfsc   STATUS, C
    dw 0x0ae7 ; 158a: incf    0x67, F
    dw 0x120a ; 158b: bcf     PCLATH, 0x4
    dw 0x118a ; 158c: bcf     PCLATH, 0x3
    dw 0x21e7 ; 158d: call    function_003
    dw 0x160a ; 158e: bsf     PCLATH, 0x4
    dw 0x118a ; 158f: bcf     PCLATH, 0x3
    dw 0x0084 ; 1590: movwf   FSR
    dw 0x1383 ; 1591: bcf     STATUS, IRP
    dw 0x1000 ; 1592: bcf     INDF, 0x0
    dw 0x3404 ; 1593: retlw   0x04
    dw 0x160a ; 1594: bsf     PCLATH, 0x4
    dw 0x158a ; 1595: bsf     PCLATH, 0x3
    dw 0x26ac ; 1596: call    function_069
    dw 0x160a ; 1597: bsf     PCLATH, 0x4
    dw 0x118a ; 1598: bcf     PCLATH, 0x3
    dw 0x3401 ; 1599: retlw   0x01
    dw 0x0183 ; 159a: clrf    STATUS
    dw 0x00db ; 159b: movwf   0x5b
    dw 0x30c4 ; 159c: movlw   0xc4
    dw 0x00dc ; 159d: movwf   0x5c
    dw 0x3009 ; 159e: movlw   0x09
    dw 0x00dd ; 159f: movwf   0x5d
    dw 0x1683 ; 15a0: bsf     STATUS, RP0
    dw 0x1703 ; 15a1: bsf     STATUS, RP1
    dw 0x188c ; 15a2: btfsc   EECON1, WR
    dw 0x2da0 ; 15a3: goto    label_361
    dw 0x1283 ; 15a4: bcf     STATUS, RP0
    dw 0x1303 ; 15a5: bcf     STATUS, RP1
    dw 0x085b ; 15a6: movf    0x5b, W
    dw 0x1703 ; 15a7: bsf     STATUS, RP1
    dw 0x008d ; 15a8: movwf   EEADRL
    dw 0x1303 ; 15a9: bcf     STATUS, RP1
    dw 0x085a ; 15aa: movf    0x5a, W
    dw 0x1703 ; 15ab: bsf     STATUS, RP1
    dw 0x008c ; 15ac: movwf   EEDATA
    dw 0x1683 ; 15ad: bsf     STATUS, RP0
    dw 0x138c ; 15ae: bcf     EECON1, EEPGD
    dw 0x1003 ; 15af: bcf     STATUS, C
    dw 0x1b8b ; 15b0: btfsc   INTCON, GIE
    dw 0x1403 ; 15b1: bsf     STATUS, C
    dw 0x138b ; 15b2: bcf     INTCON, GIE
    dw 0x150c ; 15b3: bsf     EECON1, WREN
    dw 0x3055 ; 15b4: movlw   0x55
    dw 0x008d ; 15b5: movwf   EECON2
    dw 0x30aa ; 15b6: movlw   0xaa
    dw 0x008d ; 15b7: movwf   EECON2
    dw 0x148c ; 15b8: bsf     EECON1, WR
    dw 0x110c ; 15b9: bcf     EECON1, WREN
    dw 0x1803 ; 15ba: btfsc   STATUS, C
    dw 0x178b ; 15bb: bsf     INTCON, GIE
    dw 0x1683 ; 15bc: bsf     STATUS, RP0
    dw 0x1703 ; 15bd: bsf     STATUS, RP1
    dw 0x1c8c ; 15be: btfss   EECON1, WR
    dw 0x2dca ; 15bf: goto    label_363
    dw 0x1283 ; 15c0: bcf     STATUS, RP0
    dw 0x1303 ; 15c1: bcf     STATUS, RP1
    dw 0x08dc ; 15c2: movf    0x5c, F
    dw 0x1903 ; 15c3: btfsc   STATUS, Z
    dw 0x03dd ; 15c4: decf    0x5d, F
    dw 0x03dc ; 15c5: decf    0x5c, F
    dw 0x085d ; 15c6: movf    0x5d, W
    dw 0x045c ; 15c7: iorwf   0x5c, W
    dw 0x1d03 ; 15c8: btfss   STATUS, Z
    dw 0x2dbc ; 15c9: goto    label_362
    dw 0x0183 ; 15ca: clrf    STATUS
    dw 0x0008 ; 15cb: return
    dw 0x0183 ; 15cc: clrf    STATUS
    dw 0x00d8 ; 15cd: movwf   0x58
    dw 0x01d9 ; 15ce: clrf    0x59
    dw 0x3011 ; 15cf: movlw   0x11
    dw 0x0258 ; 15d0: subwf   0x58, W
    dw 0x1c03 ; 15d1: btfss   STATUS, C
    dw 0x2dfe ; 15d2: goto    label_374
    dw 0x2e31 ; 15d3: goto    label_376
    dw 0x3002 ; 15d4: movlw   0x02
    dw 0x2df8 ; 15d5: goto    label_372
    dw 0x3065 ; 15d6: movlw   0x65
    dw 0x2df8 ; 15d7: goto    label_372
    dw 0x0857 ; 15d8: movf    0x57, W
    dw 0x3a02 ; 15d9: xorlw   0x02
    dw 0x1903 ; 15da: btfsc   STATUS, Z
    dw 0x2dfb ; 15db: goto    label_373
    dw 0x0857 ; 15dc: movf    0x57, W
    dw 0x3a04 ; 15dd: xorlw   0x04
    dw 0x1903 ; 15de: btfsc   STATUS, Z
    dw 0x2dfb ; 15df: goto    label_373
    dw 0x0857 ; 15e0: movf    0x57, W
    dw 0x3a06 ; 15e1: xorlw   0x06
    dw 0x1d03 ; 15e2: btfss   STATUS, Z
    dw 0x2e20 ; 15e3: goto    label_375
    dw 0x2dfb ; 15e4: goto    label_373
    dw 0x3001 ; 15e5: movlw   0x01
    dw 0x0257 ; 15e6: subwf   0x57, W
    dw 0x1c03 ; 15e7: btfss   STATUS, C
    dw 0x2e20 ; 15e8: goto    label_375
    dw 0x3035 ; 15e9: movlw   0x35
    dw 0x2df8 ; 15ea: goto    label_372
    dw 0x3064 ; 15eb: movlw   0x64
    dw 0x2df8 ; 15ec: goto    label_372
    dw 0x3004 ; 15ed: movlw   0x04
    dw 0x2df8 ; 15ee: goto    label_372
    dw 0x0a57 ; 15ef: incf    0x57, W
    dw 0x1903 ; 15f0: btfsc   STATUS, Z
    dw 0x2e20 ; 15f1: goto    label_375
    dw 0x2dfb ; 15f2: goto    label_373
    dw 0x30ae ; 15f3: movlw   0xae
    dw 0x0257 ; 15f4: subwf   0x57, W
    dw 0x1c03 ; 15f5: btfss   STATUS, C
    dw 0x2e20 ; 15f6: goto    label_375
    dw 0x30d0 ; 15f7: movlw   0xd0
    dw 0x0257 ; 15f8: subwf   0x57, W
    dw 0x1803 ; 15f9: btfsc   STATUS, C
    dw 0x2e20 ; 15fa: goto    label_375
    dw 0x01d9 ; 15fb: clrf    0x59
    dw 0x0ad9 ; 15fc: incf    0x59, F
    dw 0x2e20 ; 15fd: goto    label_375
    dw 0x0858 ; 15fe: movf    0x58, W
    dw 0x00f0 ; 15ff: movwf   Common_RAM
    dw 0x3eef ; 1600: addlw   0xef
    dw 0x1803 ; 1601: btfsc   STATUS, C
    dw 0x2e20 ; 1602: goto    label_375
    dw 0x3e11 ; 1603: addlw   0x11
    dw 0x1c03 ; 1604: btfss   STATUS, C
    dw 0x2e20 ; 1605: goto    label_375
    dw 0x3000 ; 1606: movlw   0x00
    dw 0x02f0 ; 1607: subwf   Common_RAM, F
    dw 0x3016 ; 1608: movlw   0x16
    dw 0x008a ; 1609: movwf   PCLATH
    dw 0x300f ; 160a: movlw   0x0f
    dw 0x0770 ; 160b: addwf   Common_RAM, W
    dw 0x1803 ; 160c: btfsc   STATUS, C
    dw 0x0a8a ; 160d: incf    PCLATH, F
    dw 0x0082 ; 160e: movwf   PCL
    dw 0x2ded ; 160f: goto    label_369
    dw 0x2ded ; 1610: goto    label_369
    dw 0x2dd4 ; 1611: goto    label_364
    dw 0x2dd4 ; 1612: goto    label_364
    dw 0x2dd6 ; 1613: goto    label_365
    dw 0x2dd8 ; 1614: goto    label_366
    dw 0x2de5 ; 1615: goto    label_367
    dw 0x2deb ; 1616: goto    label_368
    dw 0x2def ; 1617: goto    label_370
    dw 0x2def ; 1618: goto    label_370
    dw 0x2def ; 1619: goto    label_370
    dw 0x2def ; 161a: goto    label_370
    dw 0x2ded ; 161b: goto    label_369
    dw 0x2ded ; 161c: goto    label_369
    dw 0x2def ; 161d: goto    label_370
    dw 0x2df3 ; 161e: goto    label_371
    dw 0x2dfb ; 161f: goto    label_373
    dw 0x08d9 ; 1620: movf    0x59, F
    dw 0x1903 ; 1621: btfsc   STATUS, Z
    dw 0x0008 ; 1622: return
    dw 0x0857 ; 1623: movf    0x57, W
    dw 0x00da ; 1624: movwf   0x5a
    dw 0x0858 ; 1625: movf    0x58, W
    dw 0x259a ; 1626: call    function_033
    dw 0x0857 ; 1627: movf    0x57, W
    dw 0x00da ; 1628: movwf   0x5a
    dw 0x0858 ; 1629: movf    0x58, W
    dw 0x3e64 ; 162a: addlw   0x64
    dw 0x259a ; 162b: call    function_033
    dw 0x0857 ; 162c: movf    0x57, W
    dw 0x00da ; 162d: movwf   0x5a
    dw 0x0858 ; 162e: movf    0x58, W
    dw 0x3ec8 ; 162f: addlw   0xc8
    dw 0x2d9a ; 1630: goto    function_033
    dw 0x0857 ; 1631: movf    0x57, W
    dw 0x00da ; 1632: movwf   0x5a
    dw 0x0858 ; 1633: movf    0x58, W
    dw 0x2d9a ; 1634: goto    function_033
    dw 0x0183 ; 1635: clrf    STATUS
    dw 0x00bd ; 1636: movwf   0x3d
    dw 0x160a ; 1637: bsf     PCLATH, 0x4
    dw 0x158a ; 1638: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1639: call    function_074
    dw 0x160a ; 163a: bsf     PCLATH, 0x4
    dw 0x118a ; 163b: bcf     PCLATH, 0x3
    dw 0x083d ; 163c: movf    0x3d, W
    dw 0x0084 ; 163d: movwf   FSR
    dw 0x1383 ; 163e: bcf     STATUS, IRP
    dw 0x0800 ; 163f: movf    INDF, W
    dw 0x00f0 ; 1640: movwf   Common_RAM
    dw 0x0a84 ; 1641: incf    FSR, F
    dw 0x0800 ; 1642: movf    INDF, W
    dw 0x00f1 ; 1643: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1644: iorwf   Common_RAM, W
    dw 0x1903 ; 1645: btfsc   STATUS, Z
    dw 0x2e65 ; 1646: goto    label_378
    dw 0x083d ; 1647: movf    0x3d, W
    dw 0x0084 ; 1648: movwf   FSR
    dw 0x30ff ; 1649: movlw   0xff
    dw 0x0780 ; 164a: addwf   INDF, F
    dw 0x0a84 ; 164b: incf    FSR, F
    dw 0x1803 ; 164c: btfsc   STATUS, C
    dw 0x0a80 ; 164d: incf    INDF, F
    dw 0x0780 ; 164e: addwf   INDF, F
    dw 0x0384 ; 164f: decf    FSR, F
    dw 0x0800 ; 1650: movf    INDF, W
    dw 0x00f0 ; 1651: movwf   Common_RAM
    dw 0x0a84 ; 1652: incf    FSR, F
    dw 0x0800 ; 1653: movf    INDF, W
    dw 0x00f1 ; 1654: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1655: iorwf   Common_RAM, W
    dw 0x1d03 ; 1656: btfss   STATUS, Z
    dw 0x2e65 ; 1657: goto    label_378
    dw 0x083d ; 1658: movf    0x3d, W
    dw 0x3e02 ; 1659: addlw   0x02
    dw 0x0084 ; 165a: movwf   FSR
    dw 0x0880 ; 165b: movf    INDF, F
    dw 0x1903 ; 165c: btfsc   STATUS, Z
    dw 0x2e65 ; 165d: goto    label_378
    dw 0x083d ; 165e: movf    0x3d, W
    dw 0x3e02 ; 165f: addlw   0x02
    dw 0x0084 ; 1660: movwf   FSR
    dw 0x0800 ; 1661: movf    INDF, W
    dw 0x160a ; 1662: bsf     PCLATH, 0x4
    dw 0x118a ; 1663: bcf     PCLATH, 0x3
    dw 0x20f7 ; 1664: call    function_026
    dw 0x160a ; 1665: bsf     PCLATH, 0x4
    dw 0x158a ; 1666: bsf     PCLATH, 0x3
    dw 0x2eac ; 1667: goto    function_069
    dw 0x0183 ; 1668: clrf    STATUS
    dw 0x00bd ; 1669: movwf   0x3d
    dw 0x160a ; 166a: bsf     PCLATH, 0x4
    dw 0x158a ; 166b: bsf     PCLATH, 0x3
    dw 0x26d8 ; 166c: call    function_074
    dw 0x160a ; 166d: bsf     PCLATH, 0x4
    dw 0x118a ; 166e: bcf     PCLATH, 0x3
    dw 0x083d ; 166f: movf    0x3d, W
    dw 0x0084 ; 1670: movwf   FSR
    dw 0x1383 ; 1671: bcf     STATUS, IRP
    dw 0x0800 ; 1672: movf    INDF, W
    dw 0x00f0 ; 1673: movwf   Common_RAM
    dw 0x0a84 ; 1674: incf    FSR, F
    dw 0x0800 ; 1675: movf    INDF, W
    dw 0x00f1 ; 1676: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1677: iorwf   Common_RAM, W
    dw 0x1903 ; 1678: btfsc   STATUS, Z
    dw 0x2ea7 ; 1679: goto    label_380
    dw 0x083d ; 167a: movf    0x3d, W
    dw 0x0084 ; 167b: movwf   FSR
    dw 0x30ff ; 167c: movlw   0xff
    dw 0x0780 ; 167d: addwf   INDF, F
    dw 0x0a84 ; 167e: incf    FSR, F
    dw 0x1803 ; 167f: btfsc   STATUS, C
    dw 0x0a80 ; 1680: incf    INDF, F
    dw 0x0780 ; 1681: addwf   INDF, F
    dw 0x0384 ; 1682: decf    FSR, F
    dw 0x0800 ; 1683: movf    INDF, W
    dw 0x00f0 ; 1684: movwf   Common_RAM
    dw 0x0a84 ; 1685: incf    FSR, F
    dw 0x0800 ; 1686: movf    INDF, W
    dw 0x00f1 ; 1687: movwf   (Common_RAM + 1)
    dw 0x0470 ; 1688: iorwf   Common_RAM, W
    dw 0x1d03 ; 1689: btfss   STATUS, Z
    dw 0x2ea7 ; 168a: goto    label_380
    dw 0x083d ; 168b: movf    0x3d, W
    dw 0x3e03 ; 168c: addlw   0x03
    dw 0x0084 ; 168d: movwf   FSR
    dw 0x0800 ; 168e: movf    INDF, W
    dw 0x00f0 ; 168f: movwf   Common_RAM
    dw 0x0a84 ; 1690: incf    FSR, F
    dw 0x0800 ; 1691: movf    INDF, W
    dw 0x00f1 ; 1692: movwf   (Common_RAM + 1)
    dw 0x083d ; 1693: movf    0x3d, W
    dw 0x0084 ; 1694: movwf   FSR
    dw 0x0870 ; 1695: movf    Common_RAM, W
    dw 0x0080 ; 1696: movwf   INDF
    dw 0x0a84 ; 1697: incf    FSR, F
    dw 0x0871 ; 1698: movf    (Common_RAM + 1), W
    dw 0x0080 ; 1699: movwf   INDF
    dw 0x083d ; 169a: movf    0x3d, W
    dw 0x3e02 ; 169b: addlw   0x02
    dw 0x0084 ; 169c: movwf   FSR
    dw 0x0880 ; 169d: movf    INDF, F
    dw 0x1903 ; 169e: btfsc   STATUS, Z
    dw 0x2ea7 ; 169f: goto    label_380
    dw 0x083d ; 16a0: movf    0x3d, W
    dw 0x3e02 ; 16a1: addlw   0x02
    dw 0x0084 ; 16a2: movwf   FSR
    dw 0x0800 ; 16a3: movf    INDF, W
    dw 0x160a ; 16a4: bsf     PCLATH, 0x4
    dw 0x118a ; 16a5: bcf     PCLATH, 0x3
    dw 0x20f7 ; 16a6: call    function_026
    dw 0x160a ; 16a7: bsf     PCLATH, 0x4
    dw 0x158a ; 16a8: bsf     PCLATH, 0x3
    dw 0x2eac ; 16a9: goto    function_069
    dw 0x0183 ; 16aa: clrf    STATUS
    dw 0x00bc ; 16ab: movwf   0x3c
    dw 0x3001 ; 16ac: movlw   0x01
    dw 0x023c ; 16ad: subwf   0x3c, W
    dw 0x1803 ; 16ae: btfsc   STATUS, C
    dw 0x2eba ; 16af: goto    label_403
    dw 0x3005 ; 16b0: movlw   0x05
    dw 0x00f1 ; 16b1: movwf   (Common_RAM + 1)
    dw 0x083c ; 16b2: movf    0x3c, W
    dw 0x160a ; 16b3: bsf     PCLATH, 0x4
    dw 0x158a ; 16b4: bsf     PCLATH, 0x3
    dw 0x26e2 ; 16b5: call    function_075
    dw 0x160a ; 16b6: bsf     PCLATH, 0x4
    dw 0x118a ; 16b7: bcf     PCLATH, 0x3
    dw 0x3ea7 ; 16b8: addlw   0xa7
    dw 0x2e68 ; 16b9: goto    label_379
    dw 0x3003 ; 16ba: movlw   0x03
    dw 0x00f1 ; 16bb: movwf   (Common_RAM + 1)
    dw 0x083c ; 16bc: movf    0x3c, W
    dw 0x160a ; 16bd: bsf     PCLATH, 0x4
    dw 0x158a ; 16be: bsf     PCLATH, 0x3
    dw 0x26e2 ; 16bf: call    function_075
    dw 0x160a ; 16c0: bsf     PCLATH, 0x4
    dw 0x118a ; 16c1: bcf     PCLATH, 0x3
    dw 0x3efd ; 16c2: addlw   0xfd
    dw 0x3eac ; 16c3: addlw   0xac
    dw 0x2e35 ; 16c4: goto    label_377
    dw 0x3004 ; 16c5: movlw   0x04
    dw 0x0183 ; 16c6: clrf    STATUS
    dw 0x07b1 ; 16c7: addwf   0x31, F
    dw 0x1803 ; 16c8: btfsc   STATUS, C
    dw 0x0ab2 ; 16c9: incf    0x32, F
    dw 0x2ed3 ; 16ca: goto    label_382
    dw 0x0ab3 ; 16cb: incf    0x33, F
    dw 0x1903 ; 16cc: btfsc   STATUS, Z
    dw 0x0ab4 ; 16cd: incf    0x34, F
    dw 0x082f ; 16ce: movf    0x2f, W
    dw 0x26aa ; 16cf: call    function_035
    dw 0x160a ; 16d0: bsf     PCLATH, 0x4
    dw 0x118a ; 16d1: bcf     PCLATH, 0x3
    dw 0x0aaf ; 16d2: incf    0x2f, F
    dw 0x0832 ; 16d3: movf    0x32, W
    dw 0x0234 ; 16d4: subwf   0x34, W
    dw 0x1d03 ; 16d5: btfss   STATUS, Z
    dw 0x2ed9 ; 16d6: goto    label_383
    dw 0x0831 ; 16d7: movf    0x31, W
    dw 0x0233 ; 16d8: subwf   0x33, W
    dw 0x1c03 ; 16d9: btfss   STATUS, C
    dw 0x2ecb ; 16da: goto    label_381
    dw 0x3000 ; 16db: movlw   0x00
    dw 0x0232 ; 16dc: subwf   0x32, W
    dw 0x3004 ; 16dd: movlw   0x04
    dw 0x1903 ; 16de: btfsc   STATUS, Z
    dw 0x0231 ; 16df: subwf   0x31, W
    dw 0x1c03 ; 16e0: btfss   STATUS, C
    dw 0x0008 ; 16e1: return
    dw 0x01b1 ; 16e2: clrf    0x31
    dw 0x01b2 ; 16e3: clrf    0x32
    dw 0x01b3 ; 16e4: clrf    0x33
    dw 0x01b4 ; 16e5: clrf    0x34
    dw 0x01af ; 16e6: clrf    0x2f
    dw 0x0008 ; 16e7: return
    dw 0x0183 ; 16e8: clrf    STATUS
    dw 0x0aae ; 16e9: incf    0x2e, F
    dw 0x0b2e ; 16ea: decfsz  0x2e, W
    dw 0x2efa ; 16eb: goto    label_386
    dw 0x2ef7 ; 16ec: goto    label_385
    dw 0x160a ; 16ed: bsf     PCLATH, 0x4
    dw 0x158a ; 16ee: bsf     PCLATH, 0x3
    dw 0x26d8 ; 16ef: call    function_074
    dw 0x03b0 ; 16f0: decf    0x30, F
    dw 0x160a ; 16f1: bsf     PCLATH, 0x4
    dw 0x158a ; 16f2: bsf     PCLATH, 0x3
    dw 0x26ac ; 16f3: call    function_069
    dw 0x160a ; 16f4: bsf     PCLATH, 0x4
    dw 0x118a ; 16f5: bcf     PCLATH, 0x3
    dw 0x26c5 ; 16f6: call    function_036
    dw 0x08b0 ; 16f7: movf    0x30, F
    dw 0x1d03 ; 16f8: btfss   STATUS, Z
    dw 0x2eed ; 16f9: goto    label_384
    dw 0x03ae ; 16fa: decf    0x2e, F
    dw 0x0008 ; 16fb: return
    dw 0x0183 ; 16fc: clrf    STATUS
    dw 0x00ca ; 16fd: movwf   0x4a
    dw 0x3018 ; 16fe: movlw   0x18
    dw 0x008a ; 16ff: movwf   PCLATH
    dw 0x084a ; 1700: movf    0x4a, W
    dw 0x3907 ; 1701: andlw   0x07
    dw 0x2032 ; 1702: call    function_023
    dw 0x160a ; 1703: bsf     PCLATH, 0x4
    dw 0x118a ; 1704: bcf     PCLATH, 0x3
    dw 0x00f0 ; 1705: movwf   Common_RAM
    dw 0x084a ; 1706: movf    0x4a, W
    dw 0x00f1 ; 1707: movwf   (Common_RAM + 1)
    dw 0x1003 ; 1708: bcf     STATUS, C
    dw 0x0cf1 ; 1709: rrf     (Common_RAM + 1), F
    dw 0x1003 ; 170a: bcf     STATUS, C
    dw 0x0cf1 ; 170b: rrf     (Common_RAM + 1), F
    dw 0x1003 ; 170c: bcf     STATUS, C
    dw 0x0c71 ; 170d: rrf     (Common_RAM + 1), W
    dw 0x3ea1 ; 170e: addlw   0xa1
    dw 0x0084 ; 170f: movwf   FSR
    dw 0x1383 ; 1710: bcf     STATUS, IRP
    dw 0x0800 ; 1711: movf    INDF, W
    dw 0x0570 ; 1712: andwf   Common_RAM, W
    dw 0x1d03 ; 1713: btfss   STATUS, Z
    dw 0x3401 ; 1714: retlw   0x01
    dw 0x3400 ; 1715: retlw   0x00
    dw 0x0183 ; 1716: clrf    STATUS
    dw 0x00c9 ; 1717: movwf   0x49
    dw 0x3005 ; 1718: movlw   0x05
    dw 0x0249 ; 1719: subwf   0x49, W
    dw 0x1803 ; 171a: btfsc   STATUS, C
    dw 0x3401 ; 171b: retlw   0x01
    dw 0x0849 ; 171c: movf    0x49, W
    dw 0x26fc ; 171d: call    function_038
    dw 0x3800 ; 171e: iorlw   0x00
    dw 0x1903 ; 171f: btfsc   STATUS, Z
    dw 0x3402 ; 1720: retlw   0x02
    dw 0x160a ; 1721: bsf     PCLATH, 0x4
    dw 0x158a ; 1722: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1723: call    function_074
    dw 0x160a ; 1724: bsf     PCLATH, 0x4
    dw 0x118a ; 1725: bcf     PCLATH, 0x3
    dw 0x1683 ; 1726: bsf     STATUS, RP0
    dw 0x03a0 ; 1727: decf    0x20, F
    dw 0x1283 ; 1728: bcf     STATUS, RP0
    dw 0x0849 ; 1729: movf    0x49, W
    dw 0x3ea2 ; 172a: addlw   0xa2
    dw 0x0084 ; 172b: movwf   FSR
    dw 0x1383 ; 172c: bcf     STATUS, IRP
    dw 0x0b80 ; 172d: decfsz  INDF, F
    dw 0x2f40 ; 172e: goto    label_387
    dw 0x0849 ; 172f: movf    0x49, W
    dw 0x00f0 ; 1730: movwf   Common_RAM
    dw 0x1003 ; 1731: bcf     STATUS, C
    dw 0x0cf0 ; 1732: rrf     Common_RAM, F
    dw 0x1003 ; 1733: bcf     STATUS, C
    dw 0x0cf0 ; 1734: rrf     Common_RAM, F
    dw 0x1003 ; 1735: bcf     STATUS, C
    dw 0x0c70 ; 1736: rrf     Common_RAM, W
    dw 0x3ea1 ; 1737: addlw   0xa1
    dw 0x0084 ; 1738: movwf   FSR
    dw 0x3018 ; 1739: movlw   0x18
    dw 0x008a ; 173a: movwf   PCLATH
    dw 0x0849 ; 173b: movf    0x49, W
    dw 0x3907 ; 173c: andlw   0x07
    dw 0x2032 ; 173d: call    function_023
    dw 0x3aff ; 173e: xorlw   0xff
    dw 0x0580 ; 173f: andwf   INDF, F
    dw 0x160a ; 1740: bsf     PCLATH, 0x4
    dw 0x158a ; 1741: bsf     PCLATH, 0x3
    dw 0x26ac ; 1742: call    function_069
    dw 0x160a ; 1743: bsf     PCLATH, 0x4
    dw 0x118a ; 1744: bcf     PCLATH, 0x3
    dw 0x3400 ; 1745: retlw   0x00
    dw 0x1683 ; 1746: bsf     STATUS, RP0
    dw 0x1303 ; 1747: bcf     STATUS, RP1
    dw 0x08a0 ; 1748: movf    0x20, F
    dw 0x1903 ; 1749: btfsc   STATUS, Z
    dw 0x2f92 ; 174a: goto    label_399
    dw 0x1283 ; 174b: bcf     STATUS, RP0
    dw 0x01c0 ; 174c: clrf    0x40
    dw 0x0840 ; 174d: movf    0x40, W
    dw 0x3ea1 ; 174e: addlw   0xa1
    dw 0x0084 ; 174f: movwf   FSR
    dw 0x1383 ; 1750: bcf     STATUS, IRP
    dw 0x0880 ; 1751: movf    INDF, F
    dw 0x3001 ; 1752: movlw   0x01
    dw 0x1d03 ; 1753: btfss   STATUS, Z
    dw 0x2f5a ; 1754: goto    label_389
    dw 0x0ac0 ; 1755: incf    0x40, F
    dw 0x0240 ; 1756: subwf   0x40, W
    dw 0x1c03 ; 1757: btfss   STATUS, C
    dw 0x2f4d ; 1758: goto    label_388
    dw 0x3001 ; 1759: movlw   0x01
    dw 0x0240 ; 175a: subwf   0x40, W
    dw 0x1803 ; 175b: btfsc   STATUS, C
    dw 0x2f92 ; 175c: goto    label_399
    dw 0x0840 ; 175d: movf    0x40, W
    dw 0x3ea1 ; 175e: addlw   0xa1
    dw 0x0084 ; 175f: movwf   FSR
    dw 0x0800 ; 1760: movf    INDF, W
    dw 0x00bf ; 1761: movwf   0x3f
    dw 0x1003 ; 1762: bcf     STATUS, C
    dw 0x0dc0 ; 1763: rlf     0x40, F
    dw 0x1003 ; 1764: bcf     STATUS, C
    dw 0x0dc0 ; 1765: rlf     0x40, F
    dw 0x1003 ; 1766: bcf     STATUS, C
    dw 0x0dc0 ; 1767: rlf     0x40, F
    dw 0x183f ; 1768: btfsc   0x3f, 0x0
    dw 0x2f8e ; 1769: goto    label_397
    dw 0x18bf ; 176a: btfsc   0x3f, 0x1
    dw 0x2f8c ; 176b: goto    label_396
    dw 0x193f ; 176c: btfsc   0x3f, 0x2
    dw 0x2f89 ; 176d: goto    label_395
    dw 0x19bf ; 176e: btfsc   0x3f, 0x3
    dw 0x2f86 ; 176f: goto    label_394
    dw 0x1a3f ; 1770: btfsc   0x3f, 0x4
    dw 0x2f83 ; 1771: goto    label_393
    dw 0x1abf ; 1772: btfsc   0x3f, 0x5
    dw 0x2f80 ; 1773: goto    label_392
    dw 0x1b3f ; 1774: btfsc   0x3f, 0x6
    dw 0x2f7d ; 1775: goto    label_391
    dw 0x1bbf ; 1776: btfsc   0x3f, 0x7
    dw 0x2f7a ; 1777: goto    label_390
    dw 0x3005 ; 1778: movlw   0x05
    dw 0x2f8f ; 1779: goto    label_398
    dw 0x0840 ; 177a: movf    0x40, W
    dw 0x3e07 ; 177b: addlw   0x07
    dw 0x2f8f ; 177c: goto    label_398
    dw 0x0840 ; 177d: movf    0x40, W
    dw 0x3e06 ; 177e: addlw   0x06
    dw 0x2f8f ; 177f: goto    label_398
    dw 0x0840 ; 1780: movf    0x40, W
    dw 0x3e05 ; 1781: addlw   0x05
    dw 0x2f8f ; 1782: goto    label_398
    dw 0x0840 ; 1783: movf    0x40, W
    dw 0x3e04 ; 1784: addlw   0x04
    dw 0x2f8f ; 1785: goto    label_398
    dw 0x0840 ; 1786: movf    0x40, W
    dw 0x3e03 ; 1787: addlw   0x03
    dw 0x2f8f ; 1788: goto    label_398
    dw 0x0840 ; 1789: movf    0x40, W
    dw 0x3e02 ; 178a: addlw   0x02
    dw 0x2f8f ; 178b: goto    label_398
    dw 0x0a40 ; 178c: incf    0x40, W
    dw 0x2f8f ; 178d: goto    label_398
    dw 0x0840 ; 178e: movf    0x40, W
    dw 0x00f0 ; 178f: movwf   Common_RAM
    dw 0x01f1 ; 1790: clrf    (Common_RAM + 1)
    dw 0x2f93 ; 1791: goto    label_400
    dw 0x3005 ; 1792: movlw   0x05
    dw 0x1283 ; 1793: bcf     STATUS, RP0
    dw 0x0008 ; 1794: return
    dw 0x1683 ; 1795: bsf     STATUS, RP0
    dw 0x1303 ; 1796: bcf     STATUS, RP1
    dw 0x08a0 ; 1797: movf    0x20, F
    dw 0x1d03 ; 1798: btfss   STATUS, Z
    dw 0x2fbc ; 1799: goto    label_401
    dw 0x1283 ; 179a: bcf     STATUS, RP0
    dw 0x0862 ; 179b: movf    0x62, W
    dw 0x0461 ; 179c: iorwf   0x61, W
    dw 0x1903 ; 179d: btfsc   STATUS, Z
    dw 0x3405 ; 179e: retlw   0x05
    dw 0x08b5 ; 179f: movf    0x35, F
    dw 0x1d03 ; 17a0: btfss   STATUS, Z
    dw 0x3405 ; 17a1: retlw   0x05
    dw 0x0861 ; 17a2: movf    0x61, W
    dw 0x00cd ; 17a3: movwf   0x4d
    dw 0x0862 ; 17a4: movf    0x62, W
    dw 0x00ce ; 17a5: movwf   0x4e
    dw 0x3005 ; 17a6: movlw   0x05
    dw 0x00cf ; 17a7: movwf   0x4f
    dw 0x01d0 ; 17a8: clrf    0x50
    dw 0x160a ; 17a9: bsf     PCLATH, 0x4
    dw 0x158a ; 17aa: bsf     PCLATH, 0x3
    dw 0x25fe ; 17ab: call    function_044
    dw 0x160a ; 17ac: bsf     PCLATH, 0x4
    dw 0x118a ; 17ad: bcf     PCLATH, 0x3
    dw 0x00f0 ; 17ae: movwf   Common_RAM
    dw 0x01f1 ; 17af: clrf    (Common_RAM + 1)
    dw 0x0471 ; 17b0: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 17b1: btfsc   STATUS, Z
    dw 0x3405 ; 17b2: retlw   0x05
    dw 0x0862 ; 17b3: movf    0x62, W
    dw 0x00e7 ; 17b4: movwf   0x67
    dw 0x0861 ; 17b5: movf    0x61, W
    dw 0x120a ; 17b6: bcf     PCLATH, 0x4
    dw 0x118a ; 17b7: bcf     PCLATH, 0x3
    dw 0x21e7 ; 17b8: call    function_003
    dw 0x160a ; 17b9: bsf     PCLATH, 0x4
    dw 0x118a ; 17ba: bcf     PCLATH, 0x3
    dw 0x3405 ; 17bb: retlw   0x05
    dw 0x160a ; 17bc: bsf     PCLATH, 0x4
    dw 0x158a ; 17bd: bsf     PCLATH, 0x3
    dw 0x26d8 ; 17be: call    function_074
    dw 0x160a ; 17bf: bsf     PCLATH, 0x4
    dw 0x118a ; 17c0: bcf     PCLATH, 0x3
    dw 0x2746 ; 17c1: call    function_040
    dw 0x00bc ; 17c2: movwf   0x3c
    dw 0x3005 ; 17c3: movlw   0x05
    dw 0x023c ; 17c4: subwf   0x3c, W
    dw 0x1c03 ; 17c5: btfss   STATUS, C
    dw 0x2fcd ; 17c6: goto    label_402
    dw 0x160a ; 17c7: bsf     PCLATH, 0x4
    dw 0x158a ; 17c8: bsf     PCLATH, 0x3
    dw 0x26ac ; 17c9: call    function_069
    dw 0x160a ; 17ca: bsf     PCLATH, 0x4
    dw 0x118a ; 17cb: bcf     PCLATH, 0x3
    dw 0x3405 ; 17cc: retlw   0x05
    dw 0x083c ; 17cd: movf    0x3c, W
    dw 0x00e0 ; 17ce: movwf   0x60
    dw 0x0760 ; 17cf: addwf   0x60, W
    dw 0x3eb5 ; 17d0: addlw   0xb5
    dw 0x0084 ; 17d1: movwf   FSR
    dw 0x1383 ; 17d2: bcf     STATUS, IRP
    dw 0x0800 ; 17d3: movf    INDF, W
    dw 0x00bd ; 17d4: movwf   0x3d
    dw 0x0a84 ; 17d5: incf    FSR, F
    dw 0x0800 ; 17d6: movf    INDF, W
    dw 0x00be ; 17d7: movwf   0x3e
    dw 0x0860 ; 17d8: movf    0x60, W
    dw 0x2716 ; 17d9: call    function_039
    dw 0x160a ; 17da: bsf     PCLATH, 0x4
    dw 0x158a ; 17db: bsf     PCLATH, 0x3
    dw 0x26ac ; 17dc: call    function_069
    dw 0x160a ; 17dd: bsf     PCLATH, 0x4
    dw 0x118a ; 17de: bcf     PCLATH, 0x3
    dw 0x083e ; 17df: movf    0x3e, W
    dw 0x043d ; 17e0: iorwf   0x3d, W
    dw 0x1903 ; 17e1: btfsc   STATUS, Z
    dw 0x3405 ; 17e2: retlw   0x05
    dw 0x083d ; 17e3: movf    0x3d, W
    dw 0x00cd ; 17e4: movwf   0x4d
    dw 0x083e ; 17e5: movf    0x3e, W
    dw 0x00ce ; 17e6: movwf   0x4e
    dw 0x0860 ; 17e7: movf    0x60, W
    dw 0x00cf ; 17e8: movwf   0x4f
    dw 0x01d0 ; 17e9: clrf    0x50
    dw 0x160a ; 17ea: bsf     PCLATH, 0x4
    dw 0x158a ; 17eb: bsf     PCLATH, 0x3
    dw 0x25fe ; 17ec: call    function_044
    dw 0x160a ; 17ed: bsf     PCLATH, 0x4
    dw 0x118a ; 17ee: bcf     PCLATH, 0x3
    dw 0x00f0 ; 17ef: movwf   Common_RAM
    dw 0x01f1 ; 17f0: clrf    (Common_RAM + 1)
    dw 0x0471 ; 17f1: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 17f2: btfsc   STATUS, Z
    dw 0x3405 ; 17f3: retlw   0x05
    dw 0x01ac ; 17f4: clrf    0x2c
    dw 0x01ad ; 17f5: clrf    0x2d
    dw 0x083e ; 17f6: movf    0x3e, W
    dw 0x00e7 ; 17f7: movwf   0x67
    dw 0x083d ; 17f8: movf    0x3d, W
    dw 0x120a ; 17f9: bcf     PCLATH, 0x4
    dw 0x118a ; 17fa: bcf     PCLATH, 0x3
    dw 0x21e7 ; 17fb: call    function_003
    dw 0x160a ; 17fc: bsf     PCLATH, 0x4
    dw 0x118a ; 17fd: bcf     PCLATH, 0x3
    dw 0x0860 ; 17fe: movf    0x60, W
    dw 0x0008 ; 17ff: return
    dw 0x0782 ; 1800: addwf   PCL, F
    dw 0x3400 ; 1801: retlw   0x00
    dw 0x3400 ; 1802: retlw   0x00
    dw 0x34d0 ; 1803: retlw   0xd0
    dw 0x3403 ; 1804: retlw   0x03
    dw 0x348a ; 1805: retlw   0x8a
    dw 0x3402 ; 1806: retlw   0x02
    dw 0x34e8 ; 1807: retlw   0xe8
    dw 0x3401 ; 1808: retlw   0x01
    dw 0x3486 ; 1809: retlw   0x86
    dw 0x3401 ; 180a: retlw   0x01
    dw 0x3445 ; 180b: retlw   0x45
    dw 0x3401 ; 180c: retlw   0x01
    dw 0x3416 ; 180d: retlw   0x16
    dw 0x3401 ; 180e: retlw   0x01
    dw 0x34f3 ; 180f: retlw   0xf3
    dw 0x3400 ; 1810: retlw   0x00
    dw 0x34d8 ; 1811: retlw   0xd8
    dw 0x3400 ; 1812: retlw   0x00
    dw 0x34c2 ; 1813: retlw   0xc2
    dw 0x3400 ; 1814: retlw   0x00
    dw 0x3460 ; 1815: retlw   0x60
    dw 0x3400 ; 1816: retlw   0x00
    dw 0x3440 ; 1817: retlw   0x40
    dw 0x3400 ; 1818: retlw   0x00
    dw 0x3430 ; 1819: retlw   0x30
    dw 0x3400 ; 181a: retlw   0x00
    dw 0x3426 ; 181b: retlw   0x26
    dw 0x3400 ; 181c: retlw   0x00
    dw 0x3420 ; 181d: retlw   0x20
    dw 0x3400 ; 181e: retlw   0x00
    dw 0x344c ; 181f: retlw   0x4c
    dw 0x3404 ; 1820: retlw   0x04
    dw 0x0782 ; 1821: addwf   PCL, F
    dw 0x3400 ; 1822: retlw   0x00
    dw 0x3400 ; 1823: retlw   0x00
    dw 0x3401 ; 1824: retlw   0x01
    dw 0x3403 ; 1825: retlw   0x03
    dw 0x3407 ; 1826: retlw   0x07
    dw 0x340f ; 1827: retlw   0x0f
    dw 0x341f ; 1828: retlw   0x1f
    dw 0x343f ; 1829: retlw   0x3f
    dw 0x347f ; 182a: retlw   0x7f
    dw 0x34ff ; 182b: retlw   0xff
    dw 0x34c0 ; 182c: retlw   0xc0
    dw 0x3400 ; 182d: retlw   0x00
    dw 0x3400 ; 182e: retlw   0x00
    dw 0x3400 ; 182f: retlw   0x00
    dw 0x3400 ; 1830: retlw   0x00
    dw 0x3400 ; 1831: retlw   0x00
    dw 0x0782 ; 1832: addwf   PCL, F
    dw 0x3401 ; 1833: retlw   0x01
    dw 0x3402 ; 1834: retlw   0x02
    dw 0x3404 ; 1835: retlw   0x04
    dw 0x3408 ; 1836: retlw   0x08
    dw 0x3410 ; 1837: retlw   0x10
    dw 0x3420 ; 1838: retlw   0x20
    dw 0x3440 ; 1839: retlw   0x40
    dw 0x3480 ; 183a: retlw   0x80
    dw 0x0782 ; 183b: addwf   PCL, F
    dw 0x3400 ; 183c: retlw   0x00
    dw 0x3403 ; 183d: retlw   0x03
    dw 0x3457 ; 183e: retlw   0x57
    dw 0x3418 ; 183f: retlw   0x18
    dw 0x3401 ; 1840: retlw   0x01
    dw 0x3400 ; 1841: retlw   0x00
    dw 0x3405 ; 1842: retlw   0x05
    dw 0x3400 ; 1843: retlw   0x00
    dw 0x0782 ; 1844: addwf   PCL, F
    dw 0x3401 ; 1845: retlw   0x01
    dw 0x3451 ; 1846: retlw   0x51
    dw 0x3418 ; 1847: retlw   0x18
    dw 0x3402 ; 1848: retlw   0x02
    dw 0x3454 ; 1849: retlw   0x54
    dw 0x3418 ; 184a: retlw   0x18
    dw 0x0782 ; 184b: addwf   PCL, F
    dw 0x3408 ; 184c: retlw   0x08
    dw 0x3400 ; 184d: retlw   0x00
    dw 0x0782 ; 184e: addwf   PCL, F
    dw 0x3409 ; 184f: retlw   0x09
    dw 0x3400 ; 1850: retlw   0x00
    dw 0x120a ; 1851: bcf     PCLATH, 0x4
    dw 0x118a ; 1852: bcf     PCLATH, 0x3
    dw 0x2c38 ; 1853: goto    label_071
    dw 0x120a ; 1854: bcf     PCLATH, 0x4
    dw 0x118a ; 1855: bcf     PCLATH, 0x3
    dw 0x2ccb ; 1856: goto    label_078
    dw 0x120a ; 1857: bcf     PCLATH, 0x4
    dw 0x118a ; 1858: bcf     PCLATH, 0x3
    dw 0x2af7 ; 1859: goto    label_045
    dw 0x0782 ; 185a: addwf   PCL, F
    dw 0x3427 ; 185b: retlw   0x27
    dw 0x0782 ; 185c: addwf   PCL, F
    dw 0x3401 ; 185d: retlw   0x01
    dw 0x0782 ; 185e: addwf   PCL, F
    dw 0x342c ; 185f: retlw   0x2c
    dw 0x0782 ; 1860: addwf   PCL, F
    dw 0x340a ; 1861: retlw   0x0a
    dw 0x3fff ; 1862: addlw   0xff
    dw 0x3fff ; 1863: addlw   0xff
    dw 0x3fff ; 1864: addlw   0xff
    dw 0x3fff ; 1865: addlw   0xff
    dw 0x3fff ; 1866: addlw   0xff
    dw 0x3fff ; 1867: addlw   0xff
    dw 0x3fff ; 1868: addlw   0xff
    dw 0x3fff ; 1869: addlw   0xff
    dw 0x3fff ; 186a: addlw   0xff
    dw 0x3fff ; 186b: addlw   0xff
    dw 0x3fff ; 186c: addlw   0xff
    dw 0x3fff ; 186d: addlw   0xff
    dw 0x3fff ; 186e: addlw   0xff
    dw 0x3fff ; 186f: addlw   0xff
    dw 0x3fff ; 1870: addlw   0xff
    dw 0x3fff ; 1871: addlw   0xff
    dw 0x3fff ; 1872: addlw   0xff
    dw 0x3fff ; 1873: addlw   0xff
    dw 0x3fff ; 1874: addlw   0xff
    dw 0x3fff ; 1875: addlw   0xff
    dw 0x3fff ; 1876: addlw   0xff
    dw 0x3fff ; 1877: addlw   0xff
    dw 0x3fff ; 1878: addlw   0xff
    dw 0x3fff ; 1879: addlw   0xff
    dw 0x3fff ; 187a: addlw   0xff
    dw 0x3fff ; 187b: addlw   0xff
    dw 0x3fff ; 187c: addlw   0xff
    dw 0x3fff ; 187d: addlw   0xff
    dw 0x3fff ; 187e: addlw   0xff
    dw 0x3fff ; 187f: addlw   0xff
    dw 0x3fff ; 1880: addlw   0xff
    dw 0x3fff ; 1881: addlw   0xff
    dw 0x3fff ; 1882: addlw   0xff
    dw 0x3fff ; 1883: addlw   0xff
    dw 0x3fff ; 1884: addlw   0xff
    dw 0x3fff ; 1885: addlw   0xff
    dw 0x3fff ; 1886: addlw   0xff
    dw 0x3fff ; 1887: addlw   0xff
    dw 0x3fff ; 1888: addlw   0xff
    dw 0x3fff ; 1889: addlw   0xff
    dw 0x3fff ; 188a: addlw   0xff
    dw 0x3fff ; 188b: addlw   0xff
    dw 0x3fff ; 188c: addlw   0xff
    dw 0x3fff ; 188d: addlw   0xff
    dw 0x3fff ; 188e: addlw   0xff
    dw 0x3fff ; 188f: addlw   0xff
    dw 0x3fff ; 1890: addlw   0xff
    dw 0x3fff ; 1891: addlw   0xff
    dw 0x3fff ; 1892: addlw   0xff
    dw 0x3fff ; 1893: addlw   0xff
    dw 0x3fff ; 1894: addlw   0xff
    dw 0x3fff ; 1895: addlw   0xff
    dw 0x3fff ; 1896: addlw   0xff
    dw 0x3fff ; 1897: addlw   0xff
    dw 0x3fff ; 1898: addlw   0xff
    dw 0x3fff ; 1899: addlw   0xff
    dw 0x3fff ; 189a: addlw   0xff
    dw 0x3fff ; 189b: addlw   0xff
    dw 0x3fff ; 189c: addlw   0xff
    dw 0x3fff ; 189d: addlw   0xff
    dw 0x3fff ; 189e: addlw   0xff
    dw 0x3fff ; 189f: addlw   0xff
    dw 0x3fff ; 18a0: addlw   0xff
    dw 0x3fff ; 18a1: addlw   0xff
    dw 0x3fff ; 18a2: addlw   0xff
    dw 0x3fff ; 18a3: addlw   0xff
    dw 0x3fff ; 18a4: addlw   0xff
    dw 0x3fff ; 18a5: addlw   0xff
    dw 0x3fff ; 18a6: addlw   0xff
    dw 0x3fff ; 18a7: addlw   0xff
    dw 0x3fff ; 18a8: addlw   0xff
    dw 0x3fff ; 18a9: addlw   0xff
    dw 0x3fff ; 18aa: addlw   0xff
    dw 0x3fff ; 18ab: addlw   0xff
    dw 0x3fff ; 18ac: addlw   0xff
    dw 0x3fff ; 18ad: addlw   0xff
    dw 0x3fff ; 18ae: addlw   0xff
    dw 0x3fff ; 18af: addlw   0xff
    dw 0x3fff ; 18b0: addlw   0xff
    dw 0x3fff ; 18b1: addlw   0xff
    dw 0x3fff ; 18b2: addlw   0xff
    dw 0x3fff ; 18b3: addlw   0xff
    dw 0x3fff ; 18b4: addlw   0xff
    dw 0x3fff ; 18b5: addlw   0xff
    dw 0x3fff ; 18b6: addlw   0xff
    dw 0x3fff ; 18b7: addlw   0xff
    dw 0x3fff ; 18b8: addlw   0xff
    dw 0x3fff ; 18b9: addlw   0xff
    dw 0x3fff ; 18ba: addlw   0xff
    dw 0x3fff ; 18bb: addlw   0xff
    dw 0x3fff ; 18bc: addlw   0xff
    dw 0x3fff ; 18bd: addlw   0xff
    dw 0x3fff ; 18be: addlw   0xff
    dw 0x3fff ; 18bf: addlw   0xff
    dw 0x3fff ; 18c0: addlw   0xff
    dw 0x3fff ; 18c1: addlw   0xff
    dw 0x3fff ; 18c2: addlw   0xff
    dw 0x3fff ; 18c3: addlw   0xff
    dw 0x3fff ; 18c4: addlw   0xff
    dw 0x3fff ; 18c5: addlw   0xff
    dw 0x3fff ; 18c6: addlw   0xff
    dw 0x3fff ; 18c7: addlw   0xff
    dw 0x3fff ; 18c8: addlw   0xff
    dw 0x3fff ; 18c9: addlw   0xff
    dw 0x3fff ; 18ca: addlw   0xff
    dw 0x3fff ; 18cb: addlw   0xff
    dw 0x3fff ; 18cc: addlw   0xff
    dw 0x3fff ; 18cd: addlw   0xff
    dw 0x3fff ; 18ce: addlw   0xff
    dw 0x3fff ; 18cf: addlw   0xff
    dw 0x3fff ; 18d0: addlw   0xff
    dw 0x3fff ; 18d1: addlw   0xff
    dw 0x3fff ; 18d2: addlw   0xff
    dw 0x3fff ; 18d3: addlw   0xff
    dw 0x3fff ; 18d4: addlw   0xff
    dw 0x3fff ; 18d5: addlw   0xff
    dw 0x3fff ; 18d6: addlw   0xff
    dw 0x3fff ; 18d7: addlw   0xff
    dw 0x3fff ; 18d8: addlw   0xff
    dw 0x3fff ; 18d9: addlw   0xff
    dw 0x3fff ; 18da: addlw   0xff
    dw 0x3fff ; 18db: addlw   0xff
    dw 0x3fff ; 18dc: addlw   0xff
    dw 0x3fff ; 18dd: addlw   0xff
    dw 0x3fff ; 18de: addlw   0xff
    dw 0x3fff ; 18df: addlw   0xff
    dw 0x3fff ; 18e0: addlw   0xff
    dw 0x3fff ; 18e1: addlw   0xff
    dw 0x3fff ; 18e2: addlw   0xff
    dw 0x3fff ; 18e3: addlw   0xff
    dw 0x3fff ; 18e4: addlw   0xff
    dw 0x3fff ; 18e5: addlw   0xff
    dw 0x3fff ; 18e6: addlw   0xff
    dw 0x3fff ; 18e7: addlw   0xff
    dw 0x3fff ; 18e8: addlw   0xff
    dw 0x3fff ; 18e9: addlw   0xff
    dw 0x3fff ; 18ea: addlw   0xff
    dw 0x3fff ; 18eb: addlw   0xff
    dw 0x3fff ; 18ec: addlw   0xff
    dw 0x3fff ; 18ed: addlw   0xff
    dw 0x3fff ; 18ee: addlw   0xff
    dw 0x3fff ; 18ef: addlw   0xff
    dw 0x3fff ; 18f0: addlw   0xff
    dw 0x3fff ; 18f1: addlw   0xff
    dw 0x3fff ; 18f2: addlw   0xff
    dw 0x3fff ; 18f3: addlw   0xff
    dw 0x3fff ; 18f4: addlw   0xff
    dw 0x3fff ; 18f5: addlw   0xff
    dw 0x3fff ; 18f6: addlw   0xff
    dw 0x3fff ; 18f7: addlw   0xff
    dw 0x3fff ; 18f8: addlw   0xff
    dw 0x3fff ; 18f9: addlw   0xff
    dw 0x3fff ; 18fa: addlw   0xff
    dw 0x3fff ; 18fb: addlw   0xff
    dw 0x3fff ; 18fc: addlw   0xff
    dw 0x3fff ; 18fd: addlw   0xff
    dw 0x3fff ; 18fe: addlw   0xff
    dw 0x3fff ; 18ff: addlw   0xff
    dw 0x3fff ; 1900: addlw   0xff
    dw 0x3fff ; 1901: addlw   0xff
    dw 0x3fff ; 1902: addlw   0xff
    dw 0x3fff ; 1903: addlw   0xff
    dw 0x3fff ; 1904: addlw   0xff
    dw 0x3fff ; 1905: addlw   0xff
    dw 0x3fff ; 1906: addlw   0xff
    dw 0x3fff ; 1907: addlw   0xff
    dw 0x3fff ; 1908: addlw   0xff
    dw 0x3fff ; 1909: addlw   0xff
    dw 0x3fff ; 190a: addlw   0xff
    dw 0x3fff ; 190b: addlw   0xff
    dw 0x3fff ; 190c: addlw   0xff
    dw 0x3fff ; 190d: addlw   0xff
    dw 0x3fff ; 190e: addlw   0xff
    dw 0x3fff ; 190f: addlw   0xff
    dw 0x3fff ; 1910: addlw   0xff
    dw 0x3fff ; 1911: addlw   0xff
    dw 0x3fff ; 1912: addlw   0xff
    dw 0x3fff ; 1913: addlw   0xff
    dw 0x3fff ; 1914: addlw   0xff
    dw 0x3fff ; 1915: addlw   0xff
    dw 0x3fff ; 1916: addlw   0xff
    dw 0x3fff ; 1917: addlw   0xff
    dw 0x3fff ; 1918: addlw   0xff
    dw 0x3fff ; 1919: addlw   0xff
    dw 0x3fff ; 191a: addlw   0xff
    dw 0x3fff ; 191b: addlw   0xff
    dw 0x3fff ; 191c: addlw   0xff
    dw 0x3fff ; 191d: addlw   0xff
    dw 0x3fff ; 191e: addlw   0xff
    dw 0x3fff ; 191f: addlw   0xff
    dw 0x3fff ; 1920: addlw   0xff
    dw 0x3fff ; 1921: addlw   0xff
    dw 0x3fff ; 1922: addlw   0xff
    dw 0x3fff ; 1923: addlw   0xff
    dw 0x3fff ; 1924: addlw   0xff
    dw 0x3fff ; 1925: addlw   0xff
    dw 0x3fff ; 1926: addlw   0xff
    dw 0x3fff ; 1927: addlw   0xff
    dw 0x3fff ; 1928: addlw   0xff
    dw 0x3fff ; 1929: addlw   0xff
    dw 0x3fff ; 192a: addlw   0xff
    dw 0x3fff ; 192b: addlw   0xff
    dw 0x3fff ; 192c: addlw   0xff
    dw 0x3fff ; 192d: addlw   0xff
    dw 0x3fff ; 192e: addlw   0xff
    dw 0x3fff ; 192f: addlw   0xff
    dw 0x3fff ; 1930: addlw   0xff
    dw 0x3fff ; 1931: addlw   0xff
    dw 0x3fff ; 1932: addlw   0xff
    dw 0x3fff ; 1933: addlw   0xff
    dw 0x3fff ; 1934: addlw   0xff
    dw 0x3fff ; 1935: addlw   0xff
    dw 0x3fff ; 1936: addlw   0xff
    dw 0x3fff ; 1937: addlw   0xff
    dw 0x3fff ; 1938: addlw   0xff
    dw 0x3fff ; 1939: addlw   0xff
    dw 0x3fff ; 193a: addlw   0xff
    dw 0x3fff ; 193b: addlw   0xff
    dw 0x3fff ; 193c: addlw   0xff
    dw 0x3fff ; 193d: addlw   0xff
    dw 0x3fff ; 193e: addlw   0xff
    dw 0x3fff ; 193f: addlw   0xff
    dw 0x3fff ; 1940: addlw   0xff
    dw 0x3fff ; 1941: addlw   0xff
    dw 0x3fff ; 1942: addlw   0xff
    dw 0x3fff ; 1943: addlw   0xff
    dw 0x3fff ; 1944: addlw   0xff
    dw 0x3fff ; 1945: addlw   0xff
    dw 0x3fff ; 1946: addlw   0xff
    dw 0x3fff ; 1947: addlw   0xff
    dw 0x3fff ; 1948: addlw   0xff
    dw 0x3fff ; 1949: addlw   0xff
    dw 0x3fff ; 194a: addlw   0xff
    dw 0x3fff ; 194b: addlw   0xff
    dw 0x3fff ; 194c: addlw   0xff
    dw 0x3fff ; 194d: addlw   0xff
    dw 0x3fff ; 194e: addlw   0xff
    dw 0x3fff ; 194f: addlw   0xff
    dw 0x3fff ; 1950: addlw   0xff
    dw 0x3fff ; 1951: addlw   0xff
    dw 0x3fff ; 1952: addlw   0xff
    dw 0x3fff ; 1953: addlw   0xff
    dw 0x3fff ; 1954: addlw   0xff
    dw 0x3fff ; 1955: addlw   0xff
    dw 0x3fff ; 1956: addlw   0xff
    dw 0x3fff ; 1957: addlw   0xff
    dw 0x3fff ; 1958: addlw   0xff
    dw 0x3fff ; 1959: addlw   0xff
    dw 0x3fff ; 195a: addlw   0xff
    dw 0x3fff ; 195b: addlw   0xff
    dw 0x3fff ; 195c: addlw   0xff
    dw 0x3fff ; 195d: addlw   0xff
    dw 0x3fff ; 195e: addlw   0xff
    dw 0x3fff ; 195f: addlw   0xff
    dw 0x3fff ; 1960: addlw   0xff
    dw 0x3fff ; 1961: addlw   0xff
    dw 0x3fff ; 1962: addlw   0xff
    dw 0x3fff ; 1963: addlw   0xff
    dw 0x3fff ; 1964: addlw   0xff
    dw 0x3fff ; 1965: addlw   0xff
    dw 0x3fff ; 1966: addlw   0xff
    dw 0x3fff ; 1967: addlw   0xff
    dw 0x3fff ; 1968: addlw   0xff
    dw 0x3fff ; 1969: addlw   0xff
    dw 0x3fff ; 196a: addlw   0xff
    dw 0x3fff ; 196b: addlw   0xff
    dw 0x3fff ; 196c: addlw   0xff
    dw 0x3fff ; 196d: addlw   0xff
    dw 0x3fff ; 196e: addlw   0xff
    dw 0x3fff ; 196f: addlw   0xff
    dw 0x3fff ; 1970: addlw   0xff
    dw 0x3fff ; 1971: addlw   0xff
    dw 0x3fff ; 1972: addlw   0xff
    dw 0x3fff ; 1973: addlw   0xff
    dw 0x3fff ; 1974: addlw   0xff
    dw 0x3fff ; 1975: addlw   0xff
    dw 0x3fff ; 1976: addlw   0xff
    dw 0x3fff ; 1977: addlw   0xff
    dw 0x3fff ; 1978: addlw   0xff
    dw 0x3fff ; 1979: addlw   0xff
    dw 0x3fff ; 197a: addlw   0xff
    dw 0x3fff ; 197b: addlw   0xff
    dw 0x3fff ; 197c: addlw   0xff
    dw 0x3fff ; 197d: addlw   0xff
    dw 0x3fff ; 197e: addlw   0xff
    dw 0x3fff ; 197f: addlw   0xff
    dw 0x3fff ; 1980: addlw   0xff
    dw 0x3fff ; 1981: addlw   0xff
    dw 0x3fff ; 1982: addlw   0xff
    dw 0x3fff ; 1983: addlw   0xff
    dw 0x3fff ; 1984: addlw   0xff
    dw 0x3fff ; 1985: addlw   0xff
    dw 0x3fff ; 1986: addlw   0xff
    dw 0x3fff ; 1987: addlw   0xff
    dw 0x3fff ; 1988: addlw   0xff
    dw 0x3fff ; 1989: addlw   0xff
    dw 0x3fff ; 198a: addlw   0xff
    dw 0x3fff ; 198b: addlw   0xff
    dw 0x3fff ; 198c: addlw   0xff
    dw 0x3fff ; 198d: addlw   0xff
    dw 0x3fff ; 198e: addlw   0xff
    dw 0x3fff ; 198f: addlw   0xff
    dw 0x3fff ; 1990: addlw   0xff
    dw 0x3fff ; 1991: addlw   0xff
    dw 0x3fff ; 1992: addlw   0xff
    dw 0x3fff ; 1993: addlw   0xff
    dw 0x3fff ; 1994: addlw   0xff
    dw 0x3fff ; 1995: addlw   0xff
    dw 0x3fff ; 1996: addlw   0xff
    dw 0x3fff ; 1997: addlw   0xff
    dw 0x3fff ; 1998: addlw   0xff
    dw 0x3fff ; 1999: addlw   0xff
    dw 0x3fff ; 199a: addlw   0xff
    dw 0x3fff ; 199b: addlw   0xff
    dw 0x3fff ; 199c: addlw   0xff
    dw 0x3fff ; 199d: addlw   0xff
    dw 0x3fff ; 199e: addlw   0xff
    dw 0x3fff ; 199f: addlw   0xff
    dw 0x3fff ; 19a0: addlw   0xff
    dw 0x3fff ; 19a1: addlw   0xff
    dw 0x3fff ; 19a2: addlw   0xff
    dw 0x3fff ; 19a3: addlw   0xff
    dw 0x3fff ; 19a4: addlw   0xff
    dw 0x3fff ; 19a5: addlw   0xff
    dw 0x3fff ; 19a6: addlw   0xff
    dw 0x3fff ; 19a7: addlw   0xff
    dw 0x3fff ; 19a8: addlw   0xff
    dw 0x3fff ; 19a9: addlw   0xff
    dw 0x3fff ; 19aa: addlw   0xff
    dw 0x3fff ; 19ab: addlw   0xff
    dw 0x3fff ; 19ac: addlw   0xff
    dw 0x3fff ; 19ad: addlw   0xff
    dw 0x3fff ; 19ae: addlw   0xff
    dw 0x3fff ; 19af: addlw   0xff
    dw 0x3fff ; 19b0: addlw   0xff
    dw 0x3fff ; 19b1: addlw   0xff
    dw 0x3fff ; 19b2: addlw   0xff
    dw 0x3fff ; 19b3: addlw   0xff
    dw 0x3fff ; 19b4: addlw   0xff
    dw 0x3fff ; 19b5: addlw   0xff
    dw 0x3fff ; 19b6: addlw   0xff
    dw 0x3fff ; 19b7: addlw   0xff
    dw 0x3fff ; 19b8: addlw   0xff
    dw 0x3fff ; 19b9: addlw   0xff
    dw 0x3fff ; 19ba: addlw   0xff
    dw 0x3fff ; 19bb: addlw   0xff
    dw 0x3fff ; 19bc: addlw   0xff
    dw 0x3fff ; 19bd: addlw   0xff
    dw 0x3fff ; 19be: addlw   0xff
    dw 0x3fff ; 19bf: addlw   0xff
    dw 0x3fff ; 19c0: addlw   0xff
    dw 0x3fff ; 19c1: addlw   0xff
    dw 0x3fff ; 19c2: addlw   0xff
    dw 0x3fff ; 19c3: addlw   0xff
    dw 0x3fff ; 19c4: addlw   0xff
    dw 0x3fff ; 19c5: addlw   0xff
    dw 0x3fff ; 19c6: addlw   0xff
    dw 0x3fff ; 19c7: addlw   0xff
    dw 0x3fff ; 19c8: addlw   0xff
    dw 0x3fff ; 19c9: addlw   0xff
    dw 0x3fff ; 19ca: addlw   0xff
    dw 0x3fff ; 19cb: addlw   0xff
    dw 0x3fff ; 19cc: addlw   0xff
    dw 0x3fff ; 19cd: addlw   0xff
    dw 0x3fff ; 19ce: addlw   0xff
    dw 0x3fff ; 19cf: addlw   0xff
    dw 0x3fff ; 19d0: addlw   0xff
    dw 0x3fff ; 19d1: addlw   0xff
    dw 0x3fff ; 19d2: addlw   0xff
    dw 0x3fff ; 19d3: addlw   0xff
    dw 0x3fff ; 19d4: addlw   0xff
    dw 0x3fff ; 19d5: addlw   0xff
    dw 0x3fff ; 19d6: addlw   0xff
    dw 0x3fff ; 19d7: addlw   0xff
    dw 0x3fff ; 19d8: addlw   0xff
    dw 0x3fff ; 19d9: addlw   0xff
    dw 0x3fff ; 19da: addlw   0xff
    dw 0x3fff ; 19db: addlw   0xff
    dw 0x3fff ; 19dc: addlw   0xff
    dw 0x3fff ; 19dd: addlw   0xff
    dw 0x3fff ; 19de: addlw   0xff
    dw 0x3fff ; 19df: addlw   0xff
    dw 0x3fff ; 19e0: addlw   0xff
    dw 0x3fff ; 19e1: addlw   0xff
    dw 0x3fff ; 19e2: addlw   0xff
    dw 0x3fff ; 19e3: addlw   0xff
    dw 0x3fff ; 19e4: addlw   0xff
    dw 0x3fff ; 19e5: addlw   0xff
    dw 0x3fff ; 19e6: addlw   0xff
    dw 0x3fff ; 19e7: addlw   0xff
    dw 0x3fff ; 19e8: addlw   0xff
    dw 0x3fff ; 19e9: addlw   0xff
    dw 0x3fff ; 19ea: addlw   0xff
    dw 0x3fff ; 19eb: addlw   0xff
    dw 0x3fff ; 19ec: addlw   0xff
    dw 0x3fff ; 19ed: addlw   0xff
    dw 0x3fff ; 19ee: addlw   0xff
    dw 0x3fff ; 19ef: addlw   0xff
    dw 0x3fff ; 19f0: addlw   0xff
    dw 0x3fff ; 19f1: addlw   0xff
    dw 0x3fff ; 19f2: addlw   0xff
    dw 0x3fff ; 19f3: addlw   0xff
    dw 0x3fff ; 19f4: addlw   0xff
    dw 0x3fff ; 19f5: addlw   0xff
    dw 0x3fff ; 19f6: addlw   0xff
    dw 0x3fff ; 19f7: addlw   0xff
    dw 0x3fff ; 19f8: addlw   0xff
    dw 0x3fff ; 19f9: addlw   0xff
    dw 0x3fff ; 19fa: addlw   0xff
    dw 0x3fff ; 19fb: addlw   0xff
    dw 0x3fff ; 19fc: addlw   0xff
    dw 0x3fff ; 19fd: addlw   0xff
    dw 0x3fff ; 19fe: addlw   0xff
    dw 0x3fff ; 19ff: addlw   0xff
    dw 0x3fff ; 1a00: addlw   0xff
    dw 0x3fff ; 1a01: addlw   0xff
    dw 0x3fff ; 1a02: addlw   0xff
    dw 0x3fff ; 1a03: addlw   0xff
    dw 0x3fff ; 1a04: addlw   0xff
    dw 0x3fff ; 1a05: addlw   0xff
    dw 0x3fff ; 1a06: addlw   0xff
    dw 0x3fff ; 1a07: addlw   0xff
    dw 0x3fff ; 1a08: addlw   0xff
    dw 0x3fff ; 1a09: addlw   0xff
    dw 0x3fff ; 1a0a: addlw   0xff
    dw 0x3fff ; 1a0b: addlw   0xff
    dw 0x3fff ; 1a0c: addlw   0xff
    dw 0x3fff ; 1a0d: addlw   0xff
    dw 0x3fff ; 1a0e: addlw   0xff
    dw 0x3fff ; 1a0f: addlw   0xff
    dw 0x3fff ; 1a10: addlw   0xff
    dw 0x3fff ; 1a11: addlw   0xff
    dw 0x3fff ; 1a12: addlw   0xff
    dw 0x3fff ; 1a13: addlw   0xff
    dw 0x3fff ; 1a14: addlw   0xff
    dw 0x3fff ; 1a15: addlw   0xff
    dw 0x3fff ; 1a16: addlw   0xff
    dw 0x3fff ; 1a17: addlw   0xff
    dw 0x3fff ; 1a18: addlw   0xff
    dw 0x3fff ; 1a19: addlw   0xff
    dw 0x3fff ; 1a1a: addlw   0xff
    dw 0x3fff ; 1a1b: addlw   0xff
    dw 0x3fff ; 1a1c: addlw   0xff
    dw 0x3fff ; 1a1d: addlw   0xff
    dw 0x3fff ; 1a1e: addlw   0xff
    dw 0x3fff ; 1a1f: addlw   0xff
    dw 0x3fff ; 1a20: addlw   0xff
    dw 0x3fff ; 1a21: addlw   0xff
    dw 0x3fff ; 1a22: addlw   0xff
    dw 0x3fff ; 1a23: addlw   0xff
    dw 0x3fff ; 1a24: addlw   0xff
    dw 0x3fff ; 1a25: addlw   0xff
    dw 0x3fff ; 1a26: addlw   0xff
    dw 0x3fff ; 1a27: addlw   0xff
    dw 0x3fff ; 1a28: addlw   0xff
    dw 0x3fff ; 1a29: addlw   0xff
    dw 0x3fff ; 1a2a: addlw   0xff
    dw 0x3fff ; 1a2b: addlw   0xff
    dw 0x3fff ; 1a2c: addlw   0xff
    dw 0x3fff ; 1a2d: addlw   0xff
    dw 0x3fff ; 1a2e: addlw   0xff
    dw 0x3fff ; 1a2f: addlw   0xff
    dw 0x3fff ; 1a30: addlw   0xff
    dw 0x3fff ; 1a31: addlw   0xff
    dw 0x3fff ; 1a32: addlw   0xff
    dw 0x3fff ; 1a33: addlw   0xff
    dw 0x3fff ; 1a34: addlw   0xff
    dw 0x3fff ; 1a35: addlw   0xff
    dw 0x3fff ; 1a36: addlw   0xff
    dw 0x3fff ; 1a37: addlw   0xff
    dw 0x3fff ; 1a38: addlw   0xff
    dw 0x3fff ; 1a39: addlw   0xff
    dw 0x3fff ; 1a3a: addlw   0xff
    dw 0x3fff ; 1a3b: addlw   0xff
    dw 0x3fff ; 1a3c: addlw   0xff
    dw 0x3fff ; 1a3d: addlw   0xff
    dw 0x3fff ; 1a3e: addlw   0xff
    dw 0x3fff ; 1a3f: addlw   0xff
    dw 0x3fff ; 1a40: addlw   0xff
    dw 0x3fff ; 1a41: addlw   0xff
    dw 0x3fff ; 1a42: addlw   0xff
    dw 0x3fff ; 1a43: addlw   0xff
    dw 0x3fff ; 1a44: addlw   0xff
    dw 0x3fff ; 1a45: addlw   0xff
    dw 0x3fff ; 1a46: addlw   0xff
    dw 0x3fff ; 1a47: addlw   0xff
    dw 0x3fff ; 1a48: addlw   0xff
    dw 0x3fff ; 1a49: addlw   0xff
    dw 0x3fff ; 1a4a: addlw   0xff
    dw 0x3fff ; 1a4b: addlw   0xff
    dw 0x3fff ; 1a4c: addlw   0xff
    dw 0x3fff ; 1a4d: addlw   0xff
    dw 0x3fff ; 1a4e: addlw   0xff
    dw 0x3fff ; 1a4f: addlw   0xff
    dw 0x3fff ; 1a50: addlw   0xff
    dw 0x3fff ; 1a51: addlw   0xff
    dw 0x3fff ; 1a52: addlw   0xff
    dw 0x3fff ; 1a53: addlw   0xff
    dw 0x3fff ; 1a54: addlw   0xff
    dw 0x3fff ; 1a55: addlw   0xff
    dw 0x3fff ; 1a56: addlw   0xff
    dw 0x3fff ; 1a57: addlw   0xff
    dw 0x3fff ; 1a58: addlw   0xff
    dw 0x3fff ; 1a59: addlw   0xff
    dw 0x3fff ; 1a5a: addlw   0xff
    dw 0x3fff ; 1a5b: addlw   0xff
    dw 0x3fff ; 1a5c: addlw   0xff
    dw 0x3fff ; 1a5d: addlw   0xff
    dw 0x3fff ; 1a5e: addlw   0xff
    dw 0x3fff ; 1a5f: addlw   0xff
    dw 0x3fff ; 1a60: addlw   0xff
    dw 0x3fff ; 1a61: addlw   0xff
    dw 0x3fff ; 1a62: addlw   0xff
    dw 0x3fff ; 1a63: addlw   0xff
    dw 0x3fff ; 1a64: addlw   0xff
    dw 0x3fff ; 1a65: addlw   0xff
    dw 0x3fff ; 1a66: addlw   0xff
    dw 0x3fff ; 1a67: addlw   0xff
    dw 0x3fff ; 1a68: addlw   0xff
    dw 0x3fff ; 1a69: addlw   0xff
    dw 0x3fff ; 1a6a: addlw   0xff
    dw 0x3fff ; 1a6b: addlw   0xff
    dw 0x3fff ; 1a6c: addlw   0xff
    dw 0x3fff ; 1a6d: addlw   0xff
    dw 0x3fff ; 1a6e: addlw   0xff
    dw 0x3fff ; 1a6f: addlw   0xff
    dw 0x3fff ; 1a70: addlw   0xff
    dw 0x3fff ; 1a71: addlw   0xff
    dw 0x3fff ; 1a72: addlw   0xff
    dw 0x3fff ; 1a73: addlw   0xff
    dw 0x3fff ; 1a74: addlw   0xff
    dw 0x3fff ; 1a75: addlw   0xff
    dw 0x3fff ; 1a76: addlw   0xff
    dw 0x3fff ; 1a77: addlw   0xff
    dw 0x3fff ; 1a78: addlw   0xff
    dw 0x3fff ; 1a79: addlw   0xff
    dw 0x3fff ; 1a7a: addlw   0xff
    dw 0x3fff ; 1a7b: addlw   0xff
    dw 0x3fff ; 1a7c: addlw   0xff
    dw 0x3fff ; 1a7d: addlw   0xff
    dw 0x3fff ; 1a7e: addlw   0xff
    dw 0x3fff ; 1a7f: addlw   0xff
    dw 0x3fff ; 1a80: addlw   0xff
    dw 0x3fff ; 1a81: addlw   0xff
    dw 0x3fff ; 1a82: addlw   0xff
    dw 0x3fff ; 1a83: addlw   0xff
    dw 0x3fff ; 1a84: addlw   0xff
    dw 0x3fff ; 1a85: addlw   0xff
    dw 0x3fff ; 1a86: addlw   0xff
    dw 0x3fff ; 1a87: addlw   0xff
    dw 0x3fff ; 1a88: addlw   0xff
    dw 0x3fff ; 1a89: addlw   0xff
    dw 0x3fff ; 1a8a: addlw   0xff
    dw 0x3fff ; 1a8b: addlw   0xff
    dw 0x3fff ; 1a8c: addlw   0xff
    dw 0x3fff ; 1a8d: addlw   0xff
    dw 0x3fff ; 1a8e: addlw   0xff
    dw 0x3fff ; 1a8f: addlw   0xff
    dw 0x3fff ; 1a90: addlw   0xff
    dw 0x3fff ; 1a91: addlw   0xff
    dw 0x3fff ; 1a92: addlw   0xff
    dw 0x3fff ; 1a93: addlw   0xff
    dw 0x3fff ; 1a94: addlw   0xff
    dw 0x3fff ; 1a95: addlw   0xff
    dw 0x3fff ; 1a96: addlw   0xff
    dw 0x3fff ; 1a97: addlw   0xff
    dw 0x3fff ; 1a98: addlw   0xff
    dw 0x3fff ; 1a99: addlw   0xff
    dw 0x3fff ; 1a9a: addlw   0xff
    dw 0x3fff ; 1a9b: addlw   0xff
    dw 0x3fff ; 1a9c: addlw   0xff
    dw 0x3fff ; 1a9d: addlw   0xff
    dw 0x3fff ; 1a9e: addlw   0xff
    dw 0x3fff ; 1a9f: addlw   0xff
    dw 0x3fff ; 1aa0: addlw   0xff
    dw 0x3fff ; 1aa1: addlw   0xff
    dw 0x3fff ; 1aa2: addlw   0xff
    dw 0x3fff ; 1aa3: addlw   0xff
    dw 0x3fff ; 1aa4: addlw   0xff
    dw 0x3fff ; 1aa5: addlw   0xff
    dw 0x3fff ; 1aa6: addlw   0xff
    dw 0x3fff ; 1aa7: addlw   0xff
    dw 0x3fff ; 1aa8: addlw   0xff
    dw 0x3fff ; 1aa9: addlw   0xff
    dw 0x3fff ; 1aaa: addlw   0xff
    dw 0x3fff ; 1aab: addlw   0xff
    dw 0x3fff ; 1aac: addlw   0xff
    dw 0x3fff ; 1aad: addlw   0xff
    dw 0x3fff ; 1aae: addlw   0xff
    dw 0x3fff ; 1aaf: addlw   0xff
    dw 0x3fff ; 1ab0: addlw   0xff
    dw 0x3fff ; 1ab1: addlw   0xff
    dw 0x3fff ; 1ab2: addlw   0xff
    dw 0x3fff ; 1ab3: addlw   0xff
    dw 0x3fff ; 1ab4: addlw   0xff
    dw 0x3fff ; 1ab5: addlw   0xff
    dw 0x3fff ; 1ab6: addlw   0xff
    dw 0x3fff ; 1ab7: addlw   0xff
    dw 0x3fff ; 1ab8: addlw   0xff
    dw 0x3fff ; 1ab9: addlw   0xff
    dw 0x3fff ; 1aba: addlw   0xff
    dw 0x3fff ; 1abb: addlw   0xff
    dw 0x3fff ; 1abc: addlw   0xff
    dw 0x3fff ; 1abd: addlw   0xff
    dw 0x3fff ; 1abe: addlw   0xff
    dw 0x3fff ; 1abf: addlw   0xff
    dw 0x3fff ; 1ac0: addlw   0xff
    dw 0x3fff ; 1ac1: addlw   0xff
    dw 0x3fff ; 1ac2: addlw   0xff
    dw 0x3fff ; 1ac3: addlw   0xff
    dw 0x3fff ; 1ac4: addlw   0xff
    dw 0x3fff ; 1ac5: addlw   0xff
    dw 0x3fff ; 1ac6: addlw   0xff
    dw 0x3fff ; 1ac7: addlw   0xff
    dw 0x3fff ; 1ac8: addlw   0xff
    dw 0x3fff ; 1ac9: addlw   0xff
    dw 0x3fff ; 1aca: addlw   0xff
    dw 0x3fff ; 1acb: addlw   0xff
    dw 0x3fff ; 1acc: addlw   0xff
    dw 0x3fff ; 1acd: addlw   0xff
    dw 0x3fff ; 1ace: addlw   0xff
    dw 0x3fff ; 1acf: addlw   0xff
    dw 0x3fff ; 1ad0: addlw   0xff
    dw 0x3fff ; 1ad1: addlw   0xff
    dw 0x3fff ; 1ad2: addlw   0xff
    dw 0x3fff ; 1ad3: addlw   0xff
    dw 0x3fff ; 1ad4: addlw   0xff
    dw 0x3fff ; 1ad5: addlw   0xff
    dw 0x3fff ; 1ad6: addlw   0xff
    dw 0x3fff ; 1ad7: addlw   0xff
    dw 0x3fff ; 1ad8: addlw   0xff
    dw 0x3fff ; 1ad9: addlw   0xff
    dw 0x3fff ; 1ada: addlw   0xff
    dw 0x3fff ; 1adb: addlw   0xff
    dw 0x3fff ; 1adc: addlw   0xff
    dw 0x3fff ; 1add: addlw   0xff
    dw 0x3fff ; 1ade: addlw   0xff
    dw 0x3fff ; 1adf: addlw   0xff
    dw 0x3fff ; 1ae0: addlw   0xff
    dw 0x3fff ; 1ae1: addlw   0xff
    dw 0x3fff ; 1ae2: addlw   0xff
    dw 0x3fff ; 1ae3: addlw   0xff
    dw 0x3fff ; 1ae4: addlw   0xff
    dw 0x3fff ; 1ae5: addlw   0xff
    dw 0x3fff ; 1ae6: addlw   0xff
    dw 0x3fff ; 1ae7: addlw   0xff
    dw 0x3fff ; 1ae8: addlw   0xff
    dw 0x3fff ; 1ae9: addlw   0xff
    dw 0x3fff ; 1aea: addlw   0xff
    dw 0x3fff ; 1aeb: addlw   0xff
    dw 0x3fff ; 1aec: addlw   0xff
    dw 0x3fff ; 1aed: addlw   0xff
    dw 0x3fff ; 1aee: addlw   0xff
    dw 0x3fff ; 1aef: addlw   0xff
    dw 0x3fff ; 1af0: addlw   0xff
    dw 0x3fff ; 1af1: addlw   0xff
    dw 0x3fff ; 1af2: addlw   0xff
    dw 0x3fff ; 1af3: addlw   0xff
    dw 0x3fff ; 1af4: addlw   0xff
    dw 0x3fff ; 1af5: addlw   0xff
    dw 0x3fff ; 1af6: addlw   0xff
    dw 0x3fff ; 1af7: addlw   0xff
    dw 0x3fff ; 1af8: addlw   0xff
    dw 0x3fff ; 1af9: addlw   0xff
    dw 0x3fff ; 1afa: addlw   0xff
    dw 0x3fff ; 1afb: addlw   0xff
    dw 0x3fff ; 1afc: addlw   0xff
    dw 0x3fff ; 1afd: addlw   0xff
    dw 0x3fff ; 1afe: addlw   0xff
    dw 0x3fff ; 1aff: addlw   0xff
    dw 0x3fff ; 1b00: addlw   0xff
    dw 0x3fff ; 1b01: addlw   0xff
    dw 0x3fff ; 1b02: addlw   0xff
    dw 0x3fff ; 1b03: addlw   0xff
    dw 0x3fff ; 1b04: addlw   0xff
    dw 0x3fff ; 1b05: addlw   0xff
    dw 0x3fff ; 1b06: addlw   0xff
    dw 0x3fff ; 1b07: addlw   0xff
    dw 0x3fff ; 1b08: addlw   0xff
    dw 0x3fff ; 1b09: addlw   0xff
    dw 0x3fff ; 1b0a: addlw   0xff
    dw 0x3fff ; 1b0b: addlw   0xff
    dw 0x3fff ; 1b0c: addlw   0xff
    dw 0x3fff ; 1b0d: addlw   0xff
    dw 0x3fff ; 1b0e: addlw   0xff
    dw 0x3fff ; 1b0f: addlw   0xff
    dw 0x3fff ; 1b10: addlw   0xff
    dw 0x3fff ; 1b11: addlw   0xff
    dw 0x3fff ; 1b12: addlw   0xff
    dw 0x3fff ; 1b13: addlw   0xff
    dw 0x3fff ; 1b14: addlw   0xff
    dw 0x3fff ; 1b15: addlw   0xff
    dw 0x3fff ; 1b16: addlw   0xff
    dw 0x3fff ; 1b17: addlw   0xff
    dw 0x3fff ; 1b18: addlw   0xff
    dw 0x3fff ; 1b19: addlw   0xff
    dw 0x3fff ; 1b1a: addlw   0xff
    dw 0x3fff ; 1b1b: addlw   0xff
    dw 0x3fff ; 1b1c: addlw   0xff
    dw 0x3fff ; 1b1d: addlw   0xff
    dw 0x3fff ; 1b1e: addlw   0xff
    dw 0x3fff ; 1b1f: addlw   0xff
    dw 0x3fff ; 1b20: addlw   0xff
    dw 0x3fff ; 1b21: addlw   0xff
    dw 0x3fff ; 1b22: addlw   0xff
    dw 0x3fff ; 1b23: addlw   0xff
    dw 0x3fff ; 1b24: addlw   0xff
    dw 0x3fff ; 1b25: addlw   0xff
    dw 0x3fff ; 1b26: addlw   0xff
    dw 0x3fff ; 1b27: addlw   0xff
    dw 0x3fff ; 1b28: addlw   0xff
    dw 0x3fff ; 1b29: addlw   0xff
    dw 0x3fff ; 1b2a: addlw   0xff
    dw 0x3fff ; 1b2b: addlw   0xff
    dw 0x3fff ; 1b2c: addlw   0xff
    dw 0x3fff ; 1b2d: addlw   0xff
    dw 0x3fff ; 1b2e: addlw   0xff
    dw 0x3fff ; 1b2f: addlw   0xff
    dw 0x3fff ; 1b30: addlw   0xff
    dw 0x3fff ; 1b31: addlw   0xff
    dw 0x3fff ; 1b32: addlw   0xff
    dw 0x3fff ; 1b33: addlw   0xff
    dw 0x3fff ; 1b34: addlw   0xff
    dw 0x3fff ; 1b35: addlw   0xff
    dw 0x3fff ; 1b36: addlw   0xff
    dw 0x3fff ; 1b37: addlw   0xff
    dw 0x3fff ; 1b38: addlw   0xff
    dw 0x3fff ; 1b39: addlw   0xff
    dw 0x3fff ; 1b3a: addlw   0xff
    dw 0x3fff ; 1b3b: addlw   0xff
    dw 0x3fff ; 1b3c: addlw   0xff
    dw 0x3fff ; 1b3d: addlw   0xff
    dw 0x3fff ; 1b3e: addlw   0xff
    dw 0x3fff ; 1b3f: addlw   0xff
    dw 0x3fff ; 1b40: addlw   0xff
    dw 0x3fff ; 1b41: addlw   0xff
    dw 0x3fff ; 1b42: addlw   0xff
    dw 0x3fff ; 1b43: addlw   0xff
    dw 0x3fff ; 1b44: addlw   0xff
    dw 0x3fff ; 1b45: addlw   0xff
    dw 0x3fff ; 1b46: addlw   0xff
    dw 0x3fff ; 1b47: addlw   0xff
    dw 0x3fff ; 1b48: addlw   0xff
    dw 0x3fff ; 1b49: addlw   0xff
    dw 0x3fff ; 1b4a: addlw   0xff
    dw 0x3fff ; 1b4b: addlw   0xff
    dw 0x3fff ; 1b4c: addlw   0xff
    dw 0x3fff ; 1b4d: addlw   0xff
    dw 0x3fff ; 1b4e: addlw   0xff
    dw 0x3fff ; 1b4f: addlw   0xff
    dw 0x3fff ; 1b50: addlw   0xff
    dw 0x3fff ; 1b51: addlw   0xff
    dw 0x3fff ; 1b52: addlw   0xff
    dw 0x3fff ; 1b53: addlw   0xff
    dw 0x3fff ; 1b54: addlw   0xff
    dw 0x3fff ; 1b55: addlw   0xff
    dw 0x3fff ; 1b56: addlw   0xff
    dw 0x3fff ; 1b57: addlw   0xff
    dw 0x3fff ; 1b58: addlw   0xff
    dw 0x3fff ; 1b59: addlw   0xff
    dw 0x3fff ; 1b5a: addlw   0xff
    dw 0x3fff ; 1b5b: addlw   0xff
    dw 0x3fff ; 1b5c: addlw   0xff
    dw 0x3fff ; 1b5d: addlw   0xff
    dw 0x3fff ; 1b5e: addlw   0xff
    dw 0x3fff ; 1b5f: addlw   0xff
    dw 0x3fff ; 1b60: addlw   0xff
    dw 0x3fff ; 1b61: addlw   0xff
    dw 0x3fff ; 1b62: addlw   0xff
    dw 0x3fff ; 1b63: addlw   0xff
    dw 0x3fff ; 1b64: addlw   0xff
    dw 0x3fff ; 1b65: addlw   0xff
    dw 0x3fff ; 1b66: addlw   0xff
    dw 0x3fff ; 1b67: addlw   0xff
    dw 0x3fff ; 1b68: addlw   0xff
    dw 0x3fff ; 1b69: addlw   0xff
    dw 0x3fff ; 1b6a: addlw   0xff
    dw 0x3fff ; 1b6b: addlw   0xff
    dw 0x3fff ; 1b6c: addlw   0xff
    dw 0x3fff ; 1b6d: addlw   0xff
    dw 0x3fff ; 1b6e: addlw   0xff
    dw 0x3fff ; 1b6f: addlw   0xff
    dw 0x3fff ; 1b70: addlw   0xff
    dw 0x3fff ; 1b71: addlw   0xff
    dw 0x3fff ; 1b72: addlw   0xff
    dw 0x3fff ; 1b73: addlw   0xff
    dw 0x3fff ; 1b74: addlw   0xff
    dw 0x3fff ; 1b75: addlw   0xff
    dw 0x3fff ; 1b76: addlw   0xff
    dw 0x3fff ; 1b77: addlw   0xff
    dw 0x3fff ; 1b78: addlw   0xff
    dw 0x3fff ; 1b79: addlw   0xff
    dw 0x3fff ; 1b7a: addlw   0xff
    dw 0x3fff ; 1b7b: addlw   0xff
    dw 0x3fff ; 1b7c: addlw   0xff
    dw 0x3fff ; 1b7d: addlw   0xff
    dw 0x3fff ; 1b7e: addlw   0xff
    dw 0x3fff ; 1b7f: addlw   0xff
    dw 0x3fff ; 1b80: addlw   0xff
    dw 0x3fff ; 1b81: addlw   0xff
    dw 0x3fff ; 1b82: addlw   0xff
    dw 0x3fff ; 1b83: addlw   0xff
    dw 0x3fff ; 1b84: addlw   0xff
    dw 0x3fff ; 1b85: addlw   0xff
    dw 0x3fff ; 1b86: addlw   0xff
    dw 0x3fff ; 1b87: addlw   0xff
    dw 0x3fff ; 1b88: addlw   0xff
    dw 0x3fff ; 1b89: addlw   0xff
    dw 0x3fff ; 1b8a: addlw   0xff
    dw 0x3fff ; 1b8b: addlw   0xff
    dw 0x3fff ; 1b8c: addlw   0xff
    dw 0x3fff ; 1b8d: addlw   0xff
    dw 0x3fff ; 1b8e: addlw   0xff
    dw 0x3fff ; 1b8f: addlw   0xff
    dw 0x3fff ; 1b90: addlw   0xff
    dw 0x3fff ; 1b91: addlw   0xff
    dw 0x3fff ; 1b92: addlw   0xff
    dw 0x3fff ; 1b93: addlw   0xff
    dw 0x3fff ; 1b94: addlw   0xff
    dw 0x3fff ; 1b95: addlw   0xff
    dw 0x3fff ; 1b96: addlw   0xff
    dw 0x3fff ; 1b97: addlw   0xff
    dw 0x3fff ; 1b98: addlw   0xff
    dw 0x3fff ; 1b99: addlw   0xff
    dw 0x3fff ; 1b9a: addlw   0xff
    dw 0x3fff ; 1b9b: addlw   0xff
    dw 0x3fff ; 1b9c: addlw   0xff
    dw 0x3fff ; 1b9d: addlw   0xff
    dw 0x3fff ; 1b9e: addlw   0xff
    dw 0x3fff ; 1b9f: addlw   0xff
    dw 0x3fff ; 1ba0: addlw   0xff
    dw 0x3fff ; 1ba1: addlw   0xff
    dw 0x3fff ; 1ba2: addlw   0xff
    dw 0x3fff ; 1ba3: addlw   0xff
    dw 0x3fff ; 1ba4: addlw   0xff
    dw 0x3fff ; 1ba5: addlw   0xff
    dw 0x3fff ; 1ba6: addlw   0xff
    dw 0x3fff ; 1ba7: addlw   0xff
    dw 0x3fff ; 1ba8: addlw   0xff
    dw 0x3fff ; 1ba9: addlw   0xff
    dw 0x3fff ; 1baa: addlw   0xff
    dw 0x3fff ; 1bab: addlw   0xff
    dw 0x3fff ; 1bac: addlw   0xff
    dw 0x3fff ; 1bad: addlw   0xff
    dw 0x3fff ; 1bae: addlw   0xff
    dw 0x3fff ; 1baf: addlw   0xff
    dw 0x3fff ; 1bb0: addlw   0xff
    dw 0x3fff ; 1bb1: addlw   0xff
    dw 0x3fff ; 1bb2: addlw   0xff
    dw 0x3fff ; 1bb3: addlw   0xff
    dw 0x3fff ; 1bb4: addlw   0xff
    dw 0x3fff ; 1bb5: addlw   0xff
    dw 0x3fff ; 1bb6: addlw   0xff
    dw 0x3fff ; 1bb7: addlw   0xff
    dw 0x3fff ; 1bb8: addlw   0xff
    dw 0x3fff ; 1bb9: addlw   0xff
    dw 0x3fff ; 1bba: addlw   0xff
    dw 0x3fff ; 1bbb: addlw   0xff
    dw 0x3fff ; 1bbc: addlw   0xff
    dw 0x3fff ; 1bbd: addlw   0xff
    dw 0x3fff ; 1bbe: addlw   0xff
    dw 0x3fff ; 1bbf: addlw   0xff
    dw 0x3fff ; 1bc0: addlw   0xff
    dw 0x3fff ; 1bc1: addlw   0xff
    dw 0x3fff ; 1bc2: addlw   0xff
    dw 0x3fff ; 1bc3: addlw   0xff
    dw 0x3fff ; 1bc4: addlw   0xff
    dw 0x3fff ; 1bc5: addlw   0xff
    dw 0x3fff ; 1bc6: addlw   0xff
    dw 0x3fff ; 1bc7: addlw   0xff
    dw 0x3fff ; 1bc8: addlw   0xff
    dw 0x3fff ; 1bc9: addlw   0xff
    dw 0x3fff ; 1bca: addlw   0xff
    dw 0x3fff ; 1bcb: addlw   0xff
    dw 0x3fff ; 1bcc: addlw   0xff
    dw 0x3fff ; 1bcd: addlw   0xff
    dw 0x3fff ; 1bce: addlw   0xff
    dw 0x3fff ; 1bcf: addlw   0xff
    dw 0x3fff ; 1bd0: addlw   0xff
    dw 0x3fff ; 1bd1: addlw   0xff
    dw 0x3fff ; 1bd2: addlw   0xff
    dw 0x3fff ; 1bd3: addlw   0xff
    dw 0x3fff ; 1bd4: addlw   0xff
    dw 0x3fff ; 1bd5: addlw   0xff
    dw 0x3fff ; 1bd6: addlw   0xff
    dw 0x3fff ; 1bd7: addlw   0xff
    dw 0x3fff ; 1bd8: addlw   0xff
    dw 0x3fff ; 1bd9: addlw   0xff
    dw 0x3fff ; 1bda: addlw   0xff
    dw 0x3fff ; 1bdb: addlw   0xff
    dw 0x3fff ; 1bdc: addlw   0xff
    dw 0x3fff ; 1bdd: addlw   0xff
    dw 0x3fff ; 1bde: addlw   0xff
    dw 0x3fff ; 1bdf: addlw   0xff
    dw 0x3fff ; 1be0: addlw   0xff
    dw 0x3fff ; 1be1: addlw   0xff
    dw 0x3fff ; 1be2: addlw   0xff
    dw 0x3fff ; 1be3: addlw   0xff
    dw 0x3fff ; 1be4: addlw   0xff
    dw 0x3fff ; 1be5: addlw   0xff
    dw 0x3fff ; 1be6: addlw   0xff
    dw 0x3fff ; 1be7: addlw   0xff
    dw 0x3fff ; 1be8: addlw   0xff
    dw 0x3fff ; 1be9: addlw   0xff
    dw 0x3fff ; 1bea: addlw   0xff
    dw 0x3fff ; 1beb: addlw   0xff
    dw 0x3fff ; 1bec: addlw   0xff
    dw 0x3fff ; 1bed: addlw   0xff
    dw 0x3fff ; 1bee: addlw   0xff
    dw 0x3fff ; 1bef: addlw   0xff
    dw 0x3fff ; 1bf0: addlw   0xff
    dw 0x3fff ; 1bf1: addlw   0xff
    dw 0x3fff ; 1bf2: addlw   0xff
    dw 0x3fff ; 1bf3: addlw   0xff
    dw 0x3fff ; 1bf4: addlw   0xff
    dw 0x3fff ; 1bf5: addlw   0xff
    dw 0x3fff ; 1bf6: addlw   0xff
    dw 0x3fff ; 1bf7: addlw   0xff
    dw 0x3fff ; 1bf8: addlw   0xff
    dw 0x3fff ; 1bf9: addlw   0xff
    dw 0x3fff ; 1bfa: addlw   0xff
    dw 0x3fff ; 1bfb: addlw   0xff
    dw 0x3fff ; 1bfc: addlw   0xff
    dw 0x3fff ; 1bfd: addlw   0xff
    dw 0x3fff ; 1bfe: addlw   0xff
    dw 0x3fff ; 1bff: addlw   0xff
    dw 0x3fff ; 1c00: addlw   0xff
    dw 0x3fff ; 1c01: addlw   0xff
    dw 0x3fff ; 1c02: addlw   0xff
    dw 0x3fff ; 1c03: addlw   0xff
    dw 0x3fff ; 1c04: addlw   0xff
    dw 0x3fff ; 1c05: addlw   0xff
    dw 0x3fff ; 1c06: addlw   0xff
    dw 0x3fff ; 1c07: addlw   0xff
    dw 0x3fff ; 1c08: addlw   0xff
    dw 0x3fff ; 1c09: addlw   0xff
    dw 0x3fff ; 1c0a: addlw   0xff
    dw 0x3fff ; 1c0b: addlw   0xff
    dw 0x3fff ; 1c0c: addlw   0xff
    dw 0x3fff ; 1c0d: addlw   0xff
    dw 0x3fff ; 1c0e: addlw   0xff
    dw 0x3fff ; 1c0f: addlw   0xff
    dw 0x3fff ; 1c10: addlw   0xff
    dw 0x3fff ; 1c11: addlw   0xff
    dw 0x3fff ; 1c12: addlw   0xff
    dw 0x3fff ; 1c13: addlw   0xff
    dw 0x3fff ; 1c14: addlw   0xff
    dw 0x3fff ; 1c15: addlw   0xff
    dw 0x3fff ; 1c16: addlw   0xff
    dw 0x3fff ; 1c17: addlw   0xff
    dw 0x3fff ; 1c18: addlw   0xff
    dw 0x3fff ; 1c19: addlw   0xff
    dw 0x3fff ; 1c1a: addlw   0xff
    dw 0x3fff ; 1c1b: addlw   0xff
    dw 0x3fff ; 1c1c: addlw   0xff
    dw 0x3fff ; 1c1d: addlw   0xff
    dw 0x3fff ; 1c1e: addlw   0xff
    dw 0x3fff ; 1c1f: addlw   0xff
    dw 0x3fff ; 1c20: addlw   0xff
    dw 0x3fff ; 1c21: addlw   0xff
    dw 0x3fff ; 1c22: addlw   0xff
    dw 0x3fff ; 1c23: addlw   0xff
    dw 0x3fff ; 1c24: addlw   0xff
    dw 0x3fff ; 1c25: addlw   0xff
    dw 0x3fff ; 1c26: addlw   0xff
    dw 0x3fff ; 1c27: addlw   0xff
    dw 0x3fff ; 1c28: addlw   0xff
    dw 0x3fff ; 1c29: addlw   0xff
    dw 0x3fff ; 1c2a: addlw   0xff
    dw 0x3fff ; 1c2b: addlw   0xff
    dw 0x3fff ; 1c2c: addlw   0xff
    dw 0x3fff ; 1c2d: addlw   0xff
    dw 0x3fff ; 1c2e: addlw   0xff
    dw 0x3fff ; 1c2f: addlw   0xff
    dw 0x3fff ; 1c30: addlw   0xff
    dw 0x3fff ; 1c31: addlw   0xff
    dw 0x3fff ; 1c32: addlw   0xff
    dw 0x3fff ; 1c33: addlw   0xff
    dw 0x3fff ; 1c34: addlw   0xff
    dw 0x3fff ; 1c35: addlw   0xff
    dw 0x3fff ; 1c36: addlw   0xff
    dw 0x3fff ; 1c37: addlw   0xff
    dw 0x3fff ; 1c38: addlw   0xff
    dw 0x3fff ; 1c39: addlw   0xff
    dw 0x3fff ; 1c3a: addlw   0xff
    dw 0x3fff ; 1c3b: addlw   0xff
    dw 0x3fff ; 1c3c: addlw   0xff
    dw 0x3fff ; 1c3d: addlw   0xff
    dw 0x3fff ; 1c3e: addlw   0xff
    dw 0x3fff ; 1c3f: addlw   0xff
    dw 0x3fff ; 1c40: addlw   0xff
    dw 0x3fff ; 1c41: addlw   0xff
    dw 0x3fff ; 1c42: addlw   0xff
    dw 0x3fff ; 1c43: addlw   0xff
    dw 0x3fff ; 1c44: addlw   0xff
    dw 0x3fff ; 1c45: addlw   0xff
    dw 0x3fff ; 1c46: addlw   0xff
    dw 0x3fff ; 1c47: addlw   0xff
    dw 0x3fff ; 1c48: addlw   0xff
    dw 0x3fff ; 1c49: addlw   0xff
    dw 0x3fff ; 1c4a: addlw   0xff
    dw 0x3fff ; 1c4b: addlw   0xff
    dw 0x3fff ; 1c4c: addlw   0xff
    dw 0x3fff ; 1c4d: addlw   0xff
    dw 0x3fff ; 1c4e: addlw   0xff
    dw 0x3fff ; 1c4f: addlw   0xff
    dw 0x3fff ; 1c50: addlw   0xff
    dw 0x3fff ; 1c51: addlw   0xff
    dw 0x3fff ; 1c52: addlw   0xff
    dw 0x3fff ; 1c53: addlw   0xff
    dw 0x3fff ; 1c54: addlw   0xff
    dw 0x3fff ; 1c55: addlw   0xff
    dw 0x3fff ; 1c56: addlw   0xff
    dw 0x3fff ; 1c57: addlw   0xff
    dw 0x3fff ; 1c58: addlw   0xff
    dw 0x3fff ; 1c59: addlw   0xff
    dw 0x3fff ; 1c5a: addlw   0xff
    dw 0x3fff ; 1c5b: addlw   0xff
    dw 0x3fff ; 1c5c: addlw   0xff
    dw 0x3fff ; 1c5d: addlw   0xff
    dw 0x3fff ; 1c5e: addlw   0xff
    dw 0x3fff ; 1c5f: addlw   0xff
    dw 0x3fff ; 1c60: addlw   0xff
    dw 0x3fff ; 1c61: addlw   0xff
    dw 0x3fff ; 1c62: addlw   0xff
    dw 0x3fff ; 1c63: addlw   0xff
    dw 0x3fff ; 1c64: addlw   0xff
    dw 0x3fff ; 1c65: addlw   0xff
    dw 0x3fff ; 1c66: addlw   0xff
    dw 0x3fff ; 1c67: addlw   0xff
    dw 0x3fff ; 1c68: addlw   0xff
    dw 0x3fff ; 1c69: addlw   0xff
    dw 0x3fff ; 1c6a: addlw   0xff
    dw 0x3fff ; 1c6b: addlw   0xff
    dw 0x3fff ; 1c6c: addlw   0xff
    dw 0x3fff ; 1c6d: addlw   0xff
    dw 0x3fff ; 1c6e: addlw   0xff
    dw 0x3fff ; 1c6f: addlw   0xff
    dw 0x3fff ; 1c70: addlw   0xff
    dw 0x3fff ; 1c71: addlw   0xff
    dw 0x3fff ; 1c72: addlw   0xff
    dw 0x3fff ; 1c73: addlw   0xff
    dw 0x3fff ; 1c74: addlw   0xff
    dw 0x3fff ; 1c75: addlw   0xff
    dw 0x3fff ; 1c76: addlw   0xff
    dw 0x3fff ; 1c77: addlw   0xff
    dw 0x3fff ; 1c78: addlw   0xff
    dw 0x3fff ; 1c79: addlw   0xff
    dw 0x3fff ; 1c7a: addlw   0xff
    dw 0x3fff ; 1c7b: addlw   0xff
    dw 0x3fff ; 1c7c: addlw   0xff
    dw 0x3fff ; 1c7d: addlw   0xff
    dw 0x3fff ; 1c7e: addlw   0xff
    dw 0x3fff ; 1c7f: addlw   0xff
    dw 0x3fff ; 1c80: addlw   0xff
    dw 0x3fff ; 1c81: addlw   0xff
    dw 0x3fff ; 1c82: addlw   0xff
    dw 0x3fff ; 1c83: addlw   0xff
    dw 0x3fff ; 1c84: addlw   0xff
    dw 0x3fff ; 1c85: addlw   0xff
    dw 0x3fff ; 1c86: addlw   0xff
    dw 0x3fff ; 1c87: addlw   0xff
    dw 0x3fff ; 1c88: addlw   0xff
    dw 0x3fff ; 1c89: addlw   0xff
    dw 0x3fff ; 1c8a: addlw   0xff
    dw 0x3fff ; 1c8b: addlw   0xff
    dw 0x3fff ; 1c8c: addlw   0xff
    dw 0x3fff ; 1c8d: addlw   0xff
    dw 0x3fff ; 1c8e: addlw   0xff
    dw 0x3fff ; 1c8f: addlw   0xff
    dw 0x3fff ; 1c90: addlw   0xff
    dw 0x3fff ; 1c91: addlw   0xff
    dw 0x3fff ; 1c92: addlw   0xff
    dw 0x3fff ; 1c93: addlw   0xff
    dw 0x3fff ; 1c94: addlw   0xff
    dw 0x3fff ; 1c95: addlw   0xff
    dw 0x3fff ; 1c96: addlw   0xff
    dw 0x3fff ; 1c97: addlw   0xff
    dw 0x3fff ; 1c98: addlw   0xff
    dw 0x3fff ; 1c99: addlw   0xff
    dw 0x3fff ; 1c9a: addlw   0xff
    dw 0x3fff ; 1c9b: addlw   0xff
    dw 0x3fff ; 1c9c: addlw   0xff
    dw 0x3fff ; 1c9d: addlw   0xff
    dw 0x3fff ; 1c9e: addlw   0xff
    dw 0x3fff ; 1c9f: addlw   0xff
    dw 0x3fff ; 1ca0: addlw   0xff
    dw 0x3fff ; 1ca1: addlw   0xff
    dw 0x3fff ; 1ca2: addlw   0xff
    dw 0x3fff ; 1ca3: addlw   0xff
    dw 0x3fff ; 1ca4: addlw   0xff
    dw 0x3fff ; 1ca5: addlw   0xff
    dw 0x3fff ; 1ca6: addlw   0xff
    dw 0x3fff ; 1ca7: addlw   0xff
    dw 0x3fff ; 1ca8: addlw   0xff
    dw 0x3fff ; 1ca9: addlw   0xff
    dw 0x3fff ; 1caa: addlw   0xff
    dw 0x3fff ; 1cab: addlw   0xff
    dw 0x3fff ; 1cac: addlw   0xff
    dw 0x3fff ; 1cad: addlw   0xff
    dw 0x3fff ; 1cae: addlw   0xff
    dw 0x3fff ; 1caf: addlw   0xff
    dw 0x3fff ; 1cb0: addlw   0xff
    dw 0x3fff ; 1cb1: addlw   0xff
    dw 0x3fff ; 1cb2: addlw   0xff
    dw 0x3fff ; 1cb3: addlw   0xff
    dw 0x3fff ; 1cb4: addlw   0xff
    dw 0x3fff ; 1cb5: addlw   0xff
    dw 0x3fff ; 1cb6: addlw   0xff
    dw 0x3fff ; 1cb7: addlw   0xff
    dw 0x3fff ; 1cb8: addlw   0xff
    dw 0x3fff ; 1cb9: addlw   0xff
    dw 0x3fff ; 1cba: addlw   0xff
    dw 0x3fff ; 1cbb: addlw   0xff
    dw 0x3fff ; 1cbc: addlw   0xff
    dw 0x3fff ; 1cbd: addlw   0xff
    dw 0x3fff ; 1cbe: addlw   0xff
    dw 0x3fff ; 1cbf: addlw   0xff
    dw 0x3fff ; 1cc0: addlw   0xff
    dw 0x3fff ; 1cc1: addlw   0xff
    dw 0x3fff ; 1cc2: addlw   0xff
    dw 0x3fff ; 1cc3: addlw   0xff
    dw 0x3fff ; 1cc4: addlw   0xff
    dw 0x3fff ; 1cc5: addlw   0xff
    dw 0x3fff ; 1cc6: addlw   0xff
    dw 0x3fff ; 1cc7: addlw   0xff
    dw 0x3fff ; 1cc8: addlw   0xff
    dw 0x3fff ; 1cc9: addlw   0xff
    dw 0x3fff ; 1cca: addlw   0xff
    dw 0x3fff ; 1ccb: addlw   0xff
    dw 0x3fff ; 1ccc: addlw   0xff
    dw 0x3fff ; 1ccd: addlw   0xff
    dw 0x3fff ; 1cce: addlw   0xff
    dw 0x3fff ; 1ccf: addlw   0xff
    dw 0x3fff ; 1cd0: addlw   0xff
    dw 0x3fff ; 1cd1: addlw   0xff
    dw 0x3fff ; 1cd2: addlw   0xff
    dw 0x3fff ; 1cd3: addlw   0xff
    dw 0x3fff ; 1cd4: addlw   0xff
    dw 0x3fff ; 1cd5: addlw   0xff
    dw 0x3fff ; 1cd6: addlw   0xff
    dw 0x3fff ; 1cd7: addlw   0xff
    dw 0x3fff ; 1cd8: addlw   0xff
    dw 0x3fff ; 1cd9: addlw   0xff
    dw 0x3fff ; 1cda: addlw   0xff
    dw 0x3fff ; 1cdb: addlw   0xff
    dw 0x3fff ; 1cdc: addlw   0xff
    dw 0x3fff ; 1cdd: addlw   0xff
    dw 0x3fff ; 1cde: addlw   0xff
    dw 0x3fff ; 1cdf: addlw   0xff
    dw 0x3fff ; 1ce0: addlw   0xff
    dw 0x3fff ; 1ce1: addlw   0xff
    dw 0x3fff ; 1ce2: addlw   0xff
    dw 0x3fff ; 1ce3: addlw   0xff
    dw 0x3fff ; 1ce4: addlw   0xff
    dw 0x3fff ; 1ce5: addlw   0xff
    dw 0x3fff ; 1ce6: addlw   0xff
    dw 0x3fff ; 1ce7: addlw   0xff
    dw 0x3fff ; 1ce8: addlw   0xff
    dw 0x3fff ; 1ce9: addlw   0xff
    dw 0x3fff ; 1cea: addlw   0xff
    dw 0x3fff ; 1ceb: addlw   0xff
    dw 0x3fff ; 1cec: addlw   0xff
    dw 0x3fff ; 1ced: addlw   0xff
    dw 0x3fff ; 1cee: addlw   0xff
    dw 0x3fff ; 1cef: addlw   0xff
    dw 0x3fff ; 1cf0: addlw   0xff
    dw 0x3fff ; 1cf1: addlw   0xff
    dw 0x3fff ; 1cf2: addlw   0xff
    dw 0x3fff ; 1cf3: addlw   0xff
    dw 0x3fff ; 1cf4: addlw   0xff
    dw 0x3fff ; 1cf5: addlw   0xff
    dw 0x3fff ; 1cf6: addlw   0xff
    dw 0x3fff ; 1cf7: addlw   0xff
    dw 0x3fff ; 1cf8: addlw   0xff
    dw 0x3fff ; 1cf9: addlw   0xff
    dw 0x3fff ; 1cfa: addlw   0xff
    dw 0x3fff ; 1cfb: addlw   0xff
    dw 0x3fff ; 1cfc: addlw   0xff
    dw 0x3fff ; 1cfd: addlw   0xff
    dw 0x3fff ; 1cfe: addlw   0xff
    dw 0x3fff ; 1cff: addlw   0xff
    dw 0x3fff ; 1d00: addlw   0xff
    dw 0x3fff ; 1d01: addlw   0xff
    dw 0x3fff ; 1d02: addlw   0xff
    dw 0x3fff ; 1d03: addlw   0xff
    dw 0x3fff ; 1d04: addlw   0xff
    dw 0x3fff ; 1d05: addlw   0xff
    dw 0x3fff ; 1d06: addlw   0xff
    dw 0x3fff ; 1d07: addlw   0xff
    dw 0x3fff ; 1d08: addlw   0xff
    dw 0x3fff ; 1d09: addlw   0xff
    dw 0x3fff ; 1d0a: addlw   0xff
    dw 0x3fff ; 1d0b: addlw   0xff
    dw 0x3fff ; 1d0c: addlw   0xff
    dw 0x3fff ; 1d0d: addlw   0xff
    dw 0x3fff ; 1d0e: addlw   0xff
    dw 0x3fff ; 1d0f: addlw   0xff
    dw 0x3fff ; 1d10: addlw   0xff
    dw 0x3fff ; 1d11: addlw   0xff
    dw 0x3fff ; 1d12: addlw   0xff
    dw 0x3fff ; 1d13: addlw   0xff
    dw 0x3fff ; 1d14: addlw   0xff
    dw 0x3fff ; 1d15: addlw   0xff
    dw 0x3fff ; 1d16: addlw   0xff
    dw 0x3fff ; 1d17: addlw   0xff
    dw 0x3fff ; 1d18: addlw   0xff
    dw 0x3fff ; 1d19: addlw   0xff
    dw 0x3fff ; 1d1a: addlw   0xff
    dw 0x3fff ; 1d1b: addlw   0xff
    dw 0x3fff ; 1d1c: addlw   0xff
    dw 0x3fff ; 1d1d: addlw   0xff
    dw 0x3fff ; 1d1e: addlw   0xff
    dw 0x3fff ; 1d1f: addlw   0xff
    dw 0x3fff ; 1d20: addlw   0xff
    dw 0x3fff ; 1d21: addlw   0xff
    dw 0x3fff ; 1d22: addlw   0xff
    dw 0x3fff ; 1d23: addlw   0xff
    dw 0x3fff ; 1d24: addlw   0xff
    dw 0x3fff ; 1d25: addlw   0xff
    dw 0x3fff ; 1d26: addlw   0xff
    dw 0x3fff ; 1d27: addlw   0xff
    dw 0x3fff ; 1d28: addlw   0xff
    dw 0x3fff ; 1d29: addlw   0xff
    dw 0x3fff ; 1d2a: addlw   0xff
    dw 0x3fff ; 1d2b: addlw   0xff
    dw 0x3fff ; 1d2c: addlw   0xff
    dw 0x3fff ; 1d2d: addlw   0xff
    dw 0x3fff ; 1d2e: addlw   0xff
    dw 0x3fff ; 1d2f: addlw   0xff
    dw 0x3fff ; 1d30: addlw   0xff
    dw 0x3fff ; 1d31: addlw   0xff
    dw 0x3fff ; 1d32: addlw   0xff
    dw 0x3fff ; 1d33: addlw   0xff
    dw 0x3fff ; 1d34: addlw   0xff
    dw 0x3fff ; 1d35: addlw   0xff
    dw 0x3fff ; 1d36: addlw   0xff
    dw 0x3fff ; 1d37: addlw   0xff
    dw 0x3fff ; 1d38: addlw   0xff
    dw 0x3fff ; 1d39: addlw   0xff
    dw 0x3fff ; 1d3a: addlw   0xff
    dw 0x3fff ; 1d3b: addlw   0xff
    dw 0x3fff ; 1d3c: addlw   0xff
    dw 0x3fff ; 1d3d: addlw   0xff
    dw 0x3fff ; 1d3e: addlw   0xff
    dw 0x3fff ; 1d3f: addlw   0xff
    dw 0x3fff ; 1d40: addlw   0xff
    dw 0x3fff ; 1d41: addlw   0xff
    dw 0x3fff ; 1d42: addlw   0xff
    dw 0x3fff ; 1d43: addlw   0xff
    dw 0x3fff ; 1d44: addlw   0xff
    dw 0x3fff ; 1d45: addlw   0xff
    dw 0x3fff ; 1d46: addlw   0xff
    dw 0x3fff ; 1d47: addlw   0xff
    dw 0x3fff ; 1d48: addlw   0xff
    dw 0x3fff ; 1d49: addlw   0xff
    dw 0x3fff ; 1d4a: addlw   0xff
    dw 0x3fff ; 1d4b: addlw   0xff
    dw 0x3fff ; 1d4c: addlw   0xff
    dw 0x3fff ; 1d4d: addlw   0xff
    dw 0x3fff ; 1d4e: addlw   0xff
    dw 0x3fff ; 1d4f: addlw   0xff
    dw 0x3fff ; 1d50: addlw   0xff
    dw 0x3fff ; 1d51: addlw   0xff
    dw 0x3fff ; 1d52: addlw   0xff
    dw 0x3fff ; 1d53: addlw   0xff
    dw 0x3fff ; 1d54: addlw   0xff
    dw 0x3fff ; 1d55: addlw   0xff
    dw 0x3fff ; 1d56: addlw   0xff
    dw 0x3fff ; 1d57: addlw   0xff
    dw 0x3fff ; 1d58: addlw   0xff
    dw 0x3fff ; 1d59: addlw   0xff
    dw 0x3fff ; 1d5a: addlw   0xff
    dw 0x3fff ; 1d5b: addlw   0xff
    dw 0x3fff ; 1d5c: addlw   0xff
    dw 0x3fff ; 1d5d: addlw   0xff
    dw 0x3fff ; 1d5e: addlw   0xff
    dw 0x3fff ; 1d5f: addlw   0xff
    dw 0x3fff ; 1d60: addlw   0xff
    dw 0x3fff ; 1d61: addlw   0xff
    dw 0x3fff ; 1d62: addlw   0xff
    dw 0x3fff ; 1d63: addlw   0xff
    dw 0x3fff ; 1d64: addlw   0xff
    dw 0x3fff ; 1d65: addlw   0xff
    dw 0x3fff ; 1d66: addlw   0xff
    dw 0x3fff ; 1d67: addlw   0xff
    dw 0x3fff ; 1d68: addlw   0xff
    dw 0x3fff ; 1d69: addlw   0xff
    dw 0x3fff ; 1d6a: addlw   0xff
    dw 0x3fff ; 1d6b: addlw   0xff
    dw 0x3fff ; 1d6c: addlw   0xff
    dw 0x3fff ; 1d6d: addlw   0xff
    dw 0x3fff ; 1d6e: addlw   0xff
    dw 0x3fff ; 1d6f: addlw   0xff
    dw 0x3fff ; 1d70: addlw   0xff
    dw 0x3fff ; 1d71: addlw   0xff
    dw 0x3fff ; 1d72: addlw   0xff
    dw 0x3fff ; 1d73: addlw   0xff
    dw 0x3fff ; 1d74: addlw   0xff
    dw 0x3fff ; 1d75: addlw   0xff
    dw 0x3fff ; 1d76: addlw   0xff
    dw 0x3fff ; 1d77: addlw   0xff
    dw 0x3fff ; 1d78: addlw   0xff
    dw 0x3fff ; 1d79: addlw   0xff
    dw 0x3fff ; 1d7a: addlw   0xff
    dw 0x3fff ; 1d7b: addlw   0xff
    dw 0x3fff ; 1d7c: addlw   0xff
    dw 0x3fff ; 1d7d: addlw   0xff
    dw 0x3fff ; 1d7e: addlw   0xff
    dw 0x3fff ; 1d7f: addlw   0xff
    dw 0x3fff ; 1d80: addlw   0xff
    dw 0x3fff ; 1d81: addlw   0xff
    dw 0x3fff ; 1d82: addlw   0xff
    dw 0x3fff ; 1d83: addlw   0xff
    dw 0x3fff ; 1d84: addlw   0xff
    dw 0x3fff ; 1d85: addlw   0xff
    dw 0x3fff ; 1d86: addlw   0xff
    dw 0x3fff ; 1d87: addlw   0xff
    dw 0x3fff ; 1d88: addlw   0xff
    dw 0x3fff ; 1d89: addlw   0xff
    dw 0x3fff ; 1d8a: addlw   0xff
    dw 0x3fff ; 1d8b: addlw   0xff
    dw 0x3fff ; 1d8c: addlw   0xff
    dw 0x3fff ; 1d8d: addlw   0xff
    dw 0x3fff ; 1d8e: addlw   0xff
    dw 0x3fff ; 1d8f: addlw   0xff
    dw 0x3fff ; 1d90: addlw   0xff
    dw 0x3fff ; 1d91: addlw   0xff
    dw 0x3fff ; 1d92: addlw   0xff
    dw 0x3fff ; 1d93: addlw   0xff
    dw 0x3fff ; 1d94: addlw   0xff
    dw 0x3fff ; 1d95: addlw   0xff
    dw 0x3fff ; 1d96: addlw   0xff
    dw 0x3fff ; 1d97: addlw   0xff
    dw 0x3fff ; 1d98: addlw   0xff
    dw 0x3fff ; 1d99: addlw   0xff
    dw 0x3fff ; 1d9a: addlw   0xff
    dw 0x3fff ; 1d9b: addlw   0xff
    dw 0x3fff ; 1d9c: addlw   0xff
    dw 0x3fff ; 1d9d: addlw   0xff
    dw 0x3fff ; 1d9e: addlw   0xff
    dw 0x3fff ; 1d9f: addlw   0xff
    dw 0x3fff ; 1da0: addlw   0xff
    dw 0x3fff ; 1da1: addlw   0xff
    dw 0x3fff ; 1da2: addlw   0xff
    dw 0x3fff ; 1da3: addlw   0xff
    dw 0x3fff ; 1da4: addlw   0xff
    dw 0x3fff ; 1da5: addlw   0xff
    dw 0x3fff ; 1da6: addlw   0xff
    dw 0x3fff ; 1da7: addlw   0xff
    dw 0x3fff ; 1da8: addlw   0xff
    dw 0x3fff ; 1da9: addlw   0xff
    dw 0x3fff ; 1daa: addlw   0xff
    dw 0x3fff ; 1dab: addlw   0xff
    dw 0x3fff ; 1dac: addlw   0xff
    dw 0x3fff ; 1dad: addlw   0xff
    dw 0x3fff ; 1dae: addlw   0xff
    dw 0x3fff ; 1daf: addlw   0xff
    dw 0x3fff ; 1db0: addlw   0xff
    dw 0x3fff ; 1db1: addlw   0xff
    dw 0x3fff ; 1db2: addlw   0xff
    dw 0x3fff ; 1db3: addlw   0xff
    dw 0x3fff ; 1db4: addlw   0xff
    dw 0x3fff ; 1db5: addlw   0xff
    dw 0x3fff ; 1db6: addlw   0xff
    dw 0x3fff ; 1db7: addlw   0xff
    dw 0x3fff ; 1db8: addlw   0xff
    dw 0x3fff ; 1db9: addlw   0xff
    dw 0x3fff ; 1dba: addlw   0xff
    dw 0x3fff ; 1dbb: addlw   0xff
    dw 0x3fff ; 1dbc: addlw   0xff
    dw 0x3fff ; 1dbd: addlw   0xff
    dw 0x3fff ; 1dbe: addlw   0xff
    dw 0x3fff ; 1dbf: addlw   0xff
    dw 0x3fff ; 1dc0: addlw   0xff
    dw 0x3fff ; 1dc1: addlw   0xff
    dw 0x3fff ; 1dc2: addlw   0xff
    dw 0x3fff ; 1dc3: addlw   0xff
    dw 0x3fff ; 1dc4: addlw   0xff
    dw 0x3fff ; 1dc5: addlw   0xff
    dw 0x3fff ; 1dc6: addlw   0xff
    dw 0x3fff ; 1dc7: addlw   0xff
    dw 0x3fff ; 1dc8: addlw   0xff
    dw 0x3fff ; 1dc9: addlw   0xff
    dw 0x3fff ; 1dca: addlw   0xff
    dw 0x3fff ; 1dcb: addlw   0xff
    dw 0x3fff ; 1dcc: addlw   0xff
    dw 0x3fff ; 1dcd: addlw   0xff
    dw 0x3fff ; 1dce: addlw   0xff
    dw 0x3fff ; 1dcf: addlw   0xff
    dw 0x3fff ; 1dd0: addlw   0xff
    dw 0x3fff ; 1dd1: addlw   0xff
    dw 0x3fff ; 1dd2: addlw   0xff
    dw 0x3fff ; 1dd3: addlw   0xff
    dw 0x3fff ; 1dd4: addlw   0xff
    dw 0x3fff ; 1dd5: addlw   0xff
    dw 0x3fff ; 1dd6: addlw   0xff
    dw 0x3fff ; 1dd7: addlw   0xff
    dw 0x3fff ; 1dd8: addlw   0xff
    dw 0x3fff ; 1dd9: addlw   0xff
    dw 0x3fff ; 1dda: addlw   0xff
    dw 0x3fff ; 1ddb: addlw   0xff
    dw 0x3fff ; 1ddc: addlw   0xff
    dw 0x3fff ; 1ddd: addlw   0xff
    dw 0x3fff ; 1dde: addlw   0xff
    dw 0x3fff ; 1ddf: addlw   0xff
    dw 0x3fff ; 1de0: addlw   0xff
    dw 0x3fff ; 1de1: addlw   0xff
    dw 0x3fff ; 1de2: addlw   0xff
    dw 0x3fff ; 1de3: addlw   0xff
    dw 0x3fff ; 1de4: addlw   0xff
    dw 0x3fff ; 1de5: addlw   0xff
    dw 0x3fff ; 1de6: addlw   0xff
    dw 0x3fff ; 1de7: addlw   0xff
    dw 0x3fff ; 1de8: addlw   0xff
    dw 0x3fff ; 1de9: addlw   0xff
    dw 0x3fff ; 1dea: addlw   0xff
    dw 0x3fff ; 1deb: addlw   0xff
    dw 0x3fff ; 1dec: addlw   0xff
    dw 0x3fff ; 1ded: addlw   0xff
    dw 0x3fff ; 1dee: addlw   0xff
    dw 0x3fff ; 1def: addlw   0xff
    dw 0x3fff ; 1df0: addlw   0xff
    dw 0x3fff ; 1df1: addlw   0xff
    dw 0x3fff ; 1df2: addlw   0xff
    dw 0x3fff ; 1df3: addlw   0xff
    dw 0x3fff ; 1df4: addlw   0xff
    dw 0x3fff ; 1df5: addlw   0xff
    dw 0x3fff ; 1df6: addlw   0xff
    dw 0x3fff ; 1df7: addlw   0xff
    dw 0x3fff ; 1df8: addlw   0xff
    dw 0x3fff ; 1df9: addlw   0xff
    dw 0x0183 ; 1dfa: clrf    STATUS
    dw 0x0008 ; 1dfb: return
    dw 0x0183 ; 1dfc: clrf    STATUS
    dw 0x3401 ; 1dfd: retlw   0x01
    dw 0x0183 ; 1dfe: clrf    STATUS
    dw 0x3401 ; 1dff: retlw   0x01
    dw 0x0183 ; 1e00: clrf    STATUS
    dw 0x3401 ; 1e01: retlw   0x01
    dw 0x0183 ; 1e02: clrf    STATUS
    dw 0x0008 ; 1e03: return
    dw 0x138b ; 1e04: bcf     INTCON, GIE
    dw 0x0064 ; 1e05: clrwdt
    dw 0x2e04 ; 1e06: goto    label_114
    dw 0x0183 ; 1e07: clrf    STATUS
    dw 0x0835 ; 1e08: movf    0x35, W
    dw 0x0008 ; 1e09: return
    dw 0x0183 ; 1e0a: clrf    STATUS
    dw 0x0fb0 ; 1e0b: incfsz  0x30, F
    dw 0x0008 ; 1e0c: return
    dw 0x0008 ; 1e0d: return
    dw 0x1683 ; 1e0e: bsf     STATUS, RP0
    dw 0x1303 ; 1e0f: bcf     STATUS, RP1
    dw 0x0820 ; 1e10: movf    0x20, W
    dw 0x1283 ; 1e11: bcf     STATUS, RP0
    dw 0x0008 ; 1e12: return
    dw 0x1283 ; 1e13: bcf     STATUS, RP0
    dw 0x1703 ; 1e14: bsf     STATUS, RP1
    dw 0x0828 ; 1e15: movf    0x28, W
    dw 0x39ff ; 1e16: andlw   0xff
    dw 0x1303 ; 1e17: bcf     STATUS, RP1
    dw 0x0008 ; 1e18: return
    dw 0x0183 ; 1e19: clrf    STATUS
    dw 0x0827 ; 1e1a: movf    0x27, W
    dw 0x00f1 ; 1e1b: movwf   (Common_RAM + 1)
    dw 0x0826 ; 1e1c: movf    0x26, W
    dw 0x00f0 ; 1e1d: movwf   Common_RAM
    dw 0x0008 ; 1e1e: return
    dw 0x1283 ; 1e1f: bcf     STATUS, RP0
    dw 0x1703 ; 1e20: bsf     STATUS, RP1
    dw 0x0e2c ; 1e21: swapf   0x2c, W
    dw 0x3907 ; 1e22: andlw   0x07
    dw 0x1303 ; 1e23: bcf     STATUS, RP1
    dw 0x0008 ; 1e24: return
    dw 0x1283 ; 1e25: bcf     STATUS, RP0
    dw 0x1703 ; 1e26: bsf     STATUS, RP1
    dw 0x0839 ; 1e27: movf    0x39, W
    dw 0x39ff ; 1e28: andlw   0xff
    dw 0x1303 ; 1e29: bcf     STATUS, RP1
    dw 0x0008 ; 1e2a: return
    dw 0x1283 ; 1e2b: bcf     STATUS, RP0
    dw 0x1703 ; 1e2c: bsf     STATUS, RP1
    dw 0x083b ; 1e2d: movf    0x3b, W
    dw 0x39ff ; 1e2e: andlw   0xff
    dw 0x1303 ; 1e2f: bcf     STATUS, RP1
    dw 0x0008 ; 1e30: return
    dw 0x1283 ; 1e31: bcf     STATUS, RP0
    dw 0x1703 ; 1e32: bsf     STATUS, RP1
    dw 0x0e2c ; 1e33: swapf   0x2c, W
    dw 0x3907 ; 1e34: andlw   0x07
    dw 0x1303 ; 1e35: bcf     STATUS, RP1
    dw 0x0008 ; 1e36: return
    dw 0x1283 ; 1e37: bcf     STATUS, RP0
    dw 0x1703 ; 1e38: bsf     STATUS, RP1
    dw 0x083c ; 1e39: movf    0x3c, W
    dw 0x3907 ; 1e3a: andlw   0x07
    dw 0x1303 ; 1e3b: bcf     STATUS, RP1
    dw 0x0008 ; 1e3c: return
    dw 0x1283 ; 1e3d: bcf     STATUS, RP0
    dw 0x1703 ; 1e3e: bsf     STATUS, RP1
    dw 0x0e3c ; 1e3f: swapf   0x3c, W
    dw 0x3907 ; 1e40: andlw   0x07
    dw 0x1303 ; 1e41: bcf     STATUS, RP1
    dw 0x0008 ; 1e42: return
    dw 0x1283 ; 1e43: bcf     STATUS, RP0
    dw 0x1703 ; 1e44: bsf     STATUS, RP1
    dw 0x0e2e ; 1e45: swapf   0x2e, W
    dw 0x390f ; 1e46: andlw   0x0f
    dw 0x1303 ; 1e47: bcf     STATUS, RP1
    dw 0x0008 ; 1e48: return
    dw 0x1283 ; 1e49: bcf     STATUS, RP0
    dw 0x1703 ; 1e4a: bsf     STATUS, RP1
    dw 0x0e2d ; 1e4b: swapf   0x2d, W
    dw 0x390f ; 1e4c: andlw   0x0f
    dw 0x1303 ; 1e4d: bcf     STATUS, RP1
    dw 0x0008 ; 1e4e: return
    dw 0x1283 ; 1e4f: bcf     STATUS, RP0
    dw 0x1703 ; 1e50: bsf     STATUS, RP1
    dw 0x082d ; 1e51: movf    0x2d, W
    dw 0x390f ; 1e52: andlw   0x0f
    dw 0x1303 ; 1e53: bcf     STATUS, RP1
    dw 0x0008 ; 1e54: return
    dw 0x1283 ; 1e55: bcf     STATUS, RP0
    dw 0x1703 ; 1e56: bsf     STATUS, RP1
    dw 0x082f ; 1e57: movf    0x2f, W
    dw 0x390f ; 1e58: andlw   0x0f
    dw 0x1303 ; 1e59: bcf     STATUS, RP1
    dw 0x0008 ; 1e5a: return
    dw 0x1283 ; 1e5b: bcf     STATUS, RP0
    dw 0x1703 ; 1e5c: bsf     STATUS, RP1
    dw 0x0e2f ; 1e5d: swapf   0x2f, W
    dw 0x390f ; 1e5e: andlw   0x0f
    dw 0x1303 ; 1e5f: bcf     STATUS, RP1
    dw 0x0008 ; 1e60: return
    dw 0x1283 ; 1e61: bcf     STATUS, RP0
    dw 0x1703 ; 1e62: bsf     STATUS, RP1
    dw 0x0830 ; 1e63: movf    0x30, W
    dw 0x390f ; 1e64: andlw   0x0f
    dw 0x1303 ; 1e65: bcf     STATUS, RP1
    dw 0x0008 ; 1e66: return
    dw 0x1283 ; 1e67: bcf     STATUS, RP0
    dw 0x1703 ; 1e68: bsf     STATUS, RP1
    dw 0x0829 ; 1e69: movf    0x29, W
    dw 0x390f ; 1e6a: andlw   0x0f
    dw 0x1303 ; 1e6b: bcf     STATUS, RP1
    dw 0x0008 ; 1e6c: return
    dw 0x1283 ; 1e6d: bcf     STATUS, RP0
    dw 0x1703 ; 1e6e: bsf     STATUS, RP1
    dw 0x082e ; 1e6f: movf    0x2e, W
    dw 0x390f ; 1e70: andlw   0x0f
    dw 0x1303 ; 1e71: bcf     STATUS, RP1
    dw 0x0008 ; 1e72: return
    dw 0x1283 ; 1e73: bcf     STATUS, RP0
    dw 0x1703 ; 1e74: bsf     STATUS, RP1
    dw 0x0827 ; 1e75: movf    0x27, W
    dw 0x390f ; 1e76: andlw   0x0f
    dw 0x1303 ; 1e77: bcf     STATUS, RP1
    dw 0x0008 ; 1e78: return
    dw 0x1283 ; 1e79: bcf     STATUS, RP0
    dw 0x1703 ; 1e7a: bsf     STATUS, RP1
    dw 0x082c ; 1e7b: movf    0x2c, W
    dw 0x3907 ; 1e7c: andlw   0x07
    dw 0x1303 ; 1e7d: bcf     STATUS, RP1
    dw 0x0008 ; 1e7e: return
    dw 0x1283 ; 1e7f: bcf     STATUS, RP0
    dw 0x1703 ; 1e80: bsf     STATUS, RP1
    dw 0x082b ; 1e81: movf    0x2b, W
    dw 0x39ff ; 1e82: andlw   0xff
    dw 0x1303 ; 1e83: bcf     STATUS, RP1
    dw 0x0008 ; 1e84: return
    dw 0x1283 ; 1e85: bcf     STATUS, RP0
    dw 0x1703 ; 1e86: bsf     STATUS, RP1
    dw 0x0e27 ; 1e87: swapf   0x27, W
    dw 0x3903 ; 1e88: andlw   0x03
    dw 0x1303 ; 1e89: bcf     STATUS, RP1
    dw 0x0008 ; 1e8a: return
    dw 0x1283 ; 1e8b: bcf     STATUS, RP0
    dw 0x1703 ; 1e8c: bsf     STATUS, RP1
    dw 0x0e30 ; 1e8d: swapf   0x30, W
    dw 0x390f ; 1e8e: andlw   0x0f
    dw 0x1303 ; 1e8f: bcf     STATUS, RP1
    dw 0x0008 ; 1e90: return
    dw 0x1283 ; 1e91: bcf     STATUS, RP0
    dw 0x1703 ; 1e92: bsf     STATUS, RP1
    dw 0x0e29 ; 1e93: swapf   0x29, W
    dw 0x390f ; 1e94: andlw   0x0f
    dw 0x1303 ; 1e95: bcf     STATUS, RP1
    dw 0x0008 ; 1e96: return
    dw 0x1283 ; 1e97: bcf     STATUS, RP0
    dw 0x1703 ; 1e98: bsf     STATUS, RP1
    dw 0x0d3a ; 1e99: rlf     0x3a, W
    dw 0x0d3a ; 1e9a: rlf     0x3a, W
    dw 0x3901 ; 1e9b: andlw   0x01
    dw 0x1303 ; 1e9c: bcf     STATUS, RP1
    dw 0x0008 ; 1e9d: return
    dw 0x1283 ; 1e9e: bcf     STATUS, RP0
    dw 0x1703 ; 1e9f: bsf     STATUS, RP1
    dw 0x0d2c ; 1ea0: rlf     0x2c, W
    dw 0x0d2c ; 1ea1: rlf     0x2c, W
    dw 0x3901 ; 1ea2: andlw   0x01
    dw 0x1303 ; 1ea3: bcf     STATUS, RP1
    dw 0x0008 ; 1ea4: return
    dw 0x1283 ; 1ea5: bcf     STATUS, RP0
    dw 0x1703 ; 1ea6: bsf     STATUS, RP1
    dw 0x0d3c ; 1ea7: rlf     0x3c, W
    dw 0x0d3c ; 1ea8: rlf     0x3c, W
    dw 0x3901 ; 1ea9: andlw   0x01
    dw 0x1303 ; 1eaa: bcf     STATUS, RP1
    dw 0x0008 ; 1eab: return
    dw 0x0183 ; 1eac: clrf    STATUS
    dw 0x0ba9 ; 1ead: decfsz  0x29, F
    dw 0x2eb2 ; 1eae: goto    label_127
    dw 0x082a ; 1eaf: movf    0x2a, W
    dw 0x1d03 ; 1eb0: btfss   STATUS, Z
    dw 0x178b ; 1eb1: bsf     INTCON, GIE
    dw 0x0183 ; 1eb2: clrf    STATUS
    dw 0x0008 ; 1eb3: return
    dw 0x1283 ; 1eb4: bcf     STATUS, RP0
    dw 0x1703 ; 1eb5: bsf     STATUS, RP1
    dw 0x0c3c ; 1eb6: rrf     0x3c, W
    dw 0x00f0 ; 1eb7: movwf   0x70
    dw 0x0cf0 ; 1eb8: rrf     0x70, F
    dw 0x0c70 ; 1eb9: rrf     0x70, W
    dw 0x3901 ; 1eba: andlw   0x01
    dw 0x1303 ; 1ebb: bcf     STATUS, RP1
    dw 0x0008 ; 1ebc: return
    dw 0x1283 ; 1ebd: bcf     STATUS, RP0
    dw 0x1703 ; 1ebe: bsf     STATUS, RP1
    dw 0x0e27 ; 1ebf: swapf   0x27, W
    dw 0x00f0 ; 1ec0: movwf   0x70
    dw 0x0cf0 ; 1ec1: rrf     0x70, F
    dw 0x0c70 ; 1ec2: rrf     0x70, W
    dw 0x3903 ; 1ec3: andlw   0x03
    dw 0x1303 ; 1ec4: bcf     STATUS, RP1
    dw 0x0008 ; 1ec5: return
    dw 0x302c ; 1ec6: movlw   0x2c
    dw 0x1683 ; 1ec7: bsf     STATUS, RP0
    dw 0x1303 ; 1ec8: bcf     STATUS, RP1
    dw 0x00d3 ; 1ec9: movwf   0x53
    dw 0x3032 ; 1eca: movlw   0x32
    dw 0x00dd ; 1ecb: movwf   0x5d
    dw 0x01de ; 1ecc: clrf    0x5e
    dw 0x1283 ; 1ecd: bcf     STATUS, RP0
    dw 0x0008 ; 1ece: return
    dw 0x1283 ; 1ecf: bcf     STATUS, RP0
    dw 0x1703 ; 1ed0: bsf     STATUS, RP1
    dw 0x0c2c ; 1ed1: rrf     0x2c, W
    dw 0x00f0 ; 1ed2: movwf   0x70
    dw 0x0cf0 ; 1ed3: rrf     0x70, F
    dw 0x0c70 ; 1ed4: rrf     0x70, W
    dw 0x3901 ; 1ed5: andlw   0x01
    dw 0x1303 ; 1ed6: bcf     STATUS, RP1
    dw 0x0008 ; 1ed7: return
    dw 0x0183 ; 1ed8: clrf    STATUS
    dw 0x0aa9 ; 1ed9: incf    0x29, F
    dw 0x0b29 ; 1eda: decfsz  0x29, W
    dw 0x2ee0 ; 1edb: goto    label_130
    dw 0x080b ; 1edc: movf    INTCON, W
    dw 0x3980 ; 1edd: andlw   0x80
    dw 0x00aa ; 1ede: movwf   0x2a
    dw 0x138b ; 1edf: bcf     INTCON, GIE
    dw 0x0183 ; 1ee0: clrf    STATUS
    dw 0x0008 ; 1ee1: return
    dw 0x00f0 ; 1ee2: movwf   Common_RAM
    dw 0x3000 ; 1ee3: movlw   0x00
    dw 0x1871 ; 1ee4: btfsc   (Common_RAM + 1), 0x0
    dw 0x0770 ; 1ee5: addwf   Common_RAM, W
    dw 0x1003 ; 1ee6: bcf     STATUS, C
    dw 0x0df0 ; 1ee7: rlf     Common_RAM, F
    dw 0x1003 ; 1ee8: bcf     STATUS, C
    dw 0x0cf1 ; 1ee9: rrf     (Common_RAM + 1), F
    dw 0x08f1 ; 1eea: movf    (Common_RAM + 1), F
    dw 0x1903 ; 1eeb: btfsc   STATUS, Z
    dw 0x0008 ; 1eec: return
    dw 0x2ee4 ; 1eed: goto    label_131
    dw 0x01f4 ; 1eee: clrf    (Common_RAM + 4)
    dw 0x01f5 ; 1eef: clrf    (Common_RAM + 5)
    dw 0x1003 ; 1ef0: bcf     STATUS, C
    dw 0x0cf3 ; 1ef1: rrf     (Common_RAM + 3), F
    dw 0x0cf2 ; 1ef2: rrf     (Common_RAM + 2), F
    dw 0x1c03 ; 1ef3: btfss   STATUS, C
    dw 0x2efc ; 1ef4: goto    label_133
    dw 0x0870 ; 1ef5: movf    Common_RAM, W
    dw 0x07f4 ; 1ef6: addwf   (Common_RAM + 4), F
    dw 0x0871 ; 1ef7: movf    (Common_RAM + 1), W
    dw 0x1803 ; 1ef8: btfsc   STATUS, C
    dw 0x0a71 ; 1ef9: incf    (Common_RAM + 1), W
    dw 0x07f5 ; 1efa: addwf   (Common_RAM + 5), F
    dw 0x1003 ; 1efb: bcf     STATUS, C
    dw 0x0df0 ; 1efc: rlf     Common_RAM, F
    dw 0x0df1 ; 1efd: rlf     (Common_RAM + 1), F
    dw 0x0872 ; 1efe: movf    (Common_RAM + 2), W
    dw 0x0473 ; 1eff: iorwf   (Common_RAM + 3), W
    dw 0x1903 ; 1f00: btfsc   STATUS, Z
    dw 0x3400 ; 1f01: retlw   0x00
    dw 0x2ef0 ; 1f02: goto    label_132
    dw 0x0183 ; 1f03: clrf    STATUS
    dw 0x00bc ; 1f04: movwf   0x3c
    dw 0x3005 ; 1f05: movlw   0x05
    dw 0x023c ; 1f06: subwf   0x3c, W
    dw 0x1803 ; 1f07: btfsc   STATUS, C
    dw 0x3401 ; 1f08: retlw   0x01
    dw 0x3003 ; 1f09: movlw   0x03
    dw 0x023c ; 1f0a: subwf   0x3c, W
    dw 0x1803 ; 1f0b: btfsc   STATUS, C
    dw 0x3402 ; 1f0c: retlw   0x02
    dw 0x160a ; 1f0d: bsf     PCLATH, 0x4
    dw 0x158a ; 1f0e: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1f0f: call    function_074
    dw 0x3003 ; 1f10: movlw   0x03
    dw 0x00f1 ; 1f11: movwf   (Common_RAM + 1)
    dw 0x083c ; 1f12: movf    0x3c, W
    dw 0x160a ; 1f13: bsf     PCLATH, 0x4
    dw 0x158a ; 1f14: bsf     PCLATH, 0x3
    dw 0x26e2 ; 1f15: call    function_075
    dw 0x3e02 ; 1f16: addlw   0x02
    dw 0x3eac ; 1f17: addlw   0xac
    dw 0x0084 ; 1f18: movwf   FSR
    dw 0x1383 ; 1f19: bcf     STATUS, IRP
    dw 0x083c ; 1f1a: movf    0x3c, W
    dw 0x0080 ; 1f1b: movwf   INDF
    dw 0x160a ; 1f1c: bsf     PCLATH, 0x4
    dw 0x158a ; 1f1d: bsf     PCLATH, 0x3
    dw 0x26ac ; 1f1e: call    function_069
    dw 0x160a ; 1f1f: bsf     PCLATH, 0x4
    dw 0x158a ; 1f20: bsf     PCLATH, 0x3
    dw 0x3400 ; 1f21: retlw   0x00
    dw 0x0183 ; 1f22: clrf    STATUS
    dw 0x00cb ; 1f23: movwf   0x4b
    dw 0x3005 ; 1f24: movlw   0x05
    dw 0x024a ; 1f25: subwf   0x4a, W
    dw 0x3001 ; 1f26: movlw   0x01
    dw 0x1803 ; 1f27: btfsc   STATUS, C
    dw 0x0008 ; 1f28: return
    dw 0x024b ; 1f29: subwf   0x4b, W
    dw 0x1803 ; 1f2a: btfsc   STATUS, C
    dw 0x3402 ; 1f2b: retlw   0x02
    dw 0x160a ; 1f2c: bsf     PCLATH, 0x4
    dw 0x158a ; 1f2d: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1f2e: call    function_074
    dw 0x3005 ; 1f2f: movlw   0x05
    dw 0x00f1 ; 1f30: movwf   (Common_RAM + 1)
    dw 0x084b ; 1f31: movf    0x4b, W
    dw 0x160a ; 1f32: bsf     PCLATH, 0x4
    dw 0x158a ; 1f33: bsf     PCLATH, 0x3
    dw 0x26e2 ; 1f34: call    function_075
    dw 0x3e02 ; 1f35: addlw   0x02
    dw 0x3ea7 ; 1f36: addlw   0xa7
    dw 0x0084 ; 1f37: movwf   FSR
    dw 0x1383 ; 1f38: bcf     STATUS, IRP
    dw 0x084a ; 1f39: movf    0x4a, W
    dw 0x0080 ; 1f3a: movwf   INDF
    dw 0x160a ; 1f3b: bsf     PCLATH, 0x4
    dw 0x158a ; 1f3c: bsf     PCLATH, 0x3
    dw 0x26ac ; 1f3d: call    function_069
    dw 0x160a ; 1f3e: bsf     PCLATH, 0x4
    dw 0x158a ; 1f3f: bsf     PCLATH, 0x3
    dw 0x3400 ; 1f40: retlw   0x00
    dw 0x0183 ; 1f41: clrf    STATUS
    dw 0x00ca ; 1f42: movwf   0x4a
    dw 0x3005 ; 1f43: movlw   0x05
    dw 0x024a ; 1f44: subwf   0x4a, W
    dw 0x1c03 ; 1f45: btfss   STATUS, C
    dw 0x2f4a ; 1f46: goto    label_404
    dw 0x01f0 ; 1f47: clrf    Common_RAM
    dw 0x01f1 ; 1f48: clrf    (Common_RAM + 1)
    dw 0x0008 ; 1f49: return
    dw 0x160a ; 1f4a: bsf     PCLATH, 0x4
    dw 0x158a ; 1f4b: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1f4c: call    function_074
    dw 0x084a ; 1f4d: movf    0x4a, W
    dw 0x074a ; 1f4e: addwf   0x4a, W
    dw 0x3eb5 ; 1f4f: addlw   0xb5
    dw 0x0084 ; 1f50: movwf   FSR
    dw 0x1383 ; 1f51: bcf     STATUS, IRP
    dw 0x0800 ; 1f52: movf    INDF, W
    dw 0x00cb ; 1f53: movwf   0x4b
    dw 0x0a84 ; 1f54: incf    FSR, F
    dw 0x0800 ; 1f55: movf    INDF, W
    dw 0x00cc ; 1f56: movwf   0x4c
    dw 0x160a ; 1f57: bsf     PCLATH, 0x4
    dw 0x158a ; 1f58: bsf     PCLATH, 0x3
    dw 0x26ac ; 1f59: call    function_069
    dw 0x160a ; 1f5a: bsf     PCLATH, 0x4
    dw 0x158a ; 1f5b: bsf     PCLATH, 0x3
    dw 0x084c ; 1f5c: movf    0x4c, W
    dw 0x00f1 ; 1f5d: movwf   (Common_RAM + 1)
    dw 0x084b ; 1f5e: movf    0x4b, W
    dw 0x00f0 ; 1f5f: movwf   Common_RAM
    dw 0x0008 ; 1f60: return
    dw 0x0183 ; 1f61: clrf    STATUS
    dw 0x083d ; 1f62: movf    0x3d, W
    dw 0x043c ; 1f63: iorwf   0x3c, W
    dw 0x1903 ; 1f64: btfsc   STATUS, Z
    dw 0x2f78 ; 1f65: goto    label_405
    dw 0x083c ; 1f66: movf    0x3c, W
    dw 0x00cd ; 1f67: movwf   0x4d
    dw 0x083d ; 1f68: movf    0x3d, W
    dw 0x00ce ; 1f69: movwf   0x4e
    dw 0x3005 ; 1f6a: movlw   0x05
    dw 0x00cf ; 1f6b: movwf   0x4f
    dw 0x3003 ; 1f6c: movlw   0x03
    dw 0x00d0 ; 1f6d: movwf   0x50
    dw 0x160a ; 1f6e: bsf     PCLATH, 0x4
    dw 0x158a ; 1f6f: bsf     PCLATH, 0x3
    dw 0x25fe ; 1f70: call    function_044
    dw 0x160a ; 1f71: bsf     PCLATH, 0x4
    dw 0x158a ; 1f72: bsf     PCLATH, 0x3
    dw 0x00f0 ; 1f73: movwf   Common_RAM
    dw 0x01f1 ; 1f74: clrf    (Common_RAM + 1)
    dw 0x0471 ; 1f75: iorwf   (Common_RAM + 1), W
    dw 0x1903 ; 1f76: btfsc   STATUS, Z
    dw 0x0008 ; 1f77: return
    dw 0x160a ; 1f78: bsf     PCLATH, 0x4
    dw 0x158a ; 1f79: bsf     PCLATH, 0x3
    dw 0x26d8 ; 1f7a: call    function_074
    dw 0x160a ; 1f7b: bsf     PCLATH, 0x4
    dw 0x158a ; 1f7c: bsf     PCLATH, 0x3
    dw 0x083c ; 1f7d: movf    0x3c, W
    dw 0x00e1 ; 1f7e: movwf   0x61
    dw 0x083d ; 1f7f: movf    0x3d, W
    dw 0x00e2 ; 1f80: movwf   0x62
    dw 0x160a ; 1f81: bsf     PCLATH, 0x4
    dw 0x158a ; 1f82: bsf     PCLATH, 0x3
    dw 0x2eac ; 1f83: goto    function_069
    dw 0x0183 ; 1f84: clrf    STATUS
    dw 0x00bc ; 1f85: movwf   0x3c
    dw 0x083c ; 1f86: movf    0x3c, W
    dw 0x00be ; 1f87: movwf   0x3e
    dw 0x083d ; 1f88: movf    0x3d, W
    dw 0x00bf ; 1f89: movwf   0x3f
    dw 0x083c ; 1f8a: movf    0x3c, W
    dw 0x00bd ; 1f8b: movwf   0x3d
    dw 0x2f9f ; 1f8c: goto    label_407
    dw 0x083f ; 1f8d: movf    0x3f, W
    dw 0x00e7 ; 1f8e: movwf   0x67
    dw 0x083e ; 1f8f: movf    0x3e, W
    dw 0x120a ; 1f90: bcf     PCLATH, 0x4
    dw 0x118a ; 1f91: bcf     PCLATH, 0x3
    dw 0x21e7 ; 1f92: call    function_003
    dw 0x160a ; 1f93: bsf     PCLATH, 0x4
    dw 0x158a ; 1f94: bsf     PCLATH, 0x3
    dw 0x00f0 ; 1f95: movwf   Common_RAM
    dw 0x083d ; 1f96: movf    0x3d, W
    dw 0x0084 ; 1f97: movwf   FSR
    dw 0x1383 ; 1f98: bcf     STATUS, IRP
    dw 0x0870 ; 1f99: movf    Common_RAM, W
    dw 0x0080 ; 1f9a: movwf   INDF
    dw 0x0abd ; 1f9b: incf    0x3d, F
    dw 0x0abe ; 1f9c: incf    0x3e, F
    dw 0x1903 ; 1f9d: btfsc   STATUS, Z
    dw 0x0abf ; 1f9e: incf    0x3f, F
    dw 0x083e ; 1f9f: movf    0x3e, W
    dw 0x1903 ; 1fa0: btfsc   STATUS, Z
    dw 0x03bf ; 1fa1: decf    0x3f, F
    dw 0x03be ; 1fa2: decf    0x3e, F
    dw 0x0a3e ; 1fa3: incf    0x3e, W
    dw 0x1903 ; 1fa4: btfsc   STATUS, Z
    dw 0x0a3f ; 1fa5: incf    0x3f, W
    dw 0x1d03 ; 1fa6: btfss   STATUS, Z
    dw 0x2f8d ; 1fa7: goto    label_406
    dw 0x083c ; 1fa8: movf    0x3c, W
    dw 0x0008 ; 1fa9: return
    dw 0x0183 ; 1faa: clrf    STATUS
    dw 0x00d6 ; 1fab: movwf   0x56
    dw 0x1c56 ; 1fac: btfss   0x56, 0x0
    dw 0x2fb0 ; 1fad: goto    label_408
    dw 0x11b8 ; 1fae: bcf     0x38, 0x3
    dw 0x2fb1 ; 1faf: goto    label_409
    dw 0x15b8 ; 1fb0: bsf     0x38, 0x3
    dw 0x1cd6 ; 1fb1: btfss   0x56, 0x1
    dw 0x2fb5 ; 1fb2: goto    label_410
    dw 0x1037 ; 1fb3: bcf     0x37, 0x0
    dw 0x2fb6 ; 1fb4: goto    label_411
    dw 0x1437 ; 1fb5: bsf     0x37, 0x0
    dw 0x1d56 ; 1fb6: btfss   0x56, 0x2
    dw 0x2fba ; 1fb7: goto    label_412
    dw 0x10b7 ; 1fb8: bcf     0x37, 0x1
    dw 0x2fbb ; 1fb9: goto    label_413
    dw 0x14b7 ; 1fba: bsf     0x37, 0x1
    dw 0x1dd6 ; 1fbb: btfss   0x56, 0x3
    dw 0x2fbf ; 1fbc: goto    label_414
    dw 0x1137 ; 1fbd: bcf     0x37, 0x2
    dw 0x2fc0 ; 1fbe: goto    label_415
    dw 0x1537 ; 1fbf: bsf     0x37, 0x2
    dw 0x1e56 ; 1fc0: btfss   0x56, 0x4
    dw 0x2fc4 ; 1fc1: goto    label_416
    dw 0x11b7 ; 1fc2: bcf     0x37, 0x3
    dw 0x2fc5 ; 1fc3: goto    label_417
    dw 0x15b7 ; 1fc4: bsf     0x37, 0x3
    dw 0x1ed6 ; 1fc5: btfss   0x56, 0x5
    dw 0x2fc9 ; 1fc6: goto    label_418
    dw 0x1038 ; 1fc7: bcf     0x38, 0x0
    dw 0x2fca ; 1fc8: goto    label_419
    dw 0x1438 ; 1fc9: bsf     0x38, 0x0
    dw 0x1f56 ; 1fca: btfss   0x56, 0x6
    dw 0x2fce ; 1fcb: goto    label_420
    dw 0x10b8 ; 1fcc: bcf     0x38, 0x1
    dw 0x2fcf ; 1fcd: goto    label_421
    dw 0x14b8 ; 1fce: bsf     0x38, 0x1
    dw 0x1fd6 ; 1fcf: btfss   0x56, 0x7
    dw 0x2fd3 ; 1fd0: goto    label_422
    dw 0x1138 ; 1fd1: bcf     0x38, 0x2
    dw 0x0008 ; 1fd2: return
    dw 0x1538 ; 1fd3: bsf     0x38, 0x2
    dw 0x0008 ; 1fd4: return
    dw 0x0183 ; 1fd5: clrf    STATUS
    dw 0x00d6 ; 1fd6: movwf   0x56
    dw 0x1c56 ; 1fd7: btfss   0x56, 0x0
    dw 0x2fdb ; 1fd8: goto    label_423
    dw 0x1238 ; 1fd9: bcf     0x38, 0x4
    dw 0x2fdc ; 1fda: goto    label_424
    dw 0x1638 ; 1fdb: bsf     0x38, 0x4
    dw 0x1cd6 ; 1fdc: btfss   0x56, 0x1
    dw 0x2fe0 ; 1fdd: goto    label_425
    dw 0x11b6 ; 1fde: bcf     0x36, 0x3
    dw 0x2fe1 ; 1fdf: goto    label_426
    dw 0x15b6 ; 1fe0: bsf     0x36, 0x3
    dw 0x1d56 ; 1fe1: btfss   0x56, 0x2
    dw 0x2fe5 ; 1fe2: goto    label_427
    dw 0x1136 ; 1fe3: bcf     0x36, 0x2
    dw 0x2fe6 ; 1fe4: goto    label_428
    dw 0x1536 ; 1fe5: bsf     0x36, 0x2
    dw 0x1dd6 ; 1fe6: btfss   0x56, 0x3
    dw 0x2fea ; 1fe7: goto    label_429
    dw 0x10b6 ; 1fe8: bcf     0x36, 0x1
    dw 0x2feb ; 1fe9: goto    label_430
    dw 0x14b6 ; 1fea: bsf     0x36, 0x1
    dw 0x1e56 ; 1feb: btfss   0x56, 0x4
    dw 0x2fef ; 1fec: goto    label_431
    dw 0x1036 ; 1fed: bcf     0x36, 0x0
    dw 0x2ff0 ; 1fee: goto    label_432
    dw 0x1436 ; 1fef: bsf     0x36, 0x0
    dw 0x1ed6 ; 1ff0: btfss   0x56, 0x5
    dw 0x2ff4 ; 1ff1: goto    label_433
    dw 0x13b8 ; 1ff2: bcf     0x38, 0x7
    dw 0x2ff5 ; 1ff3: goto    label_434
    dw 0x17b8 ; 1ff4: bsf     0x38, 0x7
    dw 0x1f56 ; 1ff5: btfss   0x56, 0x6
    dw 0x2ff9 ; 1ff6: goto    label_435
    dw 0x1338 ; 1ff7: bcf     0x38, 0x6
    dw 0x2ffa ; 1ff8: goto    label_436
    dw 0x1738 ; 1ff9: bsf     0x38, 0x6
    dw 0x1fd6 ; 1ffa: btfss   0x56, 0x7
    dw 0x2ffe ; 1ffb: goto    label_437
    dw 0x12b8 ; 1ffc: bcf     0x38, 0x5
    dw 0x0008 ; 1ffd: return
    dw 0x16b8 ; 1ffe: bsf     0x38, 0x5
    dw 0x0008 ; 1fff: return
    org 0x2000
    dw 0x007f, 0x007f, 0x007f, 0x007f
    __config 0x37ea
    org 0x2100
    de 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10, 0x03, 0x06, 0x5d, 0x70, 0x00, 0x00, 0x64, 0xc8
    de 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01
    de 0x27, 0x91, 0x17, 0x96, 0x01, 0x93, 0x69, 0x32, 0x06, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01, 0xff
    de 0x06, 0x10, 0x11, 0xff, 0xff, 0xff, 0x41, 0x20, 0x31, 0x37, 0x32, 0x20, 0x35, 0x34, 0x32, 0x20
    de 0x30, 0x30, 0x20, 0x32, 0x33, 0x20, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10, 0x03, 0x06, 0x5d, 0x70
    de 0x00, 0x00, 0x64, 0xc8, 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10
    de 0x03, 0x06, 0x5d, 0x70, 0x00, 0x00, 0x64, 0xc8, 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    end
