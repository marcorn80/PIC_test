# Risultati e confini dell'analisi

## Identificazione e materiale

Firmware fornito: `PIC16F917_benz2.hex`.
SHA-256 dell'allegato originale:
`df4fc64997e730b548eb8838211c88c877440bd9c2d7fc9ec5b3ce7f42f17530`.

Il nome indica PIC16F917, coerente con la mappa memoria e con lo schema fornito.
Non sono presenti simboli di debug che permettano di recuperare nomi e commenti
originali. I nomi C sono stati assegnati durante la ricostruzione.

Contenuti osservati, con indirizzi in **parole PIC**, non byte Intel HEX:

| Area | Intervallo | Risultato |
|---|---|---|
| Programma | 0x0000..0x1fff | 8192 parole, 6758 diverse da 0x3fff; contiene anche tabelle |
| USER ID | 0x2000..0x2003 | quattro parole 0x007f |
| Configurazione | 0x2007 | 0x37ea |
| EEPROM | 0x2100..0x21ff | 256 byte, con byte alti a zero nel file HEX |

I checksum di tutti i record passano. Configuration bits: HS, watchdog ON,
power-up timer ON, MCLR ON, code/data protection OFF, brown-out ON,
IESO ON, fail-safe clock monitor OFF, debug OFF.

## Schema e interfaccia

Il PDF è una scansione, senza testo estraibile. L'identificazione del MCP2021A
e dei collegamenti deriva dalla lettura visiva, non da una netlist elettrica.
Il quarzo è indicato circa 4,91 MHz, confermato dall'utente; non è confermata
la frequenza precisa fino alle ultime cifre. RC7 riceve la seriale tramite il
transceiver LIN; RC6 è la trasmissione, RB4 partecipa all'abilitazione. RC5 è
collegato al transistor del cicalino; RE1 al circuito di misura. La funzione
esatta delle misure analogiche richiede ancora il completamento dell'analisi.

Il firmware inizializza SPBRG=63, BRGH=1, SYNC=0, RX9=1 e TX9=1
(`0x14d4..0x14df`). Formula: baud=Fosc/(16*64). Risultano circa **4800 baud**;
con 4,9152 MHz sono esattamente 4800, con 4,910 MHz circa 4794,9.

La routine `0x0421..0x0437` calcola l'XOR degli otto bit del byte; il parser
confronta il risultato con il nono bit (`0x0449..0x0455`). Questo corrisponde
a **8 bit dati con parità pari**, implementati dal PIC in modalità a 9 bit.
Il ricevitore asincrono controlla il bit di stop; il numero di stop bit impiegato
dal trasmettitore esterno non può essere misurato dal solo file. Per prove su
PC, 4800 8E1 è un'impostazione candidata coerente con la ricezione osservata.

Il percorso analizzato non usa il framing LIN standard break/0x55/PID:
si tratta di un formato proprietario su interfaccia fisica LIN. Non si può
identificare la centralina trasmittente o attribuire un nome ufficiale Mercedes
al protocollo sulla sola base di questi dati.

## Pacchetti ricostruiti

Il parser `0x0438..0x04ca` e il trasmettitore `0x04cb..0x0520` supportano:

```
HEADER DATA[1..4] CHECKSUM
```

- Numero di byte dati: `(HEADER >> 6) + 1`.
- Gruppo: `(HEADER >> 4) & 3`.
- Tipo: `HEADER & 0x0f`.
- CHECKSUM: somma di HEADER e dati, modulo 256; non complemento né CRC.
- Tutti i byte, incluso il checksum, hanno il nono bit di parità pari.
- Il codice di ricezione azzera un frame parziale dopo un intervallo di almeno
  sei tick software osservato alla ricezione successiva (`0x009e..0x00b1`).
  Il tick Timer0 usa prescaler 1:64 e precarica 237: nominalmente circa 0,99 ms,
  più latenza di interrupt e ricarica. Non è stato misurato il timeout reale.

Nell'EEPROM, l'indice 5 vale 2 e seleziona la **modalità 2**. Le impostazioni
sono memorizzate con copie agli offset 0, 100 e 200; `0x0698..0x06da` sceglie
una coppia coincidente. Se tutte differiscono usa valori di fallback; per
l'indice 5 entra invece in un ciclo con interrupt disabilitati e watchdog
azzerato (`0x1e04..0x1e06`). Il C restituisce questo evento al chiamante,
anziché bloccare il programma host usato per le prove.

Dispatch osservato a `0x021e..0x02f6`:

| Gruppo | Dati richiesti | Destinazione |
|---|---|---|
| 0 | 4 byte | quattro byte di visualizzazione/richiesta sonora, RAM 0x12d..0x130 |
| 1 | 4 byte, tipo < 8 | RAM 0x139..0x13c |
| 2 | 1 byte, tipo < 8 | RAM 0x128 |
| 3 | tipo 1; 1, 2 o 4 byte | rispettivamente RAM 0x129, 0x12b..0x12c, 0x135..0x138 |

Tipi accettati: 1 e 13..15; inoltre 2/3 in modalità 2, 4/5 in modalità 4,
6/7 in modalità 6, con i vincoli della tabella. Il significato fisico degli
altri gruppi non è ancora ricostruito. Un dettaglio mantenuto nel C: i rami
di gruppo 3 leggono PR2 come valore del temporaneo 0x03d, non il byte header,
per effetto della selezione dei banchi (`0x02ba..0x02c9`).

## LED e suono: percorso di gruppo 0

Le routine `0x1fd5..0x1fff` e `0x1faa..0x1fd4` aggiornano copie dei registri
PORTB/C/D. Un bit di pattern a 1 porta l'uscita corrispondente a 0: **LED attivi
bassi**, coerente con lo schema. La polarità è provata dal codice e dalla
connessione dei LED al positivo, senza esecuzione sulla scheda.

| Bit del pattern | Banco A | Banco B |
|---|---|---|
| 0 | RD4 | RD3 |
| 1 | RB3 | RC0 |
| 2 | RB2 | RC1 |
| 3 | RB1 | RC2 |
| 4 | RB0 | RC3 |
| 5 | RD7 | RD0 |
| 6 | RD6 | RD1 |
| 7 | RD5 | RD2 |

La tabella `0x1822..0x1831` converte un nibble 0..15 in:
`00 00 01 03 07 0F 1F 3F 7F FF C0 00 00 00 00 00`.
Non è una tabella di distanze espresse in centimetri: l'unità fisica non è nota.

In modalità 2, gruppo 0 (`0x08ce..0x0a18`): il nibble alto del primo byte dati
seleziona il pattern del banco A, il basso quello del banco B. Il tipo 1
aggiorna entrambi; 2 il banco A; 3 il banco B. La luminosità è scalata e
applicata con un ciclo software di dieci fasi. L'indice sonoro è il massimo
fra i due nibble del terzo byte dati; il valore 15 modifica un flag speciale.
Le altre modalità e le eccezioni dei tipi 13..15 sono conservate nel C.

La tabella `0x1801..0x1820` contiene i conteggi sonori:
`0,976,650,488,390,325,278,243,216,194,96,64,48,38,32,1100`.
Non sono frequenze acustiche misurate. L'inviluppo del cicalino e i suoi
feedback devono ancora essere integrati: selezionare l'indice non equivale
ad avere già ricostruito l'intera generazione del suono.

Esempio **sintetico**, non catturato da un veicolo:

```
python3 scripts/protocol.py encode C1 34 00 55 00
C1 34 00 55 00 4A
```

Con la modalità 2, richiede pattern A=0x03, B=0x07 e indice sonoro 5. La
risposta fisica non è stata provata. Una UART ordinaria può inviare i byte
con parità hardware pari; per il bus LIN serve l'adattamento elettrico previsto
dalla scheda, non una connessione diretta del bus a un adattatore USB.

## Validazione e limiti

Riscontri durevoli: i due assembly, `build/recovered.hex`, `build/readable.hex`
e `build/validation.json`; sorgente e limiti del modello in `tests/pic14.py`.
Le prove coprono tutti i 256 header in otto modalità per il dispatch, tutte
le combinazioni di fase 0..9 e duty 0..10 in quattro stati di flag per il tick,
512 pattern LED, 256 casi di parità, 85 letture EEPROM, 1024 frame con e senza
errori e 1152 stati del percorso applicativo di gruppo 0. Le 32 voci di tabella
sono confrontate direttamente con le parole originali. Nessun test è su hardware.

La prova di uguaglianza HEX è completa. L'equivalenza C è invece limitata alle
routine e ai casi dichiarati, e dipende dalla correttezza del modello di
istruzioni; non è una verifica formale né una misura delle periferiche reali.

Differenze dichiarate: `pdc_rx_byte` elimina la coda e lo scheduler; il timeout
deve essere invocato dal chiamante. La lettura hardware proposta cattura RX9D
prima di RCREG, mentre l'ISR originale lo legge dopo (`0x00c0`, `0x00ce`):
il comportamento con FIFO piena non è dichiarato equivalente. Il parser
originale conserva l'ultimo FERR, non l'OR di tutti i FERR del frame. I tempi
degli interrupt, errori UART reali, ADC, watchdog e scritture EEPROM non sono
modellati nelle prove differenziali. XC8 e le risorse del port non sono verificati.

I file allegati sono trattati come dati da analizzare. Non sono state eseguite
istruzioni eventualmente presenti nei documenti, né avviato codice nativo del
firmware. Non sono stati trasmessi messaggi sul bus o contattati dispositivi.
