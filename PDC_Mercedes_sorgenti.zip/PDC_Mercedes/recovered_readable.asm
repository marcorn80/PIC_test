; Complete PIC16F917 disassembly; numeric register operands are bank-relative.
    processor 16f917
    radix hex
    org 0
    movlw   0x01                     ; 0000: 3001
    movwf   0x0a                     ; 0001: 008a
    goto    0x0110                   ; 0002: 2910
    dw 0x3fff ; erased               ; 0003: 3fff
    movwf   0x77                     ; 0004: 00f7
    movf    0x03, 0x0                ; 0005: 0803
    clrf    0x03                     ; 0006: 0183
    movwf   0x63                     ; 0007: 00e3
    movf    0x04, 0x0                ; 0008: 0804
    movwf   0x64                     ; 0009: 00e4
    movf    0x0a, 0x0                ; 000a: 080a
    movwf   0x65                     ; 000b: 00e5
    clrf    0x0a                     ; 000c: 018a
    movf    0x70, 0x0                ; 000d: 0870
    movwf   0x6a                     ; 000e: 00ea
    movf    0x71, 0x0                ; 000f: 0871
    movwf   0x78                     ; 0010: 00f8
    movf    0x72, 0x0                ; 0011: 0872
    movwf   0x6f                     ; 0012: 00ef
    movf    0x73, 0x0                ; 0013: 0873
    movwf   0x6c                     ; 0014: 00ec
    movf    0x74, 0x0                ; 0015: 0874
    movwf   0x6b                     ; 0016: 00eb
    movf    0x75, 0x0                ; 0017: 0875
    movwf   0x6e                     ; 0018: 00ee
    movf    0x76, 0x0                ; 0019: 0876
    movwf   0x6d                     ; 001a: 00ed
    movf    0x66, 0x0                ; 001b: 0866
    movwf   0x68                     ; 001c: 00e8
    movf    0x67, 0x0                ; 001d: 0867
    movwf   0x69                     ; 001e: 00e9
    btfsc   0x0b, 0x5                ; 001f: 1a8b
    btfss   0x0b, 0x2                ; 0020: 1d0b
    goto    0x0094                   ; 0021: 2894
    bcf     0x0b, 0x2                ; 0022: 110b
    movlw   0xed                     ; 0023: 30ed
    bcf     0x03, 0x5                ; 0024: 1283
    bcf     0x03, 0x6                ; 0025: 1303
    movwf   0x01                     ; 0026: 0081
    bsf     0x03, 0x5                ; 0027: 1683
    btfss   0x4e, 0x7                ; 0028: 1fce
    goto    0x0032                   ; 0029: 2832
    bsf     0x03, 0x6                ; 002a: 1703
    incf    0x10, 0x1                ; 002b: 0a90
    clrwdt                           ; 002c: 0064
    movlw   0x2d                     ; 002d: 302d
    subwf   0x10, 0x0                ; 002e: 0210
    bcf     0x03, 0x6                ; 002f: 1303
    btfsc   0x03, 0x0                ; 0030: 1803
    bcf     0x4e, 0x7                ; 0031: 13ce
    bcf     0x03, 0x6                ; 0032: 1303
    btfsc   0x4e, 0x7                ; 0033: 1bce
    goto    0x003a                   ; 0034: 283a
    bsf     0x0a, 0x4                ; 0035: 160a
    bsf     0x0a, 0x3                ; 0036: 158a
    call    0x060a                   ; 0037: 260a
    bcf     0x0a, 0x4                ; 0038: 120a
    bcf     0x0a, 0x3                ; 0039: 118a
    bsf     0x03, 0x5                ; 003a: 1683
    btfss   0x4e, 0x0                ; 003b: 1c4e
    goto    0x007f                   ; 003c: 287f
    movf    0x51, 0x1                ; 003d: 08d1
    btfss   0x03, 0x2                ; 003e: 1d03
    goto    0x0064                   ; 003f: 2864
    movf    0x40, 0x1                ; 0040: 08c0
    btfsc   0x03, 0x2                ; 0041: 1903
    movf    0x3f, 0x1                ; 0042: 08bf
    btfsc   0x03, 0x2                ; 0043: 1903
    goto    0x0064                   ; 0044: 2864
    movf    0x51, 0x0                ; 0045: 0851
    xorwf   0x40, 0x0                ; 0046: 0640
    btfss   0x03, 0x2                ; 0047: 1d03
    goto    0x004d                   ; 0048: 284d
    movf    0x51, 0x0                ; 0049: 0851
    xorwf   0x3f, 0x0                ; 004a: 063f
    btfsc   0x03, 0x2                ; 004b: 1903
    goto    0x0064                   ; 004c: 2864
    movf    0x40, 0x1                ; 004d: 08c0
    btfss   0x03, 0x2                ; 004e: 1d03
    goto    0x0056                   ; 004f: 2856
    movlw   0x0f                     ; 0050: 300f
    bcf     0x03, 0x5                ; 0051: 1283
    iorwf   0x36, 0x1                ; 0052: 04b6
    iorwf   0x37, 0x1                ; 0053: 04b7
    movlw   0x99                     ; 0054: 3099
    iorwf   0x38, 0x1                ; 0055: 04b8
    bsf     0x03, 0x5                ; 0056: 1683
    movf    0x3f, 0x1                ; 0057: 08bf
    btfss   0x03, 0x2                ; 0058: 1d03
    goto    0x005d                   ; 0059: 285d
    movlw   0x66                     ; 005a: 3066
    bcf     0x03, 0x5                ; 005b: 1283
    iorwf   0x38, 0x1                ; 005c: 04b8
    bcf     0x03, 0x5                ; 005d: 1283
    movf    0x36, 0x0                ; 005e: 0836
    movwf   0x06                     ; 005f: 0086
    movf    0x37, 0x0                ; 0060: 0837
    movwf   0x07                     ; 0061: 0087
    movf    0x38, 0x0                ; 0062: 0838
    movwf   0x08                     ; 0063: 0088
    bsf     0x03, 0x5                ; 0064: 1683
    movf    0x51, 0x0                ; 0065: 0851
    xorwf   0x40, 0x0                ; 0066: 0640
    btfss   0x03, 0x2                ; 0067: 1d03
    goto    0x006f                   ; 0068: 286f
    movlw   0x0f                     ; 0069: 300f
    bcf     0x03, 0x5                ; 006a: 1283
    iorwf   0x06, 0x1                ; 006b: 0486
    iorwf   0x07, 0x1                ; 006c: 0487
    movlw   0x99                     ; 006d: 3099
    iorwf   0x08, 0x1                ; 006e: 0488
    bsf     0x03, 0x5                ; 006f: 1683
    movf    0x51, 0x0                ; 0070: 0851
    xorwf   0x3f, 0x0                ; 0071: 063f
    btfss   0x03, 0x2                ; 0072: 1d03
    goto    0x0077                   ; 0073: 2877
    movlw   0x66                     ; 0074: 3066
    bcf     0x03, 0x5                ; 0075: 1283
    iorwf   0x08, 0x1                ; 0076: 0488
    bsf     0x03, 0x5                ; 0077: 1683
    incf    0x51, 0x1                ; 0078: 0ad1
    movf    0x51, 0x0                ; 0079: 0851
    xorlw   0x0a                     ; 007a: 3a0a
    btfss   0x03, 0x2                ; 007b: 1d03
    goto    0x008d                   ; 007c: 288d
    clrf    0x51                     ; 007d: 01d1
    goto    0x008d                   ; 007e: 288d
    btfsc   0x4e, 0x1                ; 007f: 18ce
    goto    0x008d                   ; 0080: 288d
    bcf     0x03, 0x5                ; 0081: 1283
    movf    0x06, 0x0                ; 0082: 0806
    movwf   0x36                     ; 0083: 00b6
    movf    0x07, 0x0                ; 0084: 0807
    movwf   0x37                     ; 0085: 00b7
    movf    0x08, 0x0                ; 0086: 0808
    movwf   0x38                     ; 0087: 00b8
    movlw   0x0f                     ; 0088: 300f
    iorwf   0x06, 0x1                ; 0089: 0486
    iorwf   0x07, 0x1                ; 008a: 0487
    movlw   0x99                     ; 008b: 3099
    iorwf   0x08, 0x1                ; 008c: 0488
    bcf     0x03, 0x5                ; 008d: 1283
    bsf     0x03, 0x6                ; 008e: 1703
    movf    0x44, 0x1                ; 008f: 08c4
    btfsc   0x03, 0x2                ; 0090: 1903
    goto    0x00f3                   ; 0091: 28f3
    incf    0x3d, 0x1                ; 0092: 0abd
    goto    0x00f3                   ; 0093: 28f3
    bsf     0x03, 0x5                ; 0094: 1683
    bcf     0x03, 0x6                ; 0095: 1303
    btfss   0x0c, 0x5                ; 0096: 1e8c
    goto    0x00e8                   ; 0097: 28e8
    bcf     0x03, 0x5                ; 0098: 1283
    btfss   0x0c, 0x5                ; 0099: 1e8c
    goto    0x00e8                   ; 009a: 28e8
    bsf     0x03, 0x5                ; 009b: 1683
    btfsc   0x4e, 0x6                ; 009c: 1b4e
    goto    0x00e0                   ; 009d: 28e0
    movlw   0x06                     ; 009e: 3006
    bcf     0x03, 0x5                ; 009f: 1283
    bsf     0x03, 0x6                ; 00a0: 1703
    subwf   0x3d, 0x0                ; 00a1: 023d
    btfss   0x03, 0x0                ; 00a2: 1c03
    goto    0x00b2                   ; 00a3: 28b2
    movf    0x44, 0x1                ; 00a4: 08c4
    btfsc   0x03, 0x2                ; 00a5: 1903
    goto    0x00b2                   ; 00a6: 28b2
    bsf     0x03, 0x5                ; 00a7: 1683
    clrf    0x1c                     ; 00a8: 019c
    clrf    0x1d                     ; 00a9: 019d
    bcf     0x03, 0x5                ; 00aa: 1283
    clrf    0x44                     ; 00ab: 01c4
    clrf    0x3e                     ; 00ac: 01be
    clrf    0x43                     ; 00ad: 01c3
    bcf     0x03, 0x6                ; 00ae: 1303
    clrf    0x3b                     ; 00af: 01bb
    clrf    0x39                     ; 00b0: 01b9
    goto    0x00dd                   ; 00b1: 28dd
    bcf     0x03, 0x6                ; 00b2: 1303
    incf    0x39, 0x1                ; 00b3: 0ab9
    movlw   0x00                     ; 00b4: 3000
    btfsc   0x18, 0x2                ; 00b5: 1918
    movlw   0x01                     ; 00b6: 3001
    movwf   0x70                     ; 00b7: 00f0
    swapf   0x70, 0x1                ; 00b8: 0ef0
    bsf     0x03, 0x5                ; 00b9: 1683
    movf    0x58, 0x0                ; 00ba: 0858
    xorwf   0x70, 0x0                ; 00bb: 0670
    andlw   0xef                     ; 00bc: 39ef
    xorwf   0x70, 0x0                ; 00bd: 0670
    movwf   0x58                     ; 00be: 00d8
    bcf     0x03, 0x5                ; 00bf: 1283
    movf    0x1a, 0x0                ; 00c0: 081a
    movwf   0x70                     ; 00c1: 00f0
    clrf    0x71                     ; 00c2: 01f1
    movf    0x3b, 0x0                ; 00c3: 083b
    addwf   0x3b, 0x0                ; 00c4: 073b
    addlw   0x9c                     ; 00c5: 3e9c
    movwf   0x04                     ; 00c6: 0084
    bsf     0x03, 0x7                ; 00c7: 1783
    movf    0x70, 0x0                ; 00c8: 0870
    movwf   0x00                     ; 00c9: 0080
    incf    0x04, 0x1                ; 00ca: 0a84
    movf    0x71, 0x0                ; 00cb: 0871
    movwf   0x00                     ; 00cc: 0080
    movlw   0x00                     ; 00cd: 3000
    btfsc   0x18, 0x0                ; 00ce: 1818
    movlw   0x01                     ; 00cf: 3001
    movwf   0x71                     ; 00d0: 00f1
    clrf    0x70                     ; 00d1: 01f0
    movf    0x3b, 0x0                ; 00d2: 083b
    addwf   0x3b, 0x0                ; 00d3: 073b
    addlw   0x9c                     ; 00d4: 3e9c
    movwf   0x04                     ; 00d5: 0084
    bsf     0x03, 0x7                ; 00d6: 1783
    movf    0x70, 0x0                ; 00d7: 0870
    iorwf   0x00, 0x1                ; 00d8: 0480
    incf    0x04, 0x1                ; 00d9: 0a84
    movf    0x71, 0x0                ; 00da: 0871
    iorwf   0x00, 0x1                ; 00db: 0480
    incf    0x3b, 0x1                ; 00dc: 0abb
    bsf     0x03, 0x6                ; 00dd: 1703
    clrf    0x3d                     ; 00de: 01bd
    goto    0x00f3                   ; 00df: 28f3
    bcf     0x03, 0x5                ; 00e0: 1283
    movf    0x1a, 0x0                ; 00e1: 081a
    bsf     0x03, 0x6                ; 00e2: 1703
    movwf   0x3f                     ; 00e3: 00bf
    bsf     0x03, 0x5                ; 00e4: 1683
    bcf     0x03, 0x6                ; 00e5: 1303
    bcf     0x4e, 0x6                ; 00e6: 134e
    goto    0x00f3                   ; 00e7: 28f3
    bsf     0x03, 0x5                ; 00e8: 1683
    btfss   0x18, 0x5                ; 00e9: 1e98
    goto    0x00f3                   ; 00ea: 28f3
    bcf     0x03, 0x5                ; 00eb: 1283
    btfss   0x0c, 0x4                ; 00ec: 1e0c
    goto    0x00f3                   ; 00ed: 28f3
    bcf     0x03, 0x5                ; 00ee: 1283
    clrf    0x3a                     ; 00ef: 01ba
    incf    0x3a, 0x1                ; 00f0: 0aba
    bsf     0x03, 0x5                ; 00f1: 1683
    bcf     0x0c, 0x4                ; 00f2: 120c
    bcf     0x03, 0x6                ; 00f3: 1303
    bcf     0x03, 0x5                ; 00f4: 1283
    movf    0x6a, 0x0                ; 00f5: 086a
    movwf   0x70                     ; 00f6: 00f0
    movf    0x78, 0x0                ; 00f7: 0878
    movwf   0x71                     ; 00f8: 00f1
    movf    0x6f, 0x0                ; 00f9: 086f
    movwf   0x72                     ; 00fa: 00f2
    movf    0x6c, 0x0                ; 00fb: 086c
    movwf   0x73                     ; 00fc: 00f3
    movf    0x6b, 0x0                ; 00fd: 086b
    movwf   0x74                     ; 00fe: 00f4
    movf    0x6e, 0x0                ; 00ff: 086e
    movwf   0x75                     ; 0100: 00f5
    movf    0x6d, 0x0                ; 0101: 086d
    movwf   0x76                     ; 0102: 00f6
    movf    0x68, 0x0                ; 0103: 0868
    movwf   0x66                     ; 0104: 00e6
    movf    0x69, 0x0                ; 0105: 0869
    movwf   0x67                     ; 0106: 00e7
    movf    0x64, 0x0                ; 0107: 0864
    movwf   0x04                     ; 0108: 0084
    movf    0x65, 0x0                ; 0109: 0865
    movwf   0x0a                     ; 010a: 008a
    movf    0x63, 0x0                ; 010b: 0863
    movwf   0x03                     ; 010c: 0083
    swapf   0x77, 0x1                ; 010d: 0ef7
    swapf   0x77, 0x0                ; 010e: 0e77
    retfie                           ; 010f: 0009
    movlw   0x20                     ; 0110: 3020
    movwf   0x04                     ; 0111: 0084
    movlw   0x5f                     ; 0112: 305f
    call    0x0137                   ; 0113: 2137
    movlw   0x07                     ; 0114: 3007
    movwf   0x67                     ; 0115: 00e7
    movlw   0xfc                     ; 0116: 30fc
    movwf   0x66                     ; 0117: 00e6
    movlw   0x5f                     ; 0118: 305f
    movwf   0x04                     ; 0119: 0084
    movlw   0x63                     ; 011a: 3063
    call    0x013c                   ; 011b: 213c
    movlw   0xa0                     ; 011c: 30a0
    movwf   0x04                     ; 011d: 0084
    movlw   0xdb                     ; 011e: 30db
    call    0x0137                   ; 011f: 2137
    movlw   0x07                     ; 0120: 3007
    movwf   0x67                     ; 0121: 00e7
    movlw   0xf8                     ; 0122: 30f8
    movwf   0x66                     ; 0123: 00e6
    movlw   0xdb                     ; 0124: 30db
    movwf   0x04                     ; 0125: 0084
    movlw   0xdf                     ; 0126: 30df
    call    0x013c                   ; 0127: 213c
    bsf     0x03, 0x7                ; 0128: 1783
    movlw   0x20                     ; 0129: 3020
    movwf   0x04                     ; 012a: 0084
    movlw   0x4b                     ; 012b: 304b
    call    0x0137                   ; 012c: 2137
    movlw   0x90                     ; 012d: 3090
    movwf   0x04                     ; 012e: 0084
    movlw   0xc5                     ; 012f: 30c5
    call    0x0137                   ; 0130: 2137
    bcf     0x0a, 0x4                ; 0131: 120a
    bcf     0x0a, 0x3                ; 0132: 118a
    goto    0x0149                   ; 0133: 2949
    xorwf   0x04, 0x0                ; 0134: 0604
    clrf    0x00                     ; 0135: 0180
    incf    0x04, 0x1                ; 0136: 0a84
    xorwf   0x04, 0x0                ; 0137: 0604
    btfss   0x03, 0x2                ; 0138: 1d03
    goto    0x0134                   ; 0139: 2934
    clrwdt                           ; 013a: 0064
    retlw   0x00                     ; 013b: 3400
    movwf   0x70                     ; 013c: 00f0
    bcf     0x0a, 0x4                ; 013d: 120a
    bcf     0x0a, 0x3                ; 013e: 118a
    call    0x01ea                   ; 013f: 21ea
    bcf     0x0a, 0x4                ; 0140: 120a
    bcf     0x0a, 0x3                ; 0141: 118a
    movwf   0x00                     ; 0142: 0080
    incf    0x04, 0x1                ; 0143: 0a84
    movf    0x04, 0x0                ; 0144: 0804
    xorwf   0x70, 0x0                ; 0145: 0670
    btfsc   0x03, 0x2                ; 0146: 1903
    retlw   0x00                     ; 0147: 3400
    goto    0x013d                   ; 0148: 293d
    bsf     0x0a, 0x4                ; 0149: 160a
    bcf     0x0a, 0x3                ; 014a: 118a
    call    0x0484                   ; 014b: 2484
    bsf     0x03, 0x5                ; 014c: 1683
    bcf     0x4e, 0x0                ; 014d: 104e
    bcf     0x03, 0x5                ; 014e: 1283
    bsf     0x03, 0x6                ; 014f: 1703
    clrf    0x21                     ; 0150: 01a1
    incf    0x21, 0x1                ; 0151: 0aa1
    bcf     0x0a, 0x4                ; 0152: 120a
    bcf     0x0a, 0x3                ; 0153: 118a
    call    0x03fc                   ; 0154: 23fc
    movlw   0x45                     ; 0155: 3045
    movwf   0x3c                     ; 0156: 00bc
    movlw   0x18                     ; 0157: 3018
    movwf   0x3d                     ; 0158: 00bd
    movlw   0x02                     ; 0159: 3002
    movwf   0x3e                     ; 015a: 00be
    bsf     0x0a, 0x4                ; 015b: 160a
    bcf     0x0a, 0x3                ; 015c: 118a
    call    0x00b3                   ; 015d: 20b3
    movlw   0x3c                     ; 015e: 303c
    movwf   0x3c                     ; 015f: 00bc
    movlw   0x18                     ; 0160: 3018
    movwf   0x3d                     ; 0161: 00bd
    clrf    0x3e                     ; 0162: 01be
    incf    0x3e, 0x1                ; 0163: 0abe
    bsf     0x0a, 0x4                ; 0164: 160a
    bcf     0x0a, 0x3                ; 0165: 118a
    call    0x0407                   ; 0166: 2407
    bcf     0x0a, 0x4                ; 0167: 120a
    bcf     0x0a, 0x3                ; 0168: 118a
    call    0x0741                   ; 0169: 2741
    bsf     0x03, 0x5                ; 016a: 1683
    bsf     0x03, 0x6                ; 016b: 1703
    movf    0x43, 0x0                ; 016c: 0843
    bcf     0x03, 0x5                ; 016d: 1283
    bcf     0x03, 0x6                ; 016e: 1303
    movwf   0x56                     ; 016f: 00d6
    bsf     0x03, 0x5                ; 0170: 1683
    bsf     0x03, 0x6                ; 0171: 1703
    movf    0x42, 0x0                ; 0172: 0842
    bsf     0x0a, 0x4                ; 0173: 160a
    bcf     0x0a, 0x3                ; 0174: 118a
    call    0x01e7                   ; 0175: 21e7
    bsf     0x03, 0x5                ; 0176: 1683
    bsf     0x03, 0x6                ; 0177: 1703
    movf    0x3b, 0x0                ; 0178: 083b
    bcf     0x03, 0x5                ; 0179: 1283
    movwf   0x20                     ; 017a: 00a0
    movlw   0x0a                     ; 017b: 300a
    bsf     0x03, 0x5                ; 017c: 1683
    bcf     0x03, 0x6                ; 017d: 1303
    movwf   0x59                     ; 017e: 00d9
    clrf    0x5a                     ; 017f: 01da
    bcf     0x03, 0x5                ; 0180: 1283
    bsf     0x03, 0x6                ; 0181: 1703
    movf    0x20, 0x0                ; 0182: 0820
    bcf     0x0a, 0x4                ; 0183: 120a
    bsf     0x0a, 0x3                ; 0184: 158a
    call    0x0046                   ; 0185: 2046
    bsf     0x03, 0x5                ; 0186: 1683
    clrf    0x51                     ; 0187: 01d1
    movlw   0x00                     ; 0188: 3000
    bsf     0x0a, 0x4                ; 0189: 160a
    bsf     0x0a, 0x3                ; 018a: 158a
    call    0x07d5                   ; 018b: 27d5
    movlw   0x00                     ; 018c: 3000
    bsf     0x0a, 0x4                ; 018d: 160a
    bsf     0x0a, 0x3                ; 018e: 158a
    call    0x07aa                   ; 018f: 27aa
    movlw   0x0f                     ; 0190: 300f
    iorwf   0x06, 0x1                ; 0191: 0486
    iorwf   0x07, 0x1                ; 0192: 0487
    movlw   0xff                     ; 0193: 30ff
    movwf   0x08                     ; 0194: 0088
    bsf     0x0a, 0x4                ; 0195: 160a
    bsf     0x0a, 0x3                ; 0196: 158a
    call    0x06c6                   ; 0197: 26c6
    bcf     0x0a, 0x4                ; 0198: 120a
    bcf     0x0a, 0x3                ; 0199: 118a
    clrf    0x3b                     ; 019a: 01bb
    bsf     0x03, 0x5                ; 019b: 1683
    bsf     0x0c, 0x5                ; 019c: 168c
    bcf     0x03, 0x5                ; 019d: 1283
    bsf     0x18, 0x4                ; 019e: 1618
    movlw   0x03                     ; 019f: 3003
    subwf   0x28, 0x0                ; 01a0: 0228
    btfsc   0x03, 0x0                ; 01a1: 1803
    goto    0x01ad                   ; 01a2: 29ad
    movf    0x39, 0x1                ; 01a3: 08b9
    btfsc   0x03, 0x2                ; 01a4: 1903
    goto    0x01ad                   ; 01a5: 29ad
    decf    0x39, 0x1                ; 01a6: 03b9
    movlw   0x01                     ; 01a7: 3001
    bsf     0x0a, 0x4                ; 01a8: 160a
    bcf     0x0a, 0x3                ; 01a9: 118a
    call    0x00f7                   ; 01aa: 20f7
    bcf     0x0a, 0x4                ; 01ab: 120a
    bcf     0x0a, 0x3                ; 01ac: 118a
    decfsz  0x3a, 0x0                ; 01ad: 0b3a
    goto    0x01b4                   ; 01ae: 29b4
    clrf    0x3a                     ; 01af: 01ba
    movlw   0x02                     ; 01b0: 3002
    bsf     0x0a, 0x4                ; 01b1: 160a
    bcf     0x0a, 0x3                ; 01b2: 118a
    call    0x00f7                   ; 01b3: 20f7
    clrwdt                           ; 01b4: 0064
    bsf     0x0a, 0x4                ; 01b5: 160a
    bcf     0x0a, 0x3                ; 01b6: 118a
    call    0x0795                   ; 01b7: 2795
    bsf     0x0a, 0x4                ; 01b8: 160a
    bcf     0x0a, 0x3                ; 01b9: 118a
    call    0x06e8                   ; 01ba: 26e8
    bcf     0x0a, 0x4                ; 01bb: 120a
    bcf     0x0a, 0x3                ; 01bc: 118a
    bsf     0x03, 0x6                ; 01bd: 1703
    movf    0x21, 0x1                ; 01be: 08a1
    btfss   0x03, 0x2                ; 01bf: 1d03
    goto    0x01d2                   ; 01c0: 29d2
    bcf     0x0a, 0x4                ; 01c1: 120a
    bcf     0x0a, 0x3                ; 01c2: 118a
    call    0x021e                   ; 01c3: 221e
    bcf     0x0a, 0x4                ; 01c4: 120a
    bcf     0x0a, 0x3                ; 01c5: 118a
    iorlw   0x00                     ; 01c6: 3800
    btfsc   0x03, 0x2                ; 01c7: 1903
    goto    0x01cf                   ; 01c8: 29cf
    bcf     0x0a, 0x4                ; 01c9: 120a
    bcf     0x0a, 0x3                ; 01ca: 118a
    call    0x0535                   ; 01cb: 2535
    bcf     0x0a, 0x4                ; 01cc: 120a
    bsf     0x0a, 0x3                ; 01cd: 158a
    call    0x00ce                   ; 01ce: 20ce
    bsf     0x03, 0x6                ; 01cf: 1703
    clrf    0x21                     ; 01d0: 01a1
    incf    0x21, 0x1                ; 01d1: 0aa1
    bsf     0x0a, 0x4                ; 01d2: 160a
    bcf     0x0a, 0x3                ; 01d3: 118a
    call    0x0393                   ; 01d4: 2393
    bcf     0x0a, 0x4                ; 01d5: 120a
    bcf     0x0a, 0x3                ; 01d6: 118a
    call    0x05e4                   ; 01d7: 25e4
    movlw   0x03                     ; 01d8: 3003
    bsf     0x0a, 0x4                ; 01d9: 160a
    bsf     0x0a, 0x3                ; 01da: 158a
    call    0x0741                   ; 01db: 2741
    movlw   0x01                     ; 01dc: 3001
    bsf     0x0a, 0x4                ; 01dd: 160a
    bsf     0x0a, 0x3                ; 01de: 158a
    call    0x0741                   ; 01df: 2741
    movlw   0x02                     ; 01e0: 3002
    bsf     0x0a, 0x4                ; 01e1: 160a
    bsf     0x0a, 0x3                ; 01e2: 158a
    call    0x0741                   ; 01e3: 2741
    bcf     0x0a, 0x4                ; 01e4: 120a
    bcf     0x0a, 0x3                ; 01e5: 118a
    goto    0x019f                   ; 01e6: 299f
    bcf     0x03, 0x5                ; 01e7: 1283
    bcf     0x03, 0x6                ; 01e8: 1303
    movwf   0x66                     ; 01e9: 00e6
    btfsc   0x67, 0x7                ; 01ea: 1be7
    goto    0x01f5                   ; 01eb: 29f5
    btfsc   0x67, 0x6                ; 01ec: 1b67
    goto    0x01fd                   ; 01ed: 29fd
    movf    0x67, 0x0                ; 01ee: 0867
    movwf   0x0a                     ; 01ef: 008a
    movf    0x66, 0x0                ; 01f0: 0866
    incf    0x66, 0x1                ; 01f1: 0ae6
    btfsc   0x03, 0x2                ; 01f2: 1903
    incf    0x67, 0x1                ; 01f3: 0ae7
    movwf   0x02                     ; 01f4: 0082
    bcf     0x03, 0x7                ; 01f5: 1383
    btfsc   0x67, 0x0                ; 01f6: 1867
    bsf     0x03, 0x7                ; 01f7: 1783
    movf    0x66, 0x0                ; 01f8: 0866
    incf    0x66, 0x1                ; 01f9: 0ae6
    movwf   0x04                     ; 01fa: 0084
    movf    0x00, 0x0                ; 01fb: 0800
    return                           ; 01fc: 0008
    movlw   0x64                     ; 01fd: 3064
    movwf   0x72                     ; 01fe: 00f2
    clrf    0x73                     ; 01ff: 01f3
    bcf     0x03, 0x5                ; 0200: 1283
    bcf     0x03, 0x6                ; 0201: 1303
    movf    0x21, 0x0                ; 0202: 0821
    movwf   0x71                     ; 0203: 00f1
    movf    0x20, 0x0                ; 0204: 0820
    movwf   0x70                     ; 0205: 00f0
    bsf     0x0a, 0x4                ; 0206: 160a
    bsf     0x0a, 0x3                ; 0207: 158a
    call    0x06ee                   ; 0208: 26ee
    movf    0x74, 0x0                ; 0209: 0874
    movwf   0x70                     ; 020a: 00f0
    movf    0x75, 0x0                ; 020b: 0875
    movwf   0x71                     ; 020c: 00f1
    movf    0x23, 0x0                ; 020d: 0823
    movwf   0x73                     ; 020e: 00f3
    movf    0x22, 0x0                ; 020f: 0822
    movwf   0x72                     ; 0210: 00f2
    movf    0x20, 0x0                ; 0211: 0820
    addwf   0x72, 0x1                ; 0212: 07f2
    btfsc   0x03, 0x0                ; 0213: 1803
    incf    0x73, 0x1                ; 0214: 0af3
    movf    0x21, 0x0                ; 0215: 0821
    addwf   0x73, 0x1                ; 0216: 07f3
    bcf     0x0a, 0x4                ; 0217: 120a
    bcf     0x0a, 0x3                ; 0218: 118a
    call    0x07be                   ; 0219: 27be
    bcf     0x0a, 0x4                ; 021a: 120a
    bcf     0x0a, 0x3                ; 021b: 118a
    movf    0x74, 0x0                ; 021c: 0874
    return                           ; 021d: 0008
    bsf     0x0a, 0x4                ; 021e: 160a
    bsf     0x0a, 0x3                ; 021f: 158a
    call    0x06bd                   ; 0220: 26bd
    movwf   0x3e                     ; 0221: 00be
    bsf     0x0a, 0x4                ; 0222: 160a
    bsf     0x0a, 0x3                ; 0223: 158a
    call    0x0685                   ; 0224: 2685
    movwf   0x3c                     ; 0225: 00bc
    bsf     0x0a, 0x4                ; 0226: 160a
    bsf     0x0a, 0x3                ; 0227: 158a
    call    0x0673                   ; 0228: 2673
    bcf     0x0a, 0x4                ; 0229: 120a
    bcf     0x0a, 0x3                ; 022a: 118a
    movwf   0x3f                     ; 022b: 00bf
    movf    0x3f, 0x1                ; 022c: 08bf
    btfsc   0x03, 0x2                ; 022d: 1903
    goto    0x02f4                   ; 022e: 2af4
    bsf     0x03, 0x6                ; 022f: 1703
    movf    0x22, 0x0                ; 0230: 0822
    xorlw   0x02                     ; 0231: 3a02
    btfsc   0x03, 0x2                ; 0232: 1903
    goto    0x0249                   ; 0233: 2a49
    movf    0x22, 0x0                ; 0234: 0822
    xorlw   0x04                     ; 0235: 3a04
    btfsc   0x03, 0x2                ; 0236: 1903
    goto    0x0249                   ; 0237: 2a49
    movf    0x22, 0x0                ; 0238: 0822
    xorlw   0x06                     ; 0239: 3a06
    btfss   0x03, 0x2                ; 023a: 1d03
    goto    0x02f4                   ; 023b: 2af4
    goto    0x0249                   ; 023c: 2a49
    bsf     0x03, 0x6                ; 023d: 1703
    movf    0x22, 0x0                ; 023e: 0822
    xorlw   0x02                     ; 023f: 3a02
    goto    0x0267                   ; 0240: 2a67
    bsf     0x03, 0x6                ; 0241: 1703
    movf    0x22, 0x0                ; 0242: 0822
    xorlw   0x04                     ; 0243: 3a04
    goto    0x0267                   ; 0244: 2a67
    bsf     0x03, 0x6                ; 0245: 1703
    movf    0x22, 0x0                ; 0246: 0822
    xorlw   0x06                     ; 0247: 3a06
    goto    0x0267                   ; 0248: 2a67
    bcf     0x03, 0x6                ; 0249: 1303
    movf    0x3f, 0x0                ; 024a: 083f
    xorlw   0x01                     ; 024b: 3a01
    btfsc   0x03, 0x2                ; 024c: 1903
    goto    0x02e7                   ; 024d: 2ae7
    xorlw   0x03                     ; 024e: 3a03
    btfsc   0x03, 0x2                ; 024f: 1903
    goto    0x023d                   ; 0250: 2a3d
    xorlw   0x01                     ; 0251: 3a01
    btfsc   0x03, 0x2                ; 0252: 1903
    goto    0x023d                   ; 0253: 2a3d
    xorlw   0x07                     ; 0254: 3a07
    btfsc   0x03, 0x2                ; 0255: 1903
    goto    0x0241                   ; 0256: 2a41
    xorlw   0x01                     ; 0257: 3a01
    btfsc   0x03, 0x2                ; 0258: 1903
    goto    0x0241                   ; 0259: 2a41
    xorlw   0x03                     ; 025a: 3a03
    btfsc   0x03, 0x2                ; 025b: 1903
    goto    0x0245                   ; 025c: 2a45
    xorlw   0x01                     ; 025d: 3a01
    btfsc   0x03, 0x2                ; 025e: 1903
    goto    0x0245                   ; 025f: 2a45
    xorlw   0x0a                     ; 0260: 3a0a
    btfsc   0x03, 0x2                ; 0261: 1903
    goto    0x02e7                   ; 0262: 2ae7
    xorlw   0x03                     ; 0263: 3a03
    btfsc   0x03, 0x2                ; 0264: 1903
    goto    0x02e7                   ; 0265: 2ae7
    xorlw   0x01                     ; 0266: 3a01
    btfsc   0x03, 0x2                ; 0267: 1903
    goto    0x02e7                   ; 0268: 2ae7
    goto    0x02f4                   ; 0269: 2af4
    movf    0x3e, 0x0                ; 026a: 083e
    xorlw   0x03                     ; 026b: 3a03
    btfss   0x03, 0x2                ; 026c: 1d03
    goto    0x02f4                   ; 026d: 2af4
    bsf     0x03, 0x5                ; 026e: 1683
    bsf     0x03, 0x6                ; 026f: 1703
    movf    0x13, 0x0                ; 0270: 0813
    bcf     0x03, 0x5                ; 0271: 1283
    movwf   0x2d                     ; 0272: 00ad
    bsf     0x03, 0x5                ; 0273: 1683
    movf    0x14, 0x0                ; 0274: 0814
    bcf     0x03, 0x5                ; 0275: 1283
    movwf   0x2e                     ; 0276: 00ae
    bsf     0x03, 0x5                ; 0277: 1683
    movf    0x15, 0x0                ; 0278: 0815
    bcf     0x03, 0x5                ; 0279: 1283
    movwf   0x2f                     ; 027a: 00af
    bsf     0x03, 0x5                ; 027b: 1683
    movf    0x16, 0x0                ; 027c: 0816
    bcf     0x03, 0x5                ; 027d: 1283
    movwf   0x30                     ; 027e: 00b0
    goto    0x02db                   ; 027f: 2adb
    movf    0x3e, 0x0                ; 0280: 083e
    xorlw   0x03                     ; 0281: 3a03
    btfss   0x03, 0x2                ; 0282: 1d03
    goto    0x02f4                   ; 0283: 2af4
    movlw   0x08                     ; 0284: 3008
    subwf   0x3f, 0x0                ; 0285: 023f
    btfsc   0x03, 0x0                ; 0286: 1803
    goto    0x02f4                   ; 0287: 2af4
    bsf     0x03, 0x5                ; 0288: 1683
    bsf     0x03, 0x6                ; 0289: 1703
    movf    0x12, 0x0                ; 028a: 0812
    bcf     0x03, 0x5                ; 028b: 1283
    bcf     0x03, 0x6                ; 028c: 1303
    movwf   0x3d                     ; 028d: 00bd
    bsf     0x03, 0x5                ; 028e: 1683
    bsf     0x03, 0x6                ; 028f: 1703
    movf    0x13, 0x0                ; 0290: 0813
    bcf     0x03, 0x5                ; 0291: 1283
    movwf   0x39                     ; 0292: 00b9
    bsf     0x03, 0x5                ; 0293: 1683
    movf    0x14, 0x0                ; 0294: 0814
    bcf     0x03, 0x5                ; 0295: 1283
    movwf   0x3a                     ; 0296: 00ba
    bsf     0x03, 0x5                ; 0297: 1683
    movf    0x15, 0x0                ; 0298: 0815
    bcf     0x03, 0x5                ; 0299: 1283
    movwf   0x3b                     ; 029a: 00bb
    bsf     0x03, 0x5                ; 029b: 1683
    movf    0x16, 0x0                ; 029c: 0816
    bcf     0x03, 0x5                ; 029d: 1283
    movwf   0x3c                     ; 029e: 00bc
    goto    0x02db                   ; 029f: 2adb
    movf    0x3e, 0x1                ; 02a0: 08be
    btfss   0x03, 0x2                ; 02a1: 1d03
    goto    0x02f4                   ; 02a2: 2af4
    movlw   0x08                     ; 02a3: 3008
    subwf   0x3f, 0x0                ; 02a4: 023f
    btfsc   0x03, 0x0                ; 02a5: 1803
    goto    0x02f4                   ; 02a6: 2af4
    bsf     0x03, 0x5                ; 02a7: 1683
    bsf     0x03, 0x6                ; 02a8: 1703
    movf    0x13, 0x0                ; 02a9: 0813
    bcf     0x03, 0x5                ; 02aa: 1283
    movwf   0x28                     ; 02ab: 00a8
    goto    0x02db                   ; 02ac: 2adb
    decfsz  0x3f, 0x0                ; 02ad: 0b3f
    goto    0x02f4                   ; 02ae: 2af4
    goto    0x02dd                   ; 02af: 2add
    bsf     0x03, 0x5                ; 02b0: 1683
    bsf     0x03, 0x6                ; 02b1: 1703
    movf    0x13, 0x0                ; 02b2: 0813
    bcf     0x03, 0x5                ; 02b3: 1283
    movwf   0x2b                     ; 02b4: 00ab
    bsf     0x03, 0x5                ; 02b5: 1683
    movf    0x14, 0x0                ; 02b6: 0814
    bcf     0x03, 0x5                ; 02b7: 1283
    movwf   0x2c                     ; 02b8: 00ac
    goto    0x02db                   ; 02b9: 2adb
    bsf     0x03, 0x5                ; 02ba: 1683
    movf    0x12, 0x0                ; 02bb: 0812
    bcf     0x03, 0x5                ; 02bc: 1283
    bcf     0x03, 0x6                ; 02bd: 1303
    movwf   0x3d                     ; 02be: 00bd
    bsf     0x03, 0x5                ; 02bf: 1683
    bsf     0x03, 0x6                ; 02c0: 1703
    movf    0x13, 0x0                ; 02c1: 0813
    bcf     0x03, 0x5                ; 02c2: 1283
    movwf   0x29                     ; 02c3: 00a9
    goto    0x02db                   ; 02c4: 2adb
    bsf     0x03, 0x5                ; 02c5: 1683
    movf    0x12, 0x0                ; 02c6: 0812
    bcf     0x03, 0x5                ; 02c7: 1283
    bcf     0x03, 0x6                ; 02c8: 1303
    movwf   0x3d                     ; 02c9: 00bd
    bsf     0x03, 0x5                ; 02ca: 1683
    bsf     0x03, 0x6                ; 02cb: 1703
    movf    0x13, 0x0                ; 02cc: 0813
    bcf     0x03, 0x5                ; 02cd: 1283
    movwf   0x35                     ; 02ce: 00b5
    bsf     0x03, 0x5                ; 02cf: 1683
    movf    0x14, 0x0                ; 02d0: 0814
    bcf     0x03, 0x5                ; 02d1: 1283
    movwf   0x36                     ; 02d2: 00b6
    bsf     0x03, 0x5                ; 02d3: 1683
    movf    0x15, 0x0                ; 02d4: 0815
    bcf     0x03, 0x5                ; 02d5: 1283
    movwf   0x37                     ; 02d6: 00b7
    bsf     0x03, 0x5                ; 02d7: 1683
    movf    0x16, 0x0                ; 02d8: 0816
    bcf     0x03, 0x5                ; 02d9: 1283
    movwf   0x38                     ; 02da: 00b8
    movlw   0x01                     ; 02db: 3001
    goto    0x02f5                   ; 02dc: 2af5
    movf    0x3e, 0x0                ; 02dd: 083e
    btfsc   0x03, 0x2                ; 02de: 1903
    goto    0x02ba                   ; 02df: 2aba
    xorlw   0x01                     ; 02e0: 3a01
    btfsc   0x03, 0x2                ; 02e1: 1903
    goto    0x02b0                   ; 02e2: 2ab0
    xorlw   0x02                     ; 02e3: 3a02
    btfsc   0x03, 0x2                ; 02e4: 1903
    goto    0x02c5                   ; 02e5: 2ac5
    goto    0x02f4                   ; 02e6: 2af4
    bcf     0x03, 0x6                ; 02e7: 1303
    movf    0x3c, 0x0                ; 02e8: 083c
    btfsc   0x03, 0x2                ; 02e9: 1903
    goto    0x026a                   ; 02ea: 2a6a
    xorlw   0x01                     ; 02eb: 3a01
    btfsc   0x03, 0x2                ; 02ec: 1903
    goto    0x0280                   ; 02ed: 2a80
    xorlw   0x03                     ; 02ee: 3a03
    btfsc   0x03, 0x2                ; 02ef: 1903
    goto    0x02a0                   ; 02f0: 2aa0
    xorlw   0x01                     ; 02f1: 3a01
    btfsc   0x03, 0x2                ; 02f2: 1903
    goto    0x02ad                   ; 02f3: 2aad
    movlw   0x00                     ; 02f4: 3000
    bcf     0x03, 0x6                ; 02f5: 1303
    return                           ; 02f6: 0008
    clrf    0x03                     ; 02f7: 0183
    btfss   0x12, 0x2                ; 02f8: 1d12
    goto    0x036f                   ; 02f9: 2b6f
    bsf     0x03, 0x5                ; 02fa: 1683
    movf    0x57, 0x0                ; 02fb: 0857
    iorwf   0x56, 0x0                ; 02fc: 0456
    btfsc   0x03, 0x2                ; 02fd: 1903
    goto    0x0340                   ; 02fe: 2b40
    movf    0x56, 0x1                ; 02ff: 08d6
    btfsc   0x03, 0x2                ; 0300: 1903
    decf    0x57, 0x1                ; 0301: 03d7
    decf    0x56, 0x1                ; 0302: 03d6
    bcf     0x03, 0x5                ; 0303: 1283
    bsf     0x03, 0x6                ; 0304: 1703
    movf    0x46, 0x1                ; 0305: 08c6
    btfsc   0x03, 0x2                ; 0306: 1903
    goto    0x030a                   ; 0307: 2b0a
    decf    0x46, 0x1                ; 0308: 03c6
    goto    0x0379                   ; 0309: 2b79
    bsf     0x03, 0x5                ; 030a: 1683
    bcf     0x03, 0x6                ; 030b: 1303
    bsf     0x07, 0x5                ; 030c: 1687
    movlw   0xf0                     ; 030d: 30f0
    bcf     0x03, 0x5                ; 030e: 1283
    andwf   0x17, 0x1                ; 030f: 0597
    bsf     0x03, 0x5                ; 0310: 1683
    bsf     0x03, 0x6                ; 0311: 1703
    bcf     0x32, 0x3                ; 0312: 11b2
    btfss   0x32, 0x5                ; 0313: 1eb2
    goto    0x0322                   ; 0314: 2b22
    bcf     0x32, 0x5                ; 0315: 12b2
    movf    0x43, 0x0                ; 0316: 0843
    bcf     0x03, 0x5                ; 0317: 1283
    bcf     0x03, 0x6                ; 0318: 1303
    movwf   0x56                     ; 0319: 00d6
    bsf     0x03, 0x5                ; 031a: 1683
    bsf     0x03, 0x6                ; 031b: 1703
    movf    0x42, 0x0                ; 031c: 0842
    bsf     0x0a, 0x4                ; 031d: 160a
    bcf     0x0a, 0x3                ; 031e: 118a
    call    0x01e7                   ; 031f: 21e7
    bcf     0x0a, 0x4                ; 0320: 120a
    bcf     0x0a, 0x3                ; 0321: 118a
    bsf     0x03, 0x5                ; 0322: 1683
    bsf     0x03, 0x6                ; 0323: 1703
    btfss   0x32, 0x4                ; 0324: 1e32
    goto    0x0379                   ; 0325: 2b79
    bcf     0x32, 0x4                ; 0326: 1232
    movlw   0x18                     ; 0327: 3018
    movwf   0x0a                     ; 0328: 008a
    bcf     0x03, 0x6                ; 0329: 1303
    movf    0x52, 0x0                ; 032a: 0852
    addwf   0x52, 0x0                ; 032b: 0752
    movwf   0x70                     ; 032c: 00f0
    call    0x0000                   ; 032d: 2000
    movwf   0x56                     ; 032e: 00d6
    incf    0x70, 0x0                ; 032f: 0a70
    call    0x0000                   ; 0330: 2000
    movwf   0x57                     ; 0331: 00d7
    bcf     0x0a, 0x4                ; 0332: 120a
    bcf     0x0a, 0x3                ; 0333: 118a
    movlw   0x03                     ; 0334: 3003
    subwf   0x57, 0x0                ; 0335: 0257
    movlw   0xe9                     ; 0336: 30e9
    btfsc   0x03, 0x2                ; 0337: 1903
    subwf   0x56, 0x0                ; 0338: 0256
    btfsc   0x03, 0x0                ; 0339: 1803
    goto    0x0377                   ; 033a: 2b77
    movlw   0xea                     ; 033b: 30ea
    addwf   0x56, 0x1                ; 033c: 07d6
    btfss   0x03, 0x0                ; 033d: 1c03
    decf    0x57, 0x1                ; 033e: 03d7
    goto    0x0379                   ; 033f: 2b79
    movlw   0x18                     ; 0340: 3018
    movwf   0x0a                     ; 0341: 008a
    movf    0x52, 0x0                ; 0342: 0852
    addwf   0x52, 0x0                ; 0343: 0752
    movwf   0x70                     ; 0344: 00f0
    call    0x0000                   ; 0345: 2000
    movwf   0x56                     ; 0346: 00d6
    incf    0x70, 0x0                ; 0347: 0a70
    call    0x0000                   ; 0348: 2000
    movwf   0x57                     ; 0349: 00d7
    bcf     0x0a, 0x4                ; 034a: 120a
    bcf     0x0a, 0x3                ; 034b: 118a
    movlw   0x16                     ; 034c: 3016
    bcf     0x03, 0x5                ; 034d: 1283
    bsf     0x03, 0x6                ; 034e: 1703
    movwf   0x46                     ; 034f: 00c6
    bsf     0x03, 0x5                ; 0350: 1683
    bcf     0x03, 0x6                ; 0351: 1303
    movf    0x57, 0x0                ; 0352: 0857
    iorwf   0x56, 0x0                ; 0353: 0456
    btfsc   0x03, 0x2                ; 0354: 1903
    goto    0x0366                   ; 0355: 2b66
    bcf     0x07, 0x5                ; 0356: 1287
    movlw   0x0c                     ; 0357: 300c
    bcf     0x03, 0x5                ; 0358: 1283
    iorwf   0x17, 0x1                ; 0359: 0497
    bsf     0x03, 0x5                ; 035a: 1683
    bsf     0x03, 0x6                ; 035b: 1703
    bsf     0x32, 0x3                ; 035c: 15b2
    movlw   0x03                     ; 035d: 3003
    bcf     0x03, 0x6                ; 035e: 1303
    subwf   0x57, 0x0                ; 035f: 0257
    movlw   0xe9                     ; 0360: 30e9
    btfsc   0x03, 0x2                ; 0361: 1903
    subwf   0x56, 0x0                ; 0362: 0256
    btfss   0x03, 0x0                ; 0363: 1c03
    goto    0x0379                   ; 0364: 2b79
    goto    0x0377                   ; 0365: 2b77
    bsf     0x07, 0x5                ; 0366: 1687
    movlw   0xf0                     ; 0367: 30f0
    bcf     0x03, 0x5                ; 0368: 1283
    andwf   0x17, 0x1                ; 0369: 0597
    bcf     0x12, 0x2                ; 036a: 1112
    bsf     0x03, 0x5                ; 036b: 1683
    bsf     0x03, 0x6                ; 036c: 1703
    clrf    0x32                     ; 036d: 01b2
    goto    0x0379                   ; 036e: 2b79
    bsf     0x03, 0x5                ; 036f: 1683
    btfsc   0x07, 0x5                ; 0370: 1a87
    goto    0x0379                   ; 0371: 2b79
    bsf     0x07, 0x5                ; 0372: 1687
    movlw   0xf0                     ; 0373: 30f0
    bcf     0x03, 0x5                ; 0374: 1283
    andwf   0x17, 0x1                ; 0375: 0597
    bsf     0x03, 0x5                ; 0376: 1683
    clrf    0x56                     ; 0377: 01d6
    clrf    0x57                     ; 0378: 01d7
    bsf     0x03, 0x5                ; 0379: 1683
    bsf     0x03, 0x6                ; 037a: 1703
    movf    0x44, 0x1                ; 037b: 08c4
    btfsc   0x03, 0x2                ; 037c: 1903
    goto    0x03f8                   ; 037d: 2bf8
    clrf    0x44                     ; 037e: 01c4
    bcf     0x03, 0x6                ; 037f: 1303
    movf    0x4f, 0x0                ; 0380: 084f
    xorlw   0x32                     ; 0381: 3a32
    btfss   0x03, 0x2                ; 0382: 1d03
    goto    0x03d0                   ; 0383: 2bd0
    movlw   0x32                     ; 0384: 3032
    movwf   0x72                     ; 0385: 00f2
    clrf    0x73                     ; 0386: 01f3
    movf    0x55, 0x0                ; 0387: 0855
    movwf   0x71                     ; 0388: 00f1
    movf    0x54, 0x0                ; 0389: 0854
    movwf   0x70                     ; 038a: 00f0
    bcf     0x0a, 0x4                ; 038b: 120a
    bcf     0x0a, 0x3                ; 038c: 118a
    call    0x07be                   ; 038d: 27be
    bcf     0x0a, 0x4                ; 038e: 120a
    bcf     0x0a, 0x3                ; 038f: 118a
    movf    0x74, 0x0                ; 0390: 0874
    bcf     0x03, 0x5                ; 0391: 1283
    bsf     0x03, 0x6                ; 0392: 1703
    movwf   0x47                     ; 0393: 00c7
    movf    0x75, 0x0                ; 0394: 0875
    movwf   0x48                     ; 0395: 00c8
    movf    0x4a, 0x0                ; 0396: 084a
    movwf   0x71                     ; 0397: 00f1
    movf    0x49, 0x0                ; 0398: 0849
    movwf   0x70                     ; 0399: 00f0
    movlw   0x05                     ; 039a: 3005
    addwf   0x70, 0x1                ; 039b: 07f0
    btfsc   0x03, 0x0                ; 039c: 1803
    incf    0x71, 0x1                ; 039d: 0af1
    movf    0x48, 0x0                ; 039e: 0848
    subwf   0x71, 0x0                ; 039f: 0271
    btfss   0x03, 0x2                ; 03a0: 1d03
    goto    0x03a4                   ; 03a1: 2ba4
    movf    0x47, 0x0                ; 03a2: 0847
    subwf   0x70, 0x0                ; 03a3: 0270
    btfsc   0x03, 0x0                ; 03a4: 1803
    goto    0x03ac                   ; 03a5: 2bac
    bsf     0x03, 0x5                ; 03a6: 1683
    bcf     0x03, 0x6                ; 03a7: 1303
    movf    0x4e, 0x0                ; 03a8: 084e
    andlw   0xf3                     ; 03a9: 39f3
    iorlw   0x04                     ; 03aa: 3804
    goto    0x03c3                   ; 03ab: 2bc3
    movf    0x4a, 0x0                ; 03ac: 084a
    movwf   0x71                     ; 03ad: 00f1
    movf    0x49, 0x0                ; 03ae: 0849
    movwf   0x70                     ; 03af: 00f0
    movlw   0xfb                     ; 03b0: 30fb
    addwf   0x70, 0x1                ; 03b1: 07f0
    btfsc   0x03, 0x0                ; 03b2: 1803
    incf    0x71, 0x1                ; 03b3: 0af1
    movlw   0xff                     ; 03b4: 30ff
    addwf   0x71, 0x1                ; 03b5: 07f1
    movf    0x71, 0x0                ; 03b6: 0871
    subwf   0x48, 0x0                ; 03b7: 0248
    btfss   0x03, 0x2                ; 03b8: 1d03
    goto    0x03bc                   ; 03b9: 2bbc
    movf    0x70, 0x0                ; 03ba: 0870
    subwf   0x47, 0x0                ; 03bb: 0247
    bsf     0x03, 0x5                ; 03bc: 1683
    bcf     0x03, 0x6                ; 03bd: 1303
    btfsc   0x03, 0x0                ; 03be: 1803
    goto    0x03cc                   ; 03bf: 2bcc
    movf    0x4e, 0x0                ; 03c0: 084e
    andlw   0xf3                     ; 03c1: 39f3
    iorlw   0x08                     ; 03c2: 3808
    movwf   0x4e                     ; 03c3: 00ce
    bcf     0x03, 0x5                ; 03c4: 1283
    bsf     0x03, 0x6                ; 03c5: 1703
    movf    0x47, 0x0                ; 03c6: 0847
    movwf   0x49                     ; 03c7: 00c9
    movf    0x48, 0x0                ; 03c8: 0848
    movwf   0x4a                     ; 03c9: 00ca
    bsf     0x03, 0x5                ; 03ca: 1683
    bcf     0x03, 0x6                ; 03cb: 1303
    clrf    0x4f                     ; 03cc: 01cf
    clrf    0x54                     ; 03cd: 01d4
    clrf    0x55                     ; 03ce: 01d5
    goto    0x03de                   ; 03cf: 2bde
    movlw   0x04                     ; 03d0: 3004
    bsf     0x0a, 0x4                ; 03d1: 160a
    bcf     0x0a, 0x3                ; 03d2: 118a
    call    0x0000                   ; 03d3: 2000
    bcf     0x0a, 0x4                ; 03d4: 120a
    bcf     0x0a, 0x3                ; 03d5: 118a
    movf    0x70, 0x0                ; 03d6: 0870
    bsf     0x03, 0x5                ; 03d7: 1683
    addwf   0x54, 0x1                ; 03d8: 07d4
    btfsc   0x03, 0x0                ; 03d9: 1803
    incf    0x55, 0x1                ; 03da: 0ad5
    movf    0x71, 0x0                ; 03db: 0871
    addwf   0x55, 0x1                ; 03dc: 07d5
    incf    0x4f, 0x1                ; 03dd: 0acf
    movlw   0xff                     ; 03de: 30ff
    addwf   0x5d, 0x1                ; 03df: 07dd
    btfss   0x03, 0x0                ; 03e0: 1c03
    decf    0x5e, 0x1                ; 03e1: 03de
    movf    0x5e, 0x0                ; 03e2: 085e
    iorwf   0x5d, 0x0                ; 03e3: 045d
    btfss   0x03, 0x2                ; 03e4: 1d03
    goto    0x03fa                   ; 03e5: 2bfa
    movlw   0x32                     ; 03e6: 3032
    movwf   0x5d                     ; 03e7: 00dd
    clrf    0x5e                     ; 03e8: 01de
    movf    0x53, 0x1                ; 03e9: 08d3
    btfsc   0x03, 0x2                ; 03ea: 1903
    goto    0x03fa                   ; 03eb: 2bfa
    decf    0x53, 0x1                ; 03ec: 03d3
    movf    0x53, 0x0                ; 03ed: 0853
    xorlw   0x27                     ; 03ee: 3a27
    btfss   0x03, 0x2                ; 03ef: 1d03
    goto    0x03f3                   ; 03f0: 2bf3
    bsf     0x58, 0x0                ; 03f1: 1458
    goto    0x03fa                   ; 03f2: 2bfa
    movf    0x53, 0x1                ; 03f3: 08d3
    btfss   0x03, 0x2                ; 03f4: 1d03
    goto    0x03fa                   ; 03f5: 2bfa
    bsf     0x58, 0x1                ; 03f6: 14d8
    goto    0x03fa                   ; 03f7: 2bfa
    clrf    0x44                     ; 03f8: 01c4
    incf    0x44, 0x1                ; 03f9: 0ac4
    clrf    0x03                     ; 03fa: 0183
    return                           ; 03fb: 0008
    movlw   0xfa                     ; 03fc: 30fa
    bsf     0x03, 0x5                ; 03fd: 1683
    bsf     0x03, 0x6                ; 03fe: 1703
    movwf   0x11                     ; 03ff: 0091
    goto    0x0402                   ; 0400: 2c02
    decf    0x11, 0x1                ; 0401: 0391
    movf    0x11, 0x1                ; 0402: 0891
    btfss   0x03, 0x2                ; 0403: 1d03
    goto    0x0401                   ; 0404: 2c01
    bcf     0x03, 0x5                ; 0405: 1283
    bcf     0x03, 0x6                ; 0406: 1303
    bsf     0x06, 0x4                ; 0407: 1606
    movlw   0xfa                     ; 0408: 30fa
    bsf     0x03, 0x5                ; 0409: 1683
    bsf     0x03, 0x6                ; 040a: 1703
    movwf   0x11                     ; 040b: 0091
    movf    0x11, 0x1                ; 040c: 0891
    btfsc   0x03, 0x2                ; 040d: 1903
    goto    0x0411                   ; 040e: 2c11
    decf    0x11, 0x1                ; 040f: 0391
    goto    0x040c                   ; 0410: 2c0c
    bcf     0x03, 0x5                ; 0411: 1283
    bcf     0x03, 0x6                ; 0412: 1303
    bcf     0x06, 0x4                ; 0413: 1206
    movlw   0xfa                     ; 0414: 30fa
    bsf     0x03, 0x5                ; 0415: 1683
    bsf     0x03, 0x6                ; 0416: 1703
    movwf   0x11                     ; 0417: 0091
    movf    0x11, 0x1                ; 0418: 0891
    btfsc   0x03, 0x2                ; 0419: 1903
    goto    0x041d                   ; 041a: 2c1d
    decf    0x11, 0x1                ; 041b: 0391
    goto    0x0418                   ; 041c: 2c18
    bcf     0x03, 0x5                ; 041d: 1283
    bcf     0x03, 0x6                ; 041e: 1303
    bsf     0x06, 0x4                ; 041f: 1606
    return                           ; 0420: 0008
    clrf    0x03                     ; 0421: 0183
    movwf   0x42                     ; 0422: 00c2
    clrf    0x43                     ; 0423: 01c3
    clrf    0x44                     ; 0424: 01c4
    incf    0x44, 0x1                ; 0425: 0ac4
    movf    0x42, 0x0                ; 0426: 0842
    movwf   0x04                     ; 0427: 0084
    movf    0x00, 0x0                ; 0428: 0800
    andwf   0x44, 0x0                ; 0429: 0544
    btfsc   0x03, 0x2                ; 042a: 1903
    goto    0x0431                   ; 042b: 2c31
    movf    0x43, 0x1                ; 042c: 08c3
    movlw   0x00                     ; 042d: 3000
    btfsc   0x03, 0x2                ; 042e: 1903
    movlw   0x01                     ; 042f: 3001
    movwf   0x43                     ; 0430: 00c3
    bcf     0x03, 0x0                ; 0431: 1003
    rlf     0x44, 0x1                ; 0432: 0dc4
    movf    0x44, 0x1                ; 0433: 08c4
    btfss   0x03, 0x2                ; 0434: 1d03
    goto    0x0426                   ; 0435: 2c26
    movf    0x43, 0x0                ; 0436: 0843
    return                           ; 0437: 0008
    bcf     0x0b, 0x7                ; 0438: 138b
    bcf     0x03, 0x5                ; 0439: 1283
    bcf     0x03, 0x6                ; 043a: 1303
    movf    0x3b, 0x1                ; 043b: 08bb
    btfsc   0x03, 0x2                ; 043c: 1903
    goto    0x04c7                   ; 043d: 2cc7
    bsf     0x03, 0x6                ; 043e: 1703
    movf    0x44, 0x0                ; 043f: 0844
    addlw   0x92                     ; 0440: 3e92
    movwf   0x04                     ; 0441: 0084
    bsf     0x03, 0x7                ; 0442: 1783
    bsf     0x03, 0x5                ; 0443: 1683
    movf    0x1c, 0x0                ; 0444: 081c
    movwf   0x00                     ; 0445: 0080
    movf    0x1c, 0x0                ; 0446: 081c
    bcf     0x03, 0x5                ; 0447: 1283
    bcf     0x03, 0x6                ; 0448: 1303
    movwf   0x40                     ; 0449: 00c0
    bsf     0x03, 0x5                ; 044a: 1683
    bsf     0x03, 0x6                ; 044b: 1703
    movf    0x1d, 0x0                ; 044c: 081d
    bcf     0x03, 0x5                ; 044d: 1283
    bcf     0x03, 0x6                ; 044e: 1303
    movwf   0x3f                     ; 044f: 00bf
    movlw   0x40                     ; 0450: 3040
    call    0x0421                   ; 0451: 2421
    xorwf   0x3f, 0x0                ; 0452: 063f
    bsf     0x03, 0x5                ; 0453: 1683
    btfss   0x03, 0x2                ; 0454: 1d03
    bsf     0x58, 0x5                ; 0455: 16d8
    bsf     0x03, 0x6                ; 0456: 1703
    movf    0x1e, 0x0                ; 0457: 081e
    movwf   0x1c                     ; 0458: 009c
    movf    0x1f, 0x0                ; 0459: 081f
    movwf   0x1d                     ; 045a: 009d
    movf    0x20, 0x0                ; 045b: 0820
    movwf   0x1e                     ; 045c: 009e
    movf    0x21, 0x0                ; 045d: 0821
    movwf   0x1f                     ; 045e: 009f
    movf    0x22, 0x0                ; 045f: 0822
    movwf   0x20                     ; 0460: 00a0
    movf    0x23, 0x0                ; 0461: 0823
    movwf   0x21                     ; 0462: 00a1
    movf    0x24, 0x0                ; 0463: 0824
    movwf   0x22                     ; 0464: 00a2
    movf    0x25, 0x0                ; 0465: 0825
    movwf   0x23                     ; 0466: 00a3
    movf    0x26, 0x0                ; 0467: 0826
    movwf   0x24                     ; 0468: 00a4
    movf    0x27, 0x0                ; 0469: 0827
    movwf   0x25                     ; 046a: 00a5
    movf    0x28, 0x0                ; 046b: 0828
    movwf   0x26                     ; 046c: 00a6
    movf    0x29, 0x0                ; 046d: 0829
    movwf   0x27                     ; 046e: 00a7
    movf    0x2a, 0x0                ; 046f: 082a
    movwf   0x28                     ; 0470: 00a8
    movf    0x2b, 0x0                ; 0471: 082b
    movwf   0x29                     ; 0472: 00a9
    movf    0x2c, 0x0                ; 0473: 082c
    movwf   0x2a                     ; 0474: 00aa
    movf    0x2d, 0x0                ; 0475: 082d
    movwf   0x2b                     ; 0476: 00ab
    movf    0x2e, 0x0                ; 0477: 082e
    movwf   0x2c                     ; 0478: 00ac
    movf    0x2f, 0x0                ; 0479: 082f
    movwf   0x2d                     ; 047a: 00ad
    clrf    0x2e                     ; 047b: 01ae
    clrf    0x2f                     ; 047c: 01af
    bcf     0x03, 0x5                ; 047d: 1283
    bcf     0x03, 0x6                ; 047e: 1303
    decf    0x3b, 0x1                ; 047f: 03bb
    bsf     0x03, 0x6                ; 0480: 1703
    movf    0x43, 0x1                ; 0481: 08c3
    btfss   0x03, 0x2                ; 0482: 1d03
    goto    0x0492                   ; 0483: 2c92
    movf    0x44, 0x0                ; 0484: 0844
    addlw   0x92                     ; 0485: 3e92
    movwf   0x04                     ; 0486: 0084
    bsf     0x03, 0x7                ; 0487: 1783
    movf    0x00, 0x0                ; 0488: 0800
    movwf   0x27                     ; 0489: 00a7
    swapf   0x27, 0x0                ; 048a: 0e27
    movwf   0x70                     ; 048b: 00f0
    rrf     0x70, 0x1                ; 048c: 0cf0
    rrf     0x70, 0x0                ; 048d: 0c70
    andlw   0x03                     ; 048e: 3903
    movwf   0x70                     ; 048f: 00f0
    incf    0x70, 0x0                ; 0490: 0a70
    movwf   0x43                     ; 0491: 00c3
    movf    0x44, 0x0                ; 0492: 0844
    subwf   0x43, 0x0                ; 0493: 0243
    movf    0x44, 0x0                ; 0494: 0844
    btfss   0x03, 0x0                ; 0495: 1c03
    goto    0x049e                   ; 0496: 2c9e
    addlw   0x92                     ; 0497: 3e92
    movwf   0x04                     ; 0498: 0084
    bsf     0x03, 0x7                ; 0499: 1783
    movf    0x00, 0x0                ; 049a: 0800
    addwf   0x3e, 0x1                ; 049b: 07be
    incf    0x44, 0x1                ; 049c: 0ac4
    goto    0x04c8                   ; 049d: 2cc8
    addlw   0x92                     ; 049e: 3e92
    movwf   0x04                     ; 049f: 0084
    bsf     0x03, 0x7                ; 04a0: 1783
    movf    0x00, 0x0                ; 04a1: 0800
    xorwf   0x3e, 0x0                ; 04a2: 063e
    btfsc   0x03, 0x2                ; 04a3: 1903
    goto    0x04a8                   ; 04a4: 2ca8
    bsf     0x03, 0x5                ; 04a5: 1683
    bcf     0x03, 0x6                ; 04a6: 1303
    bsf     0x58, 0x2                ; 04a7: 1558
    bcf     0x03, 0x5                ; 04a8: 1283
    bsf     0x03, 0x6                ; 04a9: 1703
    clrf    0x44                     ; 04aa: 01c4
    clrf    0x3e                     ; 04ab: 01be
    clrf    0x43                     ; 04ac: 01c3
    bcf     0x03, 0x6                ; 04ad: 1303
    clrf    0x3b                     ; 04ae: 01bb
    clrf    0x39                     ; 04af: 01b9
    bsf     0x03, 0x5                ; 04b0: 1683
    btfss   0x58, 0x2                ; 04b1: 1d58
    btfsc   0x58, 0x4                ; 04b2: 1a58
    goto    0x04be                   ; 04b3: 2cbe
    bcf     0x03, 0x5                ; 04b4: 1283
    btfsc   0x18, 0x1                ; 04b5: 1898
    goto    0x04be                   ; 04b6: 2cbe
    bsf     0x03, 0x5                ; 04b7: 1683
    btfsc   0x58, 0x5                ; 04b8: 1ad8
    goto    0x04be                   ; 04b9: 2cbe
    bcf     0x03, 0x5                ; 04ba: 1283
    bsf     0x03, 0x6                ; 04bb: 1703
    clrf    0x21                     ; 04bc: 01a1
    goto    0x04c8                   ; 04bd: 2cc8
    bsf     0x03, 0x5                ; 04be: 1683
    bcf     0x58, 0x2                ; 04bf: 1158
    bcf     0x58, 0x5                ; 04c0: 12d8
    bcf     0x03, 0x5                ; 04c1: 1283
    btfss   0x18, 0x1                ; 04c2: 1c98
    goto    0x04c8                   ; 04c3: 2cc8
    bcf     0x18, 0x4                ; 04c4: 1218
    bsf     0x18, 0x4                ; 04c5: 1618
    goto    0x04c8                   ; 04c6: 2cc8
    nop                              ; 04c7: 0000
    bsf     0x0b, 0x7                ; 04c8: 178b
    bcf     0x03, 0x6                ; 04c9: 1303
    return                           ; 04ca: 0008
    clrf    0x03                     ; 04cb: 0183
    clrf    0x3f                     ; 04cc: 01bf
    clrf    0x40                     ; 04cd: 01c0
    movlw   0xc4                     ; 04ce: 30c4
    bsf     0x03, 0x5                ; 04cf: 1683
    movwf   0x43                     ; 04d0: 00c3
    movf    0x44, 0x0                ; 04d1: 0844
    bcf     0x03, 0x5                ; 04d2: 1283
    bsf     0x03, 0x6                ; 04d3: 1703
    movwf   0x27                     ; 04d4: 00a7
    swapf   0x27, 0x0                ; 04d5: 0e27
    movwf   0x70                     ; 04d6: 00f0
    rrf     0x70, 0x1                ; 04d7: 0cf0
    rrf     0x70, 0x0                ; 04d8: 0c70
    andlw   0x03                     ; 04d9: 3903
    addlw   0x03                     ; 04da: 3e03
    bcf     0x03, 0x6                ; 04db: 1303
    movwf   0x3f                     ; 04dc: 00bf
    movwf   0x41                     ; 04dd: 00c1
    movf    0x41, 0x1                ; 04de: 08c1
    btfsc   0x03, 0x2                ; 04df: 1903
    goto    0x0515                   ; 04e0: 2d15
    btfss   0x0c, 0x4                ; 04e1: 1e0c
    goto    0x04e1                   ; 04e2: 2ce1
    bsf     0x03, 0x5                ; 04e3: 1683
    bsf     0x4e, 0x6                ; 04e4: 174e
    movlw   0xff                     ; 04e5: 30ff
    bsf     0x03, 0x6                ; 04e6: 1703
    movwf   0x11                     ; 04e7: 0091
    bcf     0x03, 0x6                ; 04e8: 1303
    movf    0x43, 0x0                ; 04e9: 0843
    call    0x0421                   ; 04ea: 2421
    movwf   0x70                     ; 04eb: 00f0
    rrf     0x70, 0x0                ; 04ec: 0c70
    bsf     0x03, 0x5                ; 04ed: 1683
    btfss   0x03, 0x0                ; 04ee: 1c03
    goto    0x04f2                   ; 04ef: 2cf2
    bsf     0x18, 0x0                ; 04f0: 1418
    goto    0x04f3                   ; 04f1: 2cf3
    bcf     0x18, 0x0                ; 04f2: 1018
    movf    0x43, 0x0                ; 04f3: 0843
    movwf   0x04                     ; 04f4: 0084
    bcf     0x03, 0x7                ; 04f5: 1383
    movf    0x00, 0x0                ; 04f6: 0800
    bcf     0x03, 0x5                ; 04f7: 1283
    movwf   0x19                     ; 04f8: 0099
    bsf     0x03, 0x5                ; 04f9: 1683
    btfsc   0x18, 0x1                ; 04fa: 1898
    goto    0x04ff                   ; 04fb: 2cff
    goto    0x04f9                   ; 04fc: 2cf9
    bsf     0x03, 0x6                ; 04fd: 1703
    decf    0x11, 0x1                ; 04fe: 0391
    bcf     0x03, 0x6                ; 04ff: 1303
    btfss   0x4e, 0x6                ; 0500: 1f4e
    goto    0x0506                   ; 0501: 2d06
    bsf     0x03, 0x6                ; 0502: 1703
    movf    0x11, 0x1                ; 0503: 0891
    btfss   0x03, 0x2                ; 0504: 1d03
    goto    0x04fd                   ; 0505: 2cfd
    bcf     0x03, 0x6                ; 0506: 1303
    movf    0x43, 0x0                ; 0507: 0843
    movwf   0x04                     ; 0508: 0084
    movf    0x00, 0x0                ; 0509: 0800
    bcf     0x03, 0x5                ; 050a: 1283
    bsf     0x03, 0x6                ; 050b: 1703
    xorwf   0x3f, 0x0                ; 050c: 063f
    bcf     0x03, 0x6                ; 050d: 1303
    btfss   0x03, 0x2                ; 050e: 1d03
    incf    0x40, 0x1                ; 050f: 0ac0
    bsf     0x03, 0x5                ; 0510: 1683
    incf    0x43, 0x1                ; 0511: 0ac3
    bcf     0x03, 0x5                ; 0512: 1283
    decfsz  0x41, 0x1                ; 0513: 0bc1
    goto    0x04e1                   ; 0514: 2ce1
    movf    0x40, 0x1                ; 0515: 08c0
    btfsc   0x03, 0x2                ; 0516: 1903
    goto    0x051d                   ; 0517: 2d1d
    call    0x03fc                   ; 0518: 23fc
    clrf    0x3a                     ; 0519: 01ba
    incf    0x3a, 0x1                ; 051a: 0aba
    bsf     0x03, 0x5                ; 051b: 1683
    bcf     0x0c, 0x4                ; 051c: 120c
    bcf     0x03, 0x5                ; 051d: 1283
    bcf     0x18, 0x4                ; 051e: 1218
    bsf     0x18, 0x4                ; 051f: 1618
    return                           ; 0520: 0008
    movlw   0x00                     ; 0521: 3000
    bsf     0x0a, 0x4                ; 0522: 160a
    bsf     0x0a, 0x3                ; 0523: 158a
    call    0x07d5                   ; 0524: 27d5
    movlw   0x00                     ; 0525: 3000
    bsf     0x0a, 0x4                ; 0526: 160a
    bsf     0x0a, 0x3                ; 0527: 158a
    call    0x07aa                   ; 0528: 27aa
    bcf     0x0a, 0x4                ; 0529: 120a
    bcf     0x0a, 0x3                ; 052a: 118a
    movf    0x36, 0x0                ; 052b: 0836
    movwf   0x06                     ; 052c: 0086
    movf    0x37, 0x0                ; 052d: 0837
    movwf   0x07                     ; 052e: 0087
    movf    0x38, 0x0                ; 052f: 0838
    movwf   0x08                     ; 0530: 0088
    bsf     0x03, 0x5                ; 0531: 1683
    bcf     0x4e, 0x0                ; 0532: 104e
    bcf     0x03, 0x5                ; 0533: 1283
    return                           ; 0534: 0008
    bsf     0x0a, 0x4                ; 0535: 160a
    bsf     0x0a, 0x3                ; 0536: 158a
    call    0x0673                   ; 0537: 2673
    bcf     0x0a, 0x4                ; 0538: 120a
    bcf     0x0a, 0x3                ; 0539: 118a
    movwf   0x3d                     ; 053a: 00bd
    clrf    0x3e                     ; 053b: 01be
    incf    0x3e, 0x1                ; 053c: 0abe
    goto    0x0564                   ; 053d: 2d64
    bsf     0x03, 0x6                ; 053e: 1703
    movf    0x22, 0x0                ; 053f: 0822
    xorlw   0x04                     ; 0540: 3a04
    btfsc   0x03, 0x2                ; 0541: 1903
    goto    0x0560                   ; 0542: 2d60
    movf    0x22, 0x0                ; 0543: 0822
    xorlw   0x06                     ; 0544: 3a06
    btfss   0x03, 0x2                ; 0545: 1d03
    goto    0x054d                   ; 0546: 2d4d
    goto    0x0560                   ; 0547: 2d60
    bsf     0x03, 0x6                ; 0548: 1703
    movf    0x22, 0x0                ; 0549: 0822
    xorlw   0x02                     ; 054a: 3a02
    movlw   0x00                     ; 054b: 3000
    btfss   0x03, 0x2                ; 054c: 1d03
    movlw   0x01                     ; 054d: 3001
    goto    0x0561                   ; 054e: 2d61
    bsf     0x03, 0x6                ; 054f: 1703
    movf    0x22, 0x0                ; 0550: 0822
    xorlw   0x04                     ; 0551: 3a04
    goto    0x0558                   ; 0552: 2d58
    clrf    0x3e                     ; 0553: 01be
    goto    0x0577                   ; 0554: 2d77
    bsf     0x03, 0x6                ; 0555: 1703
    movf    0x22, 0x0                ; 0556: 0822
    xorlw   0x06                     ; 0557: 3a06
    btfsc   0x03, 0x2                ; 0558: 1903
    goto    0x0560                   ; 0559: 2d60
    movf    0x22, 0x0                ; 055a: 0822
    xorlw   0x02                     ; 055b: 3a02
    btfsc   0x03, 0x2                ; 055c: 1903
    goto    0x0560                   ; 055d: 2d60
    movlw   0x01                     ; 055e: 3001
    goto    0x0561                   ; 055f: 2d61
    movlw   0x00                     ; 0560: 3000
    bcf     0x03, 0x6                ; 0561: 1303
    movwf   0x3e                     ; 0562: 00be
    goto    0x0577                   ; 0563: 2d77
    movf    0x3d, 0x0                ; 0564: 083d
    xorlw   0x02                     ; 0565: 3a02
    btfsc   0x03, 0x2                ; 0566: 1903
    goto    0x053e                   ; 0567: 2d3e
    xorlw   0x01                     ; 0568: 3a01
    btfsc   0x03, 0x2                ; 0569: 1903
    goto    0x0553                   ; 056a: 2d53
    xorlw   0x07                     ; 056b: 3a07
    btfsc   0x03, 0x2                ; 056c: 1903
    goto    0x0548                   ; 056d: 2d48
    xorlw   0x01                     ; 056e: 3a01
    btfsc   0x03, 0x2                ; 056f: 1903
    goto    0x054f                   ; 0570: 2d4f
    xorlw   0x03                     ; 0571: 3a03
    btfsc   0x03, 0x2                ; 0572: 1903
    goto    0x0548                   ; 0573: 2d48
    xorlw   0x01                     ; 0574: 3a01
    btfsc   0x03, 0x2                ; 0575: 1903
    goto    0x0555                   ; 0576: 2d55
    movf    0x3e, 0x1                ; 0577: 08be
    btfsc   0x03, 0x2                ; 0578: 1903
    goto    0x05ac                   ; 0579: 2dac
    bsf     0x03, 0x5                ; 057a: 1683
    btfss   0x58, 0x0                ; 057b: 1c58
    goto    0x05ac                   ; 057c: 2dac
    movlw   0x00                     ; 057d: 3000
    bsf     0x0a, 0x4                ; 057e: 160a
    bsf     0x0a, 0x3                ; 057f: 158a
    call    0x07d5                   ; 0580: 27d5
    movlw   0x00                     ; 0581: 3000
    bsf     0x0a, 0x4                ; 0582: 160a
    bsf     0x0a, 0x3                ; 0583: 158a
    call    0x07aa                   ; 0584: 27aa
    bcf     0x0a, 0x4                ; 0585: 120a
    bcf     0x0a, 0x3                ; 0586: 118a
    goto    0x05ac                   ; 0587: 2dac
    clrf    0x3e                     ; 0588: 01be
    goto    0x05c0                   ; 0589: 2dc0
    bsf     0x03, 0x6                ; 058a: 1703
    movf    0x22, 0x0                ; 058b: 0822
    xorlw   0x02                     ; 058c: 3a02
    movlw   0x00                     ; 058d: 3000
    btfss   0x03, 0x2                ; 058e: 1d03
    movlw   0x01                     ; 058f: 3001
    goto    0x05a9                   ; 0590: 2da9
    bsf     0x03, 0x6                ; 0591: 1703
    movf    0x22, 0x0                ; 0592: 0822
    xorlw   0x04                     ; 0593: 3a04
    goto    0x05a0                   ; 0594: 2da0
    bsf     0x03, 0x6                ; 0595: 1703
    movf    0x22, 0x0                ; 0596: 0822
    xorlw   0x04                     ; 0597: 3a04
    btfsc   0x03, 0x2                ; 0598: 1903
    goto    0x05a8                   ; 0599: 2da8
    movf    0x22, 0x0                ; 059a: 0822
    xorlw   0x02                     ; 059b: 3a02
    goto    0x05a4                   ; 059c: 2da4
    bsf     0x03, 0x6                ; 059d: 1703
    movf    0x22, 0x0                ; 059e: 0822
    xorlw   0x02                     ; 059f: 3a02
    btfsc   0x03, 0x2                ; 05a0: 1903
    goto    0x05a8                   ; 05a1: 2da8
    movf    0x22, 0x0                ; 05a2: 0822
    xorlw   0x06                     ; 05a3: 3a06
    btfsc   0x03, 0x2                ; 05a4: 1903
    goto    0x05a8                   ; 05a5: 2da8
    movlw   0x01                     ; 05a6: 3001
    goto    0x05a9                   ; 05a7: 2da9
    movlw   0x00                     ; 05a8: 3000
    bcf     0x03, 0x6                ; 05a9: 1303
    movwf   0x3e                     ; 05aa: 00be
    goto    0x05c0                   ; 05ab: 2dc0
    bcf     0x03, 0x5                ; 05ac: 1283
    movf    0x3d, 0x0                ; 05ad: 083d
    xorlw   0x02                     ; 05ae: 3a02
    btfsc   0x03, 0x2                ; 05af: 1903
    goto    0x0588                   ; 05b0: 2d88
    xorlw   0x01                     ; 05b1: 3a01
    btfsc   0x03, 0x2                ; 05b2: 1903
    goto    0x0591                   ; 05b3: 2d91
    xorlw   0x07                     ; 05b4: 3a07
    btfsc   0x03, 0x2                ; 05b5: 1903
    goto    0x0595                   ; 05b6: 2d95
    xorlw   0x01                     ; 05b7: 3a01
    btfsc   0x03, 0x2                ; 05b8: 1903
    goto    0x058a                   ; 05b9: 2d8a
    xorlw   0x03                     ; 05ba: 3a03
    btfsc   0x03, 0x2                ; 05bb: 1903
    goto    0x059d                   ; 05bc: 2d9d
    xorlw   0x01                     ; 05bd: 3a01
    btfsc   0x03, 0x2                ; 05be: 1903
    goto    0x0595                   ; 05bf: 2d95
    movf    0x3e, 0x1                ; 05c0: 08be
    btfsc   0x03, 0x2                ; 05c1: 1903
    goto    0x05ce                   ; 05c2: 2dce
    bsf     0x03, 0x5                ; 05c3: 1683
    btfss   0x58, 0x0                ; 05c4: 1c58
    goto    0x05ce                   ; 05c5: 2dce
    movlw   0x00                     ; 05c6: 3000
    bsf     0x0a, 0x4                ; 05c7: 160a
    bsf     0x0a, 0x3                ; 05c8: 158a
    call    0x07d5                   ; 05c9: 27d5
    movlw   0x00                     ; 05ca: 3000
    bsf     0x0a, 0x4                ; 05cb: 160a
    bsf     0x0a, 0x3                ; 05cc: 158a
    call    0x07aa                   ; 05cd: 27aa
    bsf     0x0a, 0x4                ; 05ce: 160a
    bsf     0x0a, 0x3                ; 05cf: 158a
    call    0x0685                   ; 05d0: 2685
    bcf     0x0a, 0x4                ; 05d1: 120a
    bcf     0x0a, 0x3                ; 05d2: 118a
    iorlw   0x00                     ; 05d3: 3800
    bsf     0x03, 0x5                ; 05d4: 1683
    btfss   0x03, 0x2                ; 05d5: 1d03
    goto    0x05de                   ; 05d6: 2dde
    btfss   0x58, 0x1                ; 05d7: 1cd8
    goto    0x05dd                   ; 05d8: 2ddd
    bsf     0x03, 0x6                ; 05d9: 1703
    movf    0x3b, 0x0                ; 05da: 083b
    bcf     0x03, 0x5                ; 05db: 1283
    movwf   0x20                     ; 05dc: 00a0
    bsf     0x03, 0x5                ; 05dd: 1683
    bcf     0x03, 0x6                ; 05de: 1303
    bcf     0x58, 0x0                ; 05df: 1058
    bcf     0x58, 0x1                ; 05e0: 10d8
    bsf     0x0a, 0x4                ; 05e1: 160a
    bsf     0x0a, 0x3                ; 05e2: 158a
    goto    0x06c6                   ; 05e3: 2ec6
    movlw   0x07                     ; 05e4: 3007
    bsf     0x0a, 0x4                ; 05e5: 160a
    bcf     0x0a, 0x3                ; 05e6: 118a
    call    0x0000                   ; 05e7: 2000
    movf    0x70, 0x0                ; 05e8: 0870
    movwf   0x3c                     ; 05e9: 00bc
    movlw   0x07                     ; 05ea: 3007
    bsf     0x0a, 0x4                ; 05eb: 160a
    bcf     0x0a, 0x3                ; 05ec: 118a
    call    0x0000                   ; 05ed: 2000
    bcf     0x0a, 0x4                ; 05ee: 120a
    bcf     0x0a, 0x3                ; 05ef: 118a
    bsf     0x03, 0x5                ; 05f0: 1683
    bsf     0x03, 0x6                ; 05f1: 1703
    movf    0x3d, 0x0                ; 05f2: 083d
    movwf   0x72                     ; 05f3: 00f2
    clrf    0x73                     ; 05f4: 01f3
    bcf     0x03, 0x0                ; 05f5: 1003
    rlf     0x72, 0x1                ; 05f6: 0df2
    rlf     0x73, 0x1                ; 05f7: 0df3
    movf    0x71, 0x0                ; 05f8: 0871
    subwf   0x73, 0x0                ; 05f9: 0273
    btfss   0x03, 0x2                ; 05fa: 1d03
    goto    0x05fe                   ; 05fb: 2dfe
    movf    0x70, 0x0                ; 05fc: 0870
    subwf   0x72, 0x0                ; 05fd: 0272
    btfsc   0x03, 0x0                ; 05fe: 1803
    goto    0x060a                   ; 05ff: 2e0a
    bcf     0x03, 0x5                ; 0600: 1283
    bcf     0x03, 0x6                ; 0601: 1303
    btfss   0x18, 0x4                ; 0602: 1e18
    goto    0x062e                   ; 0603: 2e2e
    bcf     0x18, 0x4                ; 0604: 1218
    bsf     0x03, 0x5                ; 0605: 1683
    bsf     0x58, 0x0                ; 0606: 1458
    bcf     0x58, 0x1                ; 0607: 10d8
    clrf    0x53                     ; 0608: 01d3
    goto    0x062e                   ; 0609: 2e2e
    movlw   0x07                     ; 060a: 3007
    bsf     0x0a, 0x4                ; 060b: 160a
    bcf     0x0a, 0x3                ; 060c: 118a
    call    0x0000                   ; 060d: 2000
    bcf     0x0a, 0x4                ; 060e: 120a
    bcf     0x0a, 0x3                ; 060f: 118a
    bsf     0x03, 0x5                ; 0610: 1683
    bsf     0x03, 0x6                ; 0611: 1703
    movf    0x3d, 0x0                ; 0612: 083d
    movwf   0x72                     ; 0613: 00f2
    clrf    0x73                     ; 0614: 01f3
    bcf     0x03, 0x0                ; 0615: 1003
    rlf     0x72, 0x1                ; 0616: 0df2
    rlf     0x73, 0x1                ; 0617: 0df3
    movlw   0xce                     ; 0618: 30ce
    addwf   0x72, 0x1                ; 0619: 07f2
    btfsc   0x03, 0x0                ; 061a: 1803
    incf    0x73, 0x1                ; 061b: 0af3
    movlw   0xff                     ; 061c: 30ff
    addwf   0x73, 0x1                ; 061d: 07f3
    movf    0x73, 0x0                ; 061e: 0873
    subwf   0x71, 0x0                ; 061f: 0271
    btfss   0x03, 0x2                ; 0620: 1d03
    goto    0x0624                   ; 0621: 2e24
    movf    0x72, 0x0                ; 0622: 0872
    subwf   0x70, 0x0                ; 0623: 0270
    btfsc   0x03, 0x0                ; 0624: 1803
    goto    0x062e                   ; 0625: 2e2e
    bcf     0x03, 0x5                ; 0626: 1283
    bcf     0x03, 0x6                ; 0627: 1303
    btfsc   0x18, 0x4                ; 0628: 1a18
    goto    0x062e                   ; 0629: 2e2e
    bsf     0x18, 0x4                ; 062a: 1618
    call    0x0535                   ; 062b: 2535
    bcf     0x0a, 0x4                ; 062c: 120a
    bcf     0x0a, 0x3                ; 062d: 118a
    bsf     0x03, 0x5                ; 062e: 1683
    bcf     0x03, 0x6                ; 062f: 1303
    btfss   0x58, 0x1                ; 0630: 1cd8
    goto    0x0636                   ; 0631: 2e36
    call    0x0521                   ; 0632: 2521
    bcf     0x0a, 0x4                ; 0633: 120a
    bcf     0x0a, 0x3                ; 0634: 118a
    goto    0x0655                   ; 0635: 2e55
    btfss   0x58, 0x0                ; 0636: 1c58
    goto    0x0655                   ; 0637: 2e55
    bsf     0x4e, 0x0                ; 0638: 144e
    bcf     0x03, 0x5                ; 0639: 1283
    bsf     0x03, 0x6                ; 063a: 1703
    movf    0x20, 0x1                ; 063b: 08a0
    btfss   0x03, 0x2                ; 063c: 1d03
    goto    0x0642                   ; 063d: 2e42
    movlw   0x3c                     ; 063e: 303c
    bcf     0x0a, 0x4                ; 063f: 120a
    bsf     0x0a, 0x3                ; 0640: 158a
    call    0x0046                   ; 0641: 2046
    movlw   0xc0                     ; 0642: 30c0
    bsf     0x0a, 0x4                ; 0643: 160a
    bsf     0x0a, 0x3                ; 0644: 158a
    call    0x07d5                   ; 0645: 27d5
    movlw   0xc0                     ; 0646: 30c0
    bsf     0x0a, 0x4                ; 0647: 160a
    bsf     0x0a, 0x3                ; 0648: 158a
    call    0x07aa                   ; 0649: 27aa
    bcf     0x0a, 0x4                ; 064a: 120a
    bcf     0x0a, 0x3                ; 064b: 118a
    bsf     0x03, 0x5                ; 064c: 1683
    bsf     0x4e, 0x0                ; 064d: 144e
    bcf     0x03, 0x5                ; 064e: 1283
    bcf     0x12, 0x2                ; 064f: 1112
    bsf     0x03, 0x5                ; 0650: 1683
    clrf    0x56                     ; 0651: 01d6
    clrf    0x57                     ; 0652: 01d7
    bsf     0x03, 0x6                ; 0653: 1703
    clrf    0x32                     ; 0654: 01b2
    clrf    0x03                     ; 0655: 0183
    return                           ; 0656: 0008
    clrf    0x03                     ; 0657: 0183
    movwf   0x5c                     ; 0658: 00dc
    movlw   0xc4                     ; 0659: 30c4
    movwf   0x5d                     ; 065a: 00dd
    movlw   0x09                     ; 065b: 3009
    movwf   0x5e                     ; 065c: 00de
    goto    0x066a                   ; 065d: 2e6a
    bcf     0x03, 0x5                ; 065e: 1283
    bcf     0x03, 0x6                ; 065f: 1303
    movf    0x5d, 0x1                ; 0660: 08dd
    btfsc   0x03, 0x2                ; 0661: 1903
    decf    0x5e, 0x1                ; 0662: 03de
    decf    0x5d, 0x1                ; 0663: 03dd
    movf    0x5e, 0x0                ; 0664: 085e
    iorwf   0x5d, 0x0                ; 0665: 045d
    btfss   0x03, 0x2                ; 0666: 1d03
    goto    0x066a                   ; 0667: 2e6a
    movlw   0xff                     ; 0668: 30ff
    goto    0x0678                   ; 0669: 2e78
    bsf     0x03, 0x5                ; 066a: 1683
    bsf     0x03, 0x6                ; 066b: 1703
    btfsc   0x0c, 0x1                ; 066c: 188c
    goto    0x065e                   ; 066d: 2e5e
    bcf     0x03, 0x5                ; 066e: 1283
    bcf     0x03, 0x6                ; 066f: 1303
    movf    0x5c, 0x0                ; 0670: 085c
    bsf     0x03, 0x6                ; 0671: 1703
    movwf   0x0d                     ; 0672: 008d
    bsf     0x03, 0x5                ; 0673: 1683
    bcf     0x0c, 0x7                ; 0674: 138c
    bsf     0x0c, 0x0                ; 0675: 140c
    bcf     0x03, 0x5                ; 0676: 1283
    movf    0x0c, 0x0                ; 0677: 080c
    bcf     0x03, 0x6                ; 0678: 1303
    return                           ; 0679: 0008
    clrf    0x03                     ; 067a: 0183
    movwf   0x5a                     ; 067b: 00da
    movlw   0x11                     ; 067c: 3011
    subwf   0x5a, 0x0                ; 067d: 025a
    movf    0x5a, 0x0                ; 067e: 085a
    btfsc   0x03, 0x0                ; 067f: 1803
    goto    0x0695                   ; 0680: 2e95
    call    0x0657                   ; 0681: 2657
    movwf   0x58                     ; 0682: 00d8
    movf    0x5a, 0x0                ; 0683: 085a
    addlw   0x64                     ; 0684: 3e64
    call    0x0657                   ; 0685: 2657
    movwf   0x59                     ; 0686: 00d9
    movf    0x5a, 0x0                ; 0687: 085a
    addlw   0xc8                     ; 0688: 3ec8
    call    0x0657                   ; 0689: 2657
    movwf   0x56                     ; 068a: 00d6
    movf    0x58, 0x0                ; 068b: 0858
    xorwf   0x59, 0x0                ; 068c: 0659
    btfss   0x03, 0x2                ; 068d: 1d03
    retlw   0xff                     ; 068e: 34ff
    movf    0x59, 0x0                ; 068f: 0859
    xorwf   0x56, 0x0                ; 0690: 0656
    btfss   0x03, 0x2                ; 0691: 1d03
    retlw   0xff                     ; 0692: 34ff
    movf    0x58, 0x0                ; 0693: 0858
    return                           ; 0694: 0008
    call    0x0657                   ; 0695: 2657
    movwf   0x57                     ; 0696: 00d7
    return                           ; 0697: 0008
    clrf    0x03                     ; 0698: 0183
    movwf   0x59                     ; 0699: 00d9
    call    0x0657                   ; 069a: 2657
    movwf   0x5b                     ; 069b: 00db
    movf    0x59, 0x0                ; 069c: 0859
    addlw   0x64                     ; 069d: 3e64
    call    0x0657                   ; 069e: 2657
    movwf   0x5a                     ; 069f: 00da
    xorwf   0x5b, 0x0                ; 06a0: 065b
    btfss   0x03, 0x2                ; 06a1: 1d03
    goto    0x06a5                   ; 06a2: 2ea5
    movf    0x5b, 0x0                ; 06a3: 085b
    return                           ; 06a4: 0008
    movf    0x59, 0x0                ; 06a5: 0859
    addlw   0xc8                     ; 06a6: 3ec8
    call    0x0657                   ; 06a7: 2657
    movwf   0x58                     ; 06a8: 00d8
    xorwf   0x5b, 0x0                ; 06a9: 065b
    btfss   0x03, 0x2                ; 06aa: 1d03
    goto    0x06ae                   ; 06ab: 2eae
    movf    0x5b, 0x0                ; 06ac: 085b
    return                           ; 06ad: 0008
    movf    0x5a, 0x0                ; 06ae: 085a
    xorwf   0x58, 0x0                ; 06af: 0658
    btfss   0x03, 0x2                ; 06b0: 1d03
    goto    0x06ba                   ; 06b1: 2eba
    movf    0x5a, 0x0                ; 06b2: 085a
    return                           ; 06b3: 0008
    bsf     0x0a, 0x4                ; 06b4: 160a
    bsf     0x0a, 0x3                ; 06b5: 158a
    call    0x0604                   ; 06b6: 2604
    bcf     0x0a, 0x4                ; 06b7: 120a
    bcf     0x0a, 0x3                ; 06b8: 118a
    retlw   0x00                     ; 06b9: 3400
    movf    0x59, 0x0                ; 06ba: 0859
    movwf   0x70                     ; 06bb: 00f0
    addlw   0xef                     ; 06bc: 3eef
    btfsc   0x03, 0x0                ; 06bd: 1803
    retlw   0x00                     ; 06be: 3400
    addlw   0x11                     ; 06bf: 3e11
    movlw   0x00                     ; 06c0: 3000
    btfss   0x03, 0x0                ; 06c1: 1c03
    return                           ; 06c2: 0008
    movlw   0x06                     ; 06c3: 3006
    movwf   0x0a                     ; 06c4: 008a
    movlw   0xca                     ; 06c5: 30ca
    addwf   0x70, 0x0                ; 06c6: 0770
    btfsc   0x03, 0x0                ; 06c7: 1803
    incf    0x0a, 0x1                ; 06c8: 0a8a
    movwf   0x02                     ; 06c9: 0082
    retlw   0x02                     ; 06ca: 3402
    retlw   0x02                     ; 06cb: 3402
    retlw   0x01                     ; 06cc: 3401
    retlw   0x00                     ; 06cd: 3400
    retlw   0x3c                     ; 06ce: 343c
    goto    0x06b4                   ; 06cf: 2eb4
    retlw   0x08                     ; 06d0: 3408
    retlw   0x09                     ; 06d1: 3409
    retlw   0x03                     ; 06d2: 3403
    retlw   0x06                     ; 06d3: 3406
    retlw   0x5d                     ; 06d4: 345d
    retlw   0x70                     ; 06d5: 3470
    retlw   0x00                     ; 06d6: 3400
    retlw   0x00                     ; 06d7: 3400
    retlw   0x64                     ; 06d8: 3464
    retlw   0xc8                     ; 06d9: 34c8
    retlw   0xff                     ; 06da: 34ff
    movlw   0x00                     ; 06db: 3000
    call    0x0698                   ; 06dc: 2698
    bcf     0x0a, 0x4                ; 06dd: 120a
    bcf     0x0a, 0x3                ; 06de: 118a
    movwf   0x57                     ; 06df: 00d7
    movlw   0x01                     ; 06e0: 3001
    call    0x0698                   ; 06e1: 2698
    bcf     0x0a, 0x4                ; 06e2: 120a
    bcf     0x0a, 0x3                ; 06e3: 118a
    addwf   0x57, 0x1                ; 06e4: 07d7
    movlw   0x02                     ; 06e5: 3002
    call    0x0698                   ; 06e6: 2698
    bcf     0x0a, 0x4                ; 06e7: 120a
    bcf     0x0a, 0x3                ; 06e8: 118a
    addwf   0x57, 0x1                ; 06e9: 07d7
    movlw   0x03                     ; 06ea: 3003
    call    0x0698                   ; 06eb: 2698
    bcf     0x0a, 0x4                ; 06ec: 120a
    bcf     0x0a, 0x3                ; 06ed: 118a
    addwf   0x57, 0x1                ; 06ee: 07d7
    bsf     0x03, 0x5                ; 06ef: 1683
    bsf     0x03, 0x6                ; 06f0: 1703
    movf    0x3b, 0x0                ; 06f1: 083b
    bcf     0x03, 0x5                ; 06f2: 1283
    bcf     0x03, 0x6                ; 06f3: 1303
    addwf   0x57, 0x1                ; 06f4: 07d7
    bsf     0x03, 0x6                ; 06f5: 1703
    movf    0x22, 0x0                ; 06f6: 0822
    bcf     0x03, 0x6                ; 06f7: 1303
    addwf   0x57, 0x1                ; 06f8: 07d7
    movlw   0x06                     ; 06f9: 3006
    call    0x0698                   ; 06fa: 2698
    bcf     0x0a, 0x4                ; 06fb: 120a
    bcf     0x0a, 0x3                ; 06fc: 118a
    addwf   0x57, 0x1                ; 06fd: 07d7
    movlw   0x07                     ; 06fe: 3007
    call    0x0698                   ; 06ff: 2698
    bcf     0x0a, 0x4                ; 0700: 120a
    bcf     0x0a, 0x3                ; 0701: 118a
    addwf   0x57, 0x1                ; 0702: 07d7
    bsf     0x03, 0x5                ; 0703: 1683
    bsf     0x03, 0x6                ; 0704: 1703
    movf    0x3f, 0x0                ; 0705: 083f
    bcf     0x03, 0x5                ; 0706: 1283
    bcf     0x03, 0x6                ; 0707: 1303
    addwf   0x57, 0x1                ; 0708: 07d7
    bsf     0x03, 0x5                ; 0709: 1683
    bsf     0x03, 0x6                ; 070a: 1703
    movf    0x40, 0x0                ; 070b: 0840
    bcf     0x03, 0x5                ; 070c: 1283
    bcf     0x03, 0x6                ; 070d: 1303
    addwf   0x57, 0x1                ; 070e: 07d7
    bsf     0x03, 0x5                ; 070f: 1683
    bsf     0x03, 0x6                ; 0710: 1703
    movf    0x41, 0x0                ; 0711: 0841
    bcf     0x03, 0x5                ; 0712: 1283
    bcf     0x03, 0x6                ; 0713: 1303
    addwf   0x57, 0x1                ; 0714: 07d7
    bsf     0x03, 0x5                ; 0715: 1683
    bsf     0x03, 0x6                ; 0716: 1703
    movf    0x3e, 0x0                ; 0717: 083e
    bcf     0x03, 0x5                ; 0718: 1283
    bcf     0x03, 0x6                ; 0719: 1303
    addwf   0x57, 0x1                ; 071a: 07d7
    bsf     0x03, 0x5                ; 071b: 1683
    bsf     0x03, 0x6                ; 071c: 1703
    movf    0x30, 0x0                ; 071d: 0830
    bcf     0x03, 0x5                ; 071e: 1283
    bcf     0x03, 0x6                ; 071f: 1303
    addwf   0x57, 0x1                ; 0720: 07d7
    bsf     0x03, 0x5                ; 0721: 1683
    bsf     0x03, 0x6                ; 0722: 1703
    movf    0x31, 0x0                ; 0723: 0831
    bcf     0x03, 0x5                ; 0724: 1283
    bcf     0x03, 0x6                ; 0725: 1303
    addwf   0x57, 0x1                ; 0726: 07d7
    bsf     0x03, 0x5                ; 0727: 1683
    bsf     0x03, 0x6                ; 0728: 1703
    movf    0x33, 0x0                ; 0729: 0833
    bcf     0x03, 0x5                ; 072a: 1283
    bcf     0x03, 0x6                ; 072b: 1303
    addwf   0x57, 0x1                ; 072c: 07d7
    bsf     0x03, 0x5                ; 072d: 1683
    bsf     0x03, 0x6                ; 072e: 1703
    movf    0x3d, 0x0                ; 072f: 083d
    bcf     0x03, 0x5                ; 0730: 1283
    bcf     0x03, 0x6                ; 0731: 1303
    addwf   0x57, 0x1                ; 0732: 07d7
    movlw   0x10                     ; 0733: 3010
    call    0x0698                   ; 0734: 2698
    bcf     0x0a, 0x4                ; 0735: 120a
    bcf     0x0a, 0x3                ; 0736: 118a
    movwf   0x56                     ; 0737: 00d6
    xorwf   0x57, 0x0                ; 0738: 0657
    bsf     0x03, 0x5                ; 0739: 1683
    btfss   0x03, 0x2                ; 073a: 1d03
    goto    0x073e                   ; 073b: 2f3e
    bcf     0x58, 0x3                ; 073c: 11d8
    goto    0x073f                   ; 073d: 2f3f
    bsf     0x58, 0x3                ; 073e: 15d8
    bcf     0x03, 0x5                ; 073f: 1283
    return                           ; 0740: 0008
    movlw   0x05                     ; 0741: 3005
    call    0x0698                   ; 0742: 2698
    bcf     0x0a, 0x4                ; 0743: 120a
    bcf     0x0a, 0x3                ; 0744: 118a
    bsf     0x03, 0x6                ; 0745: 1703
    movwf   0x22                     ; 0746: 00a2
    xorlw   0x02                     ; 0747: 3a02
    btfss   0x03, 0x2                ; 0748: 1d03
    goto    0x0753                   ; 0749: 2f53
    movlw   0x00                     ; 074a: 3000
    call    0x0698                   ; 074b: 2698
    bcf     0x0a, 0x4                ; 074c: 120a
    bcf     0x0a, 0x3                ; 074d: 118a
    bsf     0x03, 0x5                ; 074e: 1683
    bsf     0x03, 0x6                ; 074f: 1703
    movwf   0x43                     ; 0750: 00c3
    movlw   0x02                     ; 0751: 3002
    goto    0x075b                   ; 0752: 2f5b
    movlw   0x01                     ; 0753: 3001
    call    0x0698                   ; 0754: 2698
    bcf     0x0a, 0x4                ; 0755: 120a
    bcf     0x0a, 0x3                ; 0756: 118a
    bsf     0x03, 0x5                ; 0757: 1683
    bsf     0x03, 0x6                ; 0758: 1703
    movwf   0x43                     ; 0759: 00c3
    movlw   0x03                     ; 075a: 3003
    call    0x0698                   ; 075b: 2698
    bcf     0x0a, 0x4                ; 075c: 120a
    bcf     0x0a, 0x3                ; 075d: 118a
    bsf     0x03, 0x5                ; 075e: 1683
    bsf     0x03, 0x6                ; 075f: 1703
    movwf   0x42                     ; 0760: 00c2
    movlw   0x04                     ; 0761: 3004
    call    0x0698                   ; 0762: 2698
    bcf     0x0a, 0x4                ; 0763: 120a
    bcf     0x0a, 0x3                ; 0764: 118a
    bsf     0x03, 0x5                ; 0765: 1683
    bsf     0x03, 0x6                ; 0766: 1703
    movwf   0x3b                     ; 0767: 00bb
    movlw   0x08                     ; 0768: 3008
    call    0x0698                   ; 0769: 2698
    bcf     0x0a, 0x4                ; 076a: 120a
    bcf     0x0a, 0x3                ; 076b: 118a
    bsf     0x03, 0x5                ; 076c: 1683
    bsf     0x03, 0x6                ; 076d: 1703
    movwf   0x3f                     ; 076e: 00bf
    movlw   0x09                     ; 076f: 3009
    call    0x0698                   ; 0770: 2698
    bcf     0x0a, 0x4                ; 0771: 120a
    bcf     0x0a, 0x3                ; 0772: 118a
    bsf     0x03, 0x5                ; 0773: 1683
    bsf     0x03, 0x6                ; 0774: 1703
    movwf   0x40                     ; 0775: 00c0
    movlw   0x0a                     ; 0776: 300a
    call    0x0698                   ; 0777: 2698
    bcf     0x0a, 0x4                ; 0778: 120a
    bcf     0x0a, 0x3                ; 0779: 118a
    bsf     0x03, 0x5                ; 077a: 1683
    bsf     0x03, 0x6                ; 077b: 1703
    movwf   0x41                     ; 077c: 00c1
    movlw   0x0b                     ; 077d: 300b
    call    0x0698                   ; 077e: 2698
    bcf     0x0a, 0x4                ; 077f: 120a
    bcf     0x0a, 0x3                ; 0780: 118a
    bsf     0x03, 0x5                ; 0781: 1683
    bsf     0x03, 0x6                ; 0782: 1703
    movwf   0x3e                     ; 0783: 00be
    movlw   0x0c                     ; 0784: 300c
    call    0x0698                   ; 0785: 2698
    bcf     0x0a, 0x4                ; 0786: 120a
    bcf     0x0a, 0x3                ; 0787: 118a
    bsf     0x03, 0x5                ; 0788: 1683
    bsf     0x03, 0x6                ; 0789: 1703
    movwf   0x30                     ; 078a: 00b0
    movlw   0x0d                     ; 078b: 300d
    call    0x0698                   ; 078c: 2698
    bcf     0x0a, 0x4                ; 078d: 120a
    bcf     0x0a, 0x3                ; 078e: 118a
    bsf     0x03, 0x5                ; 078f: 1683
    bsf     0x03, 0x6                ; 0790: 1703
    movwf   0x31                     ; 0791: 00b1
    movlw   0x0e                     ; 0792: 300e
    call    0x0698                   ; 0793: 2698
    bcf     0x0a, 0x4                ; 0794: 120a
    bcf     0x0a, 0x3                ; 0795: 118a
    bsf     0x03, 0x5                ; 0796: 1683
    bsf     0x03, 0x6                ; 0797: 1703
    movwf   0x33                     ; 0798: 00b3
    movlw   0x0f                     ; 0799: 300f
    call    0x0698                   ; 079a: 2698
    bcf     0x0a, 0x4                ; 079b: 120a
    bcf     0x0a, 0x3                ; 079c: 118a
    bsf     0x03, 0x5                ; 079d: 1683
    bsf     0x03, 0x6                ; 079e: 1703
    movwf   0x3d                     ; 079f: 00bd
    movlw   0x10                     ; 07a0: 3010
    call    0x0698                   ; 07a1: 2698
    bcf     0x0a, 0x4                ; 07a2: 120a
    bcf     0x0a, 0x3                ; 07a3: 118a
    bsf     0x03, 0x5                ; 07a4: 1683
    bsf     0x03, 0x6                ; 07a5: 1703
    movwf   0x3c                     ; 07a6: 00bc
    clrf    0x03                     ; 07a7: 0183
    return                           ; 07a8: 0008
    clrf    0x76                     ; 07a9: 01f6
    btfss   0x71, 0x7                ; 07aa: 1ff1
    goto    0x07b3                   ; 07ab: 2fb3
    comf    0x70, 0x1                ; 07ac: 09f0
    incf    0x70, 0x1                ; 07ad: 0af0
    btfsc   0x03, 0x2                ; 07ae: 1903
    decf    0x71, 0x1                ; 07af: 03f1
    comf    0x71, 0x1                ; 07b0: 09f1
    bsf     0x76, 0x6                ; 07b1: 1776
    bsf     0x76, 0x7                ; 07b2: 17f6
    movf    0x73, 0x0                ; 07b3: 0873
    andlw   0x80                     ; 07b4: 3980
    xorwf   0x76, 0x1                ; 07b5: 06f6
    btfss   0x73, 0x7                ; 07b6: 1ff3
    goto    0x07bf                   ; 07b7: 2fbf
    comf    0x72, 0x1                ; 07b8: 09f2
    incf    0x72, 0x1                ; 07b9: 0af2
    btfsc   0x03, 0x2                ; 07ba: 1903
    decf    0x73, 0x1                ; 07bb: 03f3
    comf    0x73, 0x1                ; 07bc: 09f3
    goto    0x07bf                   ; 07bd: 2fbf
    clrf    0x76                     ; 07be: 01f6
    clrf    0x74                     ; 07bf: 01f4
    clrf    0x75                     ; 07c0: 01f5
    movf    0x72, 0x0                ; 07c1: 0872
    iorwf   0x73, 0x0                ; 07c2: 0473
    btfss   0x03, 0x2                ; 07c3: 1d03
    goto    0x07c8                   ; 07c4: 2fc8
    clrf    0x70                     ; 07c5: 01f0
    clrf    0x71                     ; 07c6: 01f1
    retlw   0x00                     ; 07c7: 3400
    movlw   0x1f                     ; 07c8: 301f
    iorwf   0x76, 0x1                ; 07c9: 04f6
    bcf     0x03, 0x0                ; 07ca: 1003
    incf    0x76, 0x1                ; 07cb: 0af6
    rlf     0x72, 0x1                ; 07cc: 0df2
    rlf     0x73, 0x1                ; 07cd: 0df3
    btfss   0x03, 0x0                ; 07ce: 1c03
    goto    0x07cb                   ; 07cf: 2fcb
    rrf     0x73, 0x1                ; 07d0: 0cf3
    rrf     0x72, 0x1                ; 07d1: 0cf2
    movf    0x73, 0x0                ; 07d2: 0873
    subwf   0x71, 0x0                ; 07d3: 0271
    btfss   0x03, 0x2                ; 07d4: 1d03
    goto    0x07d8                   ; 07d5: 2fd8
    movf    0x72, 0x0                ; 07d6: 0872
    subwf   0x70, 0x0                ; 07d7: 0270
    btfss   0x03, 0x0                ; 07d8: 1c03
    goto    0x07e0                   ; 07d9: 2fe0
    movf    0x72, 0x0                ; 07da: 0872
    subwf   0x70, 0x1                ; 07db: 02f0
    movf    0x73, 0x0                ; 07dc: 0873
    btfss   0x03, 0x0                ; 07dd: 1c03
    incf    0x73, 0x0                ; 07de: 0a73
    subwf   0x71, 0x1                ; 07df: 02f1
    rlf     0x74, 0x1                ; 07e0: 0df4
    rlf     0x75, 0x1                ; 07e1: 0df5
    decfsz  0x76, 0x1                ; 07e2: 0bf6
    btfsc   0x76, 0x5                ; 07e3: 1af6
    goto    0x07d0                   ; 07e4: 2fd0
    btfss   0x76, 0x7                ; 07e5: 1ff6
    goto    0x07ec                   ; 07e6: 2fec
    comf    0x74, 0x1                ; 07e7: 09f4
    incf    0x74, 0x1                ; 07e8: 0af4
    btfsc   0x03, 0x2                ; 07e9: 1903
    decf    0x75, 0x1                ; 07ea: 03f5
    comf    0x75, 0x1                ; 07eb: 09f5
    movf    0x74, 0x0                ; 07ec: 0874
    movwf   0x72                     ; 07ed: 00f2
    movf    0x75, 0x0                ; 07ee: 0875
    movwf   0x73                     ; 07ef: 00f3
    btfss   0x76, 0x6                ; 07f0: 1f76
    retlw   0x00                     ; 07f1: 3400
    comf    0x70, 0x1                ; 07f2: 09f0
    incf    0x70, 0x1                ; 07f3: 0af0
    btfsc   0x03, 0x2                ; 07f4: 1903
    decf    0x71, 0x1                ; 07f5: 03f1
    comf    0x71, 0x1                ; 07f6: 09f1
    retlw   0x00                     ; 07f7: 3400
    retlw   0x5a                     ; 07f8: 345a
    retlw   0x4f                     ; 07f9: 344f
    retlw   0x32                     ; 07fa: 3432
    retlw   0x00                     ; 07fb: 3400
    retlw   0x00                     ; 07fc: 3400
    retlw   0x00                     ; 07fd: 3400
    retlw   0x00                     ; 07fe: 3400
    retlw   0x00                     ; 07ff: 3400
    dw 0x3fff ; erased               ; 0800: 3fff
    clrf    0x03                     ; 0801: 0183
    movwf   0x3d                     ; 0802: 00bd
    movlw   0x03                     ; 0803: 3003
    subwf   0x3d, 0x0                ; 0804: 023d
    btfsc   0x03, 0x0                ; 0805: 1803
    retlw   0x02                     ; 0806: 3402
    bsf     0x0a, 0x4                ; 0807: 160a
    bsf     0x0a, 0x3                ; 0808: 158a
    call    0x06d8                   ; 0809: 26d8
    bcf     0x0a, 0x4                ; 080a: 120a
    bsf     0x0a, 0x3                ; 080b: 158a
    movf    0x3d, 0x0                ; 080c: 083d
    iorwf   0x3c, 0x0                ; 080d: 043c
    movlw   0x03                     ; 080e: 3003
    movwf   0x71                     ; 080f: 00f1
    btfss   0x03, 0x2                ; 0810: 1d03
    goto    0x0020                   ; 0811: 2820
    movf    0x3d, 0x0                ; 0812: 083d
    bsf     0x0a, 0x4                ; 0813: 160a
    bsf     0x0a, 0x3                ; 0814: 158a
    call    0x06e2                   ; 0815: 26e2
    addlw   0x02                     ; 0816: 3e02
    addlw   0xac                     ; 0817: 3eac
    movwf   0x04                     ; 0818: 0084
    bcf     0x03, 0x7                ; 0819: 1383
    movf    0x00, 0x0                ; 081a: 0800
    bsf     0x0a, 0x4                ; 081b: 160a
    bcf     0x0a, 0x3                ; 081c: 118a
    call    0x0716                   ; 081d: 2716
    movlw   0x03                     ; 081e: 3003
    movwf   0x71                     ; 081f: 00f1
    movf    0x3d, 0x0                ; 0820: 083d
    bsf     0x0a, 0x4                ; 0821: 160a
    bsf     0x0a, 0x3                ; 0822: 158a
    call    0x06e2                   ; 0823: 26e2
    addlw   0xac                     ; 0824: 3eac
    movwf   0x04                     ; 0825: 0084
    bcf     0x03, 0x7                ; 0826: 1383
    movf    0x3c, 0x0                ; 0827: 083c
    movwf   0x00                     ; 0828: 0080
    incf    0x04, 0x1                ; 0829: 0a84
    movf    0x3d, 0x0                ; 082a: 083d
    movwf   0x00                     ; 082b: 0080
    movlw   0x03                     ; 082c: 3003
    movwf   0x71                     ; 082d: 00f1
    movf    0x3d, 0x0                ; 082e: 083d
    bsf     0x0a, 0x4                ; 082f: 160a
    bsf     0x0a, 0x3                ; 0830: 158a
    call    0x06e2                   ; 0831: 26e2
    bcf     0x0a, 0x4                ; 0832: 120a
    bsf     0x0a, 0x3                ; 0833: 158a
    addlw   0x02                     ; 0834: 3e02
    addlw   0xac                     ; 0835: 3eac
    movwf   0x04                     ; 0836: 0084
    bcf     0x03, 0x7                ; 0837: 1383
    movf    0x00, 0x1                ; 0838: 0880
    btfss   0x03, 0x2                ; 0839: 1d03
    goto    0x003e                   ; 083a: 283e
    movlw   0x03                     ; 083b: 3003
    movwf   0x3c                     ; 083c: 00bc
    goto    0x003f                   ; 083d: 283f
    clrf    0x3c                     ; 083e: 01bc
    bsf     0x0a, 0x4                ; 083f: 160a
    bsf     0x0a, 0x3                ; 0840: 158a
    call    0x06ac                   ; 0841: 26ac
    bcf     0x0a, 0x4                ; 0842: 120a
    bsf     0x0a, 0x3                ; 0843: 158a
    movf    0x3c, 0x0                ; 0844: 083c
    return                           ; 0845: 0008
    clrf    0x03                     ; 0846: 0183
    movwf   0x56                     ; 0847: 00d6
    bsf     0x03, 0x5                ; 0848: 1683
    bsf     0x03, 0x6                ; 0849: 1703
    movf    0x30, 0x0                ; 084a: 0830
    addwf   0x30, 0x0                ; 084b: 0730
    sublw   0x0a                     ; 084c: 3c0a
    bcf     0x03, 0x5                ; 084d: 1283
    bcf     0x03, 0x6                ; 084e: 1303
    movwf   0x57                     ; 084f: 00d7
    movlw   0x0b                     ; 0850: 300b
    subwf   0x57, 0x0                ; 0851: 0257
    btfsc   0x03, 0x0                ; 0852: 1803
    goto    0x0056                   ; 0853: 2856
    movf    0x57, 0x0                ; 0854: 0857
    goto    0x0057                   ; 0855: 2857
    movlw   0x0a                     ; 0856: 300a
    movwf   0x57                     ; 0857: 00d7
    bcf     0x0b, 0x7                ; 0858: 138b
    movwf   0x72                     ; 0859: 00f2
    clrf    0x73                     ; 085a: 01f3
    movf    0x56, 0x0                ; 085b: 0856
    movwf   0x70                     ; 085c: 00f0
    clrf    0x71                     ; 085d: 01f1
    bsf     0x0a, 0x4                ; 085e: 160a
    bsf     0x0a, 0x3                ; 085f: 158a
    call    0x06ee                   ; 0860: 26ee
    movlw   0x32                     ; 0861: 3032
    addwf   0x74, 0x1                ; 0862: 07f4
    btfsc   0x03, 0x0                ; 0863: 1803
    incf    0x75, 0x1                ; 0864: 0af5
    movf    0x74, 0x0                ; 0865: 0874
    movwf   0x70                     ; 0866: 00f0
    movf    0x75, 0x0                ; 0867: 0875
    movwf   0x71                     ; 0868: 00f1
    movlw   0x64                     ; 0869: 3064
    movwf   0x72                     ; 086a: 00f2
    movlw   0x00                     ; 086b: 3000
    clrf    0x73                     ; 086c: 01f3
    bcf     0x0a, 0x4                ; 086d: 120a
    bcf     0x0a, 0x3                ; 086e: 118a
    call    0x07a9                   ; 086f: 27a9
    bcf     0x0a, 0x4                ; 0870: 120a
    bsf     0x0a, 0x3                ; 0871: 158a
    movf    0x74, 0x0                ; 0872: 0874
    bsf     0x03, 0x5                ; 0873: 1683
    movwf   0x3f                     ; 0874: 00bf
    movwf   0x70                     ; 0875: 00f0
    clrf    0x71                     ; 0876: 01f1
    movf    0x71, 0x0                ; 0877: 0871
    subwf   0x5a, 0x0                ; 0878: 025a
    btfss   0x03, 0x2                ; 0879: 1d03
    goto    0x007d                   ; 087a: 287d
    movf    0x70, 0x0                ; 087b: 0870
    subwf   0x59, 0x0                ; 087c: 0259
    btfss   0x03, 0x0                ; 087d: 1c03
    goto    0x0081                   ; 087e: 2881
    movf    0x3f, 0x0                ; 087f: 083f
    goto    0x0083                   ; 0880: 2883
    bcf     0x03, 0x6                ; 0881: 1303
    movf    0x59, 0x0                ; 0882: 0859
    bcf     0x03, 0x6                ; 0883: 1303
    movwf   0x3f                     ; 0884: 00bf
    bsf     0x0b, 0x7                ; 0885: 178b
    bsf     0x03, 0x6                ; 0886: 1703
    movf    0x31, 0x0                ; 0887: 0831
    addwf   0x31, 0x0                ; 0888: 0731
    sublw   0x0a                     ; 0889: 3c0a
    bcf     0x03, 0x5                ; 088a: 1283
    bcf     0x03, 0x6                ; 088b: 1303
    movwf   0x57                     ; 088c: 00d7
    movlw   0x0b                     ; 088d: 300b
    subwf   0x57, 0x0                ; 088e: 0257
    btfsc   0x03, 0x0                ; 088f: 1803
    goto    0x0093                   ; 0890: 2893
    movf    0x57, 0x0                ; 0891: 0857
    goto    0x0094                   ; 0892: 2894
    movlw   0x0a                     ; 0893: 300a
    movwf   0x57                     ; 0894: 00d7
    bcf     0x0b, 0x7                ; 0895: 138b
    movwf   0x72                     ; 0896: 00f2
    clrf    0x73                     ; 0897: 01f3
    movf    0x56, 0x0                ; 0898: 0856
    movwf   0x70                     ; 0899: 00f0
    clrf    0x71                     ; 089a: 01f1
    bsf     0x0a, 0x4                ; 089b: 160a
    bsf     0x0a, 0x3                ; 089c: 158a
    call    0x06ee                   ; 089d: 26ee
    movlw   0x32                     ; 089e: 3032
    addwf   0x74, 0x1                ; 089f: 07f4
    btfsc   0x03, 0x0                ; 08a0: 1803
    incf    0x75, 0x1                ; 08a1: 0af5
    movf    0x74, 0x0                ; 08a2: 0874
    movwf   0x70                     ; 08a3: 00f0
    movf    0x75, 0x0                ; 08a4: 0875
    movwf   0x71                     ; 08a5: 00f1
    movlw   0x64                     ; 08a6: 3064
    movwf   0x72                     ; 08a7: 00f2
    movlw   0x00                     ; 08a8: 3000
    clrf    0x73                     ; 08a9: 01f3
    bcf     0x0a, 0x4                ; 08aa: 120a
    bcf     0x0a, 0x3                ; 08ab: 118a
    call    0x07a9                   ; 08ac: 27a9
    bcf     0x0a, 0x4                ; 08ad: 120a
    bsf     0x0a, 0x3                ; 08ae: 158a
    movf    0x74, 0x0                ; 08af: 0874
    bsf     0x03, 0x5                ; 08b0: 1683
    movwf   0x40                     ; 08b1: 00c0
    movwf   0x70                     ; 08b2: 00f0
    clrf    0x71                     ; 08b3: 01f1
    movf    0x71, 0x0                ; 08b4: 0871
    subwf   0x5a, 0x0                ; 08b5: 025a
    btfss   0x03, 0x2                ; 08b6: 1d03
    goto    0x00ba                   ; 08b7: 28ba
    movf    0x70, 0x0                ; 08b8: 0870
    subwf   0x59, 0x0                ; 08b9: 0259
    btfss   0x03, 0x0                ; 08ba: 1c03
    goto    0x00be                   ; 08bb: 28be
    movf    0x40, 0x0                ; 08bc: 0840
    goto    0x00c0                   ; 08bd: 28c0
    bcf     0x03, 0x6                ; 08be: 1303
    movf    0x59, 0x0                ; 08bf: 0859
    bcf     0x03, 0x6                ; 08c0: 1303
    movwf   0x40                     ; 08c1: 00c0
    bsf     0x0b, 0x7                ; 08c2: 178b
    movf    0x3f, 0x1                ; 08c3: 08bf
    btfsc   0x03, 0x2                ; 08c4: 1903
    goto    0x00cb                   ; 08c5: 28cb
    movf    0x40, 0x1                ; 08c6: 08c0
    btfsc   0x03, 0x2                ; 08c7: 1903
    goto    0x00cb                   ; 08c8: 28cb
    movlw   0x01                     ; 08c9: 3001
    goto    0x00cc                   ; 08ca: 28cc
    movlw   0x00                     ; 08cb: 3000
    bcf     0x03, 0x5                ; 08cc: 1283
    return                           ; 08cd: 0008
    clrf    0x03                     ; 08ce: 0183
    clrf    0x3d                     ; 08cf: 01bd
    goto    0x07ed                   ; 08d0: 2fed
    bsf     0x0a, 0x4                ; 08d1: 160a
    bsf     0x0a, 0x3                ; 08d2: 158a
    call    0x066d                   ; 08d3: 266d
    movwf   0x4f                     ; 08d4: 00cf
    clrf    0x50                     ; 08d5: 01d0
    bsf     0x0a, 0x4                ; 08d6: 160a
    bsf     0x0a, 0x3                ; 08d7: 158a
    call    0x0643                   ; 08d8: 2643
    bcf     0x0a, 0x4                ; 08d9: 120a
    bsf     0x0a, 0x3                ; 08da: 158a
    goto    0x00e6                   ; 08db: 28e6
    bsf     0x0a, 0x4                ; 08dc: 160a
    bsf     0x0a, 0x3                ; 08dd: 158a
    call    0x064f                   ; 08de: 264f
    movwf   0x4f                     ; 08df: 00cf
    clrf    0x50                     ; 08e0: 01d0
    bsf     0x0a, 0x4                ; 08e1: 160a
    bsf     0x0a, 0x3                ; 08e2: 158a
    call    0x0649                   ; 08e3: 2649
    bcf     0x0a, 0x4                ; 08e4: 120a
    bsf     0x0a, 0x3                ; 08e5: 158a
    movwf   0x51                     ; 08e6: 00d1
    clrf    0x52                     ; 08e7: 01d2
    goto    0x00f4                   ; 08e8: 28f4
    bsf     0x03, 0x6                ; 08e9: 1703
    movf    0x22, 0x0                ; 08ea: 0822
    xorlw   0x02                     ; 08eb: 3a02
    btfsc   0x03, 0x2                ; 08ec: 1903
    goto    0x00dc                   ; 08ed: 28dc
    xorlw   0x06                     ; 08ee: 3a06
    btfsc   0x03, 0x2                ; 08ef: 1903
    goto    0x00d1                   ; 08f0: 28d1
    xorlw   0x02                     ; 08f1: 3a02
    btfsc   0x03, 0x2                ; 08f2: 1903
    goto    0x00d1                   ; 08f3: 28d1
    bsf     0x03, 0x6                ; 08f4: 1703
    movf    0x20, 0x0                ; 08f5: 0820
    call    0x0046                   ; 08f6: 2046
    movlw   0x18                     ; 08f7: 3018
    movwf   0x0a                     ; 08f8: 008a
    movf    0x4f, 0x0                ; 08f9: 084f
    call    0x0021                   ; 08fa: 2021
    movwf   0x53                     ; 08fb: 00d3
    clrf    0x54                     ; 08fc: 01d4
    movwf   0x4f                     ; 08fd: 00cf
    movf    0x54, 0x0                ; 08fe: 0854
    movwf   0x50                     ; 08ff: 00d0
    movlw   0x18                     ; 0900: 3018
    movwf   0x0a                     ; 0901: 008a
    movf    0x51, 0x0                ; 0902: 0851
    call    0x0021                   ; 0903: 2021
    movwf   0x53                     ; 0904: 00d3
    clrf    0x54                     ; 0905: 01d4
    movwf   0x51                     ; 0906: 00d1
    movf    0x54, 0x0                ; 0907: 0854
    movwf   0x52                     ; 0908: 00d2
    bsf     0x0a, 0x4                ; 0909: 160a
    bsf     0x0a, 0x3                ; 090a: 158a
    call    0x0673                   ; 090b: 2673
    bcf     0x0a, 0x4                ; 090c: 120a
    bsf     0x0a, 0x3                ; 090d: 158a
    xorlw   0x0e                     ; 090e: 3a0e
    btfss   0x03, 0x2                ; 090f: 1d03
    goto    0x0116                   ; 0910: 2916
    bsf     0x03, 0x6                ; 0911: 1703
    movf    0x22, 0x0                ; 0912: 0822
    xorlw   0x06                     ; 0913: 3a06
    btfsc   0x03, 0x2                ; 0914: 1903
    goto    0x0191                   ; 0915: 2991
    bsf     0x0a, 0x4                ; 0916: 160a
    bsf     0x0a, 0x3                ; 0917: 158a
    call    0x0673                   ; 0918: 2673
    bcf     0x0a, 0x4                ; 0919: 120a
    bsf     0x0a, 0x3                ; 091a: 158a
    xorlw   0x0f                     ; 091b: 3a0f
    btfss   0x03, 0x2                ; 091c: 1d03
    goto    0x0123                   ; 091d: 2923
    bsf     0x03, 0x6                ; 091e: 1703
    movf    0x22, 0x0                ; 091f: 0822
    xorlw   0x04                     ; 0920: 3a04
    btfsc   0x03, 0x2                ; 0921: 1903
    goto    0x0191                   ; 0922: 2991
    bsf     0x0a, 0x4                ; 0923: 160a
    bsf     0x0a, 0x3                ; 0924: 158a
    call    0x0673                   ; 0925: 2673
    bcf     0x0a, 0x4                ; 0926: 120a
    bsf     0x0a, 0x3                ; 0927: 158a
    movwf   0x53                     ; 0928: 00d3
    clrf    0x54                     ; 0929: 01d4
    bcf     0x0b, 0x7                ; 092a: 138b
    xorlw   0x02                     ; 092b: 3a02
    iorwf   0x54, 0x0                ; 092c: 0454
    btfsc   0x03, 0x2                ; 092d: 1903
    goto    0x014c                   ; 092e: 294c
    movf    0x53, 0x0                ; 092f: 0853
    xorlw   0x04                     ; 0930: 3a04
    iorwf   0x54, 0x0                ; 0931: 0454
    btfsc   0x03, 0x2                ; 0932: 1903
    goto    0x014c                   ; 0933: 294c
    movf    0x53, 0x0                ; 0934: 0853
    xorlw   0x06                     ; 0935: 3a06
    iorwf   0x54, 0x0                ; 0936: 0454
    btfsc   0x03, 0x2                ; 0937: 1903
    goto    0x014c                   ; 0938: 294c
    movf    0x53, 0x0                ; 0939: 0853
    xorlw   0x0d                     ; 093a: 3a0d
    iorwf   0x54, 0x0                ; 093b: 0454
    btfsc   0x03, 0x2                ; 093c: 1903
    goto    0x014c                   ; 093d: 294c
    movf    0x53, 0x0                ; 093e: 0853
    xorlw   0x0e                     ; 093f: 3a0e
    iorwf   0x54, 0x0                ; 0940: 0454
    btfsc   0x03, 0x2                ; 0941: 1903
    goto    0x014c                   ; 0942: 294c
    movf    0x53, 0x0                ; 0943: 0853
    xorlw   0x0f                     ; 0944: 3a0f
    iorwf   0x54, 0x0                ; 0945: 0454
    btfsc   0x03, 0x2                ; 0946: 1903
    goto    0x014c                   ; 0947: 294c
    decf    0x53, 0x0                ; 0948: 0353
    iorwf   0x54, 0x0                ; 0949: 0454
    btfss   0x03, 0x2                ; 094a: 1d03
    goto    0x0152                   ; 094b: 2952
    movf    0x51, 0x0                ; 094c: 0851
    bsf     0x0a, 0x4                ; 094d: 160a
    bsf     0x0a, 0x3                ; 094e: 158a
    call    0x07d5                   ; 094f: 27d5
    bcf     0x0a, 0x4                ; 0950: 120a
    bsf     0x0a, 0x3                ; 0951: 158a
    movf    0x53, 0x0                ; 0952: 0853
    xorlw   0x03                     ; 0953: 3a03
    iorwf   0x54, 0x0                ; 0954: 0454
    btfsc   0x03, 0x2                ; 0955: 1903
    goto    0x0174                   ; 0956: 2974
    movf    0x53, 0x0                ; 0957: 0853
    xorlw   0x05                     ; 0958: 3a05
    iorwf   0x54, 0x0                ; 0959: 0454
    btfsc   0x03, 0x2                ; 095a: 1903
    goto    0x0174                   ; 095b: 2974
    movf    0x53, 0x0                ; 095c: 0853
    xorlw   0x07                     ; 095d: 3a07
    iorwf   0x54, 0x0                ; 095e: 0454
    btfsc   0x03, 0x2                ; 095f: 1903
    goto    0x0174                   ; 0960: 2974
    movf    0x53, 0x0                ; 0961: 0853
    xorlw   0x0d                     ; 0962: 3a0d
    iorwf   0x54, 0x0                ; 0963: 0454
    btfsc   0x03, 0x2                ; 0964: 1903
    goto    0x0174                   ; 0965: 2974
    movf    0x53, 0x0                ; 0966: 0853
    xorlw   0x0e                     ; 0967: 3a0e
    iorwf   0x54, 0x0                ; 0968: 0454
    btfsc   0x03, 0x2                ; 0969: 1903
    goto    0x0174                   ; 096a: 2974
    movf    0x53, 0x0                ; 096b: 0853
    xorlw   0x0f                     ; 096c: 3a0f
    iorwf   0x54, 0x0                ; 096d: 0454
    btfsc   0x03, 0x2                ; 096e: 1903
    goto    0x0174                   ; 096f: 2974
    decf    0x53, 0x0                ; 0970: 0353
    iorwf   0x54, 0x0                ; 0971: 0454
    btfss   0x03, 0x2                ; 0972: 1d03
    goto    0x017a                   ; 0973: 297a
    movf    0x4f, 0x0                ; 0974: 084f
    bsf     0x0a, 0x4                ; 0975: 160a
    bsf     0x0a, 0x3                ; 0976: 158a
    call    0x07aa                   ; 0977: 27aa
    bcf     0x0a, 0x4                ; 0978: 120a
    bsf     0x0a, 0x3                ; 0979: 158a
    movf    0x50, 0x0                ; 097a: 0850
    iorwf   0x4f, 0x0                ; 097b: 044f
    btfss   0x03, 0x2                ; 097c: 1d03
    goto    0x0188                   ; 097d: 2988
    movf    0x52, 0x0                ; 097e: 0852
    iorwf   0x51, 0x0                ; 097f: 0451
    btfsc   0x03, 0x2                ; 0980: 1903
    btfsc   0x08, 0x1                ; 0981: 1888
    goto    0x0188                   ; 0982: 2988
    btfss   0x08, 0x2                ; 0983: 1d08
    btfsc   0x08, 0x6                ; 0984: 1b08
    goto    0x0188                   ; 0985: 2988
    btfss   0x08, 0x5                ; 0986: 1e88
    goto    0x018b                   ; 0987: 298b
    bsf     0x03, 0x5                ; 0988: 1683
    bsf     0x4e, 0x0                ; 0989: 144e
    goto    0x0190                   ; 098a: 2990
    bcf     0x0a, 0x4                ; 098b: 120a
    bcf     0x0a, 0x3                ; 098c: 118a
    call    0x0521                   ; 098d: 2521
    bcf     0x0a, 0x4                ; 098e: 120a
    bsf     0x0a, 0x3                ; 098f: 158a
    bsf     0x0b, 0x7                ; 0990: 178b
    bcf     0x03, 0x5                ; 0991: 1283
    bsf     0x03, 0x6                ; 0992: 1703
    movf    0x22, 0x0                ; 0993: 0822
    xorlw   0x02                     ; 0994: 3a02
    btfsc   0x03, 0x2                ; 0995: 1903
    goto    0x01d2                   ; 0996: 29d2
    movf    0x22, 0x0                ; 0997: 0822
    xorlw   0x04                     ; 0998: 3a04
    btfss   0x03, 0x2                ; 0999: 1d03
    goto    0x01c3                   ; 099a: 29c3
    bsf     0x0a, 0x4                ; 099b: 160a
    bsf     0x0a, 0x3                ; 099c: 158a
    call    0x0673                   ; 099d: 2673
    bcf     0x0a, 0x4                ; 099e: 120a
    bsf     0x0a, 0x3                ; 099f: 158a
    xorlw   0x0d                     ; 09a0: 3a0d
    btfsc   0x03, 0x2                ; 09a1: 1903
    goto    0x01cf                   ; 09a2: 29cf
    bsf     0x0a, 0x4                ; 09a3: 160a
    bsf     0x0a, 0x3                ; 09a4: 158a
    call    0x0673                   ; 09a5: 2673
    bcf     0x0a, 0x4                ; 09a6: 120a
    bsf     0x0a, 0x3                ; 09a7: 158a
    xorlw   0x0f                     ; 09a8: 3a0f
    btfsc   0x03, 0x2                ; 09a9: 1903
    goto    0x01cf                   ; 09aa: 29cf
    bsf     0x0a, 0x4                ; 09ab: 160a
    bsf     0x0a, 0x3                ; 09ac: 158a
    call    0x0661                   ; 09ad: 2661
    movwf   0x55                     ; 09ae: 00d5
    bsf     0x0a, 0x4                ; 09af: 160a
    bsf     0x0a, 0x3                ; 09b0: 158a
    call    0x068b                   ; 09b1: 268b
    bcf     0x0a, 0x4                ; 09b2: 120a
    bsf     0x0a, 0x3                ; 09b3: 158a
    subwf   0x55, 0x0                ; 09b4: 0255
    btfsc   0x03, 0x0                ; 09b5: 1803
    goto    0x01bd                   ; 09b6: 29bd
    bsf     0x0a, 0x4                ; 09b7: 160a
    bsf     0x0a, 0x3                ; 09b8: 158a
    call    0x068b                   ; 09b9: 268b
    bcf     0x0a, 0x4                ; 09ba: 120a
    bsf     0x0a, 0x3                ; 09bb: 158a
    goto    0x01e9                   ; 09bc: 29e9
    bsf     0x0a, 0x4                ; 09bd: 160a
    bsf     0x0a, 0x3                ; 09be: 158a
    call    0x0661                   ; 09bf: 2661
    bcf     0x0a, 0x4                ; 09c0: 120a
    bsf     0x0a, 0x3                ; 09c1: 158a
    goto    0x01e9                   ; 09c2: 29e9
    movf    0x22, 0x0                ; 09c3: 0822
    xorlw   0x06                     ; 09c4: 3a06
    btfss   0x03, 0x2                ; 09c5: 1d03
    goto    0x01eb                   ; 09c6: 29eb
    bsf     0x0a, 0x4                ; 09c7: 160a
    bsf     0x0a, 0x3                ; 09c8: 158a
    call    0x0673                   ; 09c9: 2673
    bcf     0x0a, 0x4                ; 09ca: 120a
    bsf     0x0a, 0x3                ; 09cb: 158a
    xorlw   0x0e                     ; 09cc: 3a0e
    btfss   0x03, 0x2                ; 09cd: 1d03
    goto    0x01d2                   ; 09ce: 29d2
    bsf     0x03, 0x5                ; 09cf: 1683
    clrf    0x52                     ; 09d0: 01d2
    goto    0x01eb                   ; 09d1: 29eb
    bsf     0x0a, 0x4                ; 09d2: 160a
    bsf     0x0a, 0x3                ; 09d3: 158a
    call    0x0655                   ; 09d4: 2655
    movwf   0x55                     ; 09d5: 00d5
    bsf     0x0a, 0x4                ; 09d6: 160a
    bsf     0x0a, 0x3                ; 09d7: 158a
    call    0x065b                   ; 09d8: 265b
    bcf     0x0a, 0x4                ; 09d9: 120a
    bsf     0x0a, 0x3                ; 09da: 158a
    subwf   0x55, 0x0                ; 09db: 0255
    btfsc   0x03, 0x0                ; 09dc: 1803
    goto    0x01e4                   ; 09dd: 29e4
    bsf     0x0a, 0x4                ; 09de: 160a
    bsf     0x0a, 0x3                ; 09df: 158a
    call    0x065b                   ; 09e0: 265b
    bcf     0x0a, 0x4                ; 09e1: 120a
    bsf     0x0a, 0x3                ; 09e2: 158a
    goto    0x01e9                   ; 09e3: 29e9
    bsf     0x0a, 0x4                ; 09e4: 160a
    bsf     0x0a, 0x3                ; 09e5: 158a
    call    0x0655                   ; 09e6: 2655
    bcf     0x0a, 0x4                ; 09e7: 120a
    bsf     0x0a, 0x3                ; 09e8: 158a
    bsf     0x03, 0x5                ; 09e9: 1683
    movwf   0x52                     ; 09ea: 00d2
    bsf     0x03, 0x5                ; 09eb: 1683
    bcf     0x03, 0x6                ; 09ec: 1303
    movf    0x52, 0x1                ; 09ed: 08d2
    btfsc   0x03, 0x2                ; 09ee: 1903
    goto    0x01f7                   ; 09ef: 29f7
    bcf     0x03, 0x5                ; 09f0: 1283
    btfsc   0x12, 0x2                ; 09f1: 1912
    goto    0x01f7                   ; 09f2: 29f7
    bsf     0x12, 0x2                ; 09f3: 1512
    bsf     0x03, 0x5                ; 09f4: 1683
    bsf     0x03, 0x6                ; 09f5: 1703
    clrf    0x32                     ; 09f6: 01b2
    bsf     0x03, 0x5                ; 09f7: 1683
    bcf     0x03, 0x6                ; 09f8: 1303
    movf    0x52, 0x0                ; 09f9: 0852
    xorlw   0x0f                     ; 09fa: 3a0f
    bsf     0x03, 0x6                ; 09fb: 1703
    btfss   0x03, 0x2                ; 09fc: 1d03
    goto    0x0200                   ; 09fd: 2a00
    bsf     0x32, 0x6                ; 09fe: 1732
    goto    0x0201                   ; 09ff: 2a01
    bcf     0x32, 0x6                ; 0a00: 1332
    movf    0x34, 0x0                ; 0a01: 0834
    bcf     0x03, 0x6                ; 0a02: 1303
    xorwf   0x52, 0x0                ; 0a03: 0652
    btfsc   0x03, 0x2                ; 0a04: 1903
    goto    0x0214                   ; 0a05: 2a14
    movf    0x52, 0x1                ; 0a06: 08d2
    bsf     0x03, 0x6                ; 0a07: 1703
    btfss   0x03, 0x2                ; 0a08: 1d03
    goto    0x020d                   ; 0a09: 2a0d
    movf    0x34, 0x1                ; 0a0a: 08b4
    btfss   0x03, 0x2                ; 0a0b: 1d03
    goto    0x0214                   ; 0a0c: 2a14
    btfss   0x32, 0x3                ; 0a0d: 1db2
    goto    0x0211                   ; 0a0e: 2a11
    bsf     0x32, 0x4                ; 0a0f: 1632
    goto    0x0214                   ; 0a10: 2a14
    bcf     0x03, 0x6                ; 0a11: 1303
    clrf    0x56                     ; 0a12: 01d6
    clrf    0x57                     ; 0a13: 01d7
    bcf     0x03, 0x6                ; 0a14: 1303
    movf    0x52, 0x0                ; 0a15: 0852
    bsf     0x03, 0x6                ; 0a16: 1703
    movwf   0x34                     ; 0a17: 00b4
    goto    0x07fe                   ; 0a18: 2ffe
    bsf     0x0a, 0x4                ; 0a19: 160a
    bsf     0x0a, 0x3                ; 0a1a: 158a
    call    0x0625                   ; 0a1b: 2625
    movwf   0x53                     ; 0a1c: 00d3
    clrf    0x54                     ; 0a1d: 01d4
    movwf   0x51                     ; 0a1e: 00d1
    movf    0x54, 0x0                ; 0a1f: 0854
    movwf   0x52                     ; 0a20: 00d2
    movf    0x51, 0x0                ; 0a21: 0851
    movwf   0x4f                     ; 0a22: 00cf
    movf    0x52, 0x0                ; 0a23: 0852
    movwf   0x50                     ; 0a24: 00d0
    bsf     0x0a, 0x4                ; 0a25: 160a
    bsf     0x0a, 0x3                ; 0a26: 158a
    call    0x0673                   ; 0a27: 2673
    bcf     0x0a, 0x4                ; 0a28: 120a
    bsf     0x0a, 0x3                ; 0a29: 158a
    movwf   0x53                     ; 0a2a: 00d3
    clrf    0x54                     ; 0a2b: 01d4
    xorlw   0x02                     ; 0a2c: 3a02
    iorwf   0x54, 0x0                ; 0a2d: 0454
    btfsc   0x03, 0x2                ; 0a2e: 1903
    goto    0x023a                   ; 0a2f: 2a3a
    movf    0x53, 0x0                ; 0a30: 0853
    xorlw   0x04                     ; 0a31: 3a04
    iorwf   0x54, 0x0                ; 0a32: 0454
    btfsc   0x03, 0x2                ; 0a33: 1903
    goto    0x023a                   ; 0a34: 2a3a
    movf    0x53, 0x0                ; 0a35: 0853
    xorlw   0x06                     ; 0a36: 3a06
    iorwf   0x54, 0x0                ; 0a37: 0454
    btfss   0x03, 0x2                ; 0a38: 1d03
    goto    0x0247                   ; 0a39: 2a47
    bsf     0x0a, 0x4                ; 0a3a: 160a
    bsf     0x0a, 0x3                ; 0a3b: 158a
    call    0x0697                   ; 0a3c: 2697
    iorlw   0x00                     ; 0a3d: 3800
    btfss   0x03, 0x2                ; 0a3e: 1d03
    bsf     0x51, 0x0                ; 0a3f: 1451
    movf    0x51, 0x0                ; 0a40: 0851
    bsf     0x0a, 0x4                ; 0a41: 160a
    bsf     0x0a, 0x3                ; 0a42: 158a
    call    0x07d5                   ; 0a43: 27d5
    bcf     0x0a, 0x4                ; 0a44: 120a
    bsf     0x0a, 0x3                ; 0a45: 158a
    goto    0x027c                   ; 0a46: 2a7c
    movf    0x53, 0x0                ; 0a47: 0853
    xorlw   0x03                     ; 0a48: 3a03
    iorwf   0x54, 0x0                ; 0a49: 0454
    btfsc   0x03, 0x2                ; 0a4a: 1903
    goto    0x0256                   ; 0a4b: 2a56
    movf    0x53, 0x0                ; 0a4c: 0853
    xorlw   0x05                     ; 0a4d: 3a05
    iorwf   0x54, 0x0                ; 0a4e: 0454
    btfsc   0x03, 0x2                ; 0a4f: 1903
    goto    0x0256                   ; 0a50: 2a56
    movf    0x53, 0x0                ; 0a51: 0853
    xorlw   0x07                     ; 0a52: 3a07
    iorwf   0x54, 0x0                ; 0a53: 0454
    btfss   0x03, 0x2                ; 0a54: 1d03
    goto    0x025f                   ; 0a55: 2a5f
    bsf     0x0a, 0x4                ; 0a56: 160a
    bsf     0x0a, 0x3                ; 0a57: 158a
    call    0x0697                   ; 0a58: 2697
    bcf     0x0a, 0x4                ; 0a59: 120a
    bsf     0x0a, 0x3                ; 0a5a: 158a
    iorlw   0x00                     ; 0a5b: 3800
    btfss   0x03, 0x2                ; 0a5c: 1d03
    bsf     0x4f, 0x0                ; 0a5d: 144f
    goto    0x0276                   ; 0a5e: 2a76
    decf    0x53, 0x0                ; 0a5f: 0353
    iorwf   0x54, 0x0                ; 0a60: 0454
    btfsc   0x03, 0x2                ; 0a61: 1903
    goto    0x0268                   ; 0a62: 2a68
    movf    0x53, 0x0                ; 0a63: 0853
    xorlw   0x0d                     ; 0a64: 3a0d
    iorwf   0x54, 0x0                ; 0a65: 0454
    btfss   0x03, 0x2                ; 0a66: 1d03
    goto    0x027c                   ; 0a67: 2a7c
    bsf     0x0a, 0x4                ; 0a68: 160a
    bsf     0x0a, 0x3                ; 0a69: 158a
    call    0x0697                   ; 0a6a: 2697
    bcf     0x0a, 0x4                ; 0a6b: 120a
    bsf     0x0a, 0x3                ; 0a6c: 158a
    iorlw   0x00                     ; 0a6d: 3800
    btfsc   0x03, 0x2                ; 0a6e: 1903
    goto    0x0272                   ; 0a6f: 2a72
    bsf     0x51, 0x0                ; 0a70: 1451
    bsf     0x4f, 0x0                ; 0a71: 144f
    movf    0x51, 0x0                ; 0a72: 0851
    bsf     0x0a, 0x4                ; 0a73: 160a
    bsf     0x0a, 0x3                ; 0a74: 158a
    call    0x07d5                   ; 0a75: 27d5
    movf    0x4f, 0x0                ; 0a76: 084f
    bsf     0x0a, 0x4                ; 0a77: 160a
    bsf     0x0a, 0x3                ; 0a78: 158a
    call    0x07aa                   ; 0a79: 27aa
    bcf     0x0a, 0x4                ; 0a7a: 120a
    bsf     0x0a, 0x3                ; 0a7b: 158a
    movf    0x50, 0x0                ; 0a7c: 0850
    iorwf   0x4f, 0x0                ; 0a7d: 044f
    btfss   0x03, 0x2                ; 0a7e: 1d03
    goto    0x028c                   ; 0a7f: 2a8c
    movf    0x52, 0x0                ; 0a80: 0852
    iorwf   0x51, 0x0                ; 0a81: 0451
    btfss   0x03, 0x2                ; 0a82: 1d03
    goto    0x028c                   ; 0a83: 2a8c
    bsf     0x0a, 0x4                ; 0a84: 160a
    bsf     0x0a, 0x3                ; 0a85: 158a
    call    0x0697                   ; 0a86: 2697
    bcf     0x0a, 0x4                ; 0a87: 120a
    bsf     0x0a, 0x3                ; 0a88: 158a
    iorlw   0x00                     ; 0a89: 3800
    btfsc   0x03, 0x2                ; 0a8a: 1903
    goto    0x028f                   ; 0a8b: 2a8f
    bsf     0x03, 0x5                ; 0a8c: 1683
    bsf     0x4e, 0x0                ; 0a8d: 144e
    goto    0x0294                   ; 0a8e: 2a94
    bcf     0x0a, 0x4                ; 0a8f: 120a
    bcf     0x0a, 0x3                ; 0a90: 118a
    call    0x0521                   ; 0a91: 2521
    bcf     0x0a, 0x4                ; 0a92: 120a
    bsf     0x0a, 0x3                ; 0a93: 158a
    bcf     0x03, 0x5                ; 0a94: 1283
    bsf     0x03, 0x6                ; 0a95: 1703
    movf    0x22, 0x0                ; 0a96: 0822
    xorlw   0x02                     ; 0a97: 3a02
    btfsc   0x03, 0x2                ; 0a98: 1903
    goto    0x029e                   ; 0a99: 2a9e
    movf    0x22, 0x0                ; 0a9a: 0822
    xorlw   0x03                     ; 0a9b: 3a03
    btfss   0x03, 0x2                ; 0a9c: 1d03
    goto    0x02ad                   ; 0a9d: 2aad
    movf    0x3a, 0x0                ; 0a9e: 083a
    andlw   0x0f                     ; 0a9f: 390f
    bsf     0x03, 0x5                ; 0aa0: 1683
    bcf     0x03, 0x6                ; 0aa1: 1303
    movwf   0x52                     ; 0aa2: 00d2
    bsf     0x0a, 0x4                ; 0aa3: 160a
    bsf     0x0a, 0x3                ; 0aa4: 158a
    call    0x063d                   ; 0aa5: 263d
    movwf   0x56                     ; 0aa6: 00d6
    bsf     0x0a, 0x4                ; 0aa7: 160a
    bsf     0x0a, 0x3                ; 0aa8: 158a
    call    0x06a5                   ; 0aa9: 26a5
    bcf     0x0a, 0x4                ; 0aaa: 120a
    bsf     0x0a, 0x3                ; 0aab: 158a
    goto    0x02c1                   ; 0aac: 2ac1
    movf    0x22, 0x0                ; 0aad: 0822
    xorlw   0x04                     ; 0aae: 3a04
    btfsc   0x03, 0x2                ; 0aaf: 1903
    goto    0x02b5                   ; 0ab0: 2ab5
    movf    0x22, 0x0                ; 0ab1: 0822
    xorlw   0x05                     ; 0ab2: 3a05
    btfss   0x03, 0x2                ; 0ab3: 1d03
    goto    0x02d1                   ; 0ab4: 2ad1
    movf    0x3a, 0x0                ; 0ab5: 083a
    andlw   0x0f                     ; 0ab6: 390f
    bsf     0x03, 0x5                ; 0ab7: 1683
    bcf     0x03, 0x6                ; 0ab8: 1303
    movwf   0x52                     ; 0ab9: 00d2
    bsf     0x0a, 0x4                ; 0aba: 160a
    bsf     0x0a, 0x3                ; 0abb: 158a
    call    0x0637                   ; 0abc: 2637
    movwf   0x56                     ; 0abd: 00d6
    bsf     0x0a, 0x4                ; 0abe: 160a
    bsf     0x0a, 0x3                ; 0abf: 158a
    call    0x06b4                   ; 0ac0: 26b4
    bsf     0x0a, 0x4                ; 0ac1: 160a
    bcf     0x0a, 0x3                ; 0ac2: 118a
    call    0x01e7                   ; 0ac3: 21e7
    bcf     0x0a, 0x4                ; 0ac4: 120a
    bsf     0x0a, 0x3                ; 0ac5: 158a
    bsf     0x03, 0x5                ; 0ac6: 1683
    movf    0x52, 0x1                ; 0ac7: 08d2
    btfsc   0x03, 0x2                ; 0ac8: 1903
    goto    0x02d1                   ; 0ac9: 2ad1
    bcf     0x03, 0x5                ; 0aca: 1283
    btfsc   0x12, 0x2                ; 0acb: 1912
    goto    0x02d1                   ; 0acc: 2ad1
    bsf     0x12, 0x2                ; 0acd: 1512
    bsf     0x03, 0x5                ; 0ace: 1683
    bsf     0x03, 0x6                ; 0acf: 1703
    clrf    0x32                     ; 0ad0: 01b2
    bsf     0x0a, 0x4                ; 0ad1: 160a
    bsf     0x0a, 0x3                ; 0ad2: 158a
    call    0x062b                   ; 0ad3: 262b
    bcf     0x0a, 0x4                ; 0ad4: 120a
    bsf     0x0a, 0x3                ; 0ad5: 158a
    call    0x0046                   ; 0ad6: 2046
    goto    0x07fe                   ; 0ad7: 2ffe
    bsf     0x0a, 0x4                ; 0ad8: 160a
    bsf     0x0a, 0x3                ; 0ad9: 158a
    call    0x0673                   ; 0ada: 2673
    bcf     0x0a, 0x4                ; 0adb: 120a
    bsf     0x0a, 0x3                ; 0adc: 158a
    movwf   0x53                     ; 0add: 00d3
    clrf    0x54                     ; 0ade: 01d4
    movf    0x54, 0x0                ; 0adf: 0854
    xorlw   0x80                     ; 0ae0: 3a80
    movwf   0x70                     ; 0ae1: 00f0
    movlw   0x80                     ; 0ae2: 3080
    subwf   0x70, 0x0                ; 0ae3: 0270
    movlw   0x02                     ; 0ae4: 3002
    btfsc   0x03, 0x2                ; 0ae5: 1903
    subwf   0x53, 0x0                ; 0ae6: 0253
    btfss   0x03, 0x0                ; 0ae7: 1c03
    goto    0x02f3                   ; 0ae8: 2af3
    movf    0x54, 0x0                ; 0ae9: 0854
    xorlw   0x80                     ; 0aea: 3a80
    movwf   0x70                     ; 0aeb: 00f0
    movlw   0x80                     ; 0aec: 3080
    subwf   0x70, 0x0                ; 0aed: 0270
    movlw   0x08                     ; 0aee: 3008
    btfsc   0x03, 0x2                ; 0aef: 1903
    subwf   0x53, 0x0                ; 0af0: 0253
    btfss   0x03, 0x0                ; 0af1: 1c03
    goto    0x0608                   ; 0af2: 2e08
    decf    0x53, 0x0                ; 0af3: 0353
    iorwf   0x54, 0x0                ; 0af4: 0454
    btfss   0x03, 0x2                ; 0af5: 1d03
    goto    0x07fe                   ; 0af6: 2ffe
    bsf     0x0a, 0x4                ; 0af7: 160a
    bsf     0x0a, 0x3                ; 0af8: 158a
    call    0x0613                   ; 0af9: 2613
    bcf     0x0a, 0x4                ; 0afa: 120a
    bsf     0x0a, 0x3                ; 0afb: 158a
    xorlw   0x01                     ; 0afc: 3a01
    btfss   0x03, 0x2                ; 0afd: 1d03
    goto    0x07fe                   ; 0afe: 2ffe
    goto    0x0608                   ; 0aff: 2e08
    bsf     0x03, 0x6                ; 0b00: 1703
    movf    0x27, 0x0                ; 0b01: 0827
    andlw   0xcf                     ; 0b02: 39cf
    iorlw   0x20                     ; 0b03: 3820
    movwf   0x27                     ; 0b04: 00a7
    andlw   0x3f                     ; 0b05: 393f
    movwf   0x27                     ; 0b06: 00a7
    bsf     0x03, 0x5                ; 0b07: 1683
    bcf     0x03, 0x6                ; 0b08: 1303
    movwf   0x44                     ; 0b09: 00c4
    goto    0x0337                   ; 0b0a: 2b37
    bsf     0x0a, 0x4                ; 0b0b: 160a
    bsf     0x0a, 0x3                ; 0b0c: 158a
    call    0x0673                   ; 0b0d: 2673
    bcf     0x0a, 0x4                ; 0b0e: 120a
    bsf     0x0a, 0x3                ; 0b0f: 158a
    xorlw   0x02                     ; 0b10: 3a02
    goto    0x031f                   ; 0b11: 2b1f
    bsf     0x0a, 0x4                ; 0b12: 160a
    bsf     0x0a, 0x3                ; 0b13: 158a
    call    0x0673                   ; 0b14: 2673
    bcf     0x0a, 0x4                ; 0b15: 120a
    bsf     0x0a, 0x3                ; 0b16: 158a
    xorlw   0x04                     ; 0b17: 3a04
    goto    0x031f                   ; 0b18: 2b1f
    bsf     0x0a, 0x4                ; 0b19: 160a
    bsf     0x0a, 0x3                ; 0b1a: 158a
    call    0x0673                   ; 0b1b: 2673
    bcf     0x0a, 0x4                ; 0b1c: 120a
    bsf     0x0a, 0x3                ; 0b1d: 158a
    xorlw   0x06                     ; 0b1e: 3a06
    bsf     0x03, 0x5                ; 0b1f: 1683
    bsf     0x03, 0x6                ; 0b20: 1703
    btfss   0x03, 0x2                ; 0b21: 1d03
    goto    0x032a                   ; 0b22: 2b2a
    movf    0x39, 0x0                ; 0b23: 0839
    bcf     0x03, 0x6                ; 0b24: 1303
    movwf   0x45                     ; 0b25: 00c5
    bsf     0x03, 0x6                ; 0b26: 1703
    bcf     0x39, 0x2                ; 0b27: 1139
    bcf     0x39, 0x3                ; 0b28: 11b9
    goto    0x0330                   ; 0b29: 2b30
    movf    0x3a, 0x0                ; 0b2a: 083a
    bcf     0x03, 0x6                ; 0b2b: 1303
    movwf   0x45                     ; 0b2c: 00c5
    bsf     0x03, 0x6                ; 0b2d: 1703
    bcf     0x3a, 0x2                ; 0b2e: 113a
    bcf     0x3a, 0x3                ; 0b2f: 11ba
    bcf     0x03, 0x6                ; 0b30: 1303
    clrf    0x46                     ; 0b31: 01c6
    movf    0x44, 0x0                ; 0b32: 0844
    addwf   0x46, 0x1                ; 0b33: 07c6
    movf    0x45, 0x0                ; 0b34: 0845
    addwf   0x46, 0x1                ; 0b35: 07c6
    goto    0x05eb                   ; 0b36: 2deb
    bcf     0x03, 0x5                ; 0b37: 1283
    bsf     0x03, 0x6                ; 0b38: 1703
    movf    0x22, 0x0                ; 0b39: 0822
    xorlw   0x02                     ; 0b3a: 3a02
    btfsc   0x03, 0x2                ; 0b3b: 1903
    goto    0x030b                   ; 0b3c: 2b0b
    xorlw   0x06                     ; 0b3d: 3a06
    btfsc   0x03, 0x2                ; 0b3e: 1903
    goto    0x0312                   ; 0b3f: 2b12
    xorlw   0x02                     ; 0b40: 3a02
    btfsc   0x03, 0x2                ; 0b41: 1903
    goto    0x0319                   ; 0b42: 2b19
    goto    0x0628                   ; 0b43: 2e28
    bsf     0x03, 0x5                ; 0b44: 1683
    bsf     0x4e, 0x1                ; 0b45: 14ce
    bcf     0x0a, 0x4                ; 0b46: 120a
    bcf     0x0a, 0x3                ; 0b47: 118a
    call    0x0521                   ; 0b48: 2521
    bsf     0x03, 0x5                ; 0b49: 1683
    bsf     0x03, 0x6                ; 0b4a: 1703
    clrf    0x35                     ; 0b4b: 01b5
    clrf    0x36                     ; 0b4c: 01b6
    clrf    0x37                     ; 0b4d: 01b7
    clrf    0x38                     ; 0b4e: 01b8
    clrf    0x39                     ; 0b4f: 01b9
    clrf    0x3a                     ; 0b50: 01ba
    bsf     0x39, 0x2                ; 0b51: 1539
    bsf     0x3a, 0x2                ; 0b52: 153a
    bcf     0x03, 0x6                ; 0b53: 1303
    bsf     0x4e, 0x7                ; 0b54: 17ce
    bsf     0x03, 0x6                ; 0b55: 1703
    clrf    0x10                     ; 0b56: 0190
    bcf     0x03, 0x5                ; 0b57: 1283
    bcf     0x03, 0x6                ; 0b58: 1303
    clrf    0x3f                     ; 0b59: 01bf
    movlw   0x00                     ; 0b5a: 3000
    bsf     0x0a, 0x4                ; 0b5b: 160a
    bsf     0x0a, 0x3                ; 0b5c: 158a
    call    0x07d5                   ; 0b5d: 27d5
    movlw   0x00                     ; 0b5e: 3000
    bsf     0x0a, 0x4                ; 0b5f: 160a
    bsf     0x0a, 0x3                ; 0b60: 158a
    call    0x07aa                   ; 0b61: 27aa
    bcf     0x0a, 0x4                ; 0b62: 120a
    bsf     0x0a, 0x3                ; 0b63: 158a
    movf    0x36, 0x0                ; 0b64: 0836
    movwf   0x06                     ; 0b65: 0086
    movf    0x37, 0x0                ; 0b66: 0837
    movwf   0x07                     ; 0b67: 0087
    movf    0x38, 0x0                ; 0b68: 0838
    movwf   0x08                     ; 0b69: 0088
    clrf    0x3d                     ; 0b6a: 01bd
    clrf    0x40                     ; 0b6b: 01c0
    incf    0x40, 0x1                ; 0b6c: 0ac0
    movlw   0x2a                     ; 0b6d: 302a
    subwf   0x40, 0x0                ; 0b6e: 0240
    btfss   0x03, 0x0                ; 0b6f: 1c03
    goto    0x036c                   ; 0b70: 2b6c
    clrf    0x3e                     ; 0b71: 01be
    incf    0x3e, 0x1                ; 0b72: 0abe
    movf    0x3d, 0x1                ; 0b73: 08bd
    btfsc   0x03, 0x2                ; 0b74: 1903
    goto    0x037d                   ; 0b75: 2b7d
    clrf    0x3d                     ; 0b76: 01bd
    movf    0x3e, 0x0                ; 0b77: 083e
    xorlw   0x80                     ; 0b78: 3a80
    btfsc   0x03, 0x2                ; 0b79: 1903
    goto    0x037d                   ; 0b7a: 2b7d
    bcf     0x03, 0x0                ; 0b7b: 1003
    rrf     0x3e, 0x1                ; 0b7c: 0cbe
    movlw   0x07                     ; 0b7d: 3007
    bsf     0x0a, 0x4                ; 0b7e: 160a
    bcf     0x0a, 0x3                ; 0b7f: 118a
    call    0x0000                   ; 0b80: 2000
    bcf     0x0a, 0x4                ; 0b81: 120a
    bsf     0x0a, 0x3                ; 0b82: 158a
    movf    0x70, 0x0                ; 0b83: 0870
    movwf   0x4d                     ; 0b84: 00cd
    movf    0x71, 0x0                ; 0b85: 0871
    movwf   0x4e                     ; 0b86: 00ce
    movlw   0x00                     ; 0b87: 3000
    subwf   0x4e, 0x0                ; 0b88: 024e
    movlw   0x95                     ; 0b89: 3095
    btfsc   0x03, 0x2                ; 0b8a: 1903
    subwf   0x4d, 0x0                ; 0b8b: 024d
    btfsc   0x03, 0x0                ; 0b8c: 1803
    goto    0x0394                   ; 0b8d: 2b94
    clrf    0x40                     ; 0b8e: 01c0
    incf    0x40, 0x1                ; 0b8f: 0ac0
    movlw   0x69                     ; 0b90: 3069
    subwf   0x40, 0x0                ; 0b91: 0240
    btfss   0x03, 0x0                ; 0b92: 1c03
    goto    0x038f                   ; 0b93: 2b8f
    movlw   0x00                     ; 0b94: 3000
    subwf   0x4e, 0x0                ; 0b95: 024e
    movlw   0x95                     ; 0b96: 3095
    btfsc   0x03, 0x2                ; 0b97: 1903
    subwf   0x4d, 0x0                ; 0b98: 024d
    bsf     0x03, 0x5                ; 0b99: 1683
    btfsc   0x03, 0x0                ; 0b9a: 1803
    goto    0x039e                   ; 0b9b: 2b9e
    btfsc   0x4e, 0x7                ; 0b9c: 1bce
    goto    0x037d                   ; 0b9d: 2b7d
    btfss   0x4e, 0x7                ; 0b9e: 1fce
    goto    0x0475                   ; 0b9f: 2c75
    movlw   0x05                     ; 0ba0: 3005
    bsf     0x0a, 0x4                ; 0ba1: 160a
    bcf     0x0a, 0x3                ; 0ba2: 118a
    call    0x0000                   ; 0ba3: 2000
    bcf     0x0a, 0x4                ; 0ba4: 120a
    bsf     0x0a, 0x3                ; 0ba5: 158a
    movf    0x70, 0x0                ; 0ba6: 0870
    movwf   0x49                     ; 0ba7: 00c9
    movf    0x71, 0x0                ; 0ba8: 0871
    movwf   0x4a                     ; 0ba9: 00ca
    movf    0x3f, 0x1                ; 0baa: 08bf
    btfsc   0x03, 0x2                ; 0bab: 1903
    goto    0x03b4                   ; 0bac: 2bb4
    movf    0x3e, 0x0                ; 0bad: 083e
    bsf     0x0a, 0x4                ; 0bae: 160a
    bsf     0x0a, 0x3                ; 0baf: 158a
    call    0x07aa                   ; 0bb0: 27aa
    bcf     0x0a, 0x4                ; 0bb1: 120a
    bsf     0x0a, 0x3                ; 0bb2: 158a
    goto    0x03ba                   ; 0bb3: 2bba
    movf    0x3e, 0x0                ; 0bb4: 083e
    bsf     0x0a, 0x4                ; 0bb5: 160a
    bsf     0x0a, 0x3                ; 0bb6: 158a
    call    0x07d5                   ; 0bb7: 27d5
    bcf     0x0a, 0x4                ; 0bb8: 120a
    bsf     0x0a, 0x3                ; 0bb9: 158a
    movlw   0x94                     ; 0bba: 3094
    movwf   0x1f                     ; 0bbb: 009f
    bsf     0x03, 0x5                ; 0bbc: 1683
    clrf    0x1f                     ; 0bbd: 019f
    bcf     0x03, 0x5                ; 0bbe: 1283
    bsf     0x1f, 0x0                ; 0bbf: 141f
    bcf     0x0c, 0x6                ; 0bc0: 130c
    movf    0x36, 0x0                ; 0bc1: 0836
    movwf   0x06                     ; 0bc2: 0086
    movf    0x37, 0x0                ; 0bc3: 0837
    movwf   0x07                     ; 0bc4: 0087
    movf    0x38, 0x0                ; 0bc5: 0838
    movwf   0x08                     ; 0bc6: 0088
    clrf    0x40                     ; 0bc7: 01c0
    incf    0x40, 0x1                ; 0bc8: 0ac0
    movlw   0x03                     ; 0bc9: 3003
    subwf   0x40, 0x0                ; 0bca: 0240
    btfss   0x03, 0x0                ; 0bcb: 1c03
    goto    0x03c8                   ; 0bcc: 2bc8
    bsf     0x1f, 0x1                ; 0bcd: 149f
    btfss   0x0c, 0x6                ; 0bce: 1f0c
    goto    0x03ce                   ; 0bcf: 2bce
    movlw   0x0f                     ; 0bd0: 300f
    iorwf   0x06, 0x1                ; 0bd1: 0486
    iorwf   0x07, 0x1                ; 0bd2: 0487
    movlw   0xff                     ; 0bd3: 30ff
    movwf   0x08                     ; 0bd4: 0088
    movf    0x1e, 0x0                ; 0bd5: 081e
    movwf   0x46                     ; 0bd6: 00c6
    bsf     0x03, 0x5                ; 0bd7: 1683
    movf    0x1e, 0x0                ; 0bd8: 081e
    bcf     0x03, 0x5                ; 0bd9: 1283
    movwf   0x45                     ; 0bda: 00c5
    bcf     0x0c, 0x6                ; 0bdb: 130c
    movlw   0x50                     ; 0bdc: 3050
    bsf     0x03, 0x5                ; 0bdd: 1683
    movwf   0x1f                     ; 0bde: 009f
    movlw   0x00                     ; 0bdf: 3000
    bsf     0x0a, 0x4                ; 0be0: 160a
    bsf     0x0a, 0x3                ; 0be1: 158a
    call    0x07d5                   ; 0be2: 27d5
    movlw   0x00                     ; 0be3: 3000
    bsf     0x0a, 0x4                ; 0be4: 160a
    bsf     0x0a, 0x3                ; 0be5: 158a
    call    0x07aa                   ; 0be6: 27aa
    bcf     0x0a, 0x4                ; 0be7: 120a
    bsf     0x0a, 0x3                ; 0be8: 158a
    movf    0x36, 0x0                ; 0be9: 0836
    movwf   0x06                     ; 0bea: 0086
    movf    0x37, 0x0                ; 0beb: 0837
    movwf   0x07                     ; 0bec: 0087
    movf    0x38, 0x0                ; 0bed: 0838
    movwf   0x08                     ; 0bee: 0088
    clrf    0x40                     ; 0bef: 01c0
    incf    0x40, 0x1                ; 0bf0: 0ac0
    movlw   0x02                     ; 0bf1: 3002
    subwf   0x40, 0x0                ; 0bf2: 0240
    btfss   0x03, 0x0                ; 0bf3: 1c03
    goto    0x03f0                   ; 0bf4: 2bf0
    movlw   0x05                     ; 0bf5: 3005
    bsf     0x0a, 0x4                ; 0bf6: 160a
    bcf     0x0a, 0x3                ; 0bf7: 118a
    call    0x0000                   ; 0bf8: 2000
    movf    0x70, 0x0                ; 0bf9: 0870
    movwf   0x4b                     ; 0bfa: 00cb
    movf    0x71, 0x0                ; 0bfb: 0871
    movwf   0x4c                     ; 0bfc: 00cc
    movlw   0x07                     ; 0bfd: 3007
    bsf     0x0a, 0x4                ; 0bfe: 160a
    bcf     0x0a, 0x3                ; 0bff: 118a
    call    0x0000                   ; 0c00: 2000
    bcf     0x0a, 0x4                ; 0c01: 120a
    bsf     0x0a, 0x3                ; 0c02: 158a
    movf    0x70, 0x0                ; 0c03: 0870
    movwf   0x4d                     ; 0c04: 00cd
    movf    0x71, 0x0                ; 0c05: 0871
    movwf   0x4e                     ; 0c06: 00ce
    movf    0x4a, 0x0                ; 0c07: 084a
    subwf   0x4c, 0x0                ; 0c08: 024c
    btfss   0x03, 0x2                ; 0c09: 1d03
    goto    0x040d                   ; 0c0a: 2c0d
    movf    0x49, 0x0                ; 0c0b: 0849
    subwf   0x4b, 0x0                ; 0c0c: 024b
    btfsc   0x03, 0x0                ; 0c0d: 1803
    goto    0x041b                   ; 0c0e: 2c1b
    movf    0x4b, 0x0                ; 0c0f: 084b
    subwf   0x49, 0x0                ; 0c10: 0249
    movwf   0x41                     ; 0c11: 00c1
    movf    0x4c, 0x0                ; 0c12: 084c
    btfss   0x03, 0x0                ; 0c13: 1c03
    incf    0x4c, 0x0                ; 0c14: 0a4c
    subwf   0x4a, 0x0                ; 0c15: 024a
    movwf   0x42                     ; 0c16: 00c2
    movf    0x49, 0x0                ; 0c17: 0849
    movwf   0x47                     ; 0c18: 00c7
    movf    0x4a, 0x0                ; 0c19: 084a
    goto    0x0426                   ; 0c1a: 2c26
    movf    0x49, 0x0                ; 0c1b: 0849
    subwf   0x4b, 0x0                ; 0c1c: 024b
    movwf   0x41                     ; 0c1d: 00c1
    movf    0x4a, 0x0                ; 0c1e: 084a
    btfss   0x03, 0x0                ; 0c1f: 1c03
    incf    0x4a, 0x0                ; 0c20: 0a4a
    subwf   0x4c, 0x0                ; 0c21: 024c
    movwf   0x42                     ; 0c22: 00c2
    movf    0x4b, 0x0                ; 0c23: 084b
    movwf   0x47                     ; 0c24: 00c7
    movf    0x4c, 0x0                ; 0c25: 084c
    movwf   0x48                     ; 0c26: 00c8
    subwf   0x46, 0x0                ; 0c27: 0246
    btfss   0x03, 0x2                ; 0c28: 1d03
    goto    0x042c                   ; 0c29: 2c2c
    movf    0x47, 0x0                ; 0c2a: 0847
    subwf   0x45, 0x0                ; 0c2b: 0245
    btfsc   0x03, 0x0                ; 0c2c: 1803
    goto    0x0436                   ; 0c2d: 2c36
    movf    0x45, 0x0                ; 0c2e: 0845
    subwf   0x47, 0x0                ; 0c2f: 0247
    movwf   0x43                     ; 0c30: 00c3
    movf    0x46, 0x0                ; 0c31: 0846
    btfss   0x03, 0x0                ; 0c32: 1c03
    incf    0x46, 0x0                ; 0c33: 0a46
    subwf   0x48, 0x0                ; 0c34: 0248
    goto    0x043d                   ; 0c35: 2c3d
    movf    0x47, 0x0                ; 0c36: 0847
    subwf   0x45, 0x0                ; 0c37: 0245
    movwf   0x43                     ; 0c38: 00c3
    movf    0x48, 0x0                ; 0c39: 0848
    btfss   0x03, 0x0                ; 0c3a: 1c03
    incf    0x48, 0x0                ; 0c3b: 0a48
    subwf   0x46, 0x0                ; 0c3c: 0246
    movwf   0x44                     ; 0c3d: 00c4
    movlw   0x00                     ; 0c3e: 3000
    subwf   0x4e, 0x0                ; 0c3f: 024e
    movlw   0x96                     ; 0c40: 3096
    btfsc   0x03, 0x2                ; 0c41: 1903
    subwf   0x4d, 0x0                ; 0c42: 024d
    btfss   0x03, 0x0                ; 0c43: 1c03
    goto    0x046d                   ; 0c44: 2c6d
    movlw   0x00                     ; 0c45: 3000
    subwf   0x42, 0x0                ; 0c46: 0242
    movlw   0x0b                     ; 0c47: 300b
    btfsc   0x03, 0x2                ; 0c48: 1903
    subwf   0x41, 0x0                ; 0c49: 0241
    clrf    0x3d                     ; 0c4a: 01bd
    btfsc   0x03, 0x0                ; 0c4b: 1803
    goto    0x046e                   ; 0c4c: 2c6e
    bsf     0x03, 0x5                ; 0c4d: 1683
    bsf     0x03, 0x6                ; 0c4e: 1703
    movf    0x33, 0x0                ; 0c4f: 0833
    movwf   0x70                     ; 0c50: 00f0
    clrf    0x71                     ; 0c51: 01f1
    bcf     0x03, 0x5                ; 0c52: 1283
    bcf     0x03, 0x6                ; 0c53: 1303
    movf    0x44, 0x0                ; 0c54: 0844
    xorlw   0x80                     ; 0c55: 3a80
    movwf   0x72                     ; 0c56: 00f2
    movf    0x71, 0x0                ; 0c57: 0871
    xorlw   0x80                     ; 0c58: 3a80
    subwf   0x72, 0x0                ; 0c59: 0272
    btfss   0x03, 0x2                ; 0c5a: 1d03
    goto    0x045e                   ; 0c5b: 2c5e
    movf    0x70, 0x0                ; 0c5c: 0870
    subwf   0x43, 0x0                ; 0c5d: 0243
    btfsc   0x03, 0x0                ; 0c5e: 1803
    goto    0x0475                   ; 0c5f: 2c75
    movf    0x3f, 0x1                ; 0c60: 08bf
    btfsc   0x03, 0x2                ; 0c61: 1903
    goto    0x0468                   ; 0c62: 2c68
    movf    0x3e, 0x0                ; 0c63: 083e
    bsf     0x03, 0x5                ; 0c64: 1683
    bsf     0x03, 0x6                ; 0c65: 1703
    iorwf   0x37, 0x1                ; 0c66: 04b7
    goto    0x0475                   ; 0c67: 2c75
    movf    0x3e, 0x0                ; 0c68: 083e
    bsf     0x03, 0x5                ; 0c69: 1683
    bsf     0x03, 0x6                ; 0c6a: 1703
    iorwf   0x35, 0x1                ; 0c6b: 04b5
    goto    0x0475                   ; 0c6c: 2c75
    clrf    0x3d                     ; 0c6d: 01bd
    incf    0x3d, 0x1                ; 0c6e: 0abd
    movf    0x3e, 0x0                ; 0c6f: 083e
    xorlw   0x80                     ; 0c70: 3a80
    btfss   0x03, 0x2                ; 0c71: 1d03
    goto    0x0475                   ; 0c72: 2c75
    movlw   0x40                     ; 0c73: 3040
    movwf   0x3e                     ; 0c74: 00be
    bcf     0x03, 0x0                ; 0c75: 1003
    bcf     0x03, 0x5                ; 0c76: 1283
    bcf     0x03, 0x6                ; 0c77: 1303
    rlf     0x3e, 0x1                ; 0c78: 0dbe
    movf    0x3e, 0x1                ; 0c79: 08be
    btfss   0x03, 0x2                ; 0c7a: 1d03
    goto    0x0373                   ; 0c7b: 2b73
    incf    0x3f, 0x1                ; 0c7c: 0abf
    movlw   0x02                     ; 0c7d: 3002
    subwf   0x3f, 0x0                ; 0c7e: 023f
    btfss   0x03, 0x0                ; 0c7f: 1c03
    goto    0x035a                   ; 0c80: 2b5a
    movlw   0x07                     ; 0c81: 3007
    bsf     0x0a, 0x4                ; 0c82: 160a
    bcf     0x0a, 0x3                ; 0c83: 118a
    call    0x0000                   ; 0c84: 2000
    bcf     0x0a, 0x4                ; 0c85: 120a
    bsf     0x0a, 0x3                ; 0c86: 158a
    movf    0x70, 0x0                ; 0c87: 0870
    movwf   0x4d                     ; 0c88: 00cd
    movf    0x71, 0x0                ; 0c89: 0871
    movwf   0x4e                     ; 0c8a: 00ce
    movlw   0x00                     ; 0c8b: 3000
    subwf   0x4e, 0x0                ; 0c8c: 024e
    movlw   0x95                     ; 0c8d: 3095
    btfsc   0x03, 0x2                ; 0c8e: 1903
    subwf   0x4d, 0x0                ; 0c8f: 024d
    btfsc   0x03, 0x0                ; 0c90: 1803
    goto    0x0498                   ; 0c91: 2c98
    clrf    0x40                     ; 0c92: 01c0
    incf    0x40, 0x1                ; 0c93: 0ac0
    movlw   0x69                     ; 0c94: 3069
    subwf   0x40, 0x0                ; 0c95: 0240
    btfss   0x03, 0x0                ; 0c96: 1c03
    goto    0x0493                   ; 0c97: 2c93
    movlw   0x00                     ; 0c98: 3000
    subwf   0x4e, 0x0                ; 0c99: 024e
    movlw   0x95                     ; 0c9a: 3095
    btfsc   0x03, 0x2                ; 0c9b: 1903
    subwf   0x4d, 0x0                ; 0c9c: 024d
    bsf     0x03, 0x5                ; 0c9d: 1683
    btfsc   0x03, 0x0                ; 0c9e: 1803
    goto    0x04a2                   ; 0c9f: 2ca2
    btfsc   0x4e, 0x7                ; 0ca0: 1bce
    goto    0x0481                   ; 0ca1: 2c81
    btfss   0x4e, 0x7                ; 0ca2: 1fce
    goto    0x04c3                   ; 0ca3: 2cc3
    bcf     0x03, 0x5                ; 0ca4: 1283
    movf    0x17, 0x0                ; 0ca5: 0817
    movwf   0x3c                     ; 0ca6: 00bc
    clrf    0x17                     ; 0ca7: 0197
    movlw   0x06                     ; 0ca8: 3006
    bsf     0x0a, 0x4                ; 0ca9: 160a
    bcf     0x0a, 0x3                ; 0caa: 118a
    call    0x0000                   ; 0cab: 2000
    bcf     0x0a, 0x4                ; 0cac: 120a
    bsf     0x0a, 0x3                ; 0cad: 158a
    movf    0x70, 0x0                ; 0cae: 0870
    movwf   0x53                     ; 0caf: 00d3
    movf    0x71, 0x0                ; 0cb0: 0871
    movwf   0x54                     ; 0cb1: 00d4
    xorlw   0x80                     ; 0cb2: 3a80
    movwf   0x70                     ; 0cb3: 00f0
    movlw   0x80                     ; 0cb4: 3080
    subwf   0x70, 0x0                ; 0cb5: 0270
    movlw   0xa5                     ; 0cb6: 30a5
    btfsc   0x03, 0x2                ; 0cb7: 1903
    subwf   0x53, 0x0                ; 0cb8: 0253
    btfsc   0x03, 0x0                ; 0cb9: 1803
    goto    0x04bf                   ; 0cba: 2cbf
    bsf     0x03, 0x5                ; 0cbb: 1683
    bsf     0x03, 0x6                ; 0cbc: 1703
    bsf     0x36, 0x0                ; 0cbd: 1436
    bsf     0x38, 0x0                ; 0cbe: 1438
    bcf     0x03, 0x5                ; 0cbf: 1283
    bcf     0x03, 0x6                ; 0cc0: 1303
    movf    0x3c, 0x0                ; 0cc1: 083c
    movwf   0x17                     ; 0cc2: 0097
    bcf     0x0a, 0x4                ; 0cc3: 120a
    bcf     0x0a, 0x3                ; 0cc4: 118a
    call    0x06db                   ; 0cc5: 26db
    bcf     0x0a, 0x4                ; 0cc6: 120a
    bsf     0x0a, 0x3                ; 0cc7: 158a
    bsf     0x03, 0x5                ; 0cc8: 1683
    btfsc   0x58, 0x3                ; 0cc9: 19d8
    goto    0x04cd                   ; 0cca: 2ccd
    btfsc   0x4e, 0x7                ; 0ccb: 1bce
    goto    0x04d7                   ; 0ccc: 2cd7
    bsf     0x03, 0x6                ; 0ccd: 1703
    bsf     0x39, 0x1                ; 0cce: 14b9
    bsf     0x39, 0x6                ; 0ccf: 1739
    bsf     0x39, 0x7                ; 0cd0: 17b9
    bsf     0x39, 0x0                ; 0cd1: 1439
    bsf     0x3a, 0x1                ; 0cd2: 14ba
    bsf     0x3a, 0x6                ; 0cd3: 173a
    bsf     0x3a, 0x7                ; 0cd4: 17ba
    bsf     0x3a, 0x0                ; 0cd5: 143a
    goto    0x0587                   ; 0cd6: 2d87
    bcf     0x03, 0x5                ; 0cd7: 1283
    clrf    0x3f                     ; 0cd8: 01bf
    movf    0x3f, 0x1                ; 0cd9: 08bf
    bsf     0x03, 0x5                ; 0cda: 1683
    bsf     0x03, 0x6                ; 0cdb: 1703
    btfsc   0x03, 0x2                ; 0cdc: 1903
    goto    0x04e2                   ; 0cdd: 2ce2
    movf    0x38, 0x0                ; 0cde: 0838
    movwf   0x71                     ; 0cdf: 00f1
    movf    0x37, 0x0                ; 0ce0: 0837
    goto    0x04e5                   ; 0ce1: 2ce5
    movf    0x36, 0x0                ; 0ce2: 0836
    movwf   0x71                     ; 0ce3: 00f1
    movf    0x35, 0x0                ; 0ce4: 0835
    movwf   0x70                     ; 0ce5: 00f0
    clrf    0x71                     ; 0ce6: 01f1
    bcf     0x03, 0x5                ; 0ce7: 1283
    bcf     0x03, 0x6                ; 0ce8: 1303
    movwf   0x53                     ; 0ce9: 00d3
    movf    0x71, 0x0                ; 0cea: 0871
    movwf   0x54                     ; 0ceb: 00d4
    xorlw   0x80                     ; 0cec: 3a80
    movwf   0x70                     ; 0ced: 00f0
    movlw   0x80                     ; 0cee: 3080
    subwf   0x70, 0x0                ; 0cef: 0270
    movlw   0x31                     ; 0cf0: 3031
    btfsc   0x03, 0x2                ; 0cf1: 1903
    subwf   0x53, 0x0                ; 0cf2: 0253
    btfss   0x03, 0x0                ; 0cf3: 1c03
    goto    0x04fc                   ; 0cf4: 2cfc
    goto    0x053f                   ; 0cf5: 2d3f
    movf    0x3f, 0x0                ; 0cf6: 083f
    addlw   0xb9                     ; 0cf7: 3eb9
    movwf   0x04                     ; 0cf8: 0084
    bsf     0x03, 0x7                ; 0cf9: 1783
    bcf     0x00, 0x6                ; 0cfa: 1300
    goto    0x0544                   ; 0cfb: 2d44
    movf    0x54, 0x0                ; 0cfc: 0854
    movwf   0x73                     ; 0cfd: 00f3
    movf    0x53, 0x0                ; 0cfe: 0853
    movwf   0x72                     ; 0cff: 00f2
    goto    0x053b                   ; 0d00: 2d3b
    movf    0x72, 0x0                ; 0d01: 0872
    movwf   0x70                     ; 0d02: 00f0
    addlw   0xd0                     ; 0d03: 3ed0
    btfsc   0x03, 0x0                ; 0d04: 1803
    goto    0x04f6                   ; 0d05: 2cf6
    addlw   0x29                     ; 0d06: 3e29
    btfss   0x03, 0x0                ; 0d07: 1c03
    goto    0x04f6                   ; 0d08: 2cf6
    movlw   0x07                     ; 0d09: 3007
    subwf   0x70, 0x1                ; 0d0a: 02f0
    movlw   0x0d                     ; 0d0b: 300d
    movwf   0x0a                     ; 0d0c: 008a
    movlw   0x12                     ; 0d0d: 3012
    addwf   0x70, 0x0                ; 0d0e: 0770
    btfsc   0x03, 0x0                ; 0d0f: 1803
    incf    0x0a, 0x1                ; 0d10: 0a8a
    movwf   0x02                     ; 0d11: 0082
    goto    0x053f                   ; 0d12: 2d3f
    goto    0x04f6                   ; 0d13: 2cf6
    goto    0x04f6                   ; 0d14: 2cf6
    goto    0x04f6                   ; 0d15: 2cf6
    goto    0x053f                   ; 0d16: 2d3f
    goto    0x04f6                   ; 0d17: 2cf6
    goto    0x053f                   ; 0d18: 2d3f
    goto    0x053f                   ; 0d19: 2d3f
    goto    0x053f                   ; 0d1a: 2d3f
    goto    0x04f6                   ; 0d1b: 2cf6
    goto    0x04f6                   ; 0d1c: 2cf6
    goto    0x04f6                   ; 0d1d: 2cf6
    goto    0x053f                   ; 0d1e: 2d3f
    goto    0x04f6                   ; 0d1f: 2cf6
    goto    0x053f                   ; 0d20: 2d3f
    goto    0x053f                   ; 0d21: 2d3f
    goto    0x053f                   ; 0d22: 2d3f
    goto    0x04f6                   ; 0d23: 2cf6
    goto    0x053f                   ; 0d24: 2d3f
    goto    0x053f                   ; 0d25: 2d3f
    goto    0x053f                   ; 0d26: 2d3f
    goto    0x053f                   ; 0d27: 2d3f
    goto    0x053f                   ; 0d28: 2d3f
    goto    0x053f                   ; 0d29: 2d3f
    goto    0x053f                   ; 0d2a: 2d3f
    goto    0x04f6                   ; 0d2b: 2cf6
    goto    0x04f6                   ; 0d2c: 2cf6
    goto    0x04f6                   ; 0d2d: 2cf6
    goto    0x053f                   ; 0d2e: 2d3f
    goto    0x04f6                   ; 0d2f: 2cf6
    goto    0x053f                   ; 0d30: 2d3f
    goto    0x053f                   ; 0d31: 2d3f
    goto    0x053f                   ; 0d32: 2d3f
    goto    0x04f6                   ; 0d33: 2cf6
    goto    0x053f                   ; 0d34: 2d3f
    goto    0x053f                   ; 0d35: 2d3f
    goto    0x053f                   ; 0d36: 2d3f
    goto    0x053f                   ; 0d37: 2d3f
    goto    0x053f                   ; 0d38: 2d3f
    goto    0x053f                   ; 0d39: 2d3f
    goto    0x053f                   ; 0d3a: 2d3f
    movf    0x73, 0x0                ; 0d3b: 0873
    btfsc   0x03, 0x2                ; 0d3c: 1903
    goto    0x0501                   ; 0d3d: 2d01
    goto    0x04f6                   ; 0d3e: 2cf6
    movf    0x3f, 0x0                ; 0d3f: 083f
    addlw   0xb9                     ; 0d40: 3eb9
    movwf   0x04                     ; 0d41: 0084
    bsf     0x03, 0x7                ; 0d42: 1783
    bsf     0x00, 0x6                ; 0d43: 1700
    movf    0x3f, 0x1                ; 0d44: 08bf
    bsf     0x03, 0x5                ; 0d45: 1683
    bsf     0x03, 0x6                ; 0d46: 1703
    btfsc   0x03, 0x2                ; 0d47: 1903
    goto    0x0551                   ; 0d48: 2d51
    movf    0x37, 0x0                ; 0d49: 0837
    bcf     0x03, 0x5                ; 0d4a: 1283
    bcf     0x03, 0x6                ; 0d4b: 1303
    movwf   0x53                     ; 0d4c: 00d3
    bsf     0x03, 0x5                ; 0d4d: 1683
    bsf     0x03, 0x6                ; 0d4e: 1703
    movf    0x38, 0x0                ; 0d4f: 0838
    goto    0x0558                   ; 0d50: 2d58
    movf    0x35, 0x0                ; 0d51: 0835
    bcf     0x03, 0x5                ; 0d52: 1283
    bcf     0x03, 0x6                ; 0d53: 1303
    movwf   0x53                     ; 0d54: 00d3
    bsf     0x03, 0x5                ; 0d55: 1683
    bsf     0x03, 0x6                ; 0d56: 1703
    movf    0x36, 0x0                ; 0d57: 0836
    bcf     0x03, 0x5                ; 0d58: 1283
    bcf     0x03, 0x6                ; 0d59: 1303
    movwf   0x54                     ; 0d5a: 00d4
    iorwf   0x53, 0x0                ; 0d5b: 0453
    btfsc   0x03, 0x2                ; 0d5c: 1903
    goto    0x0582                   ; 0d5d: 2d82
    bsf     0x03, 0x5                ; 0d5e: 1683
    bsf     0x03, 0x6                ; 0d5f: 1703
    btfss   0x36, 0x0                ; 0d60: 1c36
    goto    0x056e                   ; 0d61: 2d6e
    bcf     0x03, 0x5                ; 0d62: 1283
    bcf     0x03, 0x6                ; 0d63: 1303
    movf    0x3f, 0x0                ; 0d64: 083f
    addlw   0xb9                     ; 0d65: 3eb9
    movwf   0x04                     ; 0d66: 0084
    bsf     0x03, 0x7                ; 0d67: 1783
    bsf     0x00, 0x1                ; 0d68: 1480
    movf    0x3f, 0x0                ; 0d69: 083f
    addlw   0xb9                     ; 0d6a: 3eb9
    movwf   0x04                     ; 0d6b: 0084
    bsf     0x03, 0x7                ; 0d6c: 1783
    bsf     0x00, 0x6                ; 0d6d: 1700
    bcf     0x03, 0x5                ; 0d6e: 1283
    bcf     0x03, 0x6                ; 0d6f: 1303
    movf    0x54, 0x0                ; 0d70: 0854
    movwf   0x71                     ; 0d71: 00f1
    movf    0x53, 0x0                ; 0d72: 0853
    movwf   0x70                     ; 0d73: 00f0
    clrf    0x71                     ; 0d74: 01f1
    iorwf   0x71, 0x0                ; 0d75: 0471
    btfsc   0x03, 0x2                ; 0d76: 1903
    goto    0x057d                   ; 0d77: 2d7d
    movf    0x3f, 0x0                ; 0d78: 083f
    addlw   0xb9                     ; 0d79: 3eb9
    movwf   0x04                     ; 0d7a: 0084
    bsf     0x03, 0x7                ; 0d7b: 1783
    bsf     0x00, 0x0                ; 0d7c: 1400
    movf    0x3f, 0x0                ; 0d7d: 083f
    addlw   0xb9                     ; 0d7e: 3eb9
    movwf   0x04                     ; 0d7f: 0084
    bsf     0x03, 0x7                ; 0d80: 1783
    bsf     0x00, 0x7                ; 0d81: 1780
    incf    0x3f, 0x1                ; 0d82: 0abf
    movlw   0x02                     ; 0d83: 3002
    subwf   0x3f, 0x0                ; 0d84: 023f
    btfss   0x03, 0x0                ; 0d85: 1c03
    goto    0x04d9                   ; 0d86: 2cd9
    bsf     0x03, 0x5                ; 0d87: 1683
    bcf     0x03, 0x6                ; 0d88: 1303
    btfss   0x4e, 0x7                ; 0d89: 1fce
    goto    0x058f                   ; 0d8a: 2d8f
    bsf     0x03, 0x6                ; 0d8b: 1703
    bcf     0x39, 0x3                ; 0d8c: 11b9
    bcf     0x3a, 0x3                ; 0d8d: 11ba
    goto    0x0592                   ; 0d8e: 2d92
    bsf     0x03, 0x6                ; 0d8f: 1703
    bsf     0x39, 0x3                ; 0d90: 15b9
    bsf     0x3a, 0x3                ; 0d91: 15ba
    bcf     0x03, 0x6                ; 0d92: 1303
    bcf     0x4e, 0x1                ; 0d93: 10ce
    bsf     0x4e, 0x0                ; 0d94: 144e
    bcf     0x4e, 0x7                ; 0d95: 13ce
    goto    0x0628                   ; 0d96: 2e28
    bsf     0x03, 0x6                ; 0d97: 1703
    movf    0x27, 0x0                ; 0d98: 0827
    andlw   0xcf                     ; 0d99: 39cf
    iorlw   0x20                     ; 0d9a: 3820
    movwf   0x27                     ; 0d9b: 00a7
    andlw   0x3f                     ; 0d9c: 393f
    iorlw   0xc0                     ; 0d9d: 38c0
    movwf   0x27                     ; 0d9e: 00a7
    bsf     0x0a, 0x4                ; 0d9f: 160a
    bsf     0x0a, 0x3                ; 0da0: 158a
    call    0x004c                   ; 0da1: 204c
    movwf   0x70                     ; 0da2: 00f0
    xorwf   0x31, 0x0                ; 0da3: 0631
    andlw   0x00                     ; 0da4: 3900
    xorwf   0x70, 0x0                ; 0da5: 0670
    movwf   0x31                     ; 0da6: 00b1
    bsf     0x0a, 0x4                ; 0da7: 160a
    bsf     0x0a, 0x3                ; 0da8: 158a
    call    0x004f                   ; 0da9: 204f
    movwf   0x70                     ; 0daa: 00f0
    xorwf   0x32, 0x0                ; 0dab: 0632
    andlw   0x00                     ; 0dac: 3900
    xorwf   0x70, 0x0                ; 0dad: 0670
    movwf   0x32                     ; 0dae: 00b2
    movlw   0x06                     ; 0daf: 3006
    bcf     0x0a, 0x4                ; 0db0: 120a
    bcf     0x0a, 0x3                ; 0db1: 118a
    call    0x0698                   ; 0db2: 2698
    movwf   0x70                     ; 0db3: 00f0
    bsf     0x03, 0x6                ; 0db4: 1703
    xorwf   0x33, 0x0                ; 0db5: 0633
    andlw   0x00                     ; 0db6: 3900
    xorwf   0x70, 0x0                ; 0db7: 0670
    movwf   0x33                     ; 0db8: 00b3
    movlw   0x07                     ; 0db9: 3007
    bcf     0x0a, 0x4                ; 0dba: 120a
    bcf     0x0a, 0x3                ; 0dbb: 118a
    call    0x0698                   ; 0dbc: 2698
    bcf     0x0a, 0x4                ; 0dbd: 120a
    bsf     0x0a, 0x3                ; 0dbe: 158a
    movwf   0x70                     ; 0dbf: 00f0
    bsf     0x03, 0x6                ; 0dc0: 1703
    xorwf   0x34, 0x0                ; 0dc1: 0634
    andlw   0x00                     ; 0dc2: 3900
    xorwf   0x70, 0x0                ; 0dc3: 0670
    movwf   0x34                     ; 0dc4: 00b4
    movf    0x27, 0x0                ; 0dc5: 0827
    bsf     0x03, 0x5                ; 0dc6: 1683
    bcf     0x03, 0x6                ; 0dc7: 1303
    movwf   0x44                     ; 0dc8: 00c4
    bcf     0x03, 0x5                ; 0dc9: 1283
    bsf     0x03, 0x6                ; 0dca: 1703
    movf    0x31, 0x0                ; 0dcb: 0831
    bsf     0x03, 0x5                ; 0dcc: 1683
    bcf     0x03, 0x6                ; 0dcd: 1303
    movwf   0x45                     ; 0dce: 00c5
    bcf     0x03, 0x5                ; 0dcf: 1283
    bsf     0x03, 0x6                ; 0dd0: 1703
    movf    0x32, 0x0                ; 0dd1: 0832
    bsf     0x03, 0x5                ; 0dd2: 1683
    bcf     0x03, 0x6                ; 0dd3: 1303
    movwf   0x46                     ; 0dd4: 00c6
    bcf     0x03, 0x5                ; 0dd5: 1283
    bsf     0x03, 0x6                ; 0dd6: 1703
    movf    0x33, 0x0                ; 0dd7: 0833
    bsf     0x03, 0x5                ; 0dd8: 1683
    bcf     0x03, 0x6                ; 0dd9: 1303
    movwf   0x47                     ; 0dda: 00c7
    bcf     0x03, 0x5                ; 0ddb: 1283
    bsf     0x03, 0x6                ; 0ddc: 1703
    movf    0x34, 0x0                ; 0ddd: 0834
    bsf     0x03, 0x5                ; 0dde: 1683
    bcf     0x03, 0x6                ; 0ddf: 1303
    movwf   0x48                     ; 0de0: 00c8
    clrf    0x49                     ; 0de1: 01c9
    addwf   0x49, 0x1                ; 0de2: 07c9
    movf    0x47, 0x0                ; 0de3: 0847
    addwf   0x49, 0x1                ; 0de4: 07c9
    movf    0x46, 0x0                ; 0de5: 0846
    addwf   0x49, 0x1                ; 0de6: 07c9
    movf    0x45, 0x0                ; 0de7: 0845
    addwf   0x49, 0x1                ; 0de8: 07c9
    movf    0x44, 0x0                ; 0de9: 0844
    addwf   0x49, 0x1                ; 0dea: 07c9
    bsf     0x0c, 0x4                ; 0deb: 160c
    bsf     0x18, 0x5                ; 0dec: 1698
    goto    0x0628                   ; 0ded: 2e28
    bsf     0x03, 0x6                ; 0dee: 1703
    movf    0x47, 0x0                ; 0def: 0847
    bcf     0x03, 0x6                ; 0df0: 1303
    movwf   0x53                     ; 0df1: 00d3
    bsf     0x03, 0x6                ; 0df2: 1703
    movf    0x48, 0x0                ; 0df3: 0848
    bcf     0x03, 0x6                ; 0df4: 1303
    goto    0x0605                   ; 0df5: 2e05
    movlw   0x07                     ; 0df6: 3007
    goto    0x05fd                   ; 0df7: 2dfd
    movlw   0x05                     ; 0df8: 3005
    goto    0x05fd                   ; 0df9: 2dfd
    movlw   0x06                     ; 0dfa: 3006
    goto    0x05fd                   ; 0dfb: 2dfd
    movlw   0x00                     ; 0dfc: 3000
    bsf     0x0a, 0x4                ; 0dfd: 160a
    bcf     0x0a, 0x3                ; 0dfe: 118a
    call    0x0000                   ; 0dff: 2000
    bcf     0x0a, 0x4                ; 0e00: 120a
    bsf     0x0a, 0x3                ; 0e01: 158a
    movf    0x70, 0x0                ; 0e02: 0870
    movwf   0x53                     ; 0e03: 00d3
    movf    0x71, 0x0                ; 0e04: 0871
    movwf   0x54                     ; 0e05: 00d4
    goto    0x0628                   ; 0e06: 2e28
    goto    0x0607                   ; 0e07: 2e07
    bsf     0x0a, 0x4                ; 0e08: 160a
    bsf     0x0a, 0x3                ; 0e09: 158a
    call    0x0613                   ; 0e0a: 2613
    bcf     0x0a, 0x4                ; 0e0b: 120a
    bsf     0x0a, 0x3                ; 0e0c: 158a
    xorlw   0x00                     ; 0e0d: 3a00
    btfsc   0x03, 0x2                ; 0e0e: 1903
    goto    0x0300                   ; 0e0f: 2b00
    xorlw   0x01                     ; 0e10: 3a01
    btfsc   0x03, 0x2                ; 0e11: 1903
    goto    0x0344                   ; 0e12: 2b44
    xorlw   0x05                     ; 0e13: 3a05
    btfsc   0x03, 0x2                ; 0e14: 1903
    goto    0x05ee                   ; 0e15: 2dee
    xorlw   0x0c                     ; 0e16: 3a0c
    btfsc   0x03, 0x2                ; 0e17: 1903
    goto    0x05f6                   ; 0e18: 2df6
    xorlw   0x04                     ; 0e19: 3a04
    btfsc   0x03, 0x2                ; 0e1a: 1903
    goto    0x05f8                   ; 0e1b: 2df8
    xorlw   0x1c                     ; 0e1c: 3a1c
    btfsc   0x03, 0x2                ; 0e1d: 1903
    goto    0x05fa                   ; 0e1e: 2dfa
    xorlw   0x04                     ; 0e1f: 3a04
    btfsc   0x03, 0x2                ; 0e20: 1903
    goto    0x0607                   ; 0e21: 2e07
    xorlw   0x0c                     ; 0e22: 3a0c
    btfsc   0x03, 0x2                ; 0e23: 1903
    goto    0x05fc                   ; 0e24: 2dfc
    xorlw   0x98                     ; 0e25: 3a98
    btfsc   0x03, 0x2                ; 0e26: 1903
    goto    0x0597                   ; 0e27: 2d97
    bsf     0x0a, 0x4                ; 0e28: 160a
    bsf     0x0a, 0x3                ; 0e29: 158a
    call    0x0613                   ; 0e2a: 2613
    bcf     0x0a, 0x4                ; 0e2b: 120a
    bsf     0x0a, 0x3                ; 0e2c: 158a
    movwf   0x70                     ; 0e2d: 00f0
    movlw   0x02                     ; 0e2e: 3002
    subwf   0x70, 0x0                ; 0e2f: 0270
    btfss   0x03, 0x0                ; 0e30: 1c03
    goto    0x07fe                   ; 0e31: 2ffe
    bsf     0x0a, 0x4                ; 0e32: 160a
    bsf     0x0a, 0x3                ; 0e33: 158a
    call    0x0613                   ; 0e34: 2613
    bcf     0x0a, 0x4                ; 0e35: 120a
    bsf     0x0a, 0x3                ; 0e36: 158a
    movwf   0x70                     ; 0e37: 00f0
    movlw   0x80                     ; 0e38: 3080
    subwf   0x70, 0x0                ; 0e39: 0270
    btfsc   0x03, 0x0                ; 0e3a: 1803
    goto    0x07fe                   ; 0e3b: 2ffe
    bsf     0x03, 0x6                ; 0e3c: 1703
    movf    0x27, 0x0                ; 0e3d: 0827
    andlw   0xcf                     ; 0e3e: 39cf
    iorlw   0x20                     ; 0e3f: 3820
    movwf   0x27                     ; 0e40: 00a7
    andlw   0x3f                     ; 0e41: 393f
    iorlw   0xc0                     ; 0e42: 38c0
    movwf   0x27                     ; 0e43: 00a7
    bcf     0x03, 0x6                ; 0e44: 1303
    movf    0x54, 0x0                ; 0e45: 0854
    movwf   0x70                     ; 0e46: 00f0
    bsf     0x03, 0x6                ; 0e47: 1703
    xorwf   0x31, 0x0                ; 0e48: 0631
    andlw   0x00                     ; 0e49: 3900
    xorwf   0x70, 0x0                ; 0e4a: 0670
    movwf   0x31                     ; 0e4b: 00b1
    movf    0x32, 0x0                ; 0e4c: 0832
    bcf     0x03, 0x6                ; 0e4d: 1303
    xorwf   0x53, 0x0                ; 0e4e: 0653
    andlw   0x00                     ; 0e4f: 3900
    xorwf   0x53, 0x0                ; 0e50: 0653
    bsf     0x03, 0x6                ; 0e51: 1703
    movwf   0x32                     ; 0e52: 00b2
    movf    0x33, 0x0                ; 0e53: 0833
    andlw   0x00                     ; 0e54: 3900
    movwf   0x33                     ; 0e55: 00b3
    movf    0x34, 0x0                ; 0e56: 0834
    andlw   0x00                     ; 0e57: 3900
    movwf   0x34                     ; 0e58: 00b4
    movf    0x27, 0x0                ; 0e59: 0827
    bsf     0x03, 0x5                ; 0e5a: 1683
    bcf     0x03, 0x6                ; 0e5b: 1303
    movwf   0x44                     ; 0e5c: 00c4
    bcf     0x03, 0x5                ; 0e5d: 1283
    bsf     0x03, 0x6                ; 0e5e: 1703
    movf    0x31, 0x0                ; 0e5f: 0831
    bsf     0x03, 0x5                ; 0e60: 1683
    bcf     0x03, 0x6                ; 0e61: 1303
    movwf   0x45                     ; 0e62: 00c5
    bcf     0x03, 0x5                ; 0e63: 1283
    bsf     0x03, 0x6                ; 0e64: 1703
    movf    0x32, 0x0                ; 0e65: 0832
    bsf     0x03, 0x5                ; 0e66: 1683
    bcf     0x03, 0x6                ; 0e67: 1303
    movwf   0x46                     ; 0e68: 00c6
    bcf     0x03, 0x5                ; 0e69: 1283
    bsf     0x03, 0x6                ; 0e6a: 1703
    movf    0x33, 0x0                ; 0e6b: 0833
    bsf     0x03, 0x5                ; 0e6c: 1683
    bcf     0x03, 0x6                ; 0e6d: 1303
    movwf   0x47                     ; 0e6e: 00c7
    bcf     0x03, 0x5                ; 0e6f: 1283
    bsf     0x03, 0x6                ; 0e70: 1703
    movf    0x34, 0x0                ; 0e71: 0834
    bsf     0x03, 0x5                ; 0e72: 1683
    bcf     0x03, 0x6                ; 0e73: 1303
    movwf   0x48                     ; 0e74: 00c8
    clrf    0x49                     ; 0e75: 01c9
    addwf   0x49, 0x1                ; 0e76: 07c9
    movf    0x47, 0x0                ; 0e77: 0847
    addwf   0x49, 0x1                ; 0e78: 07c9
    movf    0x46, 0x0                ; 0e79: 0846
    addwf   0x49, 0x1                ; 0e7a: 07c9
    movf    0x45, 0x0                ; 0e7b: 0845
    addwf   0x49, 0x1                ; 0e7c: 07c9
    movf    0x44, 0x0                ; 0e7d: 0844
    addwf   0x49, 0x1                ; 0e7e: 07c9
    bsf     0x0c, 0x4                ; 0e7f: 160c
    bsf     0x18, 0x5                ; 0e80: 1698
    goto    0x07fe                   ; 0e81: 2ffe
    bsf     0x0a, 0x4                ; 0e82: 160a
    bsf     0x0a, 0x3                ; 0e83: 158a
    call    0x06bd                   ; 0e84: 26bd
    bcf     0x0a, 0x4                ; 0e85: 120a
    bsf     0x0a, 0x3                ; 0e86: 158a
    xorlw   0x01                     ; 0e87: 3a01
    btfss   0x03, 0x2                ; 0e88: 1d03
    goto    0x07d3                   ; 0e89: 2fd3
    bsf     0x0a, 0x4                ; 0e8a: 160a
    bsf     0x0a, 0x3                ; 0e8b: 158a
    call    0x0673                   ; 0e8c: 2673
    bcf     0x0a, 0x4                ; 0e8d: 120a
    bsf     0x0a, 0x3                ; 0e8e: 158a
    xorlw   0x01                     ; 0e8f: 3a01
    btfss   0x03, 0x2                ; 0e90: 1d03
    goto    0x07fe                   ; 0e91: 2ffe
    bsf     0x0a, 0x4                ; 0e92: 160a
    bsf     0x0a, 0x3                ; 0e93: 158a
    call    0x067f                   ; 0e94: 267f
    bcf     0x0a, 0x4                ; 0e95: 120a
    bsf     0x0a, 0x3                ; 0e96: 158a
    movwf   0x70                     ; 0e97: 00f0
    movlw   0x65                     ; 0e98: 3065
    subwf   0x70, 0x0                ; 0e99: 0270
    btfsc   0x03, 0x0                ; 0e9a: 1803
    goto    0x06a2                   ; 0e9b: 2ea2
    bsf     0x0a, 0x4                ; 0e9c: 160a
    bsf     0x0a, 0x3                ; 0e9d: 158a
    call    0x067f                   ; 0e9e: 267f
    bcf     0x0a, 0x4                ; 0e9f: 120a
    bsf     0x0a, 0x3                ; 0ea0: 158a
    goto    0x06a3                   ; 0ea1: 2ea3
    movlw   0x64                     ; 0ea2: 3064
    bsf     0x03, 0x6                ; 0ea3: 1703
    movwf   0x20                     ; 0ea4: 00a0
    call    0x0046                   ; 0ea5: 2046
    bsf     0x0a, 0x4                ; 0ea6: 160a
    bsf     0x0a, 0x3                ; 0ea7: 158a
    call    0x0631                   ; 0ea8: 2631
    bcf     0x0a, 0x4                ; 0ea9: 120a
    bsf     0x0a, 0x3                ; 0eaa: 158a
    movwf   0x70                     ; 0eab: 00f0
    movlw   0x04                     ; 0eac: 3004
    subwf   0x70, 0x0                ; 0ead: 0270
    btfsc   0x03, 0x0                ; 0eae: 1803
    goto    0x06b6                   ; 0eaf: 2eb6
    bsf     0x0a, 0x4                ; 0eb0: 160a
    bsf     0x0a, 0x3                ; 0eb1: 158a
    call    0x0631                   ; 0eb2: 2631
    bcf     0x0a, 0x4                ; 0eb3: 120a
    bsf     0x0a, 0x3                ; 0eb4: 158a
    goto    0x06b7                   ; 0eb5: 2eb7
    movlw   0x03                     ; 0eb6: 3003
    bsf     0x03, 0x6                ; 0eb7: 1703
    movwf   0x25                     ; 0eb8: 00a5
    bsf     0x0a, 0x4                ; 0eb9: 160a
    bsf     0x0a, 0x3                ; 0eba: 158a
    call    0x0679                   ; 0ebb: 2679
    bcf     0x0a, 0x4                ; 0ebc: 120a
    bsf     0x0a, 0x3                ; 0ebd: 158a
    movwf   0x70                     ; 0ebe: 00f0
    movlw   0x04                     ; 0ebf: 3004
    subwf   0x70, 0x0                ; 0ec0: 0270
    btfsc   0x03, 0x0                ; 0ec1: 1803
    goto    0x06c9                   ; 0ec2: 2ec9
    bsf     0x0a, 0x4                ; 0ec3: 160a
    bsf     0x0a, 0x3                ; 0ec4: 158a
    call    0x0679                   ; 0ec5: 2679
    bcf     0x0a, 0x4                ; 0ec6: 120a
    bsf     0x0a, 0x3                ; 0ec7: 158a
    goto    0x06ca                   ; 0ec8: 2eca
    movlw   0x03                     ; 0ec9: 3003
    bsf     0x03, 0x6                ; 0eca: 1703
    movwf   0x26                     ; 0ecb: 00a6
    bsf     0x0a, 0x4                ; 0ecc: 160a
    bsf     0x0a, 0x3                ; 0ecd: 158a
    call    0x069e                   ; 0ece: 269e
    bsf     0x03, 0x6                ; 0ecf: 1703
    movwf   0x23                     ; 0ed0: 00a3
    bsf     0x0a, 0x4                ; 0ed1: 160a
    bsf     0x0a, 0x3                ; 0ed2: 158a
    call    0x06cf                   ; 0ed3: 26cf
    bcf     0x0a, 0x4                ; 0ed4: 120a
    bsf     0x0a, 0x3                ; 0ed5: 158a
    bsf     0x03, 0x6                ; 0ed6: 1703
    movwf   0x24                     ; 0ed7: 00a4
    goto    0x06eb                   ; 0ed8: 2eeb
    movf    0x23, 0x0                ; 0ed9: 0823
    bsf     0x03, 0x5                ; 0eda: 1683
    movwf   0x42                     ; 0edb: 00c2
    bcf     0x03, 0x5                ; 0edc: 1283
    movf    0x25, 0x0                ; 0edd: 0825
    goto    0x06e4                   ; 0ede: 2ee4
    movf    0x24, 0x0                ; 0edf: 0824
    bsf     0x03, 0x5                ; 0ee0: 1683
    movwf   0x42                     ; 0ee1: 00c2
    bcf     0x03, 0x5                ; 0ee2: 1283
    movf    0x26, 0x0                ; 0ee3: 0826
    bsf     0x03, 0x5                ; 0ee4: 1683
    movwf   0x43                     ; 0ee5: 00c3
    btfsc   0x32, 0x3                ; 0ee6: 19b2
    btfsc   0x32, 0x6                ; 0ee7: 1b32
    goto    0x07e0                   ; 0ee8: 2fe0
    bsf     0x32, 0x5                ; 0ee9: 16b2
    goto    0x07fe                   ; 0eea: 2ffe
    movf    0x22, 0x0                ; 0eeb: 0822
    xorlw   0x02                     ; 0eec: 3a02
    btfsc   0x03, 0x2                ; 0eed: 1903
    goto    0x06d9                   ; 0eee: 2ed9
    xorlw   0x06                     ; 0eef: 3a06
    btfsc   0x03, 0x2                ; 0ef0: 1903
    goto    0x06df                   ; 0ef1: 2edf
    xorlw   0x02                     ; 0ef2: 3a02
    btfsc   0x03, 0x2                ; 0ef3: 1903
    goto    0x06d9                   ; 0ef4: 2ed9
    goto    0x07fe                   ; 0ef5: 2ffe
    bsf     0x0a, 0x4                ; 0ef6: 160a
    bsf     0x0a, 0x3                ; 0ef7: 158a
    call    0x0691                   ; 0ef8: 2691
    bcf     0x0a, 0x4                ; 0ef9: 120a
    bsf     0x0a, 0x3                ; 0efa: 158a
    xorlw   0x02                     ; 0efb: 3a02
    btfsc   0x03, 0x2                ; 0efc: 1903
    goto    0x070e                   ; 0efd: 2f0e
    bsf     0x0a, 0x4                ; 0efe: 160a
    bsf     0x0a, 0x3                ; 0eff: 158a
    call    0x0691                   ; 0f00: 2691
    bcf     0x0a, 0x4                ; 0f01: 120a
    bsf     0x0a, 0x3                ; 0f02: 158a
    xorlw   0x04                     ; 0f03: 3a04
    btfsc   0x03, 0x2                ; 0f04: 1903
    goto    0x070e                   ; 0f05: 2f0e
    bsf     0x0a, 0x4                ; 0f06: 160a
    bsf     0x0a, 0x3                ; 0f07: 158a
    call    0x0691                   ; 0f08: 2691
    bcf     0x0a, 0x4                ; 0f09: 120a
    bsf     0x0a, 0x3                ; 0f0a: 158a
    xorlw   0x06                     ; 0f0b: 3a06
    btfss   0x03, 0x2                ; 0f0c: 1d03
    goto    0x0715                   ; 0f0d: 2f15
    bsf     0x0a, 0x4                ; 0f0e: 160a
    bsf     0x0a, 0x3                ; 0f0f: 158a
    call    0x0691                   ; 0f10: 2691
    bcf     0x0a, 0x4                ; 0f11: 120a
    bsf     0x0a, 0x3                ; 0f12: 158a
    bsf     0x03, 0x6                ; 0f13: 1703
    movwf   0x22                     ; 0f14: 00a2
    bsf     0x03, 0x6                ; 0f15: 1703
    movf    0x22, 0x0                ; 0f16: 0822
    bcf     0x03, 0x6                ; 0f17: 1303
    movwf   0x57                     ; 0f18: 00d7
    movlw   0x05                     ; 0f19: 3005
    goto    0x0759                   ; 0f1a: 2f59
    movf    0x37, 0x0                ; 0f1b: 0837
    andlw   0xff                     ; 0f1c: 39ff
    bcf     0x03, 0x6                ; 0f1d: 1303
    movwf   0x57                     ; 0f1e: 00d7
    bsf     0x03, 0x6                ; 0f1f: 1703
    movf    0x36, 0x0                ; 0f20: 0836
    andlw   0xff                     ; 0f21: 39ff
    goto    0x0759                   ; 0f22: 2f59
    movf    0x27, 0x0                ; 0f23: 0827
    andlw   0xcf                     ; 0f24: 39cf
    iorlw   0x20                     ; 0f25: 3820
    movwf   0x27                     ; 0f26: 00a7
    andlw   0x3f                     ; 0f27: 393f
    movwf   0x27                     ; 0f28: 00a7
    movf    0x36, 0x0                ; 0f29: 0836
    andlw   0xff                     ; 0f2a: 39ff
    bcf     0x0a, 0x4                ; 0f2b: 120a
    bcf     0x0a, 0x3                ; 0f2c: 118a
    call    0x067a                   ; 0f2d: 267a
    bcf     0x0a, 0x4                ; 0f2e: 120a
    bsf     0x0a, 0x3                ; 0f2f: 158a
    movwf   0x70                     ; 0f30: 00f0
    bsf     0x03, 0x6                ; 0f31: 1703
    xorwf   0x31, 0x0                ; 0f32: 0631
    andlw   0x00                     ; 0f33: 3900
    xorwf   0x70, 0x0                ; 0f34: 0670
    movwf   0x31                     ; 0f35: 00b1
    movf    0x27, 0x0                ; 0f36: 0827
    bsf     0x03, 0x5                ; 0f37: 1683
    bcf     0x03, 0x6                ; 0f38: 1303
    movwf   0x44                     ; 0f39: 00c4
    bcf     0x03, 0x5                ; 0f3a: 1283
    bsf     0x03, 0x6                ; 0f3b: 1703
    movf    0x31, 0x0                ; 0f3c: 0831
    bsf     0x03, 0x5                ; 0f3d: 1683
    bcf     0x03, 0x6                ; 0f3e: 1303
    movwf   0x45                     ; 0f3f: 00c5
    clrf    0x46                     ; 0f40: 01c6
    addwf   0x46, 0x1                ; 0f41: 07c6
    movf    0x44, 0x0                ; 0f42: 0844
    addwf   0x46, 0x1                ; 0f43: 07c6
    goto    0x07c1                   ; 0f44: 2fc1
    movf    0x37, 0x0                ; 0f45: 0837
    andlw   0xff                     ; 0f46: 39ff
    bcf     0x03, 0x6                ; 0f47: 1303
    movwf   0x57                     ; 0f48: 00d7
    bsf     0x03, 0x6                ; 0f49: 1703
    movf    0x36, 0x0                ; 0f4a: 0836
    andlw   0xff                     ; 0f4b: 39ff
    bsf     0x0a, 0x4                ; 0f4c: 160a
    bcf     0x0a, 0x3                ; 0f4d: 118a
    call    0x05cc                   ; 0f4e: 25cc
    bsf     0x03, 0x6                ; 0f4f: 1703
    movf    0x38, 0x0                ; 0f50: 0838
    andlw   0xff                     ; 0f51: 39ff
    bcf     0x03, 0x6                ; 0f52: 1303
    movwf   0x57                     ; 0f53: 00d7
    bsf     0x03, 0x6                ; 0f54: 1703
    movf    0x36, 0x0                ; 0f55: 0836
    andlw   0xff                     ; 0f56: 39ff
    movwf   0x70                     ; 0f57: 00f0
    incf    0x70, 0x0                ; 0f58: 0a70
    bsf     0x0a, 0x4                ; 0f59: 160a
    bcf     0x0a, 0x3                ; 0f5a: 118a
    call    0x05cc                   ; 0f5b: 25cc
    bsf     0x0a, 0x4                ; 0f5c: 160a
    bcf     0x0a, 0x3                ; 0f5d: 118a
    call    0x024b                   ; 0f5e: 224b
    bcf     0x0a, 0x4                ; 0f5f: 120a
    bsf     0x0a, 0x3                ; 0f60: 158a
    goto    0x07de                   ; 0f61: 2fde
    movf    0x27, 0x0                ; 0f62: 0827
    andlw   0xcf                     ; 0f63: 39cf
    iorlw   0x20                     ; 0f64: 3820
    movwf   0x27                     ; 0f65: 00a7
    andlw   0x3f                     ; 0f66: 393f
    iorlw   0xc0                     ; 0f67: 38c0
    movwf   0x27                     ; 0f68: 00a7
    movf    0x36, 0x0                ; 0f69: 0836
    andlw   0xff                     ; 0f6a: 39ff
    bcf     0x0a, 0x4                ; 0f6b: 120a
    bcf     0x0a, 0x3                ; 0f6c: 118a
    call    0x067a                   ; 0f6d: 267a
    movwf   0x70                     ; 0f6e: 00f0
    bsf     0x03, 0x6                ; 0f6f: 1703
    xorwf   0x31, 0x0                ; 0f70: 0631
    andlw   0x00                     ; 0f71: 3900
    xorwf   0x70, 0x0                ; 0f72: 0670
    movwf   0x31                     ; 0f73: 00b1
    movf    0x36, 0x0                ; 0f74: 0836
    andlw   0xff                     ; 0f75: 39ff
    movwf   0x70                     ; 0f76: 00f0
    incf    0x70, 0x0                ; 0f77: 0a70
    bcf     0x0a, 0x4                ; 0f78: 120a
    bcf     0x0a, 0x3                ; 0f79: 118a
    call    0x067a                   ; 0f7a: 267a
    movwf   0x70                     ; 0f7b: 00f0
    bsf     0x03, 0x6                ; 0f7c: 1703
    xorwf   0x32, 0x0                ; 0f7d: 0632
    andlw   0x00                     ; 0f7e: 3900
    xorwf   0x70, 0x0                ; 0f7f: 0670
    movwf   0x32                     ; 0f80: 00b2
    movf    0x36, 0x0                ; 0f81: 0836
    andlw   0xff                     ; 0f82: 39ff
    addlw   0x02                     ; 0f83: 3e02
    bcf     0x0a, 0x4                ; 0f84: 120a
    bcf     0x0a, 0x3                ; 0f85: 118a
    call    0x067a                   ; 0f86: 267a
    movwf   0x70                     ; 0f87: 00f0
    bsf     0x03, 0x6                ; 0f88: 1703
    xorwf   0x33, 0x0                ; 0f89: 0633
    andlw   0x00                     ; 0f8a: 3900
    xorwf   0x70, 0x0                ; 0f8b: 0670
    movwf   0x33                     ; 0f8c: 00b3
    movf    0x36, 0x0                ; 0f8d: 0836
    andlw   0xff                     ; 0f8e: 39ff
    addlw   0x03                     ; 0f8f: 3e03
    bcf     0x0a, 0x4                ; 0f90: 120a
    bcf     0x0a, 0x3                ; 0f91: 118a
    call    0x067a                   ; 0f92: 267a
    bcf     0x0a, 0x4                ; 0f93: 120a
    bsf     0x0a, 0x3                ; 0f94: 158a
    movwf   0x70                     ; 0f95: 00f0
    bsf     0x03, 0x6                ; 0f96: 1703
    xorwf   0x34, 0x0                ; 0f97: 0634
    andlw   0x00                     ; 0f98: 3900
    xorwf   0x70, 0x0                ; 0f99: 0670
    movwf   0x34                     ; 0f9a: 00b4
    movf    0x27, 0x0                ; 0f9b: 0827
    bsf     0x03, 0x5                ; 0f9c: 1683
    bcf     0x03, 0x6                ; 0f9d: 1303
    movwf   0x44                     ; 0f9e: 00c4
    bcf     0x03, 0x5                ; 0f9f: 1283
    bsf     0x03, 0x6                ; 0fa0: 1703
    movf    0x31, 0x0                ; 0fa1: 0831
    bsf     0x03, 0x5                ; 0fa2: 1683
    bcf     0x03, 0x6                ; 0fa3: 1303
    movwf   0x45                     ; 0fa4: 00c5
    bcf     0x03, 0x5                ; 0fa5: 1283
    bsf     0x03, 0x6                ; 0fa6: 1703
    movf    0x32, 0x0                ; 0fa7: 0832
    bsf     0x03, 0x5                ; 0fa8: 1683
    bcf     0x03, 0x6                ; 0fa9: 1303
    movwf   0x46                     ; 0faa: 00c6
    bcf     0x03, 0x5                ; 0fab: 1283
    bsf     0x03, 0x6                ; 0fac: 1703
    movf    0x33, 0x0                ; 0fad: 0833
    bsf     0x03, 0x5                ; 0fae: 1683
    bcf     0x03, 0x6                ; 0faf: 1303
    movwf   0x47                     ; 0fb0: 00c7
    bcf     0x03, 0x5                ; 0fb1: 1283
    bsf     0x03, 0x6                ; 0fb2: 1703
    movf    0x34, 0x0                ; 0fb3: 0834
    bsf     0x03, 0x5                ; 0fb4: 1683
    bcf     0x03, 0x6                ; 0fb5: 1303
    movwf   0x48                     ; 0fb6: 00c8
    clrf    0x49                     ; 0fb7: 01c9
    addwf   0x49, 0x1                ; 0fb8: 07c9
    movf    0x47, 0x0                ; 0fb9: 0847
    addwf   0x49, 0x1                ; 0fba: 07c9
    movf    0x46, 0x0                ; 0fbb: 0846
    addwf   0x49, 0x1                ; 0fbc: 07c9
    movf    0x45, 0x0                ; 0fbd: 0845
    addwf   0x49, 0x1                ; 0fbe: 07c9
    movf    0x44, 0x0                ; 0fbf: 0844
    addwf   0x49, 0x1                ; 0fc0: 07c9
    bsf     0x0c, 0x4                ; 0fc1: 160c
    bsf     0x18, 0x5                ; 0fc2: 1698
    goto    0x07de                   ; 0fc3: 2fde
    bsf     0x03, 0x6                ; 0fc4: 1703
    movf    0x35, 0x0                ; 0fc5: 0835
    andlw   0xff                     ; 0fc6: 39ff
    btfsc   0x03, 0x2                ; 0fc7: 1903
    goto    0x071b                   ; 0fc8: 2f1b
    xorlw   0x01                     ; 0fc9: 3a01
    btfsc   0x03, 0x2                ; 0fca: 1903
    goto    0x0723                   ; 0fcb: 2f23
    xorlw   0x03                     ; 0fcc: 3a03
    btfsc   0x03, 0x2                ; 0fcd: 1903
    goto    0x0745                   ; 0fce: 2f45
    xorlw   0x01                     ; 0fcf: 3a01
    btfsc   0x03, 0x2                ; 0fd0: 1903
    goto    0x0762                   ; 0fd1: 2f62
    goto    0x07de                   ; 0fd2: 2fde
    bsf     0x0a, 0x4                ; 0fd3: 160a
    bsf     0x0a, 0x3                ; 0fd4: 158a
    call    0x06bd                   ; 0fd5: 26bd
    bcf     0x0a, 0x4                ; 0fd6: 120a
    bsf     0x0a, 0x3                ; 0fd7: 158a
    xorlw   0x00                     ; 0fd8: 3a00
    btfsc   0x03, 0x2                ; 0fd9: 1903
    goto    0x06f6                   ; 0fda: 2ef6
    xorlw   0x03                     ; 0fdb: 3a03
    btfsc   0x03, 0x2                ; 0fdc: 1903
    goto    0x07c4                   ; 0fdd: 2fc4
    bsf     0x03, 0x5                ; 0fde: 1683
    bsf     0x03, 0x6                ; 0fdf: 1703
    movf    0x43, 0x0                ; 0fe0: 0843
    bcf     0x03, 0x5                ; 0fe1: 1283
    bcf     0x03, 0x6                ; 0fe2: 1303
    movwf   0x56                     ; 0fe3: 00d6
    bsf     0x03, 0x5                ; 0fe4: 1683
    bsf     0x03, 0x6                ; 0fe5: 1703
    movf    0x42, 0x0                ; 0fe6: 0842
    bsf     0x0a, 0x4                ; 0fe7: 160a
    bcf     0x0a, 0x3                ; 0fe8: 118a
    call    0x01e7                   ; 0fe9: 21e7
    bcf     0x0a, 0x4                ; 0fea: 120a
    bsf     0x0a, 0x3                ; 0feb: 158a
    goto    0x07fe                   ; 0fec: 2ffe
    bsf     0x0a, 0x4                ; 0fed: 160a
    bsf     0x0a, 0x3                ; 0fee: 158a
    call    0x0685                   ; 0fef: 2685
    bcf     0x0a, 0x4                ; 0ff0: 120a
    bsf     0x0a, 0x3                ; 0ff1: 158a
    xorlw   0x00                     ; 0ff2: 3a00
    btfsc   0x03, 0x2                ; 0ff3: 1903
    goto    0x00e9                   ; 0ff4: 28e9
    xorlw   0x01                     ; 0ff5: 3a01
    btfsc   0x03, 0x2                ; 0ff6: 1903
    goto    0x0219                   ; 0ff7: 2a19
    xorlw   0x03                     ; 0ff8: 3a03
    btfsc   0x03, 0x2                ; 0ff9: 1903
    goto    0x02d8                   ; 0ffa: 2ad8
    xorlw   0x01                     ; 0ffb: 3a01
    btfsc   0x03, 0x2                ; 0ffc: 1903
    goto    0x0682                   ; 0ffd: 2e82
    clrf    0x03                     ; 0ffe: 0183
    return                           ; 0fff: 0008
    clrf    0x03                     ; 1000: 0183
    movwf   0x56                     ; 1001: 00d6
    bcf     0x03, 0x0                ; 1002: 1003
    rlf     0x56, 0x1                ; 1003: 0dd6
    bcf     0x03, 0x0                ; 1004: 1003
    rlf     0x56, 0x1                ; 1005: 0dd6
    movlw   0xe3                     ; 1006: 30e3
    andwf   0x1f, 0x1                ; 1007: 059f
    movf    0x56, 0x0                ; 1008: 0856
    iorwf   0x1f, 0x1                ; 1009: 049f
    bsf     0x1f, 0x0                ; 100a: 141f
    clrf    0x57                     ; 100b: 01d7
    nop                              ; 100c: 0000
    incf    0x57, 0x1                ; 100d: 0ad7
    movlw   0x05                     ; 100e: 3005
    subwf   0x57, 0x0                ; 100f: 0257
    btfss   0x03, 0x0                ; 1010: 1c03
    goto    0x000c                   ; 1011: 280c
    bsf     0x1f, 0x1                ; 1012: 149f
    btfsc   0x1f, 0x1                ; 1013: 189f
    goto    0x0013                   ; 1014: 2813
    bcf     0x1f, 0x0                ; 1015: 101f
    movf    0x1e, 0x0                ; 1016: 081e
    movwf   0x71                     ; 1017: 00f1
    clrf    0x70                     ; 1018: 01f0
    bsf     0x03, 0x5                ; 1019: 1683
    movf    0x1e, 0x0                ; 101a: 081e
    iorwf   0x70, 0x1                ; 101b: 04f0
    bcf     0x03, 0x5                ; 101c: 1283
    return                           ; 101d: 0008
    clrf    0x03                     ; 101e: 0183
    movwf   0x4c                     ; 101f: 00cc
    movlw   0x05                     ; 1020: 3005
    subwf   0x4c, 0x0                ; 1021: 024c
    btfsc   0x03, 0x0                ; 1022: 1803
    retlw   0x01                     ; 1023: 3401
    movf    0x4b, 0x0                ; 1024: 084b
    iorwf   0x4a, 0x0                ; 1025: 044a
    btfsc   0x03, 0x2                ; 1026: 1903
    goto    0x003a                   ; 1027: 283a
    movf    0x4a, 0x0                ; 1028: 084a
    movwf   0x4d                     ; 1029: 00cd
    movf    0x4b, 0x0                ; 102a: 084b
    movwf   0x4e                     ; 102b: 00ce
    movf    0x4c, 0x0                ; 102c: 084c
    movwf   0x4f                     ; 102d: 00cf
    clrf    0x50                     ; 102e: 01d0
    incf    0x50, 0x1                ; 102f: 0ad0
    bsf     0x0a, 0x4                ; 1030: 160a
    bsf     0x0a, 0x3                ; 1031: 158a
    call    0x05fe                   ; 1032: 25fe
    bsf     0x0a, 0x4                ; 1033: 160a
    bcf     0x0a, 0x3                ; 1034: 118a
    movwf   0x70                     ; 1035: 00f0
    clrf    0x71                     ; 1036: 01f1
    iorwf   0x71, 0x0                ; 1037: 0471
    btfsc   0x03, 0x2                ; 1038: 1903
    retlw   0x07                     ; 1039: 3407
    bsf     0x0a, 0x4                ; 103a: 160a
    bsf     0x0a, 0x3                ; 103b: 158a
    call    0x06d8                   ; 103c: 26d8
    movf    0x4c, 0x0                ; 103d: 084c
    addwf   0x4c, 0x0                ; 103e: 074c
    addlw   0xb5                     ; 103f: 3eb5
    movwf   0x04                     ; 1040: 0084
    bcf     0x03, 0x7                ; 1041: 1383
    movf    0x4a, 0x0                ; 1042: 084a
    movwf   0x00                     ; 1043: 0080
    incf    0x04, 0x1                ; 1044: 0a84
    movf    0x4b, 0x0                ; 1045: 084b
    movwf   0x00                     ; 1046: 0080
    bsf     0x0a, 0x4                ; 1047: 160a
    bsf     0x0a, 0x3                ; 1048: 158a
    call    0x06ac                   ; 1049: 26ac
    bsf     0x0a, 0x4                ; 104a: 160a
    bcf     0x0a, 0x3                ; 104b: 118a
    retlw   0x00                     ; 104c: 3400
    clrf    0x03                     ; 104d: 0183
    movwf   0x3d                     ; 104e: 00bd
    clrf    0x3c                     ; 104f: 01bc
    movlw   0x04                     ; 1050: 3004
    incf    0x35, 0x1                ; 1051: 0ab5
    subwf   0x35, 0x0                ; 1052: 0235
    btfsc   0x03, 0x0                ; 1053: 1803
    goto    0x0072                   ; 1054: 2872
    movf    0x3d, 0x1                ; 1055: 08bd
    btfss   0x03, 0x2                ; 1056: 1d03
    goto    0x006a                   ; 1057: 286a
    bsf     0x0a, 0x4                ; 1058: 160a
    bcf     0x0a, 0x3                ; 1059: 118a
    call    0x06e8                   ; 105a: 26e8
    bsf     0x0a, 0x4                ; 105b: 160a
    bcf     0x0a, 0x3                ; 105c: 118a
    goto    0x006d                   ; 105d: 286d
    bsf     0x0a, 0x4                ; 105e: 160a
    bcf     0x0a, 0x3                ; 105f: 118a
    call    0x06e8                   ; 1060: 26e8
    bsf     0x0a, 0x4                ; 1061: 160a
    bcf     0x0a, 0x3                ; 1062: 118a
    call    0x0795                   ; 1063: 2795
    bsf     0x0a, 0x4                ; 1064: 160a
    bcf     0x0a, 0x3                ; 1065: 118a
    xorlw   0x05                     ; 1066: 3a05
    btfsc   0x03, 0x2                ; 1067: 1903
    goto    0x006d                   ; 1068: 286d
    decf    0x3d, 0x1                ; 1069: 03bd
    movf    0x3d, 0x1                ; 106a: 08bd
    btfss   0x03, 0x2                ; 106b: 1d03
    goto    0x005e                   ; 106c: 285e
    movf    0x3d, 0x1                ; 106d: 08bd
    btfss   0x03, 0x2                ; 106e: 1d03
    goto    0x0079                   ; 106f: 2879
    movlw   0x05                     ; 1070: 3005
    goto    0x0078                   ; 1071: 2878
    bsf     0x0a, 0x4                ; 1072: 160a
    bcf     0x0a, 0x3                ; 1073: 118a
    call    0x06e8                   ; 1074: 26e8
    bsf     0x0a, 0x4                ; 1075: 160a
    bcf     0x0a, 0x3                ; 1076: 118a
    movlw   0x06                     ; 1077: 3006
    movwf   0x3c                     ; 1078: 00bc
    decf    0x35, 0x1                ; 1079: 03b5
    movf    0x60, 0x0                ; 107a: 0860
    movf    0x3c, 0x0                ; 107b: 083c
    return                           ; 107c: 0008
    clrf    0x03                     ; 107d: 0183
    movwf   0x46                     ; 107e: 00c6
    movf    0x43, 0x0                ; 107f: 0843
    bsf     0x0a, 0x4                ; 1080: 160a
    bsf     0x0a, 0x3                ; 1081: 158a
    call    0x0741                   ; 1082: 2741
    bsf     0x0a, 0x4                ; 1083: 160a
    bcf     0x0a, 0x3                ; 1084: 118a
    movf    0x70, 0x0                ; 1085: 0870
    movwf   0x48                     ; 1086: 00c8
    movf    0x71, 0x0                ; 1087: 0871
    movwf   0x49                     ; 1088: 00c9
    goto    0x00a2                   ; 1089: 28a2
    movf    0x43, 0x0                ; 108a: 0843
    movwf   0x4a                     ; 108b: 00ca
    movf    0x46, 0x0                ; 108c: 0846
    bsf     0x0a, 0x4                ; 108d: 160a
    bsf     0x0a, 0x3                ; 108e: 158a
    call    0x0722                   ; 108f: 2722
    bsf     0x0a, 0x4                ; 1090: 160a
    bcf     0x0a, 0x3                ; 1091: 118a
    movwf   0x47                     ; 1092: 00c7
    xorlw   0x02                     ; 1093: 3a02
    btfss   0x03, 0x2                ; 1094: 1d03
    goto    0x00a0                   ; 1095: 28a0
    movf    0x48, 0x0                ; 1096: 0848
    movwf   0x4a                     ; 1097: 00ca
    movf    0x49, 0x0                ; 1098: 0849
    movwf   0x4b                     ; 1099: 00cb
    movf    0x43, 0x0                ; 109a: 0843
    bsf     0x0a, 0x4                ; 109b: 160a
    bcf     0x0a, 0x3                ; 109c: 118a
    call    0x001e                   ; 109d: 201e
    bsf     0x0a, 0x4                ; 109e: 160a
    bcf     0x0a, 0x3                ; 109f: 118a
    movf    0x47, 0x0                ; 10a0: 0847
    return                           ; 10a1: 0008
    movf    0x44, 0x0                ; 10a2: 0844
    movwf   0x4a                     ; 10a3: 00ca
    movf    0x45, 0x0                ; 10a4: 0845
    movwf   0x4b                     ; 10a5: 00cb
    movf    0x43, 0x0                ; 10a6: 0843
    bsf     0x0a, 0x4                ; 10a7: 160a
    bcf     0x0a, 0x3                ; 10a8: 118a
    call    0x001e                   ; 10a9: 201e
    bsf     0x0a, 0x4                ; 10aa: 160a
    bcf     0x0a, 0x3                ; 10ab: 118a
    xorlw   0x00                     ; 10ac: 3a00
    btfsc   0x03, 0x2                ; 10ad: 1903
    goto    0x008a                   ; 10ae: 288a
    xorlw   0x01                     ; 10af: 3a01
    btfsc   0x03, 0x2                ; 10b0: 1903
    retlw   0x01                     ; 10b1: 3401
    retlw   0x02                     ; 10b2: 3402
    clrf    0x03                     ; 10b3: 0183
    clrf    0x3f                     ; 10b4: 01bf
    goto    0x00f2                   ; 10b5: 28f2
    movlw   0x03                     ; 10b6: 3003
    movwf   0x72                     ; 10b7: 00f2
    clrf    0x73                     ; 10b8: 01f3
    movf    0x3f, 0x0                ; 10b9: 083f
    movwf   0x70                     ; 10ba: 00f0
    clrf    0x71                     ; 10bb: 01f1
    bsf     0x0a, 0x4                ; 10bc: 160a
    bsf     0x0a, 0x3                ; 10bd: 158a
    call    0x06ee                   ; 10be: 26ee
    movf    0x3c, 0x0                ; 10bf: 083c
    addwf   0x74, 0x1                ; 10c0: 07f4
    btfsc   0x03, 0x0                ; 10c1: 1803
    incf    0x75, 0x1                ; 10c2: 0af5
    movf    0x3d, 0x0                ; 10c3: 083d
    addwf   0x75, 0x1                ; 10c4: 07f5
    movf    0x75, 0x0                ; 10c5: 0875
    movwf   0x67                     ; 10c6: 00e7
    movf    0x74, 0x0                ; 10c7: 0874
    addlw   0x01                     ; 10c8: 3e01
    btfsc   0x03, 0x0                ; 10c9: 1803
    incf    0x67, 0x1                ; 10ca: 0ae7
    bcf     0x0a, 0x4                ; 10cb: 120a
    bcf     0x0a, 0x3                ; 10cc: 118a
    call    0x01e7                   ; 10cd: 21e7
    movwf   0x70                     ; 10ce: 00f0
    bcf     0x0a, 0x4                ; 10cf: 120a
    bcf     0x0a, 0x3                ; 10d0: 118a
    call    0x01ea                   ; 10d1: 21ea
    movwf   0x71                     ; 10d2: 00f1
    movf    0x70, 0x0                ; 10d3: 0870
    movwf   0x4a                     ; 10d4: 00ca
    movf    0x71, 0x0                ; 10d5: 0871
    movwf   0x4b                     ; 10d6: 00cb
    movlw   0x03                     ; 10d7: 3003
    movwf   0x72                     ; 10d8: 00f2
    clrf    0x73                     ; 10d9: 01f3
    movf    0x3f, 0x0                ; 10da: 083f
    movwf   0x70                     ; 10db: 00f0
    clrf    0x71                     ; 10dc: 01f1
    bsf     0x0a, 0x4                ; 10dd: 160a
    bsf     0x0a, 0x3                ; 10de: 158a
    call    0x06ee                   ; 10df: 26ee
    movf    0x75, 0x0                ; 10e0: 0875
    addwf   0x3d, 0x0                ; 10e1: 073d
    movwf   0x67                     ; 10e2: 00e7
    movf    0x74, 0x0                ; 10e3: 0874
    addwf   0x3c, 0x0                ; 10e4: 073c
    btfsc   0x03, 0x0                ; 10e5: 1803
    incf    0x67, 0x1                ; 10e6: 0ae7
    bcf     0x0a, 0x4                ; 10e7: 120a
    bcf     0x0a, 0x3                ; 10e8: 118a
    call    0x01e7                   ; 10e9: 21e7
    bsf     0x0a, 0x4                ; 10ea: 160a
    bcf     0x0a, 0x3                ; 10eb: 118a
    call    0x001e                   ; 10ec: 201e
    bsf     0x0a, 0x4                ; 10ed: 160a
    bcf     0x0a, 0x3                ; 10ee: 118a
    movwf   0x70                     ; 10ef: 00f0
    clrf    0x71                     ; 10f0: 01f1
    incf    0x3f, 0x1                ; 10f1: 0abf
    movf    0x3e, 0x0                ; 10f2: 083e
    subwf   0x3f, 0x0                ; 10f3: 023f
    btfsc   0x03, 0x0                ; 10f4: 1803
    return                           ; 10f5: 0008
    goto    0x00b6                   ; 10f6: 28b6
    clrf    0x03                     ; 10f7: 0183
    movwf   0x3e                     ; 10f8: 00be
    movlw   0x05                     ; 10f9: 3005
    subwf   0x3e, 0x0                ; 10fa: 023e
    btfsc   0x03, 0x0                ; 10fb: 1803
    retlw   0x01                     ; 10fc: 3401
    movf    0x3e, 0x0                ; 10fd: 083e
    addwf   0x3e, 0x0                ; 10fe: 073e
    addlw   0xb5                     ; 10ff: 3eb5
    movwf   0x04                     ; 1100: 0084
    bcf     0x03, 0x7                ; 1101: 1383
    movf    0x00, 0x0                ; 1102: 0800
    movwf   0x70                     ; 1103: 00f0
    incf    0x04, 0x1                ; 1104: 0a84
    movf    0x00, 0x0                ; 1105: 0800
    movwf   0x71                     ; 1106: 00f1
    iorwf   0x70, 0x0                ; 1107: 0470
    btfsc   0x03, 0x2                ; 1108: 1903
    retlw   0x03                     ; 1109: 3403
    movf    0x3e, 0x0                ; 110a: 083e
    addlw   0xa2                     ; 110b: 3ea2
    movwf   0x04                     ; 110c: 0084
    incfsz  0x00, 0x0                ; 110d: 0f00
    goto    0x0110                   ; 110e: 2910
    retlw   0x04                     ; 110f: 3404
    nop                              ; 1110: 0000
    bcf     0x03, 0x5                ; 1111: 1283
    bcf     0x03, 0x6                ; 1112: 1303
    incf    0x29, 0x1                ; 1113: 0aa9
    decfsz  0x29, 0x0                ; 1114: 0b29
    goto    0x011a                   ; 1115: 291a
    movf    0x0b, 0x0                ; 1116: 080b
    andlw   0x80                     ; 1117: 3980
    movwf   0x2a                     ; 1118: 00aa
    bcf     0x0b, 0x7                ; 1119: 138b
    bsf     0x03, 0x5                ; 111a: 1683
    incf    0x20, 0x1                ; 111b: 0aa0
    bcf     0x03, 0x5                ; 111c: 1283
    movf    0x3e, 0x0                ; 111d: 083e
    movwf   0x70                     ; 111e: 00f0
    bcf     0x03, 0x0                ; 111f: 1003
    rrf     0x70, 0x1                ; 1120: 0cf0
    bcf     0x03, 0x0                ; 1121: 1003
    rrf     0x70, 0x1                ; 1122: 0cf0
    bcf     0x03, 0x0                ; 1123: 1003
    rrf     0x70, 0x0                ; 1124: 0c70
    addlw   0xa1                     ; 1125: 3ea1
    movwf   0x04                     ; 1126: 0084
    movlw   0x18                     ; 1127: 3018
    movwf   0x0a                     ; 1128: 008a
    movf    0x3e, 0x0                ; 1129: 083e
    andlw   0x07                     ; 112a: 3907
    call    0x0032                   ; 112b: 2032
    bsf     0x0a, 0x4                ; 112c: 160a
    bcf     0x0a, 0x3                ; 112d: 118a
    iorwf   0x00, 0x1                ; 112e: 0480
    movf    0x3e, 0x0                ; 112f: 083e
    addlw   0xa2                     ; 1130: 3ea2
    movwf   0x04                     ; 1131: 0084
    bcf     0x03, 0x7                ; 1132: 1383
    incf    0x00, 0x1                ; 1133: 0a80
    movf    0x3e, 0x0                ; 1134: 083e
    addlw   0xa2                     ; 1135: 3ea2
    movwf   0x04                     ; 1136: 0084
    movf    0x00, 0x0                ; 1137: 0800
    movwf   0x28                     ; 1138: 00a8
    bcf     0x03, 0x5                ; 1139: 1283
    bcf     0x03, 0x6                ; 113a: 1303
    decfsz  0x29, 0x1                ; 113b: 0ba9
    retlw   0x00                     ; 113c: 3400
    movf    0x2a, 0x0                ; 113d: 082a
    btfss   0x03, 0x2                ; 113e: 1d03
    bsf     0x0b, 0x7                ; 113f: 178b
    retlw   0x00                     ; 1140: 3400
    clrf    0x03                     ; 1141: 0183
    movf    0x3d, 0x0                ; 1142: 083d
    movwf   0x67                     ; 1143: 00e7
    movf    0x3c, 0x0                ; 1144: 083c
    addlw   0x02                     ; 1145: 3e02
    btfsc   0x03, 0x0                ; 1146: 1803
    incf    0x67, 0x1                ; 1147: 0ae7
    bcf     0x0a, 0x4                ; 1148: 120a
    bcf     0x0a, 0x3                ; 1149: 118a
    call    0x01e7                   ; 114a: 21e7
    movwf   0x70                     ; 114b: 00f0
    bcf     0x0a, 0x4                ; 114c: 120a
    bcf     0x0a, 0x3                ; 114d: 118a
    call    0x01ea                   ; 114e: 21ea
    bsf     0x0a, 0x4                ; 114f: 160a
    bcf     0x0a, 0x3                ; 1150: 118a
    movwf   0x71                     ; 1151: 00f1
    iorwf   0x70, 0x0                ; 1152: 0470
    btfsc   0x03, 0x2                ; 1153: 1903
    retlw   0x02                     ; 1154: 3402
    movf    0x3d, 0x0                ; 1155: 083d
    movwf   0x67                     ; 1156: 00e7
    movf    0x3c, 0x0                ; 1157: 083c
    addlw   0x02                     ; 1158: 3e02
    btfsc   0x03, 0x0                ; 1159: 1803
    incf    0x67, 0x1                ; 115a: 0ae7
    bcf     0x0a, 0x4                ; 115b: 120a
    bcf     0x0a, 0x3                ; 115c: 118a
    call    0x01e7                   ; 115d: 21e7
    movwf   0x70                     ; 115e: 00f0
    bcf     0x0a, 0x4                ; 115f: 120a
    bcf     0x0a, 0x3                ; 1160: 118a
    call    0x01ea                   ; 1161: 21ea
    movwf   0x71                     ; 1162: 00f1
    movf    0x70, 0x0                ; 1163: 0870
    movwf   0x3c                     ; 1164: 00bc
    movf    0x71, 0x0                ; 1165: 0871
    movwf   0x3d                     ; 1166: 00bd
    movwf   0x67                     ; 1167: 00e7
    movlw   0xff                     ; 1168: 30ff
    addwf   0x3c, 0x0                ; 1169: 073c
    btfss   0x03, 0x0                ; 116a: 1c03
    decf    0x67, 0x1                ; 116b: 03e7
    bcf     0x0a, 0x4                ; 116c: 120a
    bcf     0x0a, 0x3                ; 116d: 118a
    call    0x01e7                   ; 116e: 21e7
    movwf   0x04                     ; 116f: 0084
    bcf     0x03, 0x7                ; 1170: 1383
    movf    0x3e, 0x0                ; 1171: 083e
    movwf   0x00                     ; 1172: 0080
    incf    0x04, 0x1                ; 1173: 0a84
    movf    0x3f, 0x0                ; 1174: 083f
    movwf   0x00                     ; 1175: 0080
    movf    0x3d, 0x0                ; 1176: 083d
    movwf   0x67                     ; 1177: 00e7
    movlw   0xff                     ; 1178: 30ff
    addwf   0x3c, 0x0                ; 1179: 073c
    btfss   0x03, 0x0                ; 117a: 1c03
    decf    0x67, 0x1                ; 117b: 03e7
    bcf     0x0a, 0x4                ; 117c: 120a
    bcf     0x0a, 0x3                ; 117d: 118a
    call    0x01e7                   ; 117e: 21e7
    addlw   0x02                     ; 117f: 3e02
    movwf   0x04                     ; 1180: 0084
    bcf     0x03, 0x7                ; 1181: 1383
    movf    0x40, 0x0                ; 1182: 0840
    movwf   0x00                     ; 1183: 0080
    movf    0x3d, 0x0                ; 1184: 083d
    movwf   0x67                     ; 1185: 00e7
    movf    0x3c, 0x0                ; 1186: 083c
    bcf     0x0a, 0x4                ; 1187: 120a
    bcf     0x0a, 0x3                ; 1188: 118a
    call    0x01e7                   ; 1189: 21e7
    bsf     0x0a, 0x4                ; 118a: 160a
    bcf     0x0a, 0x3                ; 118b: 118a
    movwf   0x70                     ; 118c: 00f0
    clrf    0x71                     ; 118d: 01f1
    decf    0x70, 0x0                ; 118e: 0370
    iorwf   0x71, 0x0                ; 118f: 0471
    btfsc   0x03, 0x2                ; 1190: 1903
    retlw   0x00                     ; 1191: 3400
    retlw   0x01                     ; 1192: 3401
    clrf    0x03                     ; 1193: 0183
    movwf   0x48                     ; 1194: 00c8
    movlw   0x01                     ; 1195: 3001
    subwf   0x48, 0x0                ; 1196: 0248
    btfsc   0x03, 0x0                ; 1197: 1803
    retlw   0x02                     ; 1198: 3402
    bsf     0x0a, 0x4                ; 1199: 160a
    bsf     0x0a, 0x3                ; 119a: 158a
    call    0x06d8                   ; 119b: 26d8
    bsf     0x0a, 0x4                ; 119c: 160a
    bcf     0x0a, 0x3                ; 119d: 118a
    movf    0x44, 0x0                ; 119e: 0844
    iorwf   0x43, 0x0                ; 119f: 0443
    movlw   0x05                     ; 11a0: 3005
    movwf   0x71                     ; 11a1: 00f1
    btfss   0x03, 0x2                ; 11a2: 1d03
    goto    0x01b2                   ; 11a3: 29b2
    movf    0x48, 0x0                ; 11a4: 0848
    bsf     0x0a, 0x4                ; 11a5: 160a
    bsf     0x0a, 0x3                ; 11a6: 158a
    call    0x06e2                   ; 11a7: 26e2
    addlw   0x02                     ; 11a8: 3e02
    addlw   0xa7                     ; 11a9: 3ea7
    movwf   0x04                     ; 11aa: 0084
    bcf     0x03, 0x7                ; 11ab: 1383
    movf    0x00, 0x0                ; 11ac: 0800
    bsf     0x0a, 0x4                ; 11ad: 160a
    bcf     0x0a, 0x3                ; 11ae: 118a
    call    0x0716                   ; 11af: 2716
    movlw   0x05                     ; 11b0: 3005
    movwf   0x71                     ; 11b1: 00f1
    movf    0x48, 0x0                ; 11b2: 0848
    bsf     0x0a, 0x4                ; 11b3: 160a
    bsf     0x0a, 0x3                ; 11b4: 158a
    call    0x06e2                   ; 11b5: 26e2
    addlw   0xa7                     ; 11b6: 3ea7
    movwf   0x04                     ; 11b7: 0084
    bcf     0x03, 0x7                ; 11b8: 1383
    movf    0x43, 0x0                ; 11b9: 0843
    movwf   0x00                     ; 11ba: 0080
    incf    0x04, 0x1                ; 11bb: 0a84
    movf    0x44, 0x0                ; 11bc: 0844
    movwf   0x00                     ; 11bd: 0080
    movlw   0x05                     ; 11be: 3005
    movwf   0x71                     ; 11bf: 00f1
    movf    0x48, 0x0                ; 11c0: 0848
    bsf     0x0a, 0x4                ; 11c1: 160a
    bsf     0x0a, 0x3                ; 11c2: 158a
    call    0x06e2                   ; 11c3: 26e2
    addlw   0x03                     ; 11c4: 3e03
    addlw   0xa7                     ; 11c5: 3ea7
    movwf   0x04                     ; 11c6: 0084
    bcf     0x03, 0x7                ; 11c7: 1383
    movf    0x45, 0x0                ; 11c8: 0845
    movwf   0x00                     ; 11c9: 0080
    incf    0x04, 0x1                ; 11ca: 0a84
    movf    0x46, 0x0                ; 11cb: 0846
    movwf   0x00                     ; 11cc: 0080
    movlw   0x05                     ; 11cd: 3005
    movwf   0x71                     ; 11ce: 00f1
    movf    0x48, 0x0                ; 11cf: 0848
    bsf     0x0a, 0x4                ; 11d0: 160a
    bsf     0x0a, 0x3                ; 11d1: 158a
    call    0x06e2                   ; 11d2: 26e2
    bsf     0x0a, 0x4                ; 11d3: 160a
    bcf     0x0a, 0x3                ; 11d4: 118a
    addlw   0x02                     ; 11d5: 3e02
    addlw   0xa7                     ; 11d6: 3ea7
    movwf   0x04                     ; 11d7: 0084
    bcf     0x03, 0x7                ; 11d8: 1383
    movf    0x00, 0x1                ; 11d9: 0880
    btfss   0x03, 0x2                ; 11da: 1d03
    goto    0x01df                   ; 11db: 29df
    movlw   0x03                     ; 11dc: 3003
    movwf   0x47                     ; 11dd: 00c7
    goto    0x01e0                   ; 11de: 29e0
    clrf    0x47                     ; 11df: 01c7
    bsf     0x0a, 0x4                ; 11e0: 160a
    bsf     0x0a, 0x3                ; 11e1: 158a
    call    0x06ac                   ; 11e2: 26ac
    bsf     0x0a, 0x4                ; 11e3: 160a
    bcf     0x0a, 0x3                ; 11e4: 118a
    movf    0x47, 0x0                ; 11e5: 0847
    return                           ; 11e6: 0008
    clrf    0x03                     ; 11e7: 0183
    movwf   0x57                     ; 11e8: 00d7
    movf    0x57, 0x1                ; 11e9: 08d7
    bsf     0x03, 0x5                ; 11ea: 1683
    btfsc   0x03, 0x2                ; 11eb: 1903
    goto    0x01f3                   ; 11ec: 29f3
    movf    0x12, 0x0                ; 11ed: 0812
    xorlw   0x4f                     ; 11ee: 3a4f
    btfsc   0x03, 0x2                ; 11ef: 1903
    goto    0x020d                   ; 11f0: 2a0d
    movlw   0x4f                     ; 11f1: 304f
    goto    0x01f8                   ; 11f2: 29f8
    movf    0x12, 0x0                ; 11f3: 0812
    xorlw   0x5a                     ; 11f4: 3a5a
    btfsc   0x03, 0x2                ; 11f5: 1903
    goto    0x020d                   ; 11f6: 2a0d
    movlw   0x5a                     ; 11f7: 305a
    movwf   0x12                     ; 11f8: 0092
    goto    0x020d                   ; 11f9: 2a0d
    bsf     0x03, 0x5                ; 11fa: 1683
    bsf     0x03, 0x6                ; 11fb: 1703
    movf    0x3f, 0x0                ; 11fc: 083f
    goto    0x0209                   ; 11fd: 2a09
    bsf     0x03, 0x5                ; 11fe: 1683
    bsf     0x03, 0x6                ; 11ff: 1703
    movf    0x40, 0x0                ; 1200: 0840
    goto    0x0209                   ; 1201: 2a09
    bsf     0x03, 0x5                ; 1202: 1683
    bsf     0x03, 0x6                ; 1203: 1703
    movf    0x41, 0x0                ; 1204: 0841
    goto    0x0209                   ; 1205: 2a09
    bsf     0x03, 0x5                ; 1206: 1683
    bsf     0x03, 0x6                ; 1207: 1703
    movf    0x3e, 0x0                ; 1208: 083e
    bcf     0x03, 0x5                ; 1209: 1283
    bcf     0x03, 0x6                ; 120a: 1303
    movwf   0x58                     ; 120b: 00d8
    goto    0x021a                   ; 120c: 2a1a
    bcf     0x03, 0x5                ; 120d: 1283
    movf    0x56, 0x0                ; 120e: 0856
    btfsc   0x03, 0x2                ; 120f: 1903
    goto    0x01fa                   ; 1210: 29fa
    xorlw   0x01                     ; 1211: 3a01
    btfsc   0x03, 0x2                ; 1212: 1903
    goto    0x01fe                   ; 1213: 29fe
    xorlw   0x03                     ; 1214: 3a03
    btfsc   0x03, 0x2                ; 1215: 1903
    goto    0x0202                   ; 1216: 2a02
    xorlw   0x01                     ; 1217: 3a01
    btfsc   0x03, 0x2                ; 1218: 1903
    goto    0x0206                   ; 1219: 2a06
    movf    0x58, 0x0                ; 121a: 0858
    movwf   0x70                     ; 121b: 00f0
    bcf     0x03, 0x0                ; 121c: 1003
    rrf     0x70, 0x1                ; 121d: 0cf0
    bcf     0x03, 0x0                ; 121e: 1003
    rrf     0x70, 0x0                ; 121f: 0c70
    xorwf   0x15, 0x0                ; 1220: 0615
    btfss   0x03, 0x2                ; 1221: 1d03
    goto    0x0239                   ; 1222: 2a39
    movf    0x58, 0x0                ; 1223: 0858
    andlw   0x01                     ; 1224: 3901
    movwf   0x70                     ; 1225: 00f0
    clrf    0x71                     ; 1226: 01f1
    movlw   0x00                     ; 1227: 3000
    btfsc   0x17, 0x4                ; 1228: 1a17
    movlw   0x01                     ; 1229: 3001
    xorwf   0x70, 0x0                ; 122a: 0670
    iorwf   0x71, 0x0                ; 122b: 0471
    btfss   0x03, 0x2                ; 122c: 1d03
    goto    0x0239                   ; 122d: 2a39
    movf    0x58, 0x0                ; 122e: 0858
    andlw   0x02                     ; 122f: 3902
    movwf   0x70                     ; 1230: 00f0
    clrf    0x71                     ; 1231: 01f1
    movlw   0x00                     ; 1232: 3000
    btfsc   0x17, 0x5                ; 1233: 1a97
    movlw   0x01                     ; 1234: 3001
    xorwf   0x70, 0x0                ; 1235: 0670
    iorwf   0x71, 0x0                ; 1236: 0471
    btfsc   0x03, 0x2                ; 1237: 1903
    return                           ; 1238: 0008
    movf    0x58, 0x0                ; 1239: 0858
    movwf   0x70                     ; 123a: 00f0
    bcf     0x03, 0x0                ; 123b: 1003
    rrf     0x70, 0x1                ; 123c: 0cf0
    bcf     0x03, 0x0                ; 123d: 1003
    rrf     0x70, 0x0                ; 123e: 0c70
    movwf   0x15                     ; 123f: 0095
    btfss   0x58, 0x0                ; 1240: 1c58
    goto    0x0244                   ; 1241: 2a44
    bsf     0x17, 0x4                ; 1242: 1617
    goto    0x0245                   ; 1243: 2a45
    bcf     0x17, 0x4                ; 1244: 1217
    btfss   0x58, 0x1                ; 1245: 1cd8
    goto    0x0249                   ; 1246: 2a49
    bsf     0x17, 0x5                ; 1247: 1697
    return                           ; 1248: 0008
    bcf     0x17, 0x5                ; 1249: 1297
    return                           ; 124a: 0008
    bcf     0x0a, 0x4                ; 124b: 120a
    bcf     0x0a, 0x3                ; 124c: 118a
    call    0x0741                   ; 124d: 2741
    movlw   0x00                     ; 124e: 3000
    bcf     0x0a, 0x4                ; 124f: 120a
    bcf     0x0a, 0x3                ; 1250: 118a
    call    0x0698                   ; 1251: 2698
    movwf   0x56                     ; 1252: 00d6
    movlw   0x01                     ; 1253: 3001
    bcf     0x0a, 0x4                ; 1254: 120a
    bcf     0x0a, 0x3                ; 1255: 118a
    call    0x0698                   ; 1256: 2698
    addwf   0x56, 0x1                ; 1257: 07d6
    movlw   0x02                     ; 1258: 3002
    bcf     0x0a, 0x4                ; 1259: 120a
    bcf     0x0a, 0x3                ; 125a: 118a
    call    0x0698                   ; 125b: 2698
    addwf   0x56, 0x1                ; 125c: 07d6
    movlw   0x03                     ; 125d: 3003
    bcf     0x0a, 0x4                ; 125e: 120a
    bcf     0x0a, 0x3                ; 125f: 118a
    call    0x0698                   ; 1260: 2698
    addwf   0x56, 0x1                ; 1261: 07d6
    bsf     0x03, 0x5                ; 1262: 1683
    bsf     0x03, 0x6                ; 1263: 1703
    movf    0x3b, 0x0                ; 1264: 083b
    bcf     0x03, 0x5                ; 1265: 1283
    bcf     0x03, 0x6                ; 1266: 1303
    addwf   0x56, 0x1                ; 1267: 07d6
    bsf     0x03, 0x6                ; 1268: 1703
    movf    0x22, 0x0                ; 1269: 0822
    bcf     0x03, 0x6                ; 126a: 1303
    addwf   0x56, 0x1                ; 126b: 07d6
    movlw   0x06                     ; 126c: 3006
    bcf     0x0a, 0x4                ; 126d: 120a
    bcf     0x0a, 0x3                ; 126e: 118a
    call    0x0698                   ; 126f: 2698
    addwf   0x56, 0x1                ; 1270: 07d6
    movlw   0x07                     ; 1271: 3007
    bcf     0x0a, 0x4                ; 1272: 120a
    bcf     0x0a, 0x3                ; 1273: 118a
    call    0x0698                   ; 1274: 2698
    bsf     0x0a, 0x4                ; 1275: 160a
    bcf     0x0a, 0x3                ; 1276: 118a
    addwf   0x56, 0x1                ; 1277: 07d6
    bsf     0x03, 0x5                ; 1278: 1683
    bsf     0x03, 0x6                ; 1279: 1703
    movf    0x3f, 0x0                ; 127a: 083f
    bcf     0x03, 0x5                ; 127b: 1283
    bcf     0x03, 0x6                ; 127c: 1303
    addwf   0x56, 0x1                ; 127d: 07d6
    bsf     0x03, 0x5                ; 127e: 1683
    bsf     0x03, 0x6                ; 127f: 1703
    movf    0x40, 0x0                ; 1280: 0840
    bcf     0x03, 0x5                ; 1281: 1283
    bcf     0x03, 0x6                ; 1282: 1303
    addwf   0x56, 0x1                ; 1283: 07d6
    bsf     0x03, 0x5                ; 1284: 1683
    bsf     0x03, 0x6                ; 1285: 1703
    movf    0x41, 0x0                ; 1286: 0841
    bcf     0x03, 0x5                ; 1287: 1283
    bcf     0x03, 0x6                ; 1288: 1303
    addwf   0x56, 0x1                ; 1289: 07d6
    bsf     0x03, 0x5                ; 128a: 1683
    bsf     0x03, 0x6                ; 128b: 1703
    movf    0x3e, 0x0                ; 128c: 083e
    bcf     0x03, 0x5                ; 128d: 1283
    bcf     0x03, 0x6                ; 128e: 1303
    addwf   0x56, 0x1                ; 128f: 07d6
    bsf     0x03, 0x5                ; 1290: 1683
    bsf     0x03, 0x6                ; 1291: 1703
    movf    0x30, 0x0                ; 1292: 0830
    bcf     0x03, 0x5                ; 1293: 1283
    bcf     0x03, 0x6                ; 1294: 1303
    addwf   0x56, 0x1                ; 1295: 07d6
    bsf     0x03, 0x5                ; 1296: 1683
    bsf     0x03, 0x6                ; 1297: 1703
    movf    0x31, 0x0                ; 1298: 0831
    bcf     0x03, 0x5                ; 1299: 1283
    bcf     0x03, 0x6                ; 129a: 1303
    addwf   0x56, 0x1                ; 129b: 07d6
    bsf     0x03, 0x5                ; 129c: 1683
    bsf     0x03, 0x6                ; 129d: 1703
    movf    0x33, 0x0                ; 129e: 0833
    bcf     0x03, 0x5                ; 129f: 1283
    bcf     0x03, 0x6                ; 12a0: 1303
    addwf   0x56, 0x1                ; 12a1: 07d6
    bsf     0x03, 0x5                ; 12a2: 1683
    bsf     0x03, 0x6                ; 12a3: 1703
    movf    0x3d, 0x0                ; 12a4: 083d
    bcf     0x03, 0x5                ; 12a5: 1283
    bcf     0x03, 0x6                ; 12a6: 1303
    addwf   0x56, 0x1                ; 12a7: 07d6
    movf    0x56, 0x0                ; 12a8: 0856
    bsf     0x03, 0x5                ; 12a9: 1683
    bsf     0x03, 0x6                ; 12aa: 1703
    movwf   0x3c                     ; 12ab: 00bc
    bcf     0x03, 0x5                ; 12ac: 1283
    bcf     0x03, 0x6                ; 12ad: 1303
    movf    0x56, 0x0                ; 12ae: 0856
    movwf   0x57                     ; 12af: 00d7
    movlw   0x10                     ; 12b0: 3010
    bsf     0x0a, 0x4                ; 12b1: 160a
    bcf     0x0a, 0x3                ; 12b2: 118a
    goto    0x05cc                   ; 12b3: 2dcc
    clrf    0x03                     ; 12b4: 0183
    movf    0x3d, 0x0                ; 12b5: 083d
    movwf   0x67                     ; 12b6: 00e7
    movf    0x3c, 0x0                ; 12b7: 083c
    bcf     0x0a, 0x4                ; 12b8: 120a
    bcf     0x0a, 0x3                ; 12b9: 118a
    call    0x01e7                   ; 12ba: 21e7
    bsf     0x0a, 0x4                ; 12bb: 160a
    bcf     0x0a, 0x3                ; 12bc: 118a
    movwf   0x3c                     ; 12bd: 00bc
    clrf    0x3e                     ; 12be: 01be
    goto    0x031b                   ; 12bf: 2b1b
    movf    0x3d, 0x0                ; 12c0: 083d
    movwf   0x67                     ; 12c1: 00e7
    movf    0x3c, 0x0                ; 12c2: 083c
    addlw   0x01                     ; 12c3: 3e01
    btfsc   0x03, 0x0                ; 12c4: 1803
    incf    0x67, 0x1                ; 12c5: 0ae7
    bcf     0x0a, 0x4                ; 12c6: 120a
    bcf     0x0a, 0x3                ; 12c7: 118a
    call    0x01e7                   ; 12c8: 21e7
    bsf     0x0a, 0x4                ; 12c9: 160a
    bcf     0x0a, 0x3                ; 12ca: 118a
    movwf   0x70                     ; 12cb: 00f0
    movf    0x3e, 0x0                ; 12cc: 083e
    addwf   0x3e, 0x0                ; 12cd: 073e
    addwf   0x70, 0x0                ; 12ce: 0770
    movwf   0x04                     ; 12cf: 0084
    bcf     0x03, 0x7                ; 12d0: 1383
    movf    0x00, 0x0                ; 12d1: 0800
    movwf   0x70                     ; 12d2: 00f0
    incf    0x04, 0x1                ; 12d3: 0a84
    movf    0x00, 0x0                ; 12d4: 0800
    movwf   0x71                     ; 12d5: 00f1
    iorwf   0x70, 0x0                ; 12d6: 0470
    btfsc   0x03, 0x2                ; 12d7: 1903
    goto    0x031a                   ; 12d8: 2b1a
    movf    0x3d, 0x0                ; 12d9: 083d
    movwf   0x67                     ; 12da: 00e7
    movf    0x3c, 0x0                ; 12db: 083c
    addlw   0x01                     ; 12dc: 3e01
    btfsc   0x03, 0x0                ; 12dd: 1803
    incf    0x67, 0x1                ; 12de: 0ae7
    bcf     0x0a, 0x4                ; 12df: 120a
    bcf     0x0a, 0x3                ; 12e0: 118a
    call    0x01e7                   ; 12e1: 21e7
    movwf   0x70                     ; 12e2: 00f0
    movf    0x3e, 0x0                ; 12e3: 083e
    addwf   0x3e, 0x0                ; 12e4: 073e
    addwf   0x70, 0x0                ; 12e5: 0770
    movwf   0x04                     ; 12e6: 0084
    bcf     0x03, 0x7                ; 12e7: 1383
    movf    0x00, 0x0                ; 12e8: 0800
    movwf   0x3f                     ; 12e9: 00bf
    incf    0x04, 0x1                ; 12ea: 0a84
    movf    0x00, 0x0                ; 12eb: 0800
    movwf   0x40                     ; 12ec: 00c0
    movwf   0x67                     ; 12ed: 00e7
    movlw   0xff                     ; 12ee: 30ff
    addwf   0x3f, 0x0                ; 12ef: 073f
    btfss   0x03, 0x0                ; 12f0: 1c03
    decf    0x67, 0x1                ; 12f1: 03e7
    bcf     0x0a, 0x4                ; 12f2: 120a
    bcf     0x0a, 0x3                ; 12f3: 118a
    call    0x01e7                   ; 12f4: 21e7
    movwf   0x04                     ; 12f5: 0084
    bcf     0x03, 0x7                ; 12f6: 1383
    movf    0x3e, 0x0                ; 12f7: 083e
    movwf   0x00                     ; 12f8: 0080
    incf    0x04, 0x1                ; 12f9: 0a84
    movf    0x3f, 0x0                ; 12fa: 083f
    movwf   0x00                     ; 12fb: 0080
    movf    0x40, 0x0                ; 12fc: 0840
    movwf   0x67                     ; 12fd: 00e7
    movlw   0xff                     ; 12fe: 30ff
    addwf   0x3f, 0x0                ; 12ff: 073f
    btfss   0x03, 0x0                ; 1300: 1c03
    decf    0x67, 0x1                ; 1301: 03e7
    bcf     0x0a, 0x4                ; 1302: 120a
    bcf     0x0a, 0x3                ; 1303: 118a
    call    0x01e7                   ; 1304: 21e7
    addlw   0x02                     ; 1305: 3e02
    movwf   0x04                     ; 1306: 0084
    bcf     0x03, 0x7                ; 1307: 1383
    movf    0x40, 0x0                ; 1308: 0840
    movwf   0x00                     ; 1309: 0080
    movf    0x40, 0x0                ; 130a: 0840
    movwf   0x67                     ; 130b: 00e7
    movf    0x3f, 0x0                ; 130c: 083f
    bcf     0x0a, 0x4                ; 130d: 120a
    bcf     0x0a, 0x3                ; 130e: 118a
    call    0x01e7                   ; 130f: 21e7
    bsf     0x0a, 0x4                ; 1310: 160a
    bcf     0x0a, 0x3                ; 1311: 118a
    movwf   0x3d                     ; 1312: 00bd
    movf    0x3d, 0x1                ; 1313: 08bd
    btfsc   0x03, 0x2                ; 1314: 1903
    goto    0x031a                   ; 1315: 2b1a
    movf    0x3d, 0x0                ; 1316: 083d
    xorlw   0x02                     ; 1317: 3a02
    btfsc   0x03, 0x2                ; 1318: 1903
    retlw   0x03                     ; 1319: 3403
    incf    0x3e, 0x1                ; 131a: 0abe
    movf    0x3c, 0x0                ; 131b: 083c
    subwf   0x3e, 0x0                ; 131c: 023e
    btfsc   0x03, 0x0                ; 131d: 1803
    retlw   0x00                     ; 131e: 3400
    goto    0x02c0                   ; 131f: 2ac0
    clrf    0x03                     ; 1320: 0183
    movf    0x3d, 0x0                ; 1321: 083d
    iorwf   0x3c, 0x0                ; 1322: 043c
    btfsc   0x03, 0x2                ; 1323: 1903
    retlw   0x00                     ; 1324: 3400
    bsf     0x0a, 0x4                ; 1325: 160a
    bsf     0x0a, 0x3                ; 1326: 158a
    call    0x06d8                   ; 1327: 26d8
    movf    0x3d, 0x0                ; 1328: 083d
    movwf   0x67                     ; 1329: 00e7
    movf    0x3c, 0x0                ; 132a: 083c
    addlw   0x04                     ; 132b: 3e04
    btfsc   0x03, 0x0                ; 132c: 1803
    incf    0x67, 0x1                ; 132d: 0ae7
    bcf     0x0a, 0x4                ; 132e: 120a
    bcf     0x0a, 0x3                ; 132f: 118a
    call    0x01e7                   ; 1330: 21e7
    bsf     0x0a, 0x4                ; 1331: 160a
    bcf     0x0a, 0x3                ; 1332: 118a
    movwf   0x04                     ; 1333: 0084
    bcf     0x03, 0x7                ; 1334: 1383
    btfss   0x00, 0x0                ; 1335: 1c00
    goto    0x038d                   ; 1336: 2b8d
    movf    0x3d, 0x0                ; 1337: 083d
    movwf   0x67                     ; 1338: 00e7
    movf    0x3c, 0x0                ; 1339: 083c
    bcf     0x0a, 0x4                ; 133a: 120a
    bcf     0x0a, 0x3                ; 133b: 118a
    call    0x01e7                   ; 133c: 21e7
    bsf     0x0a, 0x4                ; 133d: 160a
    bcf     0x0a, 0x3                ; 133e: 118a
    iorlw   0x00                     ; 133f: 3800
    btfsc   0x03, 0x2                ; 1340: 1903
    goto    0x035d                   ; 1341: 2b5d
    movf    0x3e, 0x1                ; 1342: 08be
    btfsc   0x03, 0x2                ; 1343: 1903
    goto    0x035d                   ; 1344: 2b5d
    movf    0x3d, 0x0                ; 1345: 083d
    movwf   0x67                     ; 1346: 00e7
    movf    0x3c, 0x0                ; 1347: 083c
    bcf     0x0a, 0x4                ; 1348: 120a
    bcf     0x0a, 0x3                ; 1349: 118a
    call    0x01e7                   ; 134a: 21e7
    movwf   0x3c                     ; 134b: 00bc
    movlw   0x80                     ; 134c: 3080
    movwf   0x3d                     ; 134d: 00bd
    movf    0x3d, 0x0                ; 134e: 083d
    movwf   0x67                     ; 134f: 00e7
    movf    0x3c, 0x0                ; 1350: 083c
    addlw   0x01                     ; 1351: 3e01
    btfsc   0x03, 0x0                ; 1352: 1803
    incf    0x67, 0x1                ; 1353: 0ae7
    bcf     0x0a, 0x4                ; 1354: 120a
    bcf     0x0a, 0x3                ; 1355: 118a
    call    0x01e7                   ; 1356: 21e7
    movwf   0x3e                     ; 1357: 00be
    clrf    0x3f                     ; 1358: 01bf
    movf    0x3e, 0x0                ; 1359: 083e
    bsf     0x0a, 0x4                ; 135a: 160a
    bsf     0x0a, 0x3                ; 135b: 158a
    call    0x0784                   ; 135c: 2784
    movf    0x3d, 0x0                ; 135d: 083d
    movwf   0x67                     ; 135e: 00e7
    movf    0x3c, 0x0                ; 135f: 083c
    addlw   0x04                     ; 1360: 3e04
    btfsc   0x03, 0x0                ; 1361: 1803
    incf    0x67, 0x1                ; 1362: 0ae7
    bcf     0x0a, 0x4                ; 1363: 120a
    bcf     0x0a, 0x3                ; 1364: 118a
    call    0x01e7                   ; 1365: 21e7
    movwf   0x04                     ; 1366: 0084
    bcf     0x03, 0x7                ; 1367: 1383
    bcf     0x00, 0x0                ; 1368: 1000
    bsf     0x0a, 0x4                ; 1369: 160a
    bsf     0x0a, 0x3                ; 136a: 158a
    call    0x06ac                   ; 136b: 26ac
    movf    0x3d, 0x0                ; 136c: 083d
    movwf   0x67                     ; 136d: 00e7
    movf    0x3c, 0x0                ; 136e: 083c
    addlw   0x03                     ; 136f: 3e03
    btfsc   0x03, 0x0                ; 1370: 1803
    incf    0x67, 0x1                ; 1371: 0ae7
    bcf     0x0a, 0x4                ; 1372: 120a
    bcf     0x0a, 0x3                ; 1373: 118a
    call    0x01e7                   ; 1374: 21e7
    bsf     0x0a, 0x4                ; 1375: 160a
    bcf     0x0a, 0x3                ; 1376: 118a
    iorlw   0x00                     ; 1377: 3800
    btfsc   0x03, 0x2                ; 1378: 1903
    retlw   0x04                     ; 1379: 3404
    movf    0x3d, 0x0                ; 137a: 083d
    movwf   0x67                     ; 137b: 00e7
    movf    0x3c, 0x0                ; 137c: 083c
    addlw   0x03                     ; 137d: 3e03
    btfsc   0x03, 0x0                ; 137e: 1803
    incf    0x67, 0x1                ; 137f: 0ae7
    bcf     0x0a, 0x4                ; 1380: 120a
    bcf     0x0a, 0x3                ; 1381: 118a
    call    0x01e7                   ; 1382: 21e7
    bsf     0x0a, 0x4                ; 1383: 160a
    bcf     0x0a, 0x3                ; 1384: 118a
    call    0x00f7                   ; 1385: 20f7
    bsf     0x0a, 0x4                ; 1386: 160a
    bcf     0x0a, 0x3                ; 1387: 118a
    movwf   0x3c                     ; 1388: 00bc
    xorlw   0x03                     ; 1389: 3a03
    btfsc   0x03, 0x2                ; 138a: 1903
    retlw   0x03                     ; 138b: 3403
    retlw   0x00                     ; 138c: 3400
    bsf     0x0a, 0x4                ; 138d: 160a
    bsf     0x0a, 0x3                ; 138e: 158a
    call    0x06ac                   ; 138f: 26ac
    bsf     0x0a, 0x4                ; 1390: 160a
    bcf     0x0a, 0x3                ; 1391: 118a
    retlw   0x02                     ; 1392: 3402
    bsf     0x03, 0x5                ; 1393: 1683
    bcf     0x03, 0x6                ; 1394: 1303
    rrf     0x4e, 0x0                ; 1395: 0c4e
    movwf   0x70                     ; 1396: 00f0
    rrf     0x70, 0x0                ; 1397: 0c70
    andlw   0x03                     ; 1398: 3903
    xorlw   0x02                     ; 1399: 3a02
    btfss   0x03, 0x2                ; 139a: 1d03
    goto    0x03c5                   ; 139b: 2bc5
    movlw   0x01                     ; 139c: 3001
    bcf     0x03, 0x5                ; 139d: 1283
    bsf     0x03, 0x6                ; 139e: 1703
    subwf   0x48, 0x0                ; 139f: 0248
    movlw   0x3d                     ; 13a0: 303d
    btfsc   0x03, 0x2                ; 13a1: 1903
    subwf   0x47, 0x0                ; 13a2: 0247
    btfss   0x03, 0x0                ; 13a3: 1c03
    goto    0x03d5                   ; 13a4: 2bd5
    movlw   0x01                     ; 13a5: 3001
    subwf   0x48, 0x0                ; 13a6: 0248
    movlw   0x4a                     ; 13a7: 304a
    btfsc   0x03, 0x2                ; 13a8: 1903
    subwf   0x47, 0x0                ; 13a9: 0247
    movlw   0x01                     ; 13aa: 3001
    btfss   0x03, 0x0                ; 13ab: 1c03
    goto    0x03b4                   ; 13ac: 2bb4
    subwf   0x48, 0x0                ; 13ad: 0248
    movlw   0x72                     ; 13ae: 3072
    btfsc   0x03, 0x2                ; 13af: 1903
    subwf   0x47, 0x0                ; 13b0: 0247
    btfss   0x03, 0x0                ; 13b1: 1c03
    goto    0x03e7                   ; 13b2: 2be7
    movlw   0x01                     ; 13b3: 3001
    subwf   0x48, 0x0                ; 13b4: 0248
    movlw   0x7f                     ; 13b5: 307f
    btfsc   0x03, 0x2                ; 13b6: 1903
    subwf   0x47, 0x0                ; 13b7: 0247
    movlw   0x01                     ; 13b8: 3001
    btfss   0x03, 0x0                ; 13b9: 1c03
    goto    0x03c2                   ; 13ba: 2bc2
    subwf   0x48, 0x0                ; 13bb: 0248
    movlw   0x99                     ; 13bc: 3099
    btfsc   0x03, 0x2                ; 13bd: 1903
    subwf   0x47, 0x0                ; 13be: 0247
    btfss   0x03, 0x0                ; 13bf: 1c03
    goto    0x03f7                   ; 13c0: 2bf7
    movlw   0x01                     ; 13c1: 3001
    subwf   0x48, 0x0                ; 13c2: 0248
    movlw   0xa6                     ; 13c3: 30a6
    goto    0x03fc                   ; 13c4: 2bfc
    rrf     0x4e, 0x0                ; 13c5: 0c4e
    movwf   0x70                     ; 13c6: 00f0
    rrf     0x70, 0x0                ; 13c7: 0c70
    andlw   0x03                     ; 13c8: 3903
    xorlw   0x01                     ; 13c9: 3a01
    btfss   0x03, 0x2                ; 13ca: 1d03
    goto    0x0405                   ; 13cb: 2c05
    movlw   0x01                     ; 13cc: 3001
    bcf     0x03, 0x5                ; 13cd: 1283
    bsf     0x03, 0x6                ; 13ce: 1703
    subwf   0x48, 0x0                ; 13cf: 0248
    movlw   0x53                     ; 13d0: 3053
    btfsc   0x03, 0x2                ; 13d1: 1903
    subwf   0x47, 0x0                ; 13d2: 0247
    btfsc   0x03, 0x0                ; 13d3: 1803
    goto    0x03d9                   ; 13d4: 2bd9
    bsf     0x03, 0x5                ; 13d5: 1683
    bcf     0x03, 0x6                ; 13d6: 1303
    clrf    0x59                     ; 13d7: 01d9
    goto    0x0404                   ; 13d8: 2c04
    movlw   0x01                     ; 13d9: 3001
    subwf   0x48, 0x0                ; 13da: 0248
    movlw   0x60                     ; 13db: 3060
    btfsc   0x03, 0x2                ; 13dc: 1903
    subwf   0x47, 0x0                ; 13dd: 0247
    movlw   0x01                     ; 13de: 3001
    btfss   0x03, 0x0                ; 13df: 1c03
    goto    0x03ea                   ; 13e0: 2bea
    subwf   0x48, 0x0                ; 13e1: 0248
    movlw   0x80                     ; 13e2: 3080
    btfsc   0x03, 0x2                ; 13e3: 1903
    subwf   0x47, 0x0                ; 13e4: 0247
    btfsc   0x03, 0x0                ; 13e5: 1803
    goto    0x03e9                   ; 13e6: 2be9
    movlw   0x03                     ; 13e7: 3003
    goto    0x0401                   ; 13e8: 2c01
    movlw   0x01                     ; 13e9: 3001
    subwf   0x48, 0x0                ; 13ea: 0248
    movlw   0x8d                     ; 13eb: 308d
    btfsc   0x03, 0x2                ; 13ec: 1903
    subwf   0x47, 0x0                ; 13ed: 0247
    movlw   0x01                     ; 13ee: 3001
    btfss   0x03, 0x0                ; 13ef: 1c03
    goto    0x03fa                   ; 13f0: 2bfa
    subwf   0x48, 0x0                ; 13f1: 0248
    movlw   0xa3                     ; 13f2: 30a3
    btfsc   0x03, 0x2                ; 13f3: 1903
    subwf   0x47, 0x0                ; 13f4: 0247
    btfsc   0x03, 0x0                ; 13f5: 1803
    goto    0x03f9                   ; 13f6: 2bf9
    movlw   0x06                     ; 13f7: 3006
    goto    0x0401                   ; 13f8: 2c01
    movlw   0x01                     ; 13f9: 3001
    subwf   0x48, 0x0                ; 13fa: 0248
    movlw   0xb0                     ; 13fb: 30b0
    btfsc   0x03, 0x2                ; 13fc: 1903
    subwf   0x47, 0x0                ; 13fd: 0247
    btfss   0x03, 0x0                ; 13fe: 1c03
    goto    0x0405                   ; 13ff: 2c05
    movlw   0x0a                     ; 1400: 300a
    bsf     0x03, 0x5                ; 1401: 1683
    bcf     0x03, 0x6                ; 1402: 1303
    movwf   0x59                     ; 1403: 00d9
    clrf    0x5a                     ; 1404: 01da
    clrf    0x03                     ; 1405: 0183
    return                           ; 1406: 0008
    clrf    0x03                     ; 1407: 0183
    clrf    0x3f                     ; 1408: 01bf
    goto    0x047f                   ; 1409: 2c7f
    movf    0x3f, 0x0                ; 140a: 083f
    movwf   0x70                     ; 140b: 00f0
    clrf    0x71                     ; 140c: 01f1
    bcf     0x03, 0x0                ; 140d: 1003
    rlf     0x70, 0x1                ; 140e: 0df0
    rlf     0x71, 0x1                ; 140f: 0df1
    bcf     0x03, 0x0                ; 1410: 1003
    rlf     0x70, 0x1                ; 1411: 0df0
    rlf     0x71, 0x1                ; 1412: 0df1
    bcf     0x03, 0x0                ; 1413: 1003
    rlf     0x70, 0x1                ; 1414: 0df0
    rlf     0x71, 0x1                ; 1415: 0df1
    movf    0x3c, 0x0                ; 1416: 083c
    addwf   0x70, 0x0                ; 1417: 0770
    movwf   0x41                     ; 1418: 00c1
    movf    0x3d, 0x0                ; 1419: 083d
    btfsc   0x03, 0x0                ; 141a: 1803
    incf    0x3d, 0x0                ; 141b: 0a3d
    addwf   0x71, 0x0                ; 141c: 0771
    movwf   0x42                     ; 141d: 00c2
    movwf   0x67                     ; 141e: 00e7
    movf    0x41, 0x0                ; 141f: 0841
    bcf     0x0a, 0x4                ; 1420: 120a
    bcf     0x0a, 0x3                ; 1421: 118a
    call    0x01e7                   ; 1422: 21e7
    bsf     0x0a, 0x4                ; 1423: 160a
    bcf     0x0a, 0x3                ; 1424: 118a
    movwf   0x40                     ; 1425: 00c0
    movlw   0x01                     ; 1426: 3001
    subwf   0x40, 0x0                ; 1427: 0240
    btfsc   0x03, 0x0                ; 1428: 1803
    goto    0x047e                   ; 1429: 2c7e
    movf    0x42, 0x0                ; 142a: 0842
    movwf   0x67                     ; 142b: 00e7
    movf    0x41, 0x0                ; 142c: 0841
    addlw   0x01                     ; 142d: 3e01
    btfsc   0x03, 0x0                ; 142e: 1803
    incf    0x67, 0x1                ; 142f: 0ae7
    bcf     0x0a, 0x4                ; 1430: 120a
    bcf     0x0a, 0x3                ; 1431: 118a
    call    0x01e7                   ; 1432: 21e7
    movwf   0x43                     ; 1433: 00c3
    movf    0x42, 0x0                ; 1434: 0842
    movwf   0x67                     ; 1435: 00e7
    movf    0x41, 0x0                ; 1436: 0841
    addlw   0x02                     ; 1437: 3e02
    btfsc   0x03, 0x0                ; 1438: 1803
    incf    0x67, 0x1                ; 1439: 0ae7
    bcf     0x0a, 0x4                ; 143a: 120a
    bcf     0x0a, 0x3                ; 143b: 118a
    call    0x01e7                   ; 143c: 21e7
    movwf   0x70                     ; 143d: 00f0
    bcf     0x0a, 0x4                ; 143e: 120a
    bcf     0x0a, 0x3                ; 143f: 118a
    call    0x01ea                   ; 1440: 21ea
    movwf   0x71                     ; 1441: 00f1
    movf    0x70, 0x0                ; 1442: 0870
    movwf   0x44                     ; 1443: 00c4
    movf    0x71, 0x0                ; 1444: 0871
    movwf   0x45                     ; 1445: 00c5
    movf    0x40, 0x0                ; 1446: 0840
    bsf     0x0a, 0x4                ; 1447: 160a
    bcf     0x0a, 0x3                ; 1448: 118a
    call    0x007d                   ; 1449: 207d
    bsf     0x0a, 0x4                ; 144a: 160a
    bcf     0x0a, 0x3                ; 144b: 118a
    movwf   0x70                     ; 144c: 00f0
    clrf    0x71                     ; 144d: 01f1
    iorwf   0x71, 0x0                ; 144e: 0471
    btfss   0x03, 0x2                ; 144f: 1d03
    goto    0x047e                   ; 1450: 2c7e
    movf    0x42, 0x0                ; 1451: 0842
    movwf   0x67                     ; 1452: 00e7
    movf    0x41, 0x0                ; 1453: 0841
    addlw   0x04                     ; 1454: 3e04
    btfsc   0x03, 0x0                ; 1455: 1803
    incf    0x67, 0x1                ; 1456: 0ae7
    bcf     0x0a, 0x4                ; 1457: 120a
    bcf     0x0a, 0x3                ; 1458: 118a
    call    0x01e7                   ; 1459: 21e7
    movwf   0x70                     ; 145a: 00f0
    bcf     0x0a, 0x4                ; 145b: 120a
    bcf     0x0a, 0x3                ; 145c: 118a
    call    0x01ea                   ; 145d: 21ea
    movwf   0x71                     ; 145e: 00f1
    movf    0x70, 0x0                ; 145f: 0870
    movwf   0x43                     ; 1460: 00c3
    movf    0x71, 0x0                ; 1461: 0871
    movwf   0x44                     ; 1462: 00c4
    movf    0x42, 0x0                ; 1463: 0842
    movwf   0x67                     ; 1464: 00e7
    movf    0x41, 0x0                ; 1465: 0841
    addlw   0x06                     ; 1466: 3e06
    btfsc   0x03, 0x0                ; 1467: 1803
    incf    0x67, 0x1                ; 1468: 0ae7
    bcf     0x0a, 0x4                ; 1469: 120a
    bcf     0x0a, 0x3                ; 146a: 118a
    call    0x01e7                   ; 146b: 21e7
    movwf   0x70                     ; 146c: 00f0
    bcf     0x0a, 0x4                ; 146d: 120a
    bcf     0x0a, 0x3                ; 146e: 118a
    call    0x01ea                   ; 146f: 21ea
    movwf   0x71                     ; 1470: 00f1
    movf    0x70, 0x0                ; 1471: 0870
    movwf   0x45                     ; 1472: 00c5
    movf    0x71, 0x0                ; 1473: 0871
    movwf   0x46                     ; 1474: 00c6
    movf    0x40, 0x0                ; 1475: 0840
    bsf     0x0a, 0x4                ; 1476: 160a
    bcf     0x0a, 0x3                ; 1477: 118a
    call    0x0193                   ; 1478: 2193
    bsf     0x0a, 0x4                ; 1479: 160a
    bcf     0x0a, 0x3                ; 147a: 118a
    movwf   0x70                     ; 147b: 00f0
    clrf    0x71                     ; 147c: 01f1
    xorlw   0x02                     ; 147d: 3a02
    incf    0x3f, 0x1                ; 147e: 0abf
    movf    0x3e, 0x0                ; 147f: 083e
    subwf   0x3f, 0x0                ; 1480: 023f
    btfsc   0x03, 0x0                ; 1481: 1803
    return                           ; 1482: 0008
    goto    0x040a                   ; 1483: 2c0a
    clrf    0x0b                     ; 1484: 018b
    bcf     0x03, 0x5                ; 1485: 1283
    bsf     0x03, 0x6                ; 1486: 1703
    bcf     0x07, 0x4                ; 1487: 1207
    bcf     0x07, 0x7                ; 1488: 1387
    bcf     0x07, 0x0                ; 1489: 1007
    bcf     0x07, 0x1                ; 148a: 1087
    bcf     0x03, 0x6                ; 148b: 1303
    bcf     0x05, 0x3                ; 148c: 1185
    bcf     0x05, 0x4                ; 148d: 1205
    bcf     0x05, 0x1                ; 148e: 1085
    bcf     0x07, 0x2                ; 148f: 1107
    movlw   0x0f                     ; 1490: 300f
    iorwf   0x06, 0x1                ; 1491: 0486
    iorwf   0x07, 0x1                ; 1492: 0487
    movlw   0xff                     ; 1493: 30ff
    movwf   0x08                     ; 1494: 0088
    bsf     0x03, 0x5                ; 1495: 1683
    bcf     0x05, 0x1                ; 1496: 1085
    bcf     0x05, 0x2                ; 1497: 1105
    bcf     0x05, 0x3                ; 1498: 1185
    bcf     0x05, 0x4                ; 1499: 1205
    bcf     0x06, 0x0                ; 149a: 1006
    bcf     0x06, 0x1                ; 149b: 1086
    bcf     0x06, 0x2                ; 149c: 1106
    bcf     0x06, 0x3                ; 149d: 1186
    bcf     0x06, 0x4                ; 149e: 1206
    bcf     0x03, 0x5                ; 149f: 1283
    bcf     0x06, 0x4                ; 14a0: 1206
    bsf     0x03, 0x5                ; 14a1: 1683
    bsf     0x06, 0x5                ; 14a2: 1686
    bcf     0x06, 0x6                ; 14a3: 1306
    bcf     0x06, 0x7                ; 14a4: 1386
    clrf    0x15                     ; 14a5: 0195
    bcf     0x07, 0x0                ; 14a6: 1007
    bcf     0x07, 0x1                ; 14a7: 1087
    bcf     0x07, 0x2                ; 14a8: 1107
    bcf     0x07, 0x3                ; 14a9: 1187
    bcf     0x07, 0x4                ; 14aa: 1207
    bcf     0x07, 0x5                ; 14ab: 1287
    bcf     0x03, 0x5                ; 14ac: 1283
    bcf     0x07, 0x5                ; 14ad: 1287
    bsf     0x03, 0x5                ; 14ae: 1683
    bcf     0x07, 0x6                ; 14af: 1307
    bsf     0x07, 0x7                ; 14b0: 1787
    bcf     0x08, 0x0                ; 14b1: 1008
    bcf     0x08, 0x1                ; 14b2: 1088
    bcf     0x08, 0x2                ; 14b3: 1108
    bcf     0x08, 0x3                ; 14b4: 1188
    bcf     0x08, 0x4                ; 14b5: 1208
    bcf     0x08, 0x5                ; 14b6: 1288
    bcf     0x08, 0x6                ; 14b7: 1308
    bcf     0x08, 0x7                ; 14b8: 1388
    bcf     0x03, 0x5                ; 14b9: 1283
    clrf    0x17                     ; 14ba: 0197
    bcf     0x17, 0x5                ; 14bb: 1297
    bcf     0x17, 0x4                ; 14bc: 1217
    bsf     0x12, 0x1                ; 14bd: 1492
    movlw   0x5a                     ; 14be: 305a
    bsf     0x03, 0x5                ; 14bf: 1683
    movwf   0x12                     ; 14c0: 0092
    movlw   0x47                     ; 14c1: 3047
    bcf     0x03, 0x5                ; 14c2: 1283
    movwf   0x15                     ; 14c3: 0095
    clrf    0x01                     ; 14c4: 0181
    clrf    0x0b                     ; 14c5: 018b
    bsf     0x03, 0x5                ; 14c6: 1683
    bsf     0x01, 0x7                ; 14c7: 1781
    bcf     0x01, 0x5                ; 14c8: 1281
    bcf     0x01, 0x3                ; 14c9: 1181
    bsf     0x01, 0x2                ; 14ca: 1501
    bcf     0x01, 0x1                ; 14cb: 1081
    bsf     0x01, 0x0                ; 14cc: 1401
    movlw   0xed                     ; 14cd: 30ed
    bcf     0x03, 0x5                ; 14ce: 1283
    movwf   0x01                     ; 14cf: 0081
    bcf     0x0b, 0x2                ; 14d0: 110b
    bsf     0x0b, 0x5                ; 14d1: 168b
    bsf     0x03, 0x5                ; 14d2: 1683
    bcf     0x07, 0x0                ; 14d3: 1007
    movlw   0x3f                     ; 14d4: 303f
    movwf   0x19                     ; 14d5: 0099
    bsf     0x18, 0x2                ; 14d6: 1518
    bcf     0x18, 0x4                ; 14d7: 1218
    bcf     0x03, 0x5                ; 14d8: 1283
    bsf     0x18, 0x7                ; 14d9: 1798
    bsf     0x0b, 0x6                ; 14da: 170b
    bcf     0x18, 0x3                ; 14db: 1198
    bsf     0x03, 0x5                ; 14dc: 1683
    bsf     0x18, 0x6                ; 14dd: 1718
    bcf     0x03, 0x5                ; 14de: 1283
    bsf     0x18, 0x6                ; 14df: 1718
    bsf     0x03, 0x5                ; 14e0: 1683
    bsf     0x0c, 0x4                ; 14e1: 160c
    bcf     0x03, 0x5                ; 14e2: 1283
    bsf     0x03, 0x6                ; 14e3: 1703
    bsf     0x05, 0x1                ; 14e4: 1485
    bcf     0x05, 0x2                ; 14e5: 1105
    bsf     0x05, 0x3                ; 14e6: 1585
    bcf     0x05, 0x4                ; 14e7: 1205
    bsf     0x03, 0x5                ; 14e8: 1683
    bcf     0x03, 0x6                ; 14e9: 1303
    bsf     0x09, 0x0                ; 14ea: 1409
    bsf     0x09, 0x1                ; 14eb: 1489
    bcf     0x03, 0x5                ; 14ec: 1283
    bsf     0x12, 0x1                ; 14ed: 1492
    bsf     0x03, 0x5                ; 14ee: 1683
    bsf     0x09, 0x2                ; 14ef: 1509
    bsf     0x05, 0x0                ; 14f0: 1405
    bsf     0x05, 0x5                ; 14f1: 1685
    movlw   0x50                     ; 14f2: 3050
    movwf   0x1f                     ; 14f3: 009f
    bcf     0x03, 0x5                ; 14f4: 1283
    bsf     0x1f, 0x7                ; 14f5: 179f
    bcf     0x1f, 0x6                ; 14f6: 131f
    bcf     0x1f, 0x5                ; 14f7: 129f
    bcf     0x1f, 0x0                ; 14f8: 101f
    bsf     0x03, 0x5                ; 14f9: 1683
    bsf     0x11, 0x0                ; 14fa: 1411
    bcf     0x11, 0x1                ; 14fb: 1091
    bcf     0x11, 0x2                ; 14fc: 1111
    bcf     0x11, 0x3                ; 14fd: 1191
    bsf     0x11, 0x4                ; 14fe: 1611
    bsf     0x11, 0x5                ; 14ff: 1691
    bsf     0x11, 0x6                ; 1500: 1711
    bsf     0x11, 0x7                ; 1501: 1791
    bsf     0x03, 0x6                ; 1502: 1703
    bcf     0x0c, 0x7                ; 1503: 138c
    bcf     0x03, 0x5                ; 1504: 1283
    clrf    0x43                     ; 1505: 01c3
    bsf     0x0b, 0x7                ; 1506: 178b
    bcf     0x03, 0x6                ; 1507: 1303
    return                           ; 1508: 0008
    clrf    0x03                     ; 1509: 0183
    movf    0x3d, 0x0                ; 150a: 083d
    iorwf   0x3c, 0x0                ; 150b: 043c
    btfsc   0x03, 0x2                ; 150c: 1903
    retlw   0x00                     ; 150d: 3400
    bsf     0x0a, 0x4                ; 150e: 160a
    bsf     0x0a, 0x3                ; 150f: 158a
    call    0x06d8                   ; 1510: 26d8
    movf    0x3d, 0x0                ; 1511: 083d
    movwf   0x67                     ; 1512: 00e7
    movf    0x3c, 0x0                ; 1513: 083c
    addlw   0x04                     ; 1514: 3e04
    btfsc   0x03, 0x0                ; 1515: 1803
    incf    0x67, 0x1                ; 1516: 0ae7
    bcf     0x0a, 0x4                ; 1517: 120a
    bcf     0x0a, 0x3                ; 1518: 118a
    call    0x01e7                   ; 1519: 21e7
    bsf     0x0a, 0x4                ; 151a: 160a
    bcf     0x0a, 0x3                ; 151b: 118a
    movwf   0x04                     ; 151c: 0084
    bcf     0x03, 0x7                ; 151d: 1383
    btfsc   0x00, 0x0                ; 151e: 1800
    goto    0x0594                   ; 151f: 2d94
    movf    0x3d, 0x0                ; 1520: 083d
    movwf   0x67                     ; 1521: 00e7
    movf    0x3c, 0x0                ; 1522: 083c
    addlw   0x04                     ; 1523: 3e04
    btfsc   0x03, 0x0                ; 1524: 1803
    incf    0x67, 0x1                ; 1525: 0ae7
    bcf     0x0a, 0x4                ; 1526: 120a
    bcf     0x0a, 0x3                ; 1527: 118a
    call    0x01e7                   ; 1528: 21e7
    movwf   0x04                     ; 1529: 0084
    bcf     0x03, 0x7                ; 152a: 1383
    bsf     0x00, 0x0                ; 152b: 1400
    movf    0x3d, 0x0                ; 152c: 083d
    movwf   0x67                     ; 152d: 00e7
    movf    0x3c, 0x0                ; 152e: 083c
    bcf     0x0a, 0x4                ; 152f: 120a
    bcf     0x0a, 0x3                ; 1530: 118a
    call    0x01e7                   ; 1531: 21e7
    bsf     0x0a, 0x4                ; 1532: 160a
    bcf     0x0a, 0x3                ; 1533: 118a
    iorlw   0x00                     ; 1534: 3800
    btfsc   0x03, 0x2                ; 1535: 1903
    goto    0x0553                   ; 1536: 2d53
    movf    0x3f, 0x0                ; 1537: 083f
    iorwf   0x3e, 0x0                ; 1538: 043e
    btfsc   0x03, 0x2                ; 1539: 1903
    goto    0x0553                   ; 153a: 2d53
    movf    0x3e, 0x0                ; 153b: 083e
    movwf   0x3c                     ; 153c: 00bc
    movf    0x3f, 0x0                ; 153d: 083f
    movwf   0x3d                     ; 153e: 00bd
    movf    0x3d, 0x0                ; 153f: 083d
    movwf   0x67                     ; 1540: 00e7
    movf    0x3c, 0x0                ; 1541: 083c
    addlw   0x01                     ; 1542: 3e01
    btfsc   0x03, 0x0                ; 1543: 1803
    incf    0x67, 0x1                ; 1544: 0ae7
    bcf     0x0a, 0x4                ; 1545: 120a
    bcf     0x0a, 0x3                ; 1546: 118a
    call    0x01e7                   ; 1547: 21e7
    movwf   0x3e                     ; 1548: 00be
    clrf    0x3f                     ; 1549: 01bf
    movf    0x3d, 0x0                ; 154a: 083d
    movwf   0x67                     ; 154b: 00e7
    movf    0x3c, 0x0                ; 154c: 083c
    bcf     0x0a, 0x4                ; 154d: 120a
    bcf     0x0a, 0x3                ; 154e: 118a
    call    0x01e7                   ; 154f: 21e7
    bsf     0x0a, 0x4                ; 1550: 160a
    bsf     0x0a, 0x3                ; 1551: 158a
    call    0x0784                   ; 1552: 2784
    bsf     0x0a, 0x4                ; 1553: 160a
    bsf     0x0a, 0x3                ; 1554: 158a
    call    0x06ac                   ; 1555: 26ac
    movf    0x3d, 0x0                ; 1556: 083d
    movwf   0x67                     ; 1557: 00e7
    movf    0x3c, 0x0                ; 1558: 083c
    addlw   0x02                     ; 1559: 3e02
    btfsc   0x03, 0x0                ; 155a: 1803
    incf    0x67, 0x1                ; 155b: 0ae7
    bcf     0x0a, 0x4                ; 155c: 120a
    bcf     0x0a, 0x3                ; 155d: 118a
    call    0x01e7                   ; 155e: 21e7
    bsf     0x0a, 0x4                ; 155f: 160a
    bcf     0x0a, 0x3                ; 1560: 118a
    iorlw   0x00                     ; 1561: 3800
    btfsc   0x03, 0x2                ; 1562: 1903
    goto    0x0585                   ; 1563: 2d85
    movf    0x3d, 0x0                ; 1564: 083d
    movwf   0x67                     ; 1565: 00e7
    movf    0x3c, 0x0                ; 1566: 083c
    addlw   0x02                     ; 1567: 3e02
    btfsc   0x03, 0x0                ; 1568: 1803
    incf    0x67, 0x1                ; 1569: 0ae7
    bcf     0x0a, 0x4                ; 156a: 120a
    bcf     0x0a, 0x3                ; 156b: 118a
    call    0x01e7                   ; 156c: 21e7
    bsf     0x0a, 0x4                ; 156d: 160a
    bcf     0x0a, 0x3                ; 156e: 118a
    call    0x00f7                   ; 156f: 20f7
    bsf     0x0a, 0x4                ; 1570: 160a
    bcf     0x0a, 0x3                ; 1571: 118a
    movwf   0x3c                     ; 1572: 00bc
    xorlw   0x03                     ; 1573: 3a03
    btfss   0x03, 0x2                ; 1574: 1d03
    retlw   0x00                     ; 1575: 3400
    movf    0x3d, 0x0                ; 1576: 083d
    movwf   0x67                     ; 1577: 00e7
    movf    0x3c, 0x0                ; 1578: 083c
    addlw   0x04                     ; 1579: 3e04
    btfsc   0x03, 0x0                ; 157a: 1803
    incf    0x67, 0x1                ; 157b: 0ae7
    bcf     0x0a, 0x4                ; 157c: 120a
    bcf     0x0a, 0x3                ; 157d: 118a
    call    0x01e7                   ; 157e: 21e7
    bsf     0x0a, 0x4                ; 157f: 160a
    bcf     0x0a, 0x3                ; 1580: 118a
    movwf   0x04                     ; 1581: 0084
    bcf     0x03, 0x7                ; 1582: 1383
    bcf     0x00, 0x0                ; 1583: 1000
    retlw   0x03                     ; 1584: 3403
    movf    0x3d, 0x0                ; 1585: 083d
    movwf   0x67                     ; 1586: 00e7
    movf    0x3c, 0x0                ; 1587: 083c
    addlw   0x04                     ; 1588: 3e04
    btfsc   0x03, 0x0                ; 1589: 1803
    incf    0x67, 0x1                ; 158a: 0ae7
    bcf     0x0a, 0x4                ; 158b: 120a
    bcf     0x0a, 0x3                ; 158c: 118a
    call    0x01e7                   ; 158d: 21e7
    bsf     0x0a, 0x4                ; 158e: 160a
    bcf     0x0a, 0x3                ; 158f: 118a
    movwf   0x04                     ; 1590: 0084
    bcf     0x03, 0x7                ; 1591: 1383
    bcf     0x00, 0x0                ; 1592: 1000
    retlw   0x04                     ; 1593: 3404
    bsf     0x0a, 0x4                ; 1594: 160a
    bsf     0x0a, 0x3                ; 1595: 158a
    call    0x06ac                   ; 1596: 26ac
    bsf     0x0a, 0x4                ; 1597: 160a
    bcf     0x0a, 0x3                ; 1598: 118a
    retlw   0x01                     ; 1599: 3401
    clrf    0x03                     ; 159a: 0183
    movwf   0x5b                     ; 159b: 00db
    movlw   0xc4                     ; 159c: 30c4
    movwf   0x5c                     ; 159d: 00dc
    movlw   0x09                     ; 159e: 3009
    movwf   0x5d                     ; 159f: 00dd
    bsf     0x03, 0x5                ; 15a0: 1683
    bsf     0x03, 0x6                ; 15a1: 1703
    btfsc   0x0c, 0x1                ; 15a2: 188c
    goto    0x05a0                   ; 15a3: 2da0
    bcf     0x03, 0x5                ; 15a4: 1283
    bcf     0x03, 0x6                ; 15a5: 1303
    movf    0x5b, 0x0                ; 15a6: 085b
    bsf     0x03, 0x6                ; 15a7: 1703
    movwf   0x0d                     ; 15a8: 008d
    bcf     0x03, 0x6                ; 15a9: 1303
    movf    0x5a, 0x0                ; 15aa: 085a
    bsf     0x03, 0x6                ; 15ab: 1703
    movwf   0x0c                     ; 15ac: 008c
    bsf     0x03, 0x5                ; 15ad: 1683
    bcf     0x0c, 0x7                ; 15ae: 138c
    bcf     0x03, 0x0                ; 15af: 1003
    btfsc   0x0b, 0x7                ; 15b0: 1b8b
    bsf     0x03, 0x0                ; 15b1: 1403
    bcf     0x0b, 0x7                ; 15b2: 138b
    bsf     0x0c, 0x2                ; 15b3: 150c
    movlw   0x55                     ; 15b4: 3055
    movwf   0x0d                     ; 15b5: 008d
    movlw   0xaa                     ; 15b6: 30aa
    movwf   0x0d                     ; 15b7: 008d
    bsf     0x0c, 0x1                ; 15b8: 148c
    bcf     0x0c, 0x2                ; 15b9: 110c
    btfsc   0x03, 0x0                ; 15ba: 1803
    bsf     0x0b, 0x7                ; 15bb: 178b
    bsf     0x03, 0x5                ; 15bc: 1683
    bsf     0x03, 0x6                ; 15bd: 1703
    btfss   0x0c, 0x1                ; 15be: 1c8c
    goto    0x05ca                   ; 15bf: 2dca
    bcf     0x03, 0x5                ; 15c0: 1283
    bcf     0x03, 0x6                ; 15c1: 1303
    movf    0x5c, 0x1                ; 15c2: 08dc
    btfsc   0x03, 0x2                ; 15c3: 1903
    decf    0x5d, 0x1                ; 15c4: 03dd
    decf    0x5c, 0x1                ; 15c5: 03dc
    movf    0x5d, 0x0                ; 15c6: 085d
    iorwf   0x5c, 0x0                ; 15c7: 045c
    btfss   0x03, 0x2                ; 15c8: 1d03
    goto    0x05bc                   ; 15c9: 2dbc
    clrf    0x03                     ; 15ca: 0183
    return                           ; 15cb: 0008
    clrf    0x03                     ; 15cc: 0183
    movwf   0x58                     ; 15cd: 00d8
    clrf    0x59                     ; 15ce: 01d9
    movlw   0x11                     ; 15cf: 3011
    subwf   0x58, 0x0                ; 15d0: 0258
    btfss   0x03, 0x0                ; 15d1: 1c03
    goto    0x05fe                   ; 15d2: 2dfe
    goto    0x0631                   ; 15d3: 2e31
    movlw   0x02                     ; 15d4: 3002
    goto    0x05f8                   ; 15d5: 2df8
    movlw   0x65                     ; 15d6: 3065
    goto    0x05f8                   ; 15d7: 2df8
    movf    0x57, 0x0                ; 15d8: 0857
    xorlw   0x02                     ; 15d9: 3a02
    btfsc   0x03, 0x2                ; 15da: 1903
    goto    0x05fb                   ; 15db: 2dfb
    movf    0x57, 0x0                ; 15dc: 0857
    xorlw   0x04                     ; 15dd: 3a04
    btfsc   0x03, 0x2                ; 15de: 1903
    goto    0x05fb                   ; 15df: 2dfb
    movf    0x57, 0x0                ; 15e0: 0857
    xorlw   0x06                     ; 15e1: 3a06
    btfss   0x03, 0x2                ; 15e2: 1d03
    goto    0x0620                   ; 15e3: 2e20
    goto    0x05fb                   ; 15e4: 2dfb
    movlw   0x01                     ; 15e5: 3001
    subwf   0x57, 0x0                ; 15e6: 0257
    btfss   0x03, 0x0                ; 15e7: 1c03
    goto    0x0620                   ; 15e8: 2e20
    movlw   0x35                     ; 15e9: 3035
    goto    0x05f8                   ; 15ea: 2df8
    movlw   0x64                     ; 15eb: 3064
    goto    0x05f8                   ; 15ec: 2df8
    movlw   0x04                     ; 15ed: 3004
    goto    0x05f8                   ; 15ee: 2df8
    incf    0x57, 0x0                ; 15ef: 0a57
    btfsc   0x03, 0x2                ; 15f0: 1903
    goto    0x0620                   ; 15f1: 2e20
    goto    0x05fb                   ; 15f2: 2dfb
    movlw   0xae                     ; 15f3: 30ae
    subwf   0x57, 0x0                ; 15f4: 0257
    btfss   0x03, 0x0                ; 15f5: 1c03
    goto    0x0620                   ; 15f6: 2e20
    movlw   0xd0                     ; 15f7: 30d0
    subwf   0x57, 0x0                ; 15f8: 0257
    btfsc   0x03, 0x0                ; 15f9: 1803
    goto    0x0620                   ; 15fa: 2e20
    clrf    0x59                     ; 15fb: 01d9
    incf    0x59, 0x1                ; 15fc: 0ad9
    goto    0x0620                   ; 15fd: 2e20
    movf    0x58, 0x0                ; 15fe: 0858
    movwf   0x70                     ; 15ff: 00f0
    addlw   0xef                     ; 1600: 3eef
    btfsc   0x03, 0x0                ; 1601: 1803
    goto    0x0620                   ; 1602: 2e20
    addlw   0x11                     ; 1603: 3e11
    btfss   0x03, 0x0                ; 1604: 1c03
    goto    0x0620                   ; 1605: 2e20
    movlw   0x00                     ; 1606: 3000
    subwf   0x70, 0x1                ; 1607: 02f0
    movlw   0x16                     ; 1608: 3016
    movwf   0x0a                     ; 1609: 008a
    movlw   0x0f                     ; 160a: 300f
    addwf   0x70, 0x0                ; 160b: 0770
    btfsc   0x03, 0x0                ; 160c: 1803
    incf    0x0a, 0x1                ; 160d: 0a8a
    movwf   0x02                     ; 160e: 0082
    goto    0x05ed                   ; 160f: 2ded
    goto    0x05ed                   ; 1610: 2ded
    goto    0x05d4                   ; 1611: 2dd4
    goto    0x05d4                   ; 1612: 2dd4
    goto    0x05d6                   ; 1613: 2dd6
    goto    0x05d8                   ; 1614: 2dd8
    goto    0x05e5                   ; 1615: 2de5
    goto    0x05eb                   ; 1616: 2deb
    goto    0x05ef                   ; 1617: 2def
    goto    0x05ef                   ; 1618: 2def
    goto    0x05ef                   ; 1619: 2def
    goto    0x05ef                   ; 161a: 2def
    goto    0x05ed                   ; 161b: 2ded
    goto    0x05ed                   ; 161c: 2ded
    goto    0x05ef                   ; 161d: 2def
    goto    0x05f3                   ; 161e: 2df3
    goto    0x05fb                   ; 161f: 2dfb
    movf    0x59, 0x1                ; 1620: 08d9
    btfsc   0x03, 0x2                ; 1621: 1903
    return                           ; 1622: 0008
    movf    0x57, 0x0                ; 1623: 0857
    movwf   0x5a                     ; 1624: 00da
    movf    0x58, 0x0                ; 1625: 0858
    call    0x059a                   ; 1626: 259a
    movf    0x57, 0x0                ; 1627: 0857
    movwf   0x5a                     ; 1628: 00da
    movf    0x58, 0x0                ; 1629: 0858
    addlw   0x64                     ; 162a: 3e64
    call    0x059a                   ; 162b: 259a
    movf    0x57, 0x0                ; 162c: 0857
    movwf   0x5a                     ; 162d: 00da
    movf    0x58, 0x0                ; 162e: 0858
    addlw   0xc8                     ; 162f: 3ec8
    goto    0x059a                   ; 1630: 2d9a
    movf    0x57, 0x0                ; 1631: 0857
    movwf   0x5a                     ; 1632: 00da
    movf    0x58, 0x0                ; 1633: 0858
    goto    0x059a                   ; 1634: 2d9a
    clrf    0x03                     ; 1635: 0183
    movwf   0x3d                     ; 1636: 00bd
    bsf     0x0a, 0x4                ; 1637: 160a
    bsf     0x0a, 0x3                ; 1638: 158a
    call    0x06d8                   ; 1639: 26d8
    bsf     0x0a, 0x4                ; 163a: 160a
    bcf     0x0a, 0x3                ; 163b: 118a
    movf    0x3d, 0x0                ; 163c: 083d
    movwf   0x04                     ; 163d: 0084
    bcf     0x03, 0x7                ; 163e: 1383
    movf    0x00, 0x0                ; 163f: 0800
    movwf   0x70                     ; 1640: 00f0
    incf    0x04, 0x1                ; 1641: 0a84
    movf    0x00, 0x0                ; 1642: 0800
    movwf   0x71                     ; 1643: 00f1
    iorwf   0x70, 0x0                ; 1644: 0470
    btfsc   0x03, 0x2                ; 1645: 1903
    goto    0x0665                   ; 1646: 2e65
    movf    0x3d, 0x0                ; 1647: 083d
    movwf   0x04                     ; 1648: 0084
    movlw   0xff                     ; 1649: 30ff
    addwf   0x00, 0x1                ; 164a: 0780
    incf    0x04, 0x1                ; 164b: 0a84
    btfsc   0x03, 0x0                ; 164c: 1803
    incf    0x00, 0x1                ; 164d: 0a80
    addwf   0x00, 0x1                ; 164e: 0780
    decf    0x04, 0x1                ; 164f: 0384
    movf    0x00, 0x0                ; 1650: 0800
    movwf   0x70                     ; 1651: 00f0
    incf    0x04, 0x1                ; 1652: 0a84
    movf    0x00, 0x0                ; 1653: 0800
    movwf   0x71                     ; 1654: 00f1
    iorwf   0x70, 0x0                ; 1655: 0470
    btfss   0x03, 0x2                ; 1656: 1d03
    goto    0x0665                   ; 1657: 2e65
    movf    0x3d, 0x0                ; 1658: 083d
    addlw   0x02                     ; 1659: 3e02
    movwf   0x04                     ; 165a: 0084
    movf    0x00, 0x1                ; 165b: 0880
    btfsc   0x03, 0x2                ; 165c: 1903
    goto    0x0665                   ; 165d: 2e65
    movf    0x3d, 0x0                ; 165e: 083d
    addlw   0x02                     ; 165f: 3e02
    movwf   0x04                     ; 1660: 0084
    movf    0x00, 0x0                ; 1661: 0800
    bsf     0x0a, 0x4                ; 1662: 160a
    bcf     0x0a, 0x3                ; 1663: 118a
    call    0x00f7                   ; 1664: 20f7
    bsf     0x0a, 0x4                ; 1665: 160a
    bsf     0x0a, 0x3                ; 1666: 158a
    goto    0x06ac                   ; 1667: 2eac
    clrf    0x03                     ; 1668: 0183
    movwf   0x3d                     ; 1669: 00bd
    bsf     0x0a, 0x4                ; 166a: 160a
    bsf     0x0a, 0x3                ; 166b: 158a
    call    0x06d8                   ; 166c: 26d8
    bsf     0x0a, 0x4                ; 166d: 160a
    bcf     0x0a, 0x3                ; 166e: 118a
    movf    0x3d, 0x0                ; 166f: 083d
    movwf   0x04                     ; 1670: 0084
    bcf     0x03, 0x7                ; 1671: 1383
    movf    0x00, 0x0                ; 1672: 0800
    movwf   0x70                     ; 1673: 00f0
    incf    0x04, 0x1                ; 1674: 0a84
    movf    0x00, 0x0                ; 1675: 0800
    movwf   0x71                     ; 1676: 00f1
    iorwf   0x70, 0x0                ; 1677: 0470
    btfsc   0x03, 0x2                ; 1678: 1903
    goto    0x06a7                   ; 1679: 2ea7
    movf    0x3d, 0x0                ; 167a: 083d
    movwf   0x04                     ; 167b: 0084
    movlw   0xff                     ; 167c: 30ff
    addwf   0x00, 0x1                ; 167d: 0780
    incf    0x04, 0x1                ; 167e: 0a84
    btfsc   0x03, 0x0                ; 167f: 1803
    incf    0x00, 0x1                ; 1680: 0a80
    addwf   0x00, 0x1                ; 1681: 0780
    decf    0x04, 0x1                ; 1682: 0384
    movf    0x00, 0x0                ; 1683: 0800
    movwf   0x70                     ; 1684: 00f0
    incf    0x04, 0x1                ; 1685: 0a84
    movf    0x00, 0x0                ; 1686: 0800
    movwf   0x71                     ; 1687: 00f1
    iorwf   0x70, 0x0                ; 1688: 0470
    btfss   0x03, 0x2                ; 1689: 1d03
    goto    0x06a7                   ; 168a: 2ea7
    movf    0x3d, 0x0                ; 168b: 083d
    addlw   0x03                     ; 168c: 3e03
    movwf   0x04                     ; 168d: 0084
    movf    0x00, 0x0                ; 168e: 0800
    movwf   0x70                     ; 168f: 00f0
    incf    0x04, 0x1                ; 1690: 0a84
    movf    0x00, 0x0                ; 1691: 0800
    movwf   0x71                     ; 1692: 00f1
    movf    0x3d, 0x0                ; 1693: 083d
    movwf   0x04                     ; 1694: 0084
    movf    0x70, 0x0                ; 1695: 0870
    movwf   0x00                     ; 1696: 0080
    incf    0x04, 0x1                ; 1697: 0a84
    movf    0x71, 0x0                ; 1698: 0871
    movwf   0x00                     ; 1699: 0080
    movf    0x3d, 0x0                ; 169a: 083d
    addlw   0x02                     ; 169b: 3e02
    movwf   0x04                     ; 169c: 0084
    movf    0x00, 0x1                ; 169d: 0880
    btfsc   0x03, 0x2                ; 169e: 1903
    goto    0x06a7                   ; 169f: 2ea7
    movf    0x3d, 0x0                ; 16a0: 083d
    addlw   0x02                     ; 16a1: 3e02
    movwf   0x04                     ; 16a2: 0084
    movf    0x00, 0x0                ; 16a3: 0800
    bsf     0x0a, 0x4                ; 16a4: 160a
    bcf     0x0a, 0x3                ; 16a5: 118a
    call    0x00f7                   ; 16a6: 20f7
    bsf     0x0a, 0x4                ; 16a7: 160a
    bsf     0x0a, 0x3                ; 16a8: 158a
    goto    0x06ac                   ; 16a9: 2eac
    clrf    0x03                     ; 16aa: 0183
    movwf   0x3c                     ; 16ab: 00bc
    movlw   0x01                     ; 16ac: 3001
    subwf   0x3c, 0x0                ; 16ad: 023c
    btfsc   0x03, 0x0                ; 16ae: 1803
    goto    0x06ba                   ; 16af: 2eba
    movlw   0x05                     ; 16b0: 3005
    movwf   0x71                     ; 16b1: 00f1
    movf    0x3c, 0x0                ; 16b2: 083c
    bsf     0x0a, 0x4                ; 16b3: 160a
    bsf     0x0a, 0x3                ; 16b4: 158a
    call    0x06e2                   ; 16b5: 26e2
    bsf     0x0a, 0x4                ; 16b6: 160a
    bcf     0x0a, 0x3                ; 16b7: 118a
    addlw   0xa7                     ; 16b8: 3ea7
    goto    0x0668                   ; 16b9: 2e68
    movlw   0x03                     ; 16ba: 3003
    movwf   0x71                     ; 16bb: 00f1
    movf    0x3c, 0x0                ; 16bc: 083c
    bsf     0x0a, 0x4                ; 16bd: 160a
    bsf     0x0a, 0x3                ; 16be: 158a
    call    0x06e2                   ; 16bf: 26e2
    bsf     0x0a, 0x4                ; 16c0: 160a
    bcf     0x0a, 0x3                ; 16c1: 118a
    addlw   0xfd                     ; 16c2: 3efd
    addlw   0xac                     ; 16c3: 3eac
    goto    0x0635                   ; 16c4: 2e35
    movlw   0x04                     ; 16c5: 3004
    clrf    0x03                     ; 16c6: 0183
    addwf   0x31, 0x1                ; 16c7: 07b1
    btfsc   0x03, 0x0                ; 16c8: 1803
    incf    0x32, 0x1                ; 16c9: 0ab2
    goto    0x06d3                   ; 16ca: 2ed3
    incf    0x33, 0x1                ; 16cb: 0ab3
    btfsc   0x03, 0x2                ; 16cc: 1903
    incf    0x34, 0x1                ; 16cd: 0ab4
    movf    0x2f, 0x0                ; 16ce: 082f
    call    0x06aa                   ; 16cf: 26aa
    bsf     0x0a, 0x4                ; 16d0: 160a
    bcf     0x0a, 0x3                ; 16d1: 118a
    incf    0x2f, 0x1                ; 16d2: 0aaf
    movf    0x32, 0x0                ; 16d3: 0832
    subwf   0x34, 0x0                ; 16d4: 0234
    btfss   0x03, 0x2                ; 16d5: 1d03
    goto    0x06d9                   ; 16d6: 2ed9
    movf    0x31, 0x0                ; 16d7: 0831
    subwf   0x33, 0x0                ; 16d8: 0233
    btfss   0x03, 0x0                ; 16d9: 1c03
    goto    0x06cb                   ; 16da: 2ecb
    movlw   0x00                     ; 16db: 3000
    subwf   0x32, 0x0                ; 16dc: 0232
    movlw   0x04                     ; 16dd: 3004
    btfsc   0x03, 0x2                ; 16de: 1903
    subwf   0x31, 0x0                ; 16df: 0231
    btfss   0x03, 0x0                ; 16e0: 1c03
    return                           ; 16e1: 0008
    clrf    0x31                     ; 16e2: 01b1
    clrf    0x32                     ; 16e3: 01b2
    clrf    0x33                     ; 16e4: 01b3
    clrf    0x34                     ; 16e5: 01b4
    clrf    0x2f                     ; 16e6: 01af
    return                           ; 16e7: 0008
    clrf    0x03                     ; 16e8: 0183
    incf    0x2e, 0x1                ; 16e9: 0aae
    decfsz  0x2e, 0x0                ; 16ea: 0b2e
    goto    0x06fa                   ; 16eb: 2efa
    goto    0x06f7                   ; 16ec: 2ef7
    bsf     0x0a, 0x4                ; 16ed: 160a
    bsf     0x0a, 0x3                ; 16ee: 158a
    call    0x06d8                   ; 16ef: 26d8
    decf    0x30, 0x1                ; 16f0: 03b0
    bsf     0x0a, 0x4                ; 16f1: 160a
    bsf     0x0a, 0x3                ; 16f2: 158a
    call    0x06ac                   ; 16f3: 26ac
    bsf     0x0a, 0x4                ; 16f4: 160a
    bcf     0x0a, 0x3                ; 16f5: 118a
    call    0x06c5                   ; 16f6: 26c5
    movf    0x30, 0x1                ; 16f7: 08b0
    btfss   0x03, 0x2                ; 16f8: 1d03
    goto    0x06ed                   ; 16f9: 2eed
    decf    0x2e, 0x1                ; 16fa: 03ae
    return                           ; 16fb: 0008
    clrf    0x03                     ; 16fc: 0183
    movwf   0x4a                     ; 16fd: 00ca
    movlw   0x18                     ; 16fe: 3018
    movwf   0x0a                     ; 16ff: 008a
    movf    0x4a, 0x0                ; 1700: 084a
    andlw   0x07                     ; 1701: 3907
    call    0x0032                   ; 1702: 2032
    bsf     0x0a, 0x4                ; 1703: 160a
    bcf     0x0a, 0x3                ; 1704: 118a
    movwf   0x70                     ; 1705: 00f0
    movf    0x4a, 0x0                ; 1706: 084a
    movwf   0x71                     ; 1707: 00f1
    bcf     0x03, 0x0                ; 1708: 1003
    rrf     0x71, 0x1                ; 1709: 0cf1
    bcf     0x03, 0x0                ; 170a: 1003
    rrf     0x71, 0x1                ; 170b: 0cf1
    bcf     0x03, 0x0                ; 170c: 1003
    rrf     0x71, 0x0                ; 170d: 0c71
    addlw   0xa1                     ; 170e: 3ea1
    movwf   0x04                     ; 170f: 0084
    bcf     0x03, 0x7                ; 1710: 1383
    movf    0x00, 0x0                ; 1711: 0800
    andwf   0x70, 0x0                ; 1712: 0570
    btfss   0x03, 0x2                ; 1713: 1d03
    retlw   0x01                     ; 1714: 3401
    retlw   0x00                     ; 1715: 3400
    clrf    0x03                     ; 1716: 0183
    movwf   0x49                     ; 1717: 00c9
    movlw   0x05                     ; 1718: 3005
    subwf   0x49, 0x0                ; 1719: 0249
    btfsc   0x03, 0x0                ; 171a: 1803
    retlw   0x01                     ; 171b: 3401
    movf    0x49, 0x0                ; 171c: 0849
    call    0x06fc                   ; 171d: 26fc
    iorlw   0x00                     ; 171e: 3800
    btfsc   0x03, 0x2                ; 171f: 1903
    retlw   0x02                     ; 1720: 3402
    bsf     0x0a, 0x4                ; 1721: 160a
    bsf     0x0a, 0x3                ; 1722: 158a
    call    0x06d8                   ; 1723: 26d8
    bsf     0x0a, 0x4                ; 1724: 160a
    bcf     0x0a, 0x3                ; 1725: 118a
    bsf     0x03, 0x5                ; 1726: 1683
    decf    0x20, 0x1                ; 1727: 03a0
    bcf     0x03, 0x5                ; 1728: 1283
    movf    0x49, 0x0                ; 1729: 0849
    addlw   0xa2                     ; 172a: 3ea2
    movwf   0x04                     ; 172b: 0084
    bcf     0x03, 0x7                ; 172c: 1383
    decfsz  0x00, 0x1                ; 172d: 0b80
    goto    0x0740                   ; 172e: 2f40
    movf    0x49, 0x0                ; 172f: 0849
    movwf   0x70                     ; 1730: 00f0
    bcf     0x03, 0x0                ; 1731: 1003
    rrf     0x70, 0x1                ; 1732: 0cf0
    bcf     0x03, 0x0                ; 1733: 1003
    rrf     0x70, 0x1                ; 1734: 0cf0
    bcf     0x03, 0x0                ; 1735: 1003
    rrf     0x70, 0x0                ; 1736: 0c70
    addlw   0xa1                     ; 1737: 3ea1
    movwf   0x04                     ; 1738: 0084
    movlw   0x18                     ; 1739: 3018
    movwf   0x0a                     ; 173a: 008a
    movf    0x49, 0x0                ; 173b: 0849
    andlw   0x07                     ; 173c: 3907
    call    0x0032                   ; 173d: 2032
    xorlw   0xff                     ; 173e: 3aff
    andwf   0x00, 0x1                ; 173f: 0580
    bsf     0x0a, 0x4                ; 1740: 160a
    bsf     0x0a, 0x3                ; 1741: 158a
    call    0x06ac                   ; 1742: 26ac
    bsf     0x0a, 0x4                ; 1743: 160a
    bcf     0x0a, 0x3                ; 1744: 118a
    retlw   0x00                     ; 1745: 3400
    bsf     0x03, 0x5                ; 1746: 1683
    bcf     0x03, 0x6                ; 1747: 1303
    movf    0x20, 0x1                ; 1748: 08a0
    btfsc   0x03, 0x2                ; 1749: 1903
    goto    0x0792                   ; 174a: 2f92
    bcf     0x03, 0x5                ; 174b: 1283
    clrf    0x40                     ; 174c: 01c0
    movf    0x40, 0x0                ; 174d: 0840
    addlw   0xa1                     ; 174e: 3ea1
    movwf   0x04                     ; 174f: 0084
    bcf     0x03, 0x7                ; 1750: 1383
    movf    0x00, 0x1                ; 1751: 0880
    movlw   0x01                     ; 1752: 3001
    btfss   0x03, 0x2                ; 1753: 1d03
    goto    0x075a                   ; 1754: 2f5a
    incf    0x40, 0x1                ; 1755: 0ac0
    subwf   0x40, 0x0                ; 1756: 0240
    btfss   0x03, 0x0                ; 1757: 1c03
    goto    0x074d                   ; 1758: 2f4d
    movlw   0x01                     ; 1759: 3001
    subwf   0x40, 0x0                ; 175a: 0240
    btfsc   0x03, 0x0                ; 175b: 1803
    goto    0x0792                   ; 175c: 2f92
    movf    0x40, 0x0                ; 175d: 0840
    addlw   0xa1                     ; 175e: 3ea1
    movwf   0x04                     ; 175f: 0084
    movf    0x00, 0x0                ; 1760: 0800
    movwf   0x3f                     ; 1761: 00bf
    bcf     0x03, 0x0                ; 1762: 1003
    rlf     0x40, 0x1                ; 1763: 0dc0
    bcf     0x03, 0x0                ; 1764: 1003
    rlf     0x40, 0x1                ; 1765: 0dc0
    bcf     0x03, 0x0                ; 1766: 1003
    rlf     0x40, 0x1                ; 1767: 0dc0
    btfsc   0x3f, 0x0                ; 1768: 183f
    goto    0x078e                   ; 1769: 2f8e
    btfsc   0x3f, 0x1                ; 176a: 18bf
    goto    0x078c                   ; 176b: 2f8c
    btfsc   0x3f, 0x2                ; 176c: 193f
    goto    0x0789                   ; 176d: 2f89
    btfsc   0x3f, 0x3                ; 176e: 19bf
    goto    0x0786                   ; 176f: 2f86
    btfsc   0x3f, 0x4                ; 1770: 1a3f
    goto    0x0783                   ; 1771: 2f83
    btfsc   0x3f, 0x5                ; 1772: 1abf
    goto    0x0780                   ; 1773: 2f80
    btfsc   0x3f, 0x6                ; 1774: 1b3f
    goto    0x077d                   ; 1775: 2f7d
    btfsc   0x3f, 0x7                ; 1776: 1bbf
    goto    0x077a                   ; 1777: 2f7a
    movlw   0x05                     ; 1778: 3005
    goto    0x078f                   ; 1779: 2f8f
    movf    0x40, 0x0                ; 177a: 0840
    addlw   0x07                     ; 177b: 3e07
    goto    0x078f                   ; 177c: 2f8f
    movf    0x40, 0x0                ; 177d: 0840
    addlw   0x06                     ; 177e: 3e06
    goto    0x078f                   ; 177f: 2f8f
    movf    0x40, 0x0                ; 1780: 0840
    addlw   0x05                     ; 1781: 3e05
    goto    0x078f                   ; 1782: 2f8f
    movf    0x40, 0x0                ; 1783: 0840
    addlw   0x04                     ; 1784: 3e04
    goto    0x078f                   ; 1785: 2f8f
    movf    0x40, 0x0                ; 1786: 0840
    addlw   0x03                     ; 1787: 3e03
    goto    0x078f                   ; 1788: 2f8f
    movf    0x40, 0x0                ; 1789: 0840
    addlw   0x02                     ; 178a: 3e02
    goto    0x078f                   ; 178b: 2f8f
    incf    0x40, 0x0                ; 178c: 0a40
    goto    0x078f                   ; 178d: 2f8f
    movf    0x40, 0x0                ; 178e: 0840
    movwf   0x70                     ; 178f: 00f0
    clrf    0x71                     ; 1790: 01f1
    goto    0x0793                   ; 1791: 2f93
    movlw   0x05                     ; 1792: 3005
    bcf     0x03, 0x5                ; 1793: 1283
    return                           ; 1794: 0008
    bsf     0x03, 0x5                ; 1795: 1683
    bcf     0x03, 0x6                ; 1796: 1303
    movf    0x20, 0x1                ; 1797: 08a0
    btfss   0x03, 0x2                ; 1798: 1d03
    goto    0x07bc                   ; 1799: 2fbc
    bcf     0x03, 0x5                ; 179a: 1283
    movf    0x62, 0x0                ; 179b: 0862
    iorwf   0x61, 0x0                ; 179c: 0461
    btfsc   0x03, 0x2                ; 179d: 1903
    retlw   0x05                     ; 179e: 3405
    movf    0x35, 0x1                ; 179f: 08b5
    btfss   0x03, 0x2                ; 17a0: 1d03
    retlw   0x05                     ; 17a1: 3405
    movf    0x61, 0x0                ; 17a2: 0861
    movwf   0x4d                     ; 17a3: 00cd
    movf    0x62, 0x0                ; 17a4: 0862
    movwf   0x4e                     ; 17a5: 00ce
    movlw   0x05                     ; 17a6: 3005
    movwf   0x4f                     ; 17a7: 00cf
    clrf    0x50                     ; 17a8: 01d0
    bsf     0x0a, 0x4                ; 17a9: 160a
    bsf     0x0a, 0x3                ; 17aa: 158a
    call    0x05fe                   ; 17ab: 25fe
    bsf     0x0a, 0x4                ; 17ac: 160a
    bcf     0x0a, 0x3                ; 17ad: 118a
    movwf   0x70                     ; 17ae: 00f0
    clrf    0x71                     ; 17af: 01f1
    iorwf   0x71, 0x0                ; 17b0: 0471
    btfsc   0x03, 0x2                ; 17b1: 1903
    retlw   0x05                     ; 17b2: 3405
    movf    0x62, 0x0                ; 17b3: 0862
    movwf   0x67                     ; 17b4: 00e7
    movf    0x61, 0x0                ; 17b5: 0861
    bcf     0x0a, 0x4                ; 17b6: 120a
    bcf     0x0a, 0x3                ; 17b7: 118a
    call    0x01e7                   ; 17b8: 21e7
    bsf     0x0a, 0x4                ; 17b9: 160a
    bcf     0x0a, 0x3                ; 17ba: 118a
    retlw   0x05                     ; 17bb: 3405
    bsf     0x0a, 0x4                ; 17bc: 160a
    bsf     0x0a, 0x3                ; 17bd: 158a
    call    0x06d8                   ; 17be: 26d8
    bsf     0x0a, 0x4                ; 17bf: 160a
    bcf     0x0a, 0x3                ; 17c0: 118a
    call    0x0746                   ; 17c1: 2746
    movwf   0x3c                     ; 17c2: 00bc
    movlw   0x05                     ; 17c3: 3005
    subwf   0x3c, 0x0                ; 17c4: 023c
    btfss   0x03, 0x0                ; 17c5: 1c03
    goto    0x07cd                   ; 17c6: 2fcd
    bsf     0x0a, 0x4                ; 17c7: 160a
    bsf     0x0a, 0x3                ; 17c8: 158a
    call    0x06ac                   ; 17c9: 26ac
    bsf     0x0a, 0x4                ; 17ca: 160a
    bcf     0x0a, 0x3                ; 17cb: 118a
    retlw   0x05                     ; 17cc: 3405
    movf    0x3c, 0x0                ; 17cd: 083c
    movwf   0x60                     ; 17ce: 00e0
    addwf   0x60, 0x0                ; 17cf: 0760
    addlw   0xb5                     ; 17d0: 3eb5
    movwf   0x04                     ; 17d1: 0084
    bcf     0x03, 0x7                ; 17d2: 1383
    movf    0x00, 0x0                ; 17d3: 0800
    movwf   0x3d                     ; 17d4: 00bd
    incf    0x04, 0x1                ; 17d5: 0a84
    movf    0x00, 0x0                ; 17d6: 0800
    movwf   0x3e                     ; 17d7: 00be
    movf    0x60, 0x0                ; 17d8: 0860
    call    0x0716                   ; 17d9: 2716
    bsf     0x0a, 0x4                ; 17da: 160a
    bsf     0x0a, 0x3                ; 17db: 158a
    call    0x06ac                   ; 17dc: 26ac
    bsf     0x0a, 0x4                ; 17dd: 160a
    bcf     0x0a, 0x3                ; 17de: 118a
    movf    0x3e, 0x0                ; 17df: 083e
    iorwf   0x3d, 0x0                ; 17e0: 043d
    btfsc   0x03, 0x2                ; 17e1: 1903
    retlw   0x05                     ; 17e2: 3405
    movf    0x3d, 0x0                ; 17e3: 083d
    movwf   0x4d                     ; 17e4: 00cd
    movf    0x3e, 0x0                ; 17e5: 083e
    movwf   0x4e                     ; 17e6: 00ce
    movf    0x60, 0x0                ; 17e7: 0860
    movwf   0x4f                     ; 17e8: 00cf
    clrf    0x50                     ; 17e9: 01d0
    bsf     0x0a, 0x4                ; 17ea: 160a
    bsf     0x0a, 0x3                ; 17eb: 158a
    call    0x05fe                   ; 17ec: 25fe
    bsf     0x0a, 0x4                ; 17ed: 160a
    bcf     0x0a, 0x3                ; 17ee: 118a
    movwf   0x70                     ; 17ef: 00f0
    clrf    0x71                     ; 17f0: 01f1
    iorwf   0x71, 0x0                ; 17f1: 0471
    btfsc   0x03, 0x2                ; 17f2: 1903
    retlw   0x05                     ; 17f3: 3405
    clrf    0x2c                     ; 17f4: 01ac
    clrf    0x2d                     ; 17f5: 01ad
    movf    0x3e, 0x0                ; 17f6: 083e
    movwf   0x67                     ; 17f7: 00e7
    movf    0x3d, 0x0                ; 17f8: 083d
    bcf     0x0a, 0x4                ; 17f9: 120a
    bcf     0x0a, 0x3                ; 17fa: 118a
    call    0x01e7                   ; 17fb: 21e7
    bsf     0x0a, 0x4                ; 17fc: 160a
    bcf     0x0a, 0x3                ; 17fd: 118a
    movf    0x60, 0x0                ; 17fe: 0860
    return                           ; 17ff: 0008
    addwf   0x02, 0x1                ; 1800: 0782
    retlw   0x00                     ; 1801: 3400
    retlw   0x00                     ; 1802: 3400
    retlw   0xd0                     ; 1803: 34d0
    retlw   0x03                     ; 1804: 3403
    retlw   0x8a                     ; 1805: 348a
    retlw   0x02                     ; 1806: 3402
    retlw   0xe8                     ; 1807: 34e8
    retlw   0x01                     ; 1808: 3401
    retlw   0x86                     ; 1809: 3486
    retlw   0x01                     ; 180a: 3401
    retlw   0x45                     ; 180b: 3445
    retlw   0x01                     ; 180c: 3401
    retlw   0x16                     ; 180d: 3416
    retlw   0x01                     ; 180e: 3401
    retlw   0xf3                     ; 180f: 34f3
    retlw   0x00                     ; 1810: 3400
    retlw   0xd8                     ; 1811: 34d8
    retlw   0x00                     ; 1812: 3400
    retlw   0xc2                     ; 1813: 34c2
    retlw   0x00                     ; 1814: 3400
    retlw   0x60                     ; 1815: 3460
    retlw   0x00                     ; 1816: 3400
    retlw   0x40                     ; 1817: 3440
    retlw   0x00                     ; 1818: 3400
    retlw   0x30                     ; 1819: 3430
    retlw   0x00                     ; 181a: 3400
    retlw   0x26                     ; 181b: 3426
    retlw   0x00                     ; 181c: 3400
    retlw   0x20                     ; 181d: 3420
    retlw   0x00                     ; 181e: 3400
    retlw   0x4c                     ; 181f: 344c
    retlw   0x04                     ; 1820: 3404
    addwf   0x02, 0x1                ; 1821: 0782
    retlw   0x00                     ; 1822: 3400
    retlw   0x00                     ; 1823: 3400
    retlw   0x01                     ; 1824: 3401
    retlw   0x03                     ; 1825: 3403
    retlw   0x07                     ; 1826: 3407
    retlw   0x0f                     ; 1827: 340f
    retlw   0x1f                     ; 1828: 341f
    retlw   0x3f                     ; 1829: 343f
    retlw   0x7f                     ; 182a: 347f
    retlw   0xff                     ; 182b: 34ff
    retlw   0xc0                     ; 182c: 34c0
    retlw   0x00                     ; 182d: 3400
    retlw   0x00                     ; 182e: 3400
    retlw   0x00                     ; 182f: 3400
    retlw   0x00                     ; 1830: 3400
    retlw   0x00                     ; 1831: 3400
    addwf   0x02, 0x1                ; 1832: 0782
    retlw   0x01                     ; 1833: 3401
    retlw   0x02                     ; 1834: 3402
    retlw   0x04                     ; 1835: 3404
    retlw   0x08                     ; 1836: 3408
    retlw   0x10                     ; 1837: 3410
    retlw   0x20                     ; 1838: 3420
    retlw   0x40                     ; 1839: 3440
    retlw   0x80                     ; 183a: 3480
    addwf   0x02, 0x1                ; 183b: 0782
    retlw   0x00                     ; 183c: 3400
    retlw   0x03                     ; 183d: 3403
    retlw   0x57                     ; 183e: 3457
    retlw   0x18                     ; 183f: 3418
    retlw   0x01                     ; 1840: 3401
    retlw   0x00                     ; 1841: 3400
    retlw   0x05                     ; 1842: 3405
    retlw   0x00                     ; 1843: 3400
    addwf   0x02, 0x1                ; 1844: 0782
    retlw   0x01                     ; 1845: 3401
    retlw   0x51                     ; 1846: 3451
    retlw   0x18                     ; 1847: 3418
    retlw   0x02                     ; 1848: 3402
    retlw   0x54                     ; 1849: 3454
    retlw   0x18                     ; 184a: 3418
    addwf   0x02, 0x1                ; 184b: 0782
    retlw   0x08                     ; 184c: 3408
    retlw   0x00                     ; 184d: 3400
    addwf   0x02, 0x1                ; 184e: 0782
    retlw   0x09                     ; 184f: 3409
    retlw   0x00                     ; 1850: 3400
    bcf     0x0a, 0x4                ; 1851: 120a
    bcf     0x0a, 0x3                ; 1852: 118a
    goto    0x0438                   ; 1853: 2c38
    bcf     0x0a, 0x4                ; 1854: 120a
    bcf     0x0a, 0x3                ; 1855: 118a
    goto    0x04cb                   ; 1856: 2ccb
    bcf     0x0a, 0x4                ; 1857: 120a
    bcf     0x0a, 0x3                ; 1858: 118a
    goto    0x02f7                   ; 1859: 2af7
    addwf   0x02, 0x1                ; 185a: 0782
    retlw   0x27                     ; 185b: 3427
    addwf   0x02, 0x1                ; 185c: 0782
    retlw   0x01                     ; 185d: 3401
    addwf   0x02, 0x1                ; 185e: 0782
    retlw   0x2c                     ; 185f: 342c
    addwf   0x02, 0x1                ; 1860: 0782
    retlw   0x0a                     ; 1861: 340a
    dw 0x3fff ; erased               ; 1862: 3fff
    dw 0x3fff ; erased               ; 1863: 3fff
    dw 0x3fff ; erased               ; 1864: 3fff
    dw 0x3fff ; erased               ; 1865: 3fff
    dw 0x3fff ; erased               ; 1866: 3fff
    dw 0x3fff ; erased               ; 1867: 3fff
    dw 0x3fff ; erased               ; 1868: 3fff
    dw 0x3fff ; erased               ; 1869: 3fff
    dw 0x3fff ; erased               ; 186a: 3fff
    dw 0x3fff ; erased               ; 186b: 3fff
    dw 0x3fff ; erased               ; 186c: 3fff
    dw 0x3fff ; erased               ; 186d: 3fff
    dw 0x3fff ; erased               ; 186e: 3fff
    dw 0x3fff ; erased               ; 186f: 3fff
    dw 0x3fff ; erased               ; 1870: 3fff
    dw 0x3fff ; erased               ; 1871: 3fff
    dw 0x3fff ; erased               ; 1872: 3fff
    dw 0x3fff ; erased               ; 1873: 3fff
    dw 0x3fff ; erased               ; 1874: 3fff
    dw 0x3fff ; erased               ; 1875: 3fff
    dw 0x3fff ; erased               ; 1876: 3fff
    dw 0x3fff ; erased               ; 1877: 3fff
    dw 0x3fff ; erased               ; 1878: 3fff
    dw 0x3fff ; erased               ; 1879: 3fff
    dw 0x3fff ; erased               ; 187a: 3fff
    dw 0x3fff ; erased               ; 187b: 3fff
    dw 0x3fff ; erased               ; 187c: 3fff
    dw 0x3fff ; erased               ; 187d: 3fff
    dw 0x3fff ; erased               ; 187e: 3fff
    dw 0x3fff ; erased               ; 187f: 3fff
    dw 0x3fff ; erased               ; 1880: 3fff
    dw 0x3fff ; erased               ; 1881: 3fff
    dw 0x3fff ; erased               ; 1882: 3fff
    dw 0x3fff ; erased               ; 1883: 3fff
    dw 0x3fff ; erased               ; 1884: 3fff
    dw 0x3fff ; erased               ; 1885: 3fff
    dw 0x3fff ; erased               ; 1886: 3fff
    dw 0x3fff ; erased               ; 1887: 3fff
    dw 0x3fff ; erased               ; 1888: 3fff
    dw 0x3fff ; erased               ; 1889: 3fff
    dw 0x3fff ; erased               ; 188a: 3fff
    dw 0x3fff ; erased               ; 188b: 3fff
    dw 0x3fff ; erased               ; 188c: 3fff
    dw 0x3fff ; erased               ; 188d: 3fff
    dw 0x3fff ; erased               ; 188e: 3fff
    dw 0x3fff ; erased               ; 188f: 3fff
    dw 0x3fff ; erased               ; 1890: 3fff
    dw 0x3fff ; erased               ; 1891: 3fff
    dw 0x3fff ; erased               ; 1892: 3fff
    dw 0x3fff ; erased               ; 1893: 3fff
    dw 0x3fff ; erased               ; 1894: 3fff
    dw 0x3fff ; erased               ; 1895: 3fff
    dw 0x3fff ; erased               ; 1896: 3fff
    dw 0x3fff ; erased               ; 1897: 3fff
    dw 0x3fff ; erased               ; 1898: 3fff
    dw 0x3fff ; erased               ; 1899: 3fff
    dw 0x3fff ; erased               ; 189a: 3fff
    dw 0x3fff ; erased               ; 189b: 3fff
    dw 0x3fff ; erased               ; 189c: 3fff
    dw 0x3fff ; erased               ; 189d: 3fff
    dw 0x3fff ; erased               ; 189e: 3fff
    dw 0x3fff ; erased               ; 189f: 3fff
    dw 0x3fff ; erased               ; 18a0: 3fff
    dw 0x3fff ; erased               ; 18a1: 3fff
    dw 0x3fff ; erased               ; 18a2: 3fff
    dw 0x3fff ; erased               ; 18a3: 3fff
    dw 0x3fff ; erased               ; 18a4: 3fff
    dw 0x3fff ; erased               ; 18a5: 3fff
    dw 0x3fff ; erased               ; 18a6: 3fff
    dw 0x3fff ; erased               ; 18a7: 3fff
    dw 0x3fff ; erased               ; 18a8: 3fff
    dw 0x3fff ; erased               ; 18a9: 3fff
    dw 0x3fff ; erased               ; 18aa: 3fff
    dw 0x3fff ; erased               ; 18ab: 3fff
    dw 0x3fff ; erased               ; 18ac: 3fff
    dw 0x3fff ; erased               ; 18ad: 3fff
    dw 0x3fff ; erased               ; 18ae: 3fff
    dw 0x3fff ; erased               ; 18af: 3fff
    dw 0x3fff ; erased               ; 18b0: 3fff
    dw 0x3fff ; erased               ; 18b1: 3fff
    dw 0x3fff ; erased               ; 18b2: 3fff
    dw 0x3fff ; erased               ; 18b3: 3fff
    dw 0x3fff ; erased               ; 18b4: 3fff
    dw 0x3fff ; erased               ; 18b5: 3fff
    dw 0x3fff ; erased               ; 18b6: 3fff
    dw 0x3fff ; erased               ; 18b7: 3fff
    dw 0x3fff ; erased               ; 18b8: 3fff
    dw 0x3fff ; erased               ; 18b9: 3fff
    dw 0x3fff ; erased               ; 18ba: 3fff
    dw 0x3fff ; erased               ; 18bb: 3fff
    dw 0x3fff ; erased               ; 18bc: 3fff
    dw 0x3fff ; erased               ; 18bd: 3fff
    dw 0x3fff ; erased               ; 18be: 3fff
    dw 0x3fff ; erased               ; 18bf: 3fff
    dw 0x3fff ; erased               ; 18c0: 3fff
    dw 0x3fff ; erased               ; 18c1: 3fff
    dw 0x3fff ; erased               ; 18c2: 3fff
    dw 0x3fff ; erased               ; 18c3: 3fff
    dw 0x3fff ; erased               ; 18c4: 3fff
    dw 0x3fff ; erased               ; 18c5: 3fff
    dw 0x3fff ; erased               ; 18c6: 3fff
    dw 0x3fff ; erased               ; 18c7: 3fff
    dw 0x3fff ; erased               ; 18c8: 3fff
    dw 0x3fff ; erased               ; 18c9: 3fff
    dw 0x3fff ; erased               ; 18ca: 3fff
    dw 0x3fff ; erased               ; 18cb: 3fff
    dw 0x3fff ; erased               ; 18cc: 3fff
    dw 0x3fff ; erased               ; 18cd: 3fff
    dw 0x3fff ; erased               ; 18ce: 3fff
    dw 0x3fff ; erased               ; 18cf: 3fff
    dw 0x3fff ; erased               ; 18d0: 3fff
    dw 0x3fff ; erased               ; 18d1: 3fff
    dw 0x3fff ; erased               ; 18d2: 3fff
    dw 0x3fff ; erased               ; 18d3: 3fff
    dw 0x3fff ; erased               ; 18d4: 3fff
    dw 0x3fff ; erased               ; 18d5: 3fff
    dw 0x3fff ; erased               ; 18d6: 3fff
    dw 0x3fff ; erased               ; 18d7: 3fff
    dw 0x3fff ; erased               ; 18d8: 3fff
    dw 0x3fff ; erased               ; 18d9: 3fff
    dw 0x3fff ; erased               ; 18da: 3fff
    dw 0x3fff ; erased               ; 18db: 3fff
    dw 0x3fff ; erased               ; 18dc: 3fff
    dw 0x3fff ; erased               ; 18dd: 3fff
    dw 0x3fff ; erased               ; 18de: 3fff
    dw 0x3fff ; erased               ; 18df: 3fff
    dw 0x3fff ; erased               ; 18e0: 3fff
    dw 0x3fff ; erased               ; 18e1: 3fff
    dw 0x3fff ; erased               ; 18e2: 3fff
    dw 0x3fff ; erased               ; 18e3: 3fff
    dw 0x3fff ; erased               ; 18e4: 3fff
    dw 0x3fff ; erased               ; 18e5: 3fff
    dw 0x3fff ; erased               ; 18e6: 3fff
    dw 0x3fff ; erased               ; 18e7: 3fff
    dw 0x3fff ; erased               ; 18e8: 3fff
    dw 0x3fff ; erased               ; 18e9: 3fff
    dw 0x3fff ; erased               ; 18ea: 3fff
    dw 0x3fff ; erased               ; 18eb: 3fff
    dw 0x3fff ; erased               ; 18ec: 3fff
    dw 0x3fff ; erased               ; 18ed: 3fff
    dw 0x3fff ; erased               ; 18ee: 3fff
    dw 0x3fff ; erased               ; 18ef: 3fff
    dw 0x3fff ; erased               ; 18f0: 3fff
    dw 0x3fff ; erased               ; 18f1: 3fff
    dw 0x3fff ; erased               ; 18f2: 3fff
    dw 0x3fff ; erased               ; 18f3: 3fff
    dw 0x3fff ; erased               ; 18f4: 3fff
    dw 0x3fff ; erased               ; 18f5: 3fff
    dw 0x3fff ; erased               ; 18f6: 3fff
    dw 0x3fff ; erased               ; 18f7: 3fff
    dw 0x3fff ; erased               ; 18f8: 3fff
    dw 0x3fff ; erased               ; 18f9: 3fff
    dw 0x3fff ; erased               ; 18fa: 3fff
    dw 0x3fff ; erased               ; 18fb: 3fff
    dw 0x3fff ; erased               ; 18fc: 3fff
    dw 0x3fff ; erased               ; 18fd: 3fff
    dw 0x3fff ; erased               ; 18fe: 3fff
    dw 0x3fff ; erased               ; 18ff: 3fff
    dw 0x3fff ; erased               ; 1900: 3fff
    dw 0x3fff ; erased               ; 1901: 3fff
    dw 0x3fff ; erased               ; 1902: 3fff
    dw 0x3fff ; erased               ; 1903: 3fff
    dw 0x3fff ; erased               ; 1904: 3fff
    dw 0x3fff ; erased               ; 1905: 3fff
    dw 0x3fff ; erased               ; 1906: 3fff
    dw 0x3fff ; erased               ; 1907: 3fff
    dw 0x3fff ; erased               ; 1908: 3fff
    dw 0x3fff ; erased               ; 1909: 3fff
    dw 0x3fff ; erased               ; 190a: 3fff
    dw 0x3fff ; erased               ; 190b: 3fff
    dw 0x3fff ; erased               ; 190c: 3fff
    dw 0x3fff ; erased               ; 190d: 3fff
    dw 0x3fff ; erased               ; 190e: 3fff
    dw 0x3fff ; erased               ; 190f: 3fff
    dw 0x3fff ; erased               ; 1910: 3fff
    dw 0x3fff ; erased               ; 1911: 3fff
    dw 0x3fff ; erased               ; 1912: 3fff
    dw 0x3fff ; erased               ; 1913: 3fff
    dw 0x3fff ; erased               ; 1914: 3fff
    dw 0x3fff ; erased               ; 1915: 3fff
    dw 0x3fff ; erased               ; 1916: 3fff
    dw 0x3fff ; erased               ; 1917: 3fff
    dw 0x3fff ; erased               ; 1918: 3fff
    dw 0x3fff ; erased               ; 1919: 3fff
    dw 0x3fff ; erased               ; 191a: 3fff
    dw 0x3fff ; erased               ; 191b: 3fff
    dw 0x3fff ; erased               ; 191c: 3fff
    dw 0x3fff ; erased               ; 191d: 3fff
    dw 0x3fff ; erased               ; 191e: 3fff
    dw 0x3fff ; erased               ; 191f: 3fff
    dw 0x3fff ; erased               ; 1920: 3fff
    dw 0x3fff ; erased               ; 1921: 3fff
    dw 0x3fff ; erased               ; 1922: 3fff
    dw 0x3fff ; erased               ; 1923: 3fff
    dw 0x3fff ; erased               ; 1924: 3fff
    dw 0x3fff ; erased               ; 1925: 3fff
    dw 0x3fff ; erased               ; 1926: 3fff
    dw 0x3fff ; erased               ; 1927: 3fff
    dw 0x3fff ; erased               ; 1928: 3fff
    dw 0x3fff ; erased               ; 1929: 3fff
    dw 0x3fff ; erased               ; 192a: 3fff
    dw 0x3fff ; erased               ; 192b: 3fff
    dw 0x3fff ; erased               ; 192c: 3fff
    dw 0x3fff ; erased               ; 192d: 3fff
    dw 0x3fff ; erased               ; 192e: 3fff
    dw 0x3fff ; erased               ; 192f: 3fff
    dw 0x3fff ; erased               ; 1930: 3fff
    dw 0x3fff ; erased               ; 1931: 3fff
    dw 0x3fff ; erased               ; 1932: 3fff
    dw 0x3fff ; erased               ; 1933: 3fff
    dw 0x3fff ; erased               ; 1934: 3fff
    dw 0x3fff ; erased               ; 1935: 3fff
    dw 0x3fff ; erased               ; 1936: 3fff
    dw 0x3fff ; erased               ; 1937: 3fff
    dw 0x3fff ; erased               ; 1938: 3fff
    dw 0x3fff ; erased               ; 1939: 3fff
    dw 0x3fff ; erased               ; 193a: 3fff
    dw 0x3fff ; erased               ; 193b: 3fff
    dw 0x3fff ; erased               ; 193c: 3fff
    dw 0x3fff ; erased               ; 193d: 3fff
    dw 0x3fff ; erased               ; 193e: 3fff
    dw 0x3fff ; erased               ; 193f: 3fff
    dw 0x3fff ; erased               ; 1940: 3fff
    dw 0x3fff ; erased               ; 1941: 3fff
    dw 0x3fff ; erased               ; 1942: 3fff
    dw 0x3fff ; erased               ; 1943: 3fff
    dw 0x3fff ; erased               ; 1944: 3fff
    dw 0x3fff ; erased               ; 1945: 3fff
    dw 0x3fff ; erased               ; 1946: 3fff
    dw 0x3fff ; erased               ; 1947: 3fff
    dw 0x3fff ; erased               ; 1948: 3fff
    dw 0x3fff ; erased               ; 1949: 3fff
    dw 0x3fff ; erased               ; 194a: 3fff
    dw 0x3fff ; erased               ; 194b: 3fff
    dw 0x3fff ; erased               ; 194c: 3fff
    dw 0x3fff ; erased               ; 194d: 3fff
    dw 0x3fff ; erased               ; 194e: 3fff
    dw 0x3fff ; erased               ; 194f: 3fff
    dw 0x3fff ; erased               ; 1950: 3fff
    dw 0x3fff ; erased               ; 1951: 3fff
    dw 0x3fff ; erased               ; 1952: 3fff
    dw 0x3fff ; erased               ; 1953: 3fff
    dw 0x3fff ; erased               ; 1954: 3fff
    dw 0x3fff ; erased               ; 1955: 3fff
    dw 0x3fff ; erased               ; 1956: 3fff
    dw 0x3fff ; erased               ; 1957: 3fff
    dw 0x3fff ; erased               ; 1958: 3fff
    dw 0x3fff ; erased               ; 1959: 3fff
    dw 0x3fff ; erased               ; 195a: 3fff
    dw 0x3fff ; erased               ; 195b: 3fff
    dw 0x3fff ; erased               ; 195c: 3fff
    dw 0x3fff ; erased               ; 195d: 3fff
    dw 0x3fff ; erased               ; 195e: 3fff
    dw 0x3fff ; erased               ; 195f: 3fff
    dw 0x3fff ; erased               ; 1960: 3fff
    dw 0x3fff ; erased               ; 1961: 3fff
    dw 0x3fff ; erased               ; 1962: 3fff
    dw 0x3fff ; erased               ; 1963: 3fff
    dw 0x3fff ; erased               ; 1964: 3fff
    dw 0x3fff ; erased               ; 1965: 3fff
    dw 0x3fff ; erased               ; 1966: 3fff
    dw 0x3fff ; erased               ; 1967: 3fff
    dw 0x3fff ; erased               ; 1968: 3fff
    dw 0x3fff ; erased               ; 1969: 3fff
    dw 0x3fff ; erased               ; 196a: 3fff
    dw 0x3fff ; erased               ; 196b: 3fff
    dw 0x3fff ; erased               ; 196c: 3fff
    dw 0x3fff ; erased               ; 196d: 3fff
    dw 0x3fff ; erased               ; 196e: 3fff
    dw 0x3fff ; erased               ; 196f: 3fff
    dw 0x3fff ; erased               ; 1970: 3fff
    dw 0x3fff ; erased               ; 1971: 3fff
    dw 0x3fff ; erased               ; 1972: 3fff
    dw 0x3fff ; erased               ; 1973: 3fff
    dw 0x3fff ; erased               ; 1974: 3fff
    dw 0x3fff ; erased               ; 1975: 3fff
    dw 0x3fff ; erased               ; 1976: 3fff
    dw 0x3fff ; erased               ; 1977: 3fff
    dw 0x3fff ; erased               ; 1978: 3fff
    dw 0x3fff ; erased               ; 1979: 3fff
    dw 0x3fff ; erased               ; 197a: 3fff
    dw 0x3fff ; erased               ; 197b: 3fff
    dw 0x3fff ; erased               ; 197c: 3fff
    dw 0x3fff ; erased               ; 197d: 3fff
    dw 0x3fff ; erased               ; 197e: 3fff
    dw 0x3fff ; erased               ; 197f: 3fff
    dw 0x3fff ; erased               ; 1980: 3fff
    dw 0x3fff ; erased               ; 1981: 3fff
    dw 0x3fff ; erased               ; 1982: 3fff
    dw 0x3fff ; erased               ; 1983: 3fff
    dw 0x3fff ; erased               ; 1984: 3fff
    dw 0x3fff ; erased               ; 1985: 3fff
    dw 0x3fff ; erased               ; 1986: 3fff
    dw 0x3fff ; erased               ; 1987: 3fff
    dw 0x3fff ; erased               ; 1988: 3fff
    dw 0x3fff ; erased               ; 1989: 3fff
    dw 0x3fff ; erased               ; 198a: 3fff
    dw 0x3fff ; erased               ; 198b: 3fff
    dw 0x3fff ; erased               ; 198c: 3fff
    dw 0x3fff ; erased               ; 198d: 3fff
    dw 0x3fff ; erased               ; 198e: 3fff
    dw 0x3fff ; erased               ; 198f: 3fff
    dw 0x3fff ; erased               ; 1990: 3fff
    dw 0x3fff ; erased               ; 1991: 3fff
    dw 0x3fff ; erased               ; 1992: 3fff
    dw 0x3fff ; erased               ; 1993: 3fff
    dw 0x3fff ; erased               ; 1994: 3fff
    dw 0x3fff ; erased               ; 1995: 3fff
    dw 0x3fff ; erased               ; 1996: 3fff
    dw 0x3fff ; erased               ; 1997: 3fff
    dw 0x3fff ; erased               ; 1998: 3fff
    dw 0x3fff ; erased               ; 1999: 3fff
    dw 0x3fff ; erased               ; 199a: 3fff
    dw 0x3fff ; erased               ; 199b: 3fff
    dw 0x3fff ; erased               ; 199c: 3fff
    dw 0x3fff ; erased               ; 199d: 3fff
    dw 0x3fff ; erased               ; 199e: 3fff
    dw 0x3fff ; erased               ; 199f: 3fff
    dw 0x3fff ; erased               ; 19a0: 3fff
    dw 0x3fff ; erased               ; 19a1: 3fff
    dw 0x3fff ; erased               ; 19a2: 3fff
    dw 0x3fff ; erased               ; 19a3: 3fff
    dw 0x3fff ; erased               ; 19a4: 3fff
    dw 0x3fff ; erased               ; 19a5: 3fff
    dw 0x3fff ; erased               ; 19a6: 3fff
    dw 0x3fff ; erased               ; 19a7: 3fff
    dw 0x3fff ; erased               ; 19a8: 3fff
    dw 0x3fff ; erased               ; 19a9: 3fff
    dw 0x3fff ; erased               ; 19aa: 3fff
    dw 0x3fff ; erased               ; 19ab: 3fff
    dw 0x3fff ; erased               ; 19ac: 3fff
    dw 0x3fff ; erased               ; 19ad: 3fff
    dw 0x3fff ; erased               ; 19ae: 3fff
    dw 0x3fff ; erased               ; 19af: 3fff
    dw 0x3fff ; erased               ; 19b0: 3fff
    dw 0x3fff ; erased               ; 19b1: 3fff
    dw 0x3fff ; erased               ; 19b2: 3fff
    dw 0x3fff ; erased               ; 19b3: 3fff
    dw 0x3fff ; erased               ; 19b4: 3fff
    dw 0x3fff ; erased               ; 19b5: 3fff
    dw 0x3fff ; erased               ; 19b6: 3fff
    dw 0x3fff ; erased               ; 19b7: 3fff
    dw 0x3fff ; erased               ; 19b8: 3fff
    dw 0x3fff ; erased               ; 19b9: 3fff
    dw 0x3fff ; erased               ; 19ba: 3fff
    dw 0x3fff ; erased               ; 19bb: 3fff
    dw 0x3fff ; erased               ; 19bc: 3fff
    dw 0x3fff ; erased               ; 19bd: 3fff
    dw 0x3fff ; erased               ; 19be: 3fff
    dw 0x3fff ; erased               ; 19bf: 3fff
    dw 0x3fff ; erased               ; 19c0: 3fff
    dw 0x3fff ; erased               ; 19c1: 3fff
    dw 0x3fff ; erased               ; 19c2: 3fff
    dw 0x3fff ; erased               ; 19c3: 3fff
    dw 0x3fff ; erased               ; 19c4: 3fff
    dw 0x3fff ; erased               ; 19c5: 3fff
    dw 0x3fff ; erased               ; 19c6: 3fff
    dw 0x3fff ; erased               ; 19c7: 3fff
    dw 0x3fff ; erased               ; 19c8: 3fff
    dw 0x3fff ; erased               ; 19c9: 3fff
    dw 0x3fff ; erased               ; 19ca: 3fff
    dw 0x3fff ; erased               ; 19cb: 3fff
    dw 0x3fff ; erased               ; 19cc: 3fff
    dw 0x3fff ; erased               ; 19cd: 3fff
    dw 0x3fff ; erased               ; 19ce: 3fff
    dw 0x3fff ; erased               ; 19cf: 3fff
    dw 0x3fff ; erased               ; 19d0: 3fff
    dw 0x3fff ; erased               ; 19d1: 3fff
    dw 0x3fff ; erased               ; 19d2: 3fff
    dw 0x3fff ; erased               ; 19d3: 3fff
    dw 0x3fff ; erased               ; 19d4: 3fff
    dw 0x3fff ; erased               ; 19d5: 3fff
    dw 0x3fff ; erased               ; 19d6: 3fff
    dw 0x3fff ; erased               ; 19d7: 3fff
    dw 0x3fff ; erased               ; 19d8: 3fff
    dw 0x3fff ; erased               ; 19d9: 3fff
    dw 0x3fff ; erased               ; 19da: 3fff
    dw 0x3fff ; erased               ; 19db: 3fff
    dw 0x3fff ; erased               ; 19dc: 3fff
    dw 0x3fff ; erased               ; 19dd: 3fff
    dw 0x3fff ; erased               ; 19de: 3fff
    dw 0x3fff ; erased               ; 19df: 3fff
    dw 0x3fff ; erased               ; 19e0: 3fff
    dw 0x3fff ; erased               ; 19e1: 3fff
    dw 0x3fff ; erased               ; 19e2: 3fff
    dw 0x3fff ; erased               ; 19e3: 3fff
    dw 0x3fff ; erased               ; 19e4: 3fff
    dw 0x3fff ; erased               ; 19e5: 3fff
    dw 0x3fff ; erased               ; 19e6: 3fff
    dw 0x3fff ; erased               ; 19e7: 3fff
    dw 0x3fff ; erased               ; 19e8: 3fff
    dw 0x3fff ; erased               ; 19e9: 3fff
    dw 0x3fff ; erased               ; 19ea: 3fff
    dw 0x3fff ; erased               ; 19eb: 3fff
    dw 0x3fff ; erased               ; 19ec: 3fff
    dw 0x3fff ; erased               ; 19ed: 3fff
    dw 0x3fff ; erased               ; 19ee: 3fff
    dw 0x3fff ; erased               ; 19ef: 3fff
    dw 0x3fff ; erased               ; 19f0: 3fff
    dw 0x3fff ; erased               ; 19f1: 3fff
    dw 0x3fff ; erased               ; 19f2: 3fff
    dw 0x3fff ; erased               ; 19f3: 3fff
    dw 0x3fff ; erased               ; 19f4: 3fff
    dw 0x3fff ; erased               ; 19f5: 3fff
    dw 0x3fff ; erased               ; 19f6: 3fff
    dw 0x3fff ; erased               ; 19f7: 3fff
    dw 0x3fff ; erased               ; 19f8: 3fff
    dw 0x3fff ; erased               ; 19f9: 3fff
    dw 0x3fff ; erased               ; 19fa: 3fff
    dw 0x3fff ; erased               ; 19fb: 3fff
    dw 0x3fff ; erased               ; 19fc: 3fff
    dw 0x3fff ; erased               ; 19fd: 3fff
    dw 0x3fff ; erased               ; 19fe: 3fff
    dw 0x3fff ; erased               ; 19ff: 3fff
    dw 0x3fff ; erased               ; 1a00: 3fff
    dw 0x3fff ; erased               ; 1a01: 3fff
    dw 0x3fff ; erased               ; 1a02: 3fff
    dw 0x3fff ; erased               ; 1a03: 3fff
    dw 0x3fff ; erased               ; 1a04: 3fff
    dw 0x3fff ; erased               ; 1a05: 3fff
    dw 0x3fff ; erased               ; 1a06: 3fff
    dw 0x3fff ; erased               ; 1a07: 3fff
    dw 0x3fff ; erased               ; 1a08: 3fff
    dw 0x3fff ; erased               ; 1a09: 3fff
    dw 0x3fff ; erased               ; 1a0a: 3fff
    dw 0x3fff ; erased               ; 1a0b: 3fff
    dw 0x3fff ; erased               ; 1a0c: 3fff
    dw 0x3fff ; erased               ; 1a0d: 3fff
    dw 0x3fff ; erased               ; 1a0e: 3fff
    dw 0x3fff ; erased               ; 1a0f: 3fff
    dw 0x3fff ; erased               ; 1a10: 3fff
    dw 0x3fff ; erased               ; 1a11: 3fff
    dw 0x3fff ; erased               ; 1a12: 3fff
    dw 0x3fff ; erased               ; 1a13: 3fff
    dw 0x3fff ; erased               ; 1a14: 3fff
    dw 0x3fff ; erased               ; 1a15: 3fff
    dw 0x3fff ; erased               ; 1a16: 3fff
    dw 0x3fff ; erased               ; 1a17: 3fff
    dw 0x3fff ; erased               ; 1a18: 3fff
    dw 0x3fff ; erased               ; 1a19: 3fff
    dw 0x3fff ; erased               ; 1a1a: 3fff
    dw 0x3fff ; erased               ; 1a1b: 3fff
    dw 0x3fff ; erased               ; 1a1c: 3fff
    dw 0x3fff ; erased               ; 1a1d: 3fff
    dw 0x3fff ; erased               ; 1a1e: 3fff
    dw 0x3fff ; erased               ; 1a1f: 3fff
    dw 0x3fff ; erased               ; 1a20: 3fff
    dw 0x3fff ; erased               ; 1a21: 3fff
    dw 0x3fff ; erased               ; 1a22: 3fff
    dw 0x3fff ; erased               ; 1a23: 3fff
    dw 0x3fff ; erased               ; 1a24: 3fff
    dw 0x3fff ; erased               ; 1a25: 3fff
    dw 0x3fff ; erased               ; 1a26: 3fff
    dw 0x3fff ; erased               ; 1a27: 3fff
    dw 0x3fff ; erased               ; 1a28: 3fff
    dw 0x3fff ; erased               ; 1a29: 3fff
    dw 0x3fff ; erased               ; 1a2a: 3fff
    dw 0x3fff ; erased               ; 1a2b: 3fff
    dw 0x3fff ; erased               ; 1a2c: 3fff
    dw 0x3fff ; erased               ; 1a2d: 3fff
    dw 0x3fff ; erased               ; 1a2e: 3fff
    dw 0x3fff ; erased               ; 1a2f: 3fff
    dw 0x3fff ; erased               ; 1a30: 3fff
    dw 0x3fff ; erased               ; 1a31: 3fff
    dw 0x3fff ; erased               ; 1a32: 3fff
    dw 0x3fff ; erased               ; 1a33: 3fff
    dw 0x3fff ; erased               ; 1a34: 3fff
    dw 0x3fff ; erased               ; 1a35: 3fff
    dw 0x3fff ; erased               ; 1a36: 3fff
    dw 0x3fff ; erased               ; 1a37: 3fff
    dw 0x3fff ; erased               ; 1a38: 3fff
    dw 0x3fff ; erased               ; 1a39: 3fff
    dw 0x3fff ; erased               ; 1a3a: 3fff
    dw 0x3fff ; erased               ; 1a3b: 3fff
    dw 0x3fff ; erased               ; 1a3c: 3fff
    dw 0x3fff ; erased               ; 1a3d: 3fff
    dw 0x3fff ; erased               ; 1a3e: 3fff
    dw 0x3fff ; erased               ; 1a3f: 3fff
    dw 0x3fff ; erased               ; 1a40: 3fff
    dw 0x3fff ; erased               ; 1a41: 3fff
    dw 0x3fff ; erased               ; 1a42: 3fff
    dw 0x3fff ; erased               ; 1a43: 3fff
    dw 0x3fff ; erased               ; 1a44: 3fff
    dw 0x3fff ; erased               ; 1a45: 3fff
    dw 0x3fff ; erased               ; 1a46: 3fff
    dw 0x3fff ; erased               ; 1a47: 3fff
    dw 0x3fff ; erased               ; 1a48: 3fff
    dw 0x3fff ; erased               ; 1a49: 3fff
    dw 0x3fff ; erased               ; 1a4a: 3fff
    dw 0x3fff ; erased               ; 1a4b: 3fff
    dw 0x3fff ; erased               ; 1a4c: 3fff
    dw 0x3fff ; erased               ; 1a4d: 3fff
    dw 0x3fff ; erased               ; 1a4e: 3fff
    dw 0x3fff ; erased               ; 1a4f: 3fff
    dw 0x3fff ; erased               ; 1a50: 3fff
    dw 0x3fff ; erased               ; 1a51: 3fff
    dw 0x3fff ; erased               ; 1a52: 3fff
    dw 0x3fff ; erased               ; 1a53: 3fff
    dw 0x3fff ; erased               ; 1a54: 3fff
    dw 0x3fff ; erased               ; 1a55: 3fff
    dw 0x3fff ; erased               ; 1a56: 3fff
    dw 0x3fff ; erased               ; 1a57: 3fff
    dw 0x3fff ; erased               ; 1a58: 3fff
    dw 0x3fff ; erased               ; 1a59: 3fff
    dw 0x3fff ; erased               ; 1a5a: 3fff
    dw 0x3fff ; erased               ; 1a5b: 3fff
    dw 0x3fff ; erased               ; 1a5c: 3fff
    dw 0x3fff ; erased               ; 1a5d: 3fff
    dw 0x3fff ; erased               ; 1a5e: 3fff
    dw 0x3fff ; erased               ; 1a5f: 3fff
    dw 0x3fff ; erased               ; 1a60: 3fff
    dw 0x3fff ; erased               ; 1a61: 3fff
    dw 0x3fff ; erased               ; 1a62: 3fff
    dw 0x3fff ; erased               ; 1a63: 3fff
    dw 0x3fff ; erased               ; 1a64: 3fff
    dw 0x3fff ; erased               ; 1a65: 3fff
    dw 0x3fff ; erased               ; 1a66: 3fff
    dw 0x3fff ; erased               ; 1a67: 3fff
    dw 0x3fff ; erased               ; 1a68: 3fff
    dw 0x3fff ; erased               ; 1a69: 3fff
    dw 0x3fff ; erased               ; 1a6a: 3fff
    dw 0x3fff ; erased               ; 1a6b: 3fff
    dw 0x3fff ; erased               ; 1a6c: 3fff
    dw 0x3fff ; erased               ; 1a6d: 3fff
    dw 0x3fff ; erased               ; 1a6e: 3fff
    dw 0x3fff ; erased               ; 1a6f: 3fff
    dw 0x3fff ; erased               ; 1a70: 3fff
    dw 0x3fff ; erased               ; 1a71: 3fff
    dw 0x3fff ; erased               ; 1a72: 3fff
    dw 0x3fff ; erased               ; 1a73: 3fff
    dw 0x3fff ; erased               ; 1a74: 3fff
    dw 0x3fff ; erased               ; 1a75: 3fff
    dw 0x3fff ; erased               ; 1a76: 3fff
    dw 0x3fff ; erased               ; 1a77: 3fff
    dw 0x3fff ; erased               ; 1a78: 3fff
    dw 0x3fff ; erased               ; 1a79: 3fff
    dw 0x3fff ; erased               ; 1a7a: 3fff
    dw 0x3fff ; erased               ; 1a7b: 3fff
    dw 0x3fff ; erased               ; 1a7c: 3fff
    dw 0x3fff ; erased               ; 1a7d: 3fff
    dw 0x3fff ; erased               ; 1a7e: 3fff
    dw 0x3fff ; erased               ; 1a7f: 3fff
    dw 0x3fff ; erased               ; 1a80: 3fff
    dw 0x3fff ; erased               ; 1a81: 3fff
    dw 0x3fff ; erased               ; 1a82: 3fff
    dw 0x3fff ; erased               ; 1a83: 3fff
    dw 0x3fff ; erased               ; 1a84: 3fff
    dw 0x3fff ; erased               ; 1a85: 3fff
    dw 0x3fff ; erased               ; 1a86: 3fff
    dw 0x3fff ; erased               ; 1a87: 3fff
    dw 0x3fff ; erased               ; 1a88: 3fff
    dw 0x3fff ; erased               ; 1a89: 3fff
    dw 0x3fff ; erased               ; 1a8a: 3fff
    dw 0x3fff ; erased               ; 1a8b: 3fff
    dw 0x3fff ; erased               ; 1a8c: 3fff
    dw 0x3fff ; erased               ; 1a8d: 3fff
    dw 0x3fff ; erased               ; 1a8e: 3fff
    dw 0x3fff ; erased               ; 1a8f: 3fff
    dw 0x3fff ; erased               ; 1a90: 3fff
    dw 0x3fff ; erased               ; 1a91: 3fff
    dw 0x3fff ; erased               ; 1a92: 3fff
    dw 0x3fff ; erased               ; 1a93: 3fff
    dw 0x3fff ; erased               ; 1a94: 3fff
    dw 0x3fff ; erased               ; 1a95: 3fff
    dw 0x3fff ; erased               ; 1a96: 3fff
    dw 0x3fff ; erased               ; 1a97: 3fff
    dw 0x3fff ; erased               ; 1a98: 3fff
    dw 0x3fff ; erased               ; 1a99: 3fff
    dw 0x3fff ; erased               ; 1a9a: 3fff
    dw 0x3fff ; erased               ; 1a9b: 3fff
    dw 0x3fff ; erased               ; 1a9c: 3fff
    dw 0x3fff ; erased               ; 1a9d: 3fff
    dw 0x3fff ; erased               ; 1a9e: 3fff
    dw 0x3fff ; erased               ; 1a9f: 3fff
    dw 0x3fff ; erased               ; 1aa0: 3fff
    dw 0x3fff ; erased               ; 1aa1: 3fff
    dw 0x3fff ; erased               ; 1aa2: 3fff
    dw 0x3fff ; erased               ; 1aa3: 3fff
    dw 0x3fff ; erased               ; 1aa4: 3fff
    dw 0x3fff ; erased               ; 1aa5: 3fff
    dw 0x3fff ; erased               ; 1aa6: 3fff
    dw 0x3fff ; erased               ; 1aa7: 3fff
    dw 0x3fff ; erased               ; 1aa8: 3fff
    dw 0x3fff ; erased               ; 1aa9: 3fff
    dw 0x3fff ; erased               ; 1aaa: 3fff
    dw 0x3fff ; erased               ; 1aab: 3fff
    dw 0x3fff ; erased               ; 1aac: 3fff
    dw 0x3fff ; erased               ; 1aad: 3fff
    dw 0x3fff ; erased               ; 1aae: 3fff
    dw 0x3fff ; erased               ; 1aaf: 3fff
    dw 0x3fff ; erased               ; 1ab0: 3fff
    dw 0x3fff ; erased               ; 1ab1: 3fff
    dw 0x3fff ; erased               ; 1ab2: 3fff
    dw 0x3fff ; erased               ; 1ab3: 3fff
    dw 0x3fff ; erased               ; 1ab4: 3fff
    dw 0x3fff ; erased               ; 1ab5: 3fff
    dw 0x3fff ; erased               ; 1ab6: 3fff
    dw 0x3fff ; erased               ; 1ab7: 3fff
    dw 0x3fff ; erased               ; 1ab8: 3fff
    dw 0x3fff ; erased               ; 1ab9: 3fff
    dw 0x3fff ; erased               ; 1aba: 3fff
    dw 0x3fff ; erased               ; 1abb: 3fff
    dw 0x3fff ; erased               ; 1abc: 3fff
    dw 0x3fff ; erased               ; 1abd: 3fff
    dw 0x3fff ; erased               ; 1abe: 3fff
    dw 0x3fff ; erased               ; 1abf: 3fff
    dw 0x3fff ; erased               ; 1ac0: 3fff
    dw 0x3fff ; erased               ; 1ac1: 3fff
    dw 0x3fff ; erased               ; 1ac2: 3fff
    dw 0x3fff ; erased               ; 1ac3: 3fff
    dw 0x3fff ; erased               ; 1ac4: 3fff
    dw 0x3fff ; erased               ; 1ac5: 3fff
    dw 0x3fff ; erased               ; 1ac6: 3fff
    dw 0x3fff ; erased               ; 1ac7: 3fff
    dw 0x3fff ; erased               ; 1ac8: 3fff
    dw 0x3fff ; erased               ; 1ac9: 3fff
    dw 0x3fff ; erased               ; 1aca: 3fff
    dw 0x3fff ; erased               ; 1acb: 3fff
    dw 0x3fff ; erased               ; 1acc: 3fff
    dw 0x3fff ; erased               ; 1acd: 3fff
    dw 0x3fff ; erased               ; 1ace: 3fff
    dw 0x3fff ; erased               ; 1acf: 3fff
    dw 0x3fff ; erased               ; 1ad0: 3fff
    dw 0x3fff ; erased               ; 1ad1: 3fff
    dw 0x3fff ; erased               ; 1ad2: 3fff
    dw 0x3fff ; erased               ; 1ad3: 3fff
    dw 0x3fff ; erased               ; 1ad4: 3fff
    dw 0x3fff ; erased               ; 1ad5: 3fff
    dw 0x3fff ; erased               ; 1ad6: 3fff
    dw 0x3fff ; erased               ; 1ad7: 3fff
    dw 0x3fff ; erased               ; 1ad8: 3fff
    dw 0x3fff ; erased               ; 1ad9: 3fff
    dw 0x3fff ; erased               ; 1ada: 3fff
    dw 0x3fff ; erased               ; 1adb: 3fff
    dw 0x3fff ; erased               ; 1adc: 3fff
    dw 0x3fff ; erased               ; 1add: 3fff
    dw 0x3fff ; erased               ; 1ade: 3fff
    dw 0x3fff ; erased               ; 1adf: 3fff
    dw 0x3fff ; erased               ; 1ae0: 3fff
    dw 0x3fff ; erased               ; 1ae1: 3fff
    dw 0x3fff ; erased               ; 1ae2: 3fff
    dw 0x3fff ; erased               ; 1ae3: 3fff
    dw 0x3fff ; erased               ; 1ae4: 3fff
    dw 0x3fff ; erased               ; 1ae5: 3fff
    dw 0x3fff ; erased               ; 1ae6: 3fff
    dw 0x3fff ; erased               ; 1ae7: 3fff
    dw 0x3fff ; erased               ; 1ae8: 3fff
    dw 0x3fff ; erased               ; 1ae9: 3fff
    dw 0x3fff ; erased               ; 1aea: 3fff
    dw 0x3fff ; erased               ; 1aeb: 3fff
    dw 0x3fff ; erased               ; 1aec: 3fff
    dw 0x3fff ; erased               ; 1aed: 3fff
    dw 0x3fff ; erased               ; 1aee: 3fff
    dw 0x3fff ; erased               ; 1aef: 3fff
    dw 0x3fff ; erased               ; 1af0: 3fff
    dw 0x3fff ; erased               ; 1af1: 3fff
    dw 0x3fff ; erased               ; 1af2: 3fff
    dw 0x3fff ; erased               ; 1af3: 3fff
    dw 0x3fff ; erased               ; 1af4: 3fff
    dw 0x3fff ; erased               ; 1af5: 3fff
    dw 0x3fff ; erased               ; 1af6: 3fff
    dw 0x3fff ; erased               ; 1af7: 3fff
    dw 0x3fff ; erased               ; 1af8: 3fff
    dw 0x3fff ; erased               ; 1af9: 3fff
    dw 0x3fff ; erased               ; 1afa: 3fff
    dw 0x3fff ; erased               ; 1afb: 3fff
    dw 0x3fff ; erased               ; 1afc: 3fff
    dw 0x3fff ; erased               ; 1afd: 3fff
    dw 0x3fff ; erased               ; 1afe: 3fff
    dw 0x3fff ; erased               ; 1aff: 3fff
    dw 0x3fff ; erased               ; 1b00: 3fff
    dw 0x3fff ; erased               ; 1b01: 3fff
    dw 0x3fff ; erased               ; 1b02: 3fff
    dw 0x3fff ; erased               ; 1b03: 3fff
    dw 0x3fff ; erased               ; 1b04: 3fff
    dw 0x3fff ; erased               ; 1b05: 3fff
    dw 0x3fff ; erased               ; 1b06: 3fff
    dw 0x3fff ; erased               ; 1b07: 3fff
    dw 0x3fff ; erased               ; 1b08: 3fff
    dw 0x3fff ; erased               ; 1b09: 3fff
    dw 0x3fff ; erased               ; 1b0a: 3fff
    dw 0x3fff ; erased               ; 1b0b: 3fff
    dw 0x3fff ; erased               ; 1b0c: 3fff
    dw 0x3fff ; erased               ; 1b0d: 3fff
    dw 0x3fff ; erased               ; 1b0e: 3fff
    dw 0x3fff ; erased               ; 1b0f: 3fff
    dw 0x3fff ; erased               ; 1b10: 3fff
    dw 0x3fff ; erased               ; 1b11: 3fff
    dw 0x3fff ; erased               ; 1b12: 3fff
    dw 0x3fff ; erased               ; 1b13: 3fff
    dw 0x3fff ; erased               ; 1b14: 3fff
    dw 0x3fff ; erased               ; 1b15: 3fff
    dw 0x3fff ; erased               ; 1b16: 3fff
    dw 0x3fff ; erased               ; 1b17: 3fff
    dw 0x3fff ; erased               ; 1b18: 3fff
    dw 0x3fff ; erased               ; 1b19: 3fff
    dw 0x3fff ; erased               ; 1b1a: 3fff
    dw 0x3fff ; erased               ; 1b1b: 3fff
    dw 0x3fff ; erased               ; 1b1c: 3fff
    dw 0x3fff ; erased               ; 1b1d: 3fff
    dw 0x3fff ; erased               ; 1b1e: 3fff
    dw 0x3fff ; erased               ; 1b1f: 3fff
    dw 0x3fff ; erased               ; 1b20: 3fff
    dw 0x3fff ; erased               ; 1b21: 3fff
    dw 0x3fff ; erased               ; 1b22: 3fff
    dw 0x3fff ; erased               ; 1b23: 3fff
    dw 0x3fff ; erased               ; 1b24: 3fff
    dw 0x3fff ; erased               ; 1b25: 3fff
    dw 0x3fff ; erased               ; 1b26: 3fff
    dw 0x3fff ; erased               ; 1b27: 3fff
    dw 0x3fff ; erased               ; 1b28: 3fff
    dw 0x3fff ; erased               ; 1b29: 3fff
    dw 0x3fff ; erased               ; 1b2a: 3fff
    dw 0x3fff ; erased               ; 1b2b: 3fff
    dw 0x3fff ; erased               ; 1b2c: 3fff
    dw 0x3fff ; erased               ; 1b2d: 3fff
    dw 0x3fff ; erased               ; 1b2e: 3fff
    dw 0x3fff ; erased               ; 1b2f: 3fff
    dw 0x3fff ; erased               ; 1b30: 3fff
    dw 0x3fff ; erased               ; 1b31: 3fff
    dw 0x3fff ; erased               ; 1b32: 3fff
    dw 0x3fff ; erased               ; 1b33: 3fff
    dw 0x3fff ; erased               ; 1b34: 3fff
    dw 0x3fff ; erased               ; 1b35: 3fff
    dw 0x3fff ; erased               ; 1b36: 3fff
    dw 0x3fff ; erased               ; 1b37: 3fff
    dw 0x3fff ; erased               ; 1b38: 3fff
    dw 0x3fff ; erased               ; 1b39: 3fff
    dw 0x3fff ; erased               ; 1b3a: 3fff
    dw 0x3fff ; erased               ; 1b3b: 3fff
    dw 0x3fff ; erased               ; 1b3c: 3fff
    dw 0x3fff ; erased               ; 1b3d: 3fff
    dw 0x3fff ; erased               ; 1b3e: 3fff
    dw 0x3fff ; erased               ; 1b3f: 3fff
    dw 0x3fff ; erased               ; 1b40: 3fff
    dw 0x3fff ; erased               ; 1b41: 3fff
    dw 0x3fff ; erased               ; 1b42: 3fff
    dw 0x3fff ; erased               ; 1b43: 3fff
    dw 0x3fff ; erased               ; 1b44: 3fff
    dw 0x3fff ; erased               ; 1b45: 3fff
    dw 0x3fff ; erased               ; 1b46: 3fff
    dw 0x3fff ; erased               ; 1b47: 3fff
    dw 0x3fff ; erased               ; 1b48: 3fff
    dw 0x3fff ; erased               ; 1b49: 3fff
    dw 0x3fff ; erased               ; 1b4a: 3fff
    dw 0x3fff ; erased               ; 1b4b: 3fff
    dw 0x3fff ; erased               ; 1b4c: 3fff
    dw 0x3fff ; erased               ; 1b4d: 3fff
    dw 0x3fff ; erased               ; 1b4e: 3fff
    dw 0x3fff ; erased               ; 1b4f: 3fff
    dw 0x3fff ; erased               ; 1b50: 3fff
    dw 0x3fff ; erased               ; 1b51: 3fff
    dw 0x3fff ; erased               ; 1b52: 3fff
    dw 0x3fff ; erased               ; 1b53: 3fff
    dw 0x3fff ; erased               ; 1b54: 3fff
    dw 0x3fff ; erased               ; 1b55: 3fff
    dw 0x3fff ; erased               ; 1b56: 3fff
    dw 0x3fff ; erased               ; 1b57: 3fff
    dw 0x3fff ; erased               ; 1b58: 3fff
    dw 0x3fff ; erased               ; 1b59: 3fff
    dw 0x3fff ; erased               ; 1b5a: 3fff
    dw 0x3fff ; erased               ; 1b5b: 3fff
    dw 0x3fff ; erased               ; 1b5c: 3fff
    dw 0x3fff ; erased               ; 1b5d: 3fff
    dw 0x3fff ; erased               ; 1b5e: 3fff
    dw 0x3fff ; erased               ; 1b5f: 3fff
    dw 0x3fff ; erased               ; 1b60: 3fff
    dw 0x3fff ; erased               ; 1b61: 3fff
    dw 0x3fff ; erased               ; 1b62: 3fff
    dw 0x3fff ; erased               ; 1b63: 3fff
    dw 0x3fff ; erased               ; 1b64: 3fff
    dw 0x3fff ; erased               ; 1b65: 3fff
    dw 0x3fff ; erased               ; 1b66: 3fff
    dw 0x3fff ; erased               ; 1b67: 3fff
    dw 0x3fff ; erased               ; 1b68: 3fff
    dw 0x3fff ; erased               ; 1b69: 3fff
    dw 0x3fff ; erased               ; 1b6a: 3fff
    dw 0x3fff ; erased               ; 1b6b: 3fff
    dw 0x3fff ; erased               ; 1b6c: 3fff
    dw 0x3fff ; erased               ; 1b6d: 3fff
    dw 0x3fff ; erased               ; 1b6e: 3fff
    dw 0x3fff ; erased               ; 1b6f: 3fff
    dw 0x3fff ; erased               ; 1b70: 3fff
    dw 0x3fff ; erased               ; 1b71: 3fff
    dw 0x3fff ; erased               ; 1b72: 3fff
    dw 0x3fff ; erased               ; 1b73: 3fff
    dw 0x3fff ; erased               ; 1b74: 3fff
    dw 0x3fff ; erased               ; 1b75: 3fff
    dw 0x3fff ; erased               ; 1b76: 3fff
    dw 0x3fff ; erased               ; 1b77: 3fff
    dw 0x3fff ; erased               ; 1b78: 3fff
    dw 0x3fff ; erased               ; 1b79: 3fff
    dw 0x3fff ; erased               ; 1b7a: 3fff
    dw 0x3fff ; erased               ; 1b7b: 3fff
    dw 0x3fff ; erased               ; 1b7c: 3fff
    dw 0x3fff ; erased               ; 1b7d: 3fff
    dw 0x3fff ; erased               ; 1b7e: 3fff
    dw 0x3fff ; erased               ; 1b7f: 3fff
    dw 0x3fff ; erased               ; 1b80: 3fff
    dw 0x3fff ; erased               ; 1b81: 3fff
    dw 0x3fff ; erased               ; 1b82: 3fff
    dw 0x3fff ; erased               ; 1b83: 3fff
    dw 0x3fff ; erased               ; 1b84: 3fff
    dw 0x3fff ; erased               ; 1b85: 3fff
    dw 0x3fff ; erased               ; 1b86: 3fff
    dw 0x3fff ; erased               ; 1b87: 3fff
    dw 0x3fff ; erased               ; 1b88: 3fff
    dw 0x3fff ; erased               ; 1b89: 3fff
    dw 0x3fff ; erased               ; 1b8a: 3fff
    dw 0x3fff ; erased               ; 1b8b: 3fff
    dw 0x3fff ; erased               ; 1b8c: 3fff
    dw 0x3fff ; erased               ; 1b8d: 3fff
    dw 0x3fff ; erased               ; 1b8e: 3fff
    dw 0x3fff ; erased               ; 1b8f: 3fff
    dw 0x3fff ; erased               ; 1b90: 3fff
    dw 0x3fff ; erased               ; 1b91: 3fff
    dw 0x3fff ; erased               ; 1b92: 3fff
    dw 0x3fff ; erased               ; 1b93: 3fff
    dw 0x3fff ; erased               ; 1b94: 3fff
    dw 0x3fff ; erased               ; 1b95: 3fff
    dw 0x3fff ; erased               ; 1b96: 3fff
    dw 0x3fff ; erased               ; 1b97: 3fff
    dw 0x3fff ; erased               ; 1b98: 3fff
    dw 0x3fff ; erased               ; 1b99: 3fff
    dw 0x3fff ; erased               ; 1b9a: 3fff
    dw 0x3fff ; erased               ; 1b9b: 3fff
    dw 0x3fff ; erased               ; 1b9c: 3fff
    dw 0x3fff ; erased               ; 1b9d: 3fff
    dw 0x3fff ; erased               ; 1b9e: 3fff
    dw 0x3fff ; erased               ; 1b9f: 3fff
    dw 0x3fff ; erased               ; 1ba0: 3fff
    dw 0x3fff ; erased               ; 1ba1: 3fff
    dw 0x3fff ; erased               ; 1ba2: 3fff
    dw 0x3fff ; erased               ; 1ba3: 3fff
    dw 0x3fff ; erased               ; 1ba4: 3fff
    dw 0x3fff ; erased               ; 1ba5: 3fff
    dw 0x3fff ; erased               ; 1ba6: 3fff
    dw 0x3fff ; erased               ; 1ba7: 3fff
    dw 0x3fff ; erased               ; 1ba8: 3fff
    dw 0x3fff ; erased               ; 1ba9: 3fff
    dw 0x3fff ; erased               ; 1baa: 3fff
    dw 0x3fff ; erased               ; 1bab: 3fff
    dw 0x3fff ; erased               ; 1bac: 3fff
    dw 0x3fff ; erased               ; 1bad: 3fff
    dw 0x3fff ; erased               ; 1bae: 3fff
    dw 0x3fff ; erased               ; 1baf: 3fff
    dw 0x3fff ; erased               ; 1bb0: 3fff
    dw 0x3fff ; erased               ; 1bb1: 3fff
    dw 0x3fff ; erased               ; 1bb2: 3fff
    dw 0x3fff ; erased               ; 1bb3: 3fff
    dw 0x3fff ; erased               ; 1bb4: 3fff
    dw 0x3fff ; erased               ; 1bb5: 3fff
    dw 0x3fff ; erased               ; 1bb6: 3fff
    dw 0x3fff ; erased               ; 1bb7: 3fff
    dw 0x3fff ; erased               ; 1bb8: 3fff
    dw 0x3fff ; erased               ; 1bb9: 3fff
    dw 0x3fff ; erased               ; 1bba: 3fff
    dw 0x3fff ; erased               ; 1bbb: 3fff
    dw 0x3fff ; erased               ; 1bbc: 3fff
    dw 0x3fff ; erased               ; 1bbd: 3fff
    dw 0x3fff ; erased               ; 1bbe: 3fff
    dw 0x3fff ; erased               ; 1bbf: 3fff
    dw 0x3fff ; erased               ; 1bc0: 3fff
    dw 0x3fff ; erased               ; 1bc1: 3fff
    dw 0x3fff ; erased               ; 1bc2: 3fff
    dw 0x3fff ; erased               ; 1bc3: 3fff
    dw 0x3fff ; erased               ; 1bc4: 3fff
    dw 0x3fff ; erased               ; 1bc5: 3fff
    dw 0x3fff ; erased               ; 1bc6: 3fff
    dw 0x3fff ; erased               ; 1bc7: 3fff
    dw 0x3fff ; erased               ; 1bc8: 3fff
    dw 0x3fff ; erased               ; 1bc9: 3fff
    dw 0x3fff ; erased               ; 1bca: 3fff
    dw 0x3fff ; erased               ; 1bcb: 3fff
    dw 0x3fff ; erased               ; 1bcc: 3fff
    dw 0x3fff ; erased               ; 1bcd: 3fff
    dw 0x3fff ; erased               ; 1bce: 3fff
    dw 0x3fff ; erased               ; 1bcf: 3fff
    dw 0x3fff ; erased               ; 1bd0: 3fff
    dw 0x3fff ; erased               ; 1bd1: 3fff
    dw 0x3fff ; erased               ; 1bd2: 3fff
    dw 0x3fff ; erased               ; 1bd3: 3fff
    dw 0x3fff ; erased               ; 1bd4: 3fff
    dw 0x3fff ; erased               ; 1bd5: 3fff
    dw 0x3fff ; erased               ; 1bd6: 3fff
    dw 0x3fff ; erased               ; 1bd7: 3fff
    dw 0x3fff ; erased               ; 1bd8: 3fff
    dw 0x3fff ; erased               ; 1bd9: 3fff
    dw 0x3fff ; erased               ; 1bda: 3fff
    dw 0x3fff ; erased               ; 1bdb: 3fff
    dw 0x3fff ; erased               ; 1bdc: 3fff
    dw 0x3fff ; erased               ; 1bdd: 3fff
    dw 0x3fff ; erased               ; 1bde: 3fff
    dw 0x3fff ; erased               ; 1bdf: 3fff
    dw 0x3fff ; erased               ; 1be0: 3fff
    dw 0x3fff ; erased               ; 1be1: 3fff
    dw 0x3fff ; erased               ; 1be2: 3fff
    dw 0x3fff ; erased               ; 1be3: 3fff
    dw 0x3fff ; erased               ; 1be4: 3fff
    dw 0x3fff ; erased               ; 1be5: 3fff
    dw 0x3fff ; erased               ; 1be6: 3fff
    dw 0x3fff ; erased               ; 1be7: 3fff
    dw 0x3fff ; erased               ; 1be8: 3fff
    dw 0x3fff ; erased               ; 1be9: 3fff
    dw 0x3fff ; erased               ; 1bea: 3fff
    dw 0x3fff ; erased               ; 1beb: 3fff
    dw 0x3fff ; erased               ; 1bec: 3fff
    dw 0x3fff ; erased               ; 1bed: 3fff
    dw 0x3fff ; erased               ; 1bee: 3fff
    dw 0x3fff ; erased               ; 1bef: 3fff
    dw 0x3fff ; erased               ; 1bf0: 3fff
    dw 0x3fff ; erased               ; 1bf1: 3fff
    dw 0x3fff ; erased               ; 1bf2: 3fff
    dw 0x3fff ; erased               ; 1bf3: 3fff
    dw 0x3fff ; erased               ; 1bf4: 3fff
    dw 0x3fff ; erased               ; 1bf5: 3fff
    dw 0x3fff ; erased               ; 1bf6: 3fff
    dw 0x3fff ; erased               ; 1bf7: 3fff
    dw 0x3fff ; erased               ; 1bf8: 3fff
    dw 0x3fff ; erased               ; 1bf9: 3fff
    dw 0x3fff ; erased               ; 1bfa: 3fff
    dw 0x3fff ; erased               ; 1bfb: 3fff
    dw 0x3fff ; erased               ; 1bfc: 3fff
    dw 0x3fff ; erased               ; 1bfd: 3fff
    dw 0x3fff ; erased               ; 1bfe: 3fff
    dw 0x3fff ; erased               ; 1bff: 3fff
    dw 0x3fff ; erased               ; 1c00: 3fff
    dw 0x3fff ; erased               ; 1c01: 3fff
    dw 0x3fff ; erased               ; 1c02: 3fff
    dw 0x3fff ; erased               ; 1c03: 3fff
    dw 0x3fff ; erased               ; 1c04: 3fff
    dw 0x3fff ; erased               ; 1c05: 3fff
    dw 0x3fff ; erased               ; 1c06: 3fff
    dw 0x3fff ; erased               ; 1c07: 3fff
    dw 0x3fff ; erased               ; 1c08: 3fff
    dw 0x3fff ; erased               ; 1c09: 3fff
    dw 0x3fff ; erased               ; 1c0a: 3fff
    dw 0x3fff ; erased               ; 1c0b: 3fff
    dw 0x3fff ; erased               ; 1c0c: 3fff
    dw 0x3fff ; erased               ; 1c0d: 3fff
    dw 0x3fff ; erased               ; 1c0e: 3fff
    dw 0x3fff ; erased               ; 1c0f: 3fff
    dw 0x3fff ; erased               ; 1c10: 3fff
    dw 0x3fff ; erased               ; 1c11: 3fff
    dw 0x3fff ; erased               ; 1c12: 3fff
    dw 0x3fff ; erased               ; 1c13: 3fff
    dw 0x3fff ; erased               ; 1c14: 3fff
    dw 0x3fff ; erased               ; 1c15: 3fff
    dw 0x3fff ; erased               ; 1c16: 3fff
    dw 0x3fff ; erased               ; 1c17: 3fff
    dw 0x3fff ; erased               ; 1c18: 3fff
    dw 0x3fff ; erased               ; 1c19: 3fff
    dw 0x3fff ; erased               ; 1c1a: 3fff
    dw 0x3fff ; erased               ; 1c1b: 3fff
    dw 0x3fff ; erased               ; 1c1c: 3fff
    dw 0x3fff ; erased               ; 1c1d: 3fff
    dw 0x3fff ; erased               ; 1c1e: 3fff
    dw 0x3fff ; erased               ; 1c1f: 3fff
    dw 0x3fff ; erased               ; 1c20: 3fff
    dw 0x3fff ; erased               ; 1c21: 3fff
    dw 0x3fff ; erased               ; 1c22: 3fff
    dw 0x3fff ; erased               ; 1c23: 3fff
    dw 0x3fff ; erased               ; 1c24: 3fff
    dw 0x3fff ; erased               ; 1c25: 3fff
    dw 0x3fff ; erased               ; 1c26: 3fff
    dw 0x3fff ; erased               ; 1c27: 3fff
    dw 0x3fff ; erased               ; 1c28: 3fff
    dw 0x3fff ; erased               ; 1c29: 3fff
    dw 0x3fff ; erased               ; 1c2a: 3fff
    dw 0x3fff ; erased               ; 1c2b: 3fff
    dw 0x3fff ; erased               ; 1c2c: 3fff
    dw 0x3fff ; erased               ; 1c2d: 3fff
    dw 0x3fff ; erased               ; 1c2e: 3fff
    dw 0x3fff ; erased               ; 1c2f: 3fff
    dw 0x3fff ; erased               ; 1c30: 3fff
    dw 0x3fff ; erased               ; 1c31: 3fff
    dw 0x3fff ; erased               ; 1c32: 3fff
    dw 0x3fff ; erased               ; 1c33: 3fff
    dw 0x3fff ; erased               ; 1c34: 3fff
    dw 0x3fff ; erased               ; 1c35: 3fff
    dw 0x3fff ; erased               ; 1c36: 3fff
    dw 0x3fff ; erased               ; 1c37: 3fff
    dw 0x3fff ; erased               ; 1c38: 3fff
    dw 0x3fff ; erased               ; 1c39: 3fff
    dw 0x3fff ; erased               ; 1c3a: 3fff
    dw 0x3fff ; erased               ; 1c3b: 3fff
    dw 0x3fff ; erased               ; 1c3c: 3fff
    dw 0x3fff ; erased               ; 1c3d: 3fff
    dw 0x3fff ; erased               ; 1c3e: 3fff
    dw 0x3fff ; erased               ; 1c3f: 3fff
    dw 0x3fff ; erased               ; 1c40: 3fff
    dw 0x3fff ; erased               ; 1c41: 3fff
    dw 0x3fff ; erased               ; 1c42: 3fff
    dw 0x3fff ; erased               ; 1c43: 3fff
    dw 0x3fff ; erased               ; 1c44: 3fff
    dw 0x3fff ; erased               ; 1c45: 3fff
    dw 0x3fff ; erased               ; 1c46: 3fff
    dw 0x3fff ; erased               ; 1c47: 3fff
    dw 0x3fff ; erased               ; 1c48: 3fff
    dw 0x3fff ; erased               ; 1c49: 3fff
    dw 0x3fff ; erased               ; 1c4a: 3fff
    dw 0x3fff ; erased               ; 1c4b: 3fff
    dw 0x3fff ; erased               ; 1c4c: 3fff
    dw 0x3fff ; erased               ; 1c4d: 3fff
    dw 0x3fff ; erased               ; 1c4e: 3fff
    dw 0x3fff ; erased               ; 1c4f: 3fff
    dw 0x3fff ; erased               ; 1c50: 3fff
    dw 0x3fff ; erased               ; 1c51: 3fff
    dw 0x3fff ; erased               ; 1c52: 3fff
    dw 0x3fff ; erased               ; 1c53: 3fff
    dw 0x3fff ; erased               ; 1c54: 3fff
    dw 0x3fff ; erased               ; 1c55: 3fff
    dw 0x3fff ; erased               ; 1c56: 3fff
    dw 0x3fff ; erased               ; 1c57: 3fff
    dw 0x3fff ; erased               ; 1c58: 3fff
    dw 0x3fff ; erased               ; 1c59: 3fff
    dw 0x3fff ; erased               ; 1c5a: 3fff
    dw 0x3fff ; erased               ; 1c5b: 3fff
    dw 0x3fff ; erased               ; 1c5c: 3fff
    dw 0x3fff ; erased               ; 1c5d: 3fff
    dw 0x3fff ; erased               ; 1c5e: 3fff
    dw 0x3fff ; erased               ; 1c5f: 3fff
    dw 0x3fff ; erased               ; 1c60: 3fff
    dw 0x3fff ; erased               ; 1c61: 3fff
    dw 0x3fff ; erased               ; 1c62: 3fff
    dw 0x3fff ; erased               ; 1c63: 3fff
    dw 0x3fff ; erased               ; 1c64: 3fff
    dw 0x3fff ; erased               ; 1c65: 3fff
    dw 0x3fff ; erased               ; 1c66: 3fff
    dw 0x3fff ; erased               ; 1c67: 3fff
    dw 0x3fff ; erased               ; 1c68: 3fff
    dw 0x3fff ; erased               ; 1c69: 3fff
    dw 0x3fff ; erased               ; 1c6a: 3fff
    dw 0x3fff ; erased               ; 1c6b: 3fff
    dw 0x3fff ; erased               ; 1c6c: 3fff
    dw 0x3fff ; erased               ; 1c6d: 3fff
    dw 0x3fff ; erased               ; 1c6e: 3fff
    dw 0x3fff ; erased               ; 1c6f: 3fff
    dw 0x3fff ; erased               ; 1c70: 3fff
    dw 0x3fff ; erased               ; 1c71: 3fff
    dw 0x3fff ; erased               ; 1c72: 3fff
    dw 0x3fff ; erased               ; 1c73: 3fff
    dw 0x3fff ; erased               ; 1c74: 3fff
    dw 0x3fff ; erased               ; 1c75: 3fff
    dw 0x3fff ; erased               ; 1c76: 3fff
    dw 0x3fff ; erased               ; 1c77: 3fff
    dw 0x3fff ; erased               ; 1c78: 3fff
    dw 0x3fff ; erased               ; 1c79: 3fff
    dw 0x3fff ; erased               ; 1c7a: 3fff
    dw 0x3fff ; erased               ; 1c7b: 3fff
    dw 0x3fff ; erased               ; 1c7c: 3fff
    dw 0x3fff ; erased               ; 1c7d: 3fff
    dw 0x3fff ; erased               ; 1c7e: 3fff
    dw 0x3fff ; erased               ; 1c7f: 3fff
    dw 0x3fff ; erased               ; 1c80: 3fff
    dw 0x3fff ; erased               ; 1c81: 3fff
    dw 0x3fff ; erased               ; 1c82: 3fff
    dw 0x3fff ; erased               ; 1c83: 3fff
    dw 0x3fff ; erased               ; 1c84: 3fff
    dw 0x3fff ; erased               ; 1c85: 3fff
    dw 0x3fff ; erased               ; 1c86: 3fff
    dw 0x3fff ; erased               ; 1c87: 3fff
    dw 0x3fff ; erased               ; 1c88: 3fff
    dw 0x3fff ; erased               ; 1c89: 3fff
    dw 0x3fff ; erased               ; 1c8a: 3fff
    dw 0x3fff ; erased               ; 1c8b: 3fff
    dw 0x3fff ; erased               ; 1c8c: 3fff
    dw 0x3fff ; erased               ; 1c8d: 3fff
    dw 0x3fff ; erased               ; 1c8e: 3fff
    dw 0x3fff ; erased               ; 1c8f: 3fff
    dw 0x3fff ; erased               ; 1c90: 3fff
    dw 0x3fff ; erased               ; 1c91: 3fff
    dw 0x3fff ; erased               ; 1c92: 3fff
    dw 0x3fff ; erased               ; 1c93: 3fff
    dw 0x3fff ; erased               ; 1c94: 3fff
    dw 0x3fff ; erased               ; 1c95: 3fff
    dw 0x3fff ; erased               ; 1c96: 3fff
    dw 0x3fff ; erased               ; 1c97: 3fff
    dw 0x3fff ; erased               ; 1c98: 3fff
    dw 0x3fff ; erased               ; 1c99: 3fff
    dw 0x3fff ; erased               ; 1c9a: 3fff
    dw 0x3fff ; erased               ; 1c9b: 3fff
    dw 0x3fff ; erased               ; 1c9c: 3fff
    dw 0x3fff ; erased               ; 1c9d: 3fff
    dw 0x3fff ; erased               ; 1c9e: 3fff
    dw 0x3fff ; erased               ; 1c9f: 3fff
    dw 0x3fff ; erased               ; 1ca0: 3fff
    dw 0x3fff ; erased               ; 1ca1: 3fff
    dw 0x3fff ; erased               ; 1ca2: 3fff
    dw 0x3fff ; erased               ; 1ca3: 3fff
    dw 0x3fff ; erased               ; 1ca4: 3fff
    dw 0x3fff ; erased               ; 1ca5: 3fff
    dw 0x3fff ; erased               ; 1ca6: 3fff
    dw 0x3fff ; erased               ; 1ca7: 3fff
    dw 0x3fff ; erased               ; 1ca8: 3fff
    dw 0x3fff ; erased               ; 1ca9: 3fff
    dw 0x3fff ; erased               ; 1caa: 3fff
    dw 0x3fff ; erased               ; 1cab: 3fff
    dw 0x3fff ; erased               ; 1cac: 3fff
    dw 0x3fff ; erased               ; 1cad: 3fff
    dw 0x3fff ; erased               ; 1cae: 3fff
    dw 0x3fff ; erased               ; 1caf: 3fff
    dw 0x3fff ; erased               ; 1cb0: 3fff
    dw 0x3fff ; erased               ; 1cb1: 3fff
    dw 0x3fff ; erased               ; 1cb2: 3fff
    dw 0x3fff ; erased               ; 1cb3: 3fff
    dw 0x3fff ; erased               ; 1cb4: 3fff
    dw 0x3fff ; erased               ; 1cb5: 3fff
    dw 0x3fff ; erased               ; 1cb6: 3fff
    dw 0x3fff ; erased               ; 1cb7: 3fff
    dw 0x3fff ; erased               ; 1cb8: 3fff
    dw 0x3fff ; erased               ; 1cb9: 3fff
    dw 0x3fff ; erased               ; 1cba: 3fff
    dw 0x3fff ; erased               ; 1cbb: 3fff
    dw 0x3fff ; erased               ; 1cbc: 3fff
    dw 0x3fff ; erased               ; 1cbd: 3fff
    dw 0x3fff ; erased               ; 1cbe: 3fff
    dw 0x3fff ; erased               ; 1cbf: 3fff
    dw 0x3fff ; erased               ; 1cc0: 3fff
    dw 0x3fff ; erased               ; 1cc1: 3fff
    dw 0x3fff ; erased               ; 1cc2: 3fff
    dw 0x3fff ; erased               ; 1cc3: 3fff
    dw 0x3fff ; erased               ; 1cc4: 3fff
    dw 0x3fff ; erased               ; 1cc5: 3fff
    dw 0x3fff ; erased               ; 1cc6: 3fff
    dw 0x3fff ; erased               ; 1cc7: 3fff
    dw 0x3fff ; erased               ; 1cc8: 3fff
    dw 0x3fff ; erased               ; 1cc9: 3fff
    dw 0x3fff ; erased               ; 1cca: 3fff
    dw 0x3fff ; erased               ; 1ccb: 3fff
    dw 0x3fff ; erased               ; 1ccc: 3fff
    dw 0x3fff ; erased               ; 1ccd: 3fff
    dw 0x3fff ; erased               ; 1cce: 3fff
    dw 0x3fff ; erased               ; 1ccf: 3fff
    dw 0x3fff ; erased               ; 1cd0: 3fff
    dw 0x3fff ; erased               ; 1cd1: 3fff
    dw 0x3fff ; erased               ; 1cd2: 3fff
    dw 0x3fff ; erased               ; 1cd3: 3fff
    dw 0x3fff ; erased               ; 1cd4: 3fff
    dw 0x3fff ; erased               ; 1cd5: 3fff
    dw 0x3fff ; erased               ; 1cd6: 3fff
    dw 0x3fff ; erased               ; 1cd7: 3fff
    dw 0x3fff ; erased               ; 1cd8: 3fff
    dw 0x3fff ; erased               ; 1cd9: 3fff
    dw 0x3fff ; erased               ; 1cda: 3fff
    dw 0x3fff ; erased               ; 1cdb: 3fff
    dw 0x3fff ; erased               ; 1cdc: 3fff
    dw 0x3fff ; erased               ; 1cdd: 3fff
    dw 0x3fff ; erased               ; 1cde: 3fff
    dw 0x3fff ; erased               ; 1cdf: 3fff
    dw 0x3fff ; erased               ; 1ce0: 3fff
    dw 0x3fff ; erased               ; 1ce1: 3fff
    dw 0x3fff ; erased               ; 1ce2: 3fff
    dw 0x3fff ; erased               ; 1ce3: 3fff
    dw 0x3fff ; erased               ; 1ce4: 3fff
    dw 0x3fff ; erased               ; 1ce5: 3fff
    dw 0x3fff ; erased               ; 1ce6: 3fff
    dw 0x3fff ; erased               ; 1ce7: 3fff
    dw 0x3fff ; erased               ; 1ce8: 3fff
    dw 0x3fff ; erased               ; 1ce9: 3fff
    dw 0x3fff ; erased               ; 1cea: 3fff
    dw 0x3fff ; erased               ; 1ceb: 3fff
    dw 0x3fff ; erased               ; 1cec: 3fff
    dw 0x3fff ; erased               ; 1ced: 3fff
    dw 0x3fff ; erased               ; 1cee: 3fff
    dw 0x3fff ; erased               ; 1cef: 3fff
    dw 0x3fff ; erased               ; 1cf0: 3fff
    dw 0x3fff ; erased               ; 1cf1: 3fff
    dw 0x3fff ; erased               ; 1cf2: 3fff
    dw 0x3fff ; erased               ; 1cf3: 3fff
    dw 0x3fff ; erased               ; 1cf4: 3fff
    dw 0x3fff ; erased               ; 1cf5: 3fff
    dw 0x3fff ; erased               ; 1cf6: 3fff
    dw 0x3fff ; erased               ; 1cf7: 3fff
    dw 0x3fff ; erased               ; 1cf8: 3fff
    dw 0x3fff ; erased               ; 1cf9: 3fff
    dw 0x3fff ; erased               ; 1cfa: 3fff
    dw 0x3fff ; erased               ; 1cfb: 3fff
    dw 0x3fff ; erased               ; 1cfc: 3fff
    dw 0x3fff ; erased               ; 1cfd: 3fff
    dw 0x3fff ; erased               ; 1cfe: 3fff
    dw 0x3fff ; erased               ; 1cff: 3fff
    dw 0x3fff ; erased               ; 1d00: 3fff
    dw 0x3fff ; erased               ; 1d01: 3fff
    dw 0x3fff ; erased               ; 1d02: 3fff
    dw 0x3fff ; erased               ; 1d03: 3fff
    dw 0x3fff ; erased               ; 1d04: 3fff
    dw 0x3fff ; erased               ; 1d05: 3fff
    dw 0x3fff ; erased               ; 1d06: 3fff
    dw 0x3fff ; erased               ; 1d07: 3fff
    dw 0x3fff ; erased               ; 1d08: 3fff
    dw 0x3fff ; erased               ; 1d09: 3fff
    dw 0x3fff ; erased               ; 1d0a: 3fff
    dw 0x3fff ; erased               ; 1d0b: 3fff
    dw 0x3fff ; erased               ; 1d0c: 3fff
    dw 0x3fff ; erased               ; 1d0d: 3fff
    dw 0x3fff ; erased               ; 1d0e: 3fff
    dw 0x3fff ; erased               ; 1d0f: 3fff
    dw 0x3fff ; erased               ; 1d10: 3fff
    dw 0x3fff ; erased               ; 1d11: 3fff
    dw 0x3fff ; erased               ; 1d12: 3fff
    dw 0x3fff ; erased               ; 1d13: 3fff
    dw 0x3fff ; erased               ; 1d14: 3fff
    dw 0x3fff ; erased               ; 1d15: 3fff
    dw 0x3fff ; erased               ; 1d16: 3fff
    dw 0x3fff ; erased               ; 1d17: 3fff
    dw 0x3fff ; erased               ; 1d18: 3fff
    dw 0x3fff ; erased               ; 1d19: 3fff
    dw 0x3fff ; erased               ; 1d1a: 3fff
    dw 0x3fff ; erased               ; 1d1b: 3fff
    dw 0x3fff ; erased               ; 1d1c: 3fff
    dw 0x3fff ; erased               ; 1d1d: 3fff
    dw 0x3fff ; erased               ; 1d1e: 3fff
    dw 0x3fff ; erased               ; 1d1f: 3fff
    dw 0x3fff ; erased               ; 1d20: 3fff
    dw 0x3fff ; erased               ; 1d21: 3fff
    dw 0x3fff ; erased               ; 1d22: 3fff
    dw 0x3fff ; erased               ; 1d23: 3fff
    dw 0x3fff ; erased               ; 1d24: 3fff
    dw 0x3fff ; erased               ; 1d25: 3fff
    dw 0x3fff ; erased               ; 1d26: 3fff
    dw 0x3fff ; erased               ; 1d27: 3fff
    dw 0x3fff ; erased               ; 1d28: 3fff
    dw 0x3fff ; erased               ; 1d29: 3fff
    dw 0x3fff ; erased               ; 1d2a: 3fff
    dw 0x3fff ; erased               ; 1d2b: 3fff
    dw 0x3fff ; erased               ; 1d2c: 3fff
    dw 0x3fff ; erased               ; 1d2d: 3fff
    dw 0x3fff ; erased               ; 1d2e: 3fff
    dw 0x3fff ; erased               ; 1d2f: 3fff
    dw 0x3fff ; erased               ; 1d30: 3fff
    dw 0x3fff ; erased               ; 1d31: 3fff
    dw 0x3fff ; erased               ; 1d32: 3fff
    dw 0x3fff ; erased               ; 1d33: 3fff
    dw 0x3fff ; erased               ; 1d34: 3fff
    dw 0x3fff ; erased               ; 1d35: 3fff
    dw 0x3fff ; erased               ; 1d36: 3fff
    dw 0x3fff ; erased               ; 1d37: 3fff
    dw 0x3fff ; erased               ; 1d38: 3fff
    dw 0x3fff ; erased               ; 1d39: 3fff
    dw 0x3fff ; erased               ; 1d3a: 3fff
    dw 0x3fff ; erased               ; 1d3b: 3fff
    dw 0x3fff ; erased               ; 1d3c: 3fff
    dw 0x3fff ; erased               ; 1d3d: 3fff
    dw 0x3fff ; erased               ; 1d3e: 3fff
    dw 0x3fff ; erased               ; 1d3f: 3fff
    dw 0x3fff ; erased               ; 1d40: 3fff
    dw 0x3fff ; erased               ; 1d41: 3fff
    dw 0x3fff ; erased               ; 1d42: 3fff
    dw 0x3fff ; erased               ; 1d43: 3fff
    dw 0x3fff ; erased               ; 1d44: 3fff
    dw 0x3fff ; erased               ; 1d45: 3fff
    dw 0x3fff ; erased               ; 1d46: 3fff
    dw 0x3fff ; erased               ; 1d47: 3fff
    dw 0x3fff ; erased               ; 1d48: 3fff
    dw 0x3fff ; erased               ; 1d49: 3fff
    dw 0x3fff ; erased               ; 1d4a: 3fff
    dw 0x3fff ; erased               ; 1d4b: 3fff
    dw 0x3fff ; erased               ; 1d4c: 3fff
    dw 0x3fff ; erased               ; 1d4d: 3fff
    dw 0x3fff ; erased               ; 1d4e: 3fff
    dw 0x3fff ; erased               ; 1d4f: 3fff
    dw 0x3fff ; erased               ; 1d50: 3fff
    dw 0x3fff ; erased               ; 1d51: 3fff
    dw 0x3fff ; erased               ; 1d52: 3fff
    dw 0x3fff ; erased               ; 1d53: 3fff
    dw 0x3fff ; erased               ; 1d54: 3fff
    dw 0x3fff ; erased               ; 1d55: 3fff
    dw 0x3fff ; erased               ; 1d56: 3fff
    dw 0x3fff ; erased               ; 1d57: 3fff
    dw 0x3fff ; erased               ; 1d58: 3fff
    dw 0x3fff ; erased               ; 1d59: 3fff
    dw 0x3fff ; erased               ; 1d5a: 3fff
    dw 0x3fff ; erased               ; 1d5b: 3fff
    dw 0x3fff ; erased               ; 1d5c: 3fff
    dw 0x3fff ; erased               ; 1d5d: 3fff
    dw 0x3fff ; erased               ; 1d5e: 3fff
    dw 0x3fff ; erased               ; 1d5f: 3fff
    dw 0x3fff ; erased               ; 1d60: 3fff
    dw 0x3fff ; erased               ; 1d61: 3fff
    dw 0x3fff ; erased               ; 1d62: 3fff
    dw 0x3fff ; erased               ; 1d63: 3fff
    dw 0x3fff ; erased               ; 1d64: 3fff
    dw 0x3fff ; erased               ; 1d65: 3fff
    dw 0x3fff ; erased               ; 1d66: 3fff
    dw 0x3fff ; erased               ; 1d67: 3fff
    dw 0x3fff ; erased               ; 1d68: 3fff
    dw 0x3fff ; erased               ; 1d69: 3fff
    dw 0x3fff ; erased               ; 1d6a: 3fff
    dw 0x3fff ; erased               ; 1d6b: 3fff
    dw 0x3fff ; erased               ; 1d6c: 3fff
    dw 0x3fff ; erased               ; 1d6d: 3fff
    dw 0x3fff ; erased               ; 1d6e: 3fff
    dw 0x3fff ; erased               ; 1d6f: 3fff
    dw 0x3fff ; erased               ; 1d70: 3fff
    dw 0x3fff ; erased               ; 1d71: 3fff
    dw 0x3fff ; erased               ; 1d72: 3fff
    dw 0x3fff ; erased               ; 1d73: 3fff
    dw 0x3fff ; erased               ; 1d74: 3fff
    dw 0x3fff ; erased               ; 1d75: 3fff
    dw 0x3fff ; erased               ; 1d76: 3fff
    dw 0x3fff ; erased               ; 1d77: 3fff
    dw 0x3fff ; erased               ; 1d78: 3fff
    dw 0x3fff ; erased               ; 1d79: 3fff
    dw 0x3fff ; erased               ; 1d7a: 3fff
    dw 0x3fff ; erased               ; 1d7b: 3fff
    dw 0x3fff ; erased               ; 1d7c: 3fff
    dw 0x3fff ; erased               ; 1d7d: 3fff
    dw 0x3fff ; erased               ; 1d7e: 3fff
    dw 0x3fff ; erased               ; 1d7f: 3fff
    dw 0x3fff ; erased               ; 1d80: 3fff
    dw 0x3fff ; erased               ; 1d81: 3fff
    dw 0x3fff ; erased               ; 1d82: 3fff
    dw 0x3fff ; erased               ; 1d83: 3fff
    dw 0x3fff ; erased               ; 1d84: 3fff
    dw 0x3fff ; erased               ; 1d85: 3fff
    dw 0x3fff ; erased               ; 1d86: 3fff
    dw 0x3fff ; erased               ; 1d87: 3fff
    dw 0x3fff ; erased               ; 1d88: 3fff
    dw 0x3fff ; erased               ; 1d89: 3fff
    dw 0x3fff ; erased               ; 1d8a: 3fff
    dw 0x3fff ; erased               ; 1d8b: 3fff
    dw 0x3fff ; erased               ; 1d8c: 3fff
    dw 0x3fff ; erased               ; 1d8d: 3fff
    dw 0x3fff ; erased               ; 1d8e: 3fff
    dw 0x3fff ; erased               ; 1d8f: 3fff
    dw 0x3fff ; erased               ; 1d90: 3fff
    dw 0x3fff ; erased               ; 1d91: 3fff
    dw 0x3fff ; erased               ; 1d92: 3fff
    dw 0x3fff ; erased               ; 1d93: 3fff
    dw 0x3fff ; erased               ; 1d94: 3fff
    dw 0x3fff ; erased               ; 1d95: 3fff
    dw 0x3fff ; erased               ; 1d96: 3fff
    dw 0x3fff ; erased               ; 1d97: 3fff
    dw 0x3fff ; erased               ; 1d98: 3fff
    dw 0x3fff ; erased               ; 1d99: 3fff
    dw 0x3fff ; erased               ; 1d9a: 3fff
    dw 0x3fff ; erased               ; 1d9b: 3fff
    dw 0x3fff ; erased               ; 1d9c: 3fff
    dw 0x3fff ; erased               ; 1d9d: 3fff
    dw 0x3fff ; erased               ; 1d9e: 3fff
    dw 0x3fff ; erased               ; 1d9f: 3fff
    dw 0x3fff ; erased               ; 1da0: 3fff
    dw 0x3fff ; erased               ; 1da1: 3fff
    dw 0x3fff ; erased               ; 1da2: 3fff
    dw 0x3fff ; erased               ; 1da3: 3fff
    dw 0x3fff ; erased               ; 1da4: 3fff
    dw 0x3fff ; erased               ; 1da5: 3fff
    dw 0x3fff ; erased               ; 1da6: 3fff
    dw 0x3fff ; erased               ; 1da7: 3fff
    dw 0x3fff ; erased               ; 1da8: 3fff
    dw 0x3fff ; erased               ; 1da9: 3fff
    dw 0x3fff ; erased               ; 1daa: 3fff
    dw 0x3fff ; erased               ; 1dab: 3fff
    dw 0x3fff ; erased               ; 1dac: 3fff
    dw 0x3fff ; erased               ; 1dad: 3fff
    dw 0x3fff ; erased               ; 1dae: 3fff
    dw 0x3fff ; erased               ; 1daf: 3fff
    dw 0x3fff ; erased               ; 1db0: 3fff
    dw 0x3fff ; erased               ; 1db1: 3fff
    dw 0x3fff ; erased               ; 1db2: 3fff
    dw 0x3fff ; erased               ; 1db3: 3fff
    dw 0x3fff ; erased               ; 1db4: 3fff
    dw 0x3fff ; erased               ; 1db5: 3fff
    dw 0x3fff ; erased               ; 1db6: 3fff
    dw 0x3fff ; erased               ; 1db7: 3fff
    dw 0x3fff ; erased               ; 1db8: 3fff
    dw 0x3fff ; erased               ; 1db9: 3fff
    dw 0x3fff ; erased               ; 1dba: 3fff
    dw 0x3fff ; erased               ; 1dbb: 3fff
    dw 0x3fff ; erased               ; 1dbc: 3fff
    dw 0x3fff ; erased               ; 1dbd: 3fff
    dw 0x3fff ; erased               ; 1dbe: 3fff
    dw 0x3fff ; erased               ; 1dbf: 3fff
    dw 0x3fff ; erased               ; 1dc0: 3fff
    dw 0x3fff ; erased               ; 1dc1: 3fff
    dw 0x3fff ; erased               ; 1dc2: 3fff
    dw 0x3fff ; erased               ; 1dc3: 3fff
    dw 0x3fff ; erased               ; 1dc4: 3fff
    dw 0x3fff ; erased               ; 1dc5: 3fff
    dw 0x3fff ; erased               ; 1dc6: 3fff
    dw 0x3fff ; erased               ; 1dc7: 3fff
    dw 0x3fff ; erased               ; 1dc8: 3fff
    dw 0x3fff ; erased               ; 1dc9: 3fff
    dw 0x3fff ; erased               ; 1dca: 3fff
    dw 0x3fff ; erased               ; 1dcb: 3fff
    dw 0x3fff ; erased               ; 1dcc: 3fff
    dw 0x3fff ; erased               ; 1dcd: 3fff
    dw 0x3fff ; erased               ; 1dce: 3fff
    dw 0x3fff ; erased               ; 1dcf: 3fff
    dw 0x3fff ; erased               ; 1dd0: 3fff
    dw 0x3fff ; erased               ; 1dd1: 3fff
    dw 0x3fff ; erased               ; 1dd2: 3fff
    dw 0x3fff ; erased               ; 1dd3: 3fff
    dw 0x3fff ; erased               ; 1dd4: 3fff
    dw 0x3fff ; erased               ; 1dd5: 3fff
    dw 0x3fff ; erased               ; 1dd6: 3fff
    dw 0x3fff ; erased               ; 1dd7: 3fff
    dw 0x3fff ; erased               ; 1dd8: 3fff
    dw 0x3fff ; erased               ; 1dd9: 3fff
    dw 0x3fff ; erased               ; 1dda: 3fff
    dw 0x3fff ; erased               ; 1ddb: 3fff
    dw 0x3fff ; erased               ; 1ddc: 3fff
    dw 0x3fff ; erased               ; 1ddd: 3fff
    dw 0x3fff ; erased               ; 1dde: 3fff
    dw 0x3fff ; erased               ; 1ddf: 3fff
    dw 0x3fff ; erased               ; 1de0: 3fff
    dw 0x3fff ; erased               ; 1de1: 3fff
    dw 0x3fff ; erased               ; 1de2: 3fff
    dw 0x3fff ; erased               ; 1de3: 3fff
    dw 0x3fff ; erased               ; 1de4: 3fff
    dw 0x3fff ; erased               ; 1de5: 3fff
    dw 0x3fff ; erased               ; 1de6: 3fff
    dw 0x3fff ; erased               ; 1de7: 3fff
    dw 0x3fff ; erased               ; 1de8: 3fff
    dw 0x3fff ; erased               ; 1de9: 3fff
    dw 0x3fff ; erased               ; 1dea: 3fff
    dw 0x3fff ; erased               ; 1deb: 3fff
    dw 0x3fff ; erased               ; 1dec: 3fff
    dw 0x3fff ; erased               ; 1ded: 3fff
    dw 0x3fff ; erased               ; 1dee: 3fff
    dw 0x3fff ; erased               ; 1def: 3fff
    dw 0x3fff ; erased               ; 1df0: 3fff
    dw 0x3fff ; erased               ; 1df1: 3fff
    dw 0x3fff ; erased               ; 1df2: 3fff
    dw 0x3fff ; erased               ; 1df3: 3fff
    dw 0x3fff ; erased               ; 1df4: 3fff
    dw 0x3fff ; erased               ; 1df5: 3fff
    dw 0x3fff ; erased               ; 1df6: 3fff
    dw 0x3fff ; erased               ; 1df7: 3fff
    dw 0x3fff ; erased               ; 1df8: 3fff
    dw 0x3fff ; erased               ; 1df9: 3fff
    clrf    0x03                     ; 1dfa: 0183
    return                           ; 1dfb: 0008
    clrf    0x03                     ; 1dfc: 0183
    retlw   0x01                     ; 1dfd: 3401
    clrf    0x03                     ; 1dfe: 0183
    retlw   0x01                     ; 1dff: 3401
    clrf    0x03                     ; 1e00: 0183
    retlw   0x01                     ; 1e01: 3401
    clrf    0x03                     ; 1e02: 0183
    return                           ; 1e03: 0008
    bcf     0x0b, 0x7                ; 1e04: 138b
    clrwdt                           ; 1e05: 0064
    goto    0x0604                   ; 1e06: 2e04
    clrf    0x03                     ; 1e07: 0183
    movf    0x35, 0x0                ; 1e08: 0835
    return                           ; 1e09: 0008
    clrf    0x03                     ; 1e0a: 0183
    incfsz  0x30, 0x1                ; 1e0b: 0fb0
    return                           ; 1e0c: 0008
    return                           ; 1e0d: 0008
    bsf     0x03, 0x5                ; 1e0e: 1683
    bcf     0x03, 0x6                ; 1e0f: 1303
    movf    0x20, 0x0                ; 1e10: 0820
    bcf     0x03, 0x5                ; 1e11: 1283
    return                           ; 1e12: 0008
    bcf     0x03, 0x5                ; 1e13: 1283
    bsf     0x03, 0x6                ; 1e14: 1703
    movf    0x28, 0x0                ; 1e15: 0828
    andlw   0xff                     ; 1e16: 39ff
    bcf     0x03, 0x6                ; 1e17: 1303
    return                           ; 1e18: 0008
    clrf    0x03                     ; 1e19: 0183
    movf    0x27, 0x0                ; 1e1a: 0827
    movwf   0x71                     ; 1e1b: 00f1
    movf    0x26, 0x0                ; 1e1c: 0826
    movwf   0x70                     ; 1e1d: 00f0
    return                           ; 1e1e: 0008
    bcf     0x03, 0x5                ; 1e1f: 1283
    bsf     0x03, 0x6                ; 1e20: 1703
    swapf   0x2c, 0x0                ; 1e21: 0e2c
    andlw   0x07                     ; 1e22: 3907
    bcf     0x03, 0x6                ; 1e23: 1303
    return                           ; 1e24: 0008
    bcf     0x03, 0x5                ; 1e25: 1283
    bsf     0x03, 0x6                ; 1e26: 1703
    movf    0x39, 0x0                ; 1e27: 0839
    andlw   0xff                     ; 1e28: 39ff
    bcf     0x03, 0x6                ; 1e29: 1303
    return                           ; 1e2a: 0008
    bcf     0x03, 0x5                ; 1e2b: 1283
    bsf     0x03, 0x6                ; 1e2c: 1703
    movf    0x3b, 0x0                ; 1e2d: 083b
    andlw   0xff                     ; 1e2e: 39ff
    bcf     0x03, 0x6                ; 1e2f: 1303
    return                           ; 1e30: 0008
    bcf     0x03, 0x5                ; 1e31: 1283
    bsf     0x03, 0x6                ; 1e32: 1703
    swapf   0x2c, 0x0                ; 1e33: 0e2c
    andlw   0x07                     ; 1e34: 3907
    bcf     0x03, 0x6                ; 1e35: 1303
    return                           ; 1e36: 0008
    bcf     0x03, 0x5                ; 1e37: 1283
    bsf     0x03, 0x6                ; 1e38: 1703
    movf    0x3c, 0x0                ; 1e39: 083c
    andlw   0x07                     ; 1e3a: 3907
    bcf     0x03, 0x6                ; 1e3b: 1303
    return                           ; 1e3c: 0008
    bcf     0x03, 0x5                ; 1e3d: 1283
    bsf     0x03, 0x6                ; 1e3e: 1703
    swapf   0x3c, 0x0                ; 1e3f: 0e3c
    andlw   0x07                     ; 1e40: 3907
    bcf     0x03, 0x6                ; 1e41: 1303
    return                           ; 1e42: 0008
    bcf     0x03, 0x5                ; 1e43: 1283
    bsf     0x03, 0x6                ; 1e44: 1703
    swapf   0x2e, 0x0                ; 1e45: 0e2e
    andlw   0x0f                     ; 1e46: 390f
    bcf     0x03, 0x6                ; 1e47: 1303
    return                           ; 1e48: 0008
    bcf     0x03, 0x5                ; 1e49: 1283
    bsf     0x03, 0x6                ; 1e4a: 1703
    swapf   0x2d, 0x0                ; 1e4b: 0e2d
    andlw   0x0f                     ; 1e4c: 390f
    bcf     0x03, 0x6                ; 1e4d: 1303
    return                           ; 1e4e: 0008
    bcf     0x03, 0x5                ; 1e4f: 1283
    bsf     0x03, 0x6                ; 1e50: 1703
    movf    0x2d, 0x0                ; 1e51: 082d
    andlw   0x0f                     ; 1e52: 390f
    bcf     0x03, 0x6                ; 1e53: 1303
    return                           ; 1e54: 0008
    bcf     0x03, 0x5                ; 1e55: 1283
    bsf     0x03, 0x6                ; 1e56: 1703
    movf    0x2f, 0x0                ; 1e57: 082f
    andlw   0x0f                     ; 1e58: 390f
    bcf     0x03, 0x6                ; 1e59: 1303
    return                           ; 1e5a: 0008
    bcf     0x03, 0x5                ; 1e5b: 1283
    bsf     0x03, 0x6                ; 1e5c: 1703
    swapf   0x2f, 0x0                ; 1e5d: 0e2f
    andlw   0x0f                     ; 1e5e: 390f
    bcf     0x03, 0x6                ; 1e5f: 1303
    return                           ; 1e60: 0008
    bcf     0x03, 0x5                ; 1e61: 1283
    bsf     0x03, 0x6                ; 1e62: 1703
    movf    0x30, 0x0                ; 1e63: 0830
    andlw   0x0f                     ; 1e64: 390f
    bcf     0x03, 0x6                ; 1e65: 1303
    return                           ; 1e66: 0008
    bcf     0x03, 0x5                ; 1e67: 1283
    bsf     0x03, 0x6                ; 1e68: 1703
    movf    0x29, 0x0                ; 1e69: 0829
    andlw   0x0f                     ; 1e6a: 390f
    bcf     0x03, 0x6                ; 1e6b: 1303
    return                           ; 1e6c: 0008
    bcf     0x03, 0x5                ; 1e6d: 1283
    bsf     0x03, 0x6                ; 1e6e: 1703
    movf    0x2e, 0x0                ; 1e6f: 082e
    andlw   0x0f                     ; 1e70: 390f
    bcf     0x03, 0x6                ; 1e71: 1303
    return                           ; 1e72: 0008
    bcf     0x03, 0x5                ; 1e73: 1283
    bsf     0x03, 0x6                ; 1e74: 1703
    movf    0x27, 0x0                ; 1e75: 0827
    andlw   0x0f                     ; 1e76: 390f
    bcf     0x03, 0x6                ; 1e77: 1303
    return                           ; 1e78: 0008
    bcf     0x03, 0x5                ; 1e79: 1283
    bsf     0x03, 0x6                ; 1e7a: 1703
    movf    0x2c, 0x0                ; 1e7b: 082c
    andlw   0x07                     ; 1e7c: 3907
    bcf     0x03, 0x6                ; 1e7d: 1303
    return                           ; 1e7e: 0008
    bcf     0x03, 0x5                ; 1e7f: 1283
    bsf     0x03, 0x6                ; 1e80: 1703
    movf    0x2b, 0x0                ; 1e81: 082b
    andlw   0xff                     ; 1e82: 39ff
    bcf     0x03, 0x6                ; 1e83: 1303
    return                           ; 1e84: 0008
    bcf     0x03, 0x5                ; 1e85: 1283
    bsf     0x03, 0x6                ; 1e86: 1703
    swapf   0x27, 0x0                ; 1e87: 0e27
    andlw   0x03                     ; 1e88: 3903
    bcf     0x03, 0x6                ; 1e89: 1303
    return                           ; 1e8a: 0008
    bcf     0x03, 0x5                ; 1e8b: 1283
    bsf     0x03, 0x6                ; 1e8c: 1703
    swapf   0x30, 0x0                ; 1e8d: 0e30
    andlw   0x0f                     ; 1e8e: 390f
    bcf     0x03, 0x6                ; 1e8f: 1303
    return                           ; 1e90: 0008
    bcf     0x03, 0x5                ; 1e91: 1283
    bsf     0x03, 0x6                ; 1e92: 1703
    swapf   0x29, 0x0                ; 1e93: 0e29
    andlw   0x0f                     ; 1e94: 390f
    bcf     0x03, 0x6                ; 1e95: 1303
    return                           ; 1e96: 0008
    bcf     0x03, 0x5                ; 1e97: 1283
    bsf     0x03, 0x6                ; 1e98: 1703
    rlf     0x3a, 0x0                ; 1e99: 0d3a
    rlf     0x3a, 0x0                ; 1e9a: 0d3a
    andlw   0x01                     ; 1e9b: 3901
    bcf     0x03, 0x6                ; 1e9c: 1303
    return                           ; 1e9d: 0008
    bcf     0x03, 0x5                ; 1e9e: 1283
    bsf     0x03, 0x6                ; 1e9f: 1703
    rlf     0x2c, 0x0                ; 1ea0: 0d2c
    rlf     0x2c, 0x0                ; 1ea1: 0d2c
    andlw   0x01                     ; 1ea2: 3901
    bcf     0x03, 0x6                ; 1ea3: 1303
    return                           ; 1ea4: 0008
    bcf     0x03, 0x5                ; 1ea5: 1283
    bsf     0x03, 0x6                ; 1ea6: 1703
    rlf     0x3c, 0x0                ; 1ea7: 0d3c
    rlf     0x3c, 0x0                ; 1ea8: 0d3c
    andlw   0x01                     ; 1ea9: 3901
    bcf     0x03, 0x6                ; 1eaa: 1303
    return                           ; 1eab: 0008
    clrf    0x03                     ; 1eac: 0183
    decfsz  0x29, 0x1                ; 1ead: 0ba9
    goto    0x06b2                   ; 1eae: 2eb2
    movf    0x2a, 0x0                ; 1eaf: 082a
    btfss   0x03, 0x2                ; 1eb0: 1d03
    bsf     0x0b, 0x7                ; 1eb1: 178b
    clrf    0x03                     ; 1eb2: 0183
    return                           ; 1eb3: 0008
    bcf     0x03, 0x5                ; 1eb4: 1283
    bsf     0x03, 0x6                ; 1eb5: 1703
    rrf     0x3c, 0x0                ; 1eb6: 0c3c
    movwf   0x70                     ; 1eb7: 00f0
    rrf     0x70, 0x1                ; 1eb8: 0cf0
    rrf     0x70, 0x0                ; 1eb9: 0c70
    andlw   0x01                     ; 1eba: 3901
    bcf     0x03, 0x6                ; 1ebb: 1303
    return                           ; 1ebc: 0008
    bcf     0x03, 0x5                ; 1ebd: 1283
    bsf     0x03, 0x6                ; 1ebe: 1703
    swapf   0x27, 0x0                ; 1ebf: 0e27
    movwf   0x70                     ; 1ec0: 00f0
    rrf     0x70, 0x1                ; 1ec1: 0cf0
    rrf     0x70, 0x0                ; 1ec2: 0c70
    andlw   0x03                     ; 1ec3: 3903
    bcf     0x03, 0x6                ; 1ec4: 1303
    return                           ; 1ec5: 0008
    movlw   0x2c                     ; 1ec6: 302c
    bsf     0x03, 0x5                ; 1ec7: 1683
    bcf     0x03, 0x6                ; 1ec8: 1303
    movwf   0x53                     ; 1ec9: 00d3
    movlw   0x32                     ; 1eca: 3032
    movwf   0x5d                     ; 1ecb: 00dd
    clrf    0x5e                     ; 1ecc: 01de
    bcf     0x03, 0x5                ; 1ecd: 1283
    return                           ; 1ece: 0008
    bcf     0x03, 0x5                ; 1ecf: 1283
    bsf     0x03, 0x6                ; 1ed0: 1703
    rrf     0x2c, 0x0                ; 1ed1: 0c2c
    movwf   0x70                     ; 1ed2: 00f0
    rrf     0x70, 0x1                ; 1ed3: 0cf0
    rrf     0x70, 0x0                ; 1ed4: 0c70
    andlw   0x01                     ; 1ed5: 3901
    bcf     0x03, 0x6                ; 1ed6: 1303
    return                           ; 1ed7: 0008
    clrf    0x03                     ; 1ed8: 0183
    incf    0x29, 0x1                ; 1ed9: 0aa9
    decfsz  0x29, 0x0                ; 1eda: 0b29
    goto    0x06e0                   ; 1edb: 2ee0
    movf    0x0b, 0x0                ; 1edc: 080b
    andlw   0x80                     ; 1edd: 3980
    movwf   0x2a                     ; 1ede: 00aa
    bcf     0x0b, 0x7                ; 1edf: 138b
    clrf    0x03                     ; 1ee0: 0183
    return                           ; 1ee1: 0008
    movwf   0x70                     ; 1ee2: 00f0
    movlw   0x00                     ; 1ee3: 3000
    btfsc   0x71, 0x0                ; 1ee4: 1871
    addwf   0x70, 0x0                ; 1ee5: 0770
    bcf     0x03, 0x0                ; 1ee6: 1003
    rlf     0x70, 0x1                ; 1ee7: 0df0
    bcf     0x03, 0x0                ; 1ee8: 1003
    rrf     0x71, 0x1                ; 1ee9: 0cf1
    movf    0x71, 0x1                ; 1eea: 08f1
    btfsc   0x03, 0x2                ; 1eeb: 1903
    return                           ; 1eec: 0008
    goto    0x06e4                   ; 1eed: 2ee4
    clrf    0x74                     ; 1eee: 01f4
    clrf    0x75                     ; 1eef: 01f5
    bcf     0x03, 0x0                ; 1ef0: 1003
    rrf     0x73, 0x1                ; 1ef1: 0cf3
    rrf     0x72, 0x1                ; 1ef2: 0cf2
    btfss   0x03, 0x0                ; 1ef3: 1c03
    goto    0x06fc                   ; 1ef4: 2efc
    movf    0x70, 0x0                ; 1ef5: 0870
    addwf   0x74, 0x1                ; 1ef6: 07f4
    movf    0x71, 0x0                ; 1ef7: 0871
    btfsc   0x03, 0x0                ; 1ef8: 1803
    incf    0x71, 0x0                ; 1ef9: 0a71
    addwf   0x75, 0x1                ; 1efa: 07f5
    bcf     0x03, 0x0                ; 1efb: 1003
    rlf     0x70, 0x1                ; 1efc: 0df0
    rlf     0x71, 0x1                ; 1efd: 0df1
    movf    0x72, 0x0                ; 1efe: 0872
    iorwf   0x73, 0x0                ; 1eff: 0473
    btfsc   0x03, 0x2                ; 1f00: 1903
    retlw   0x00                     ; 1f01: 3400
    goto    0x06f0                   ; 1f02: 2ef0
    clrf    0x03                     ; 1f03: 0183
    movwf   0x3c                     ; 1f04: 00bc
    movlw   0x05                     ; 1f05: 3005
    subwf   0x3c, 0x0                ; 1f06: 023c
    btfsc   0x03, 0x0                ; 1f07: 1803
    retlw   0x01                     ; 1f08: 3401
    movlw   0x03                     ; 1f09: 3003
    subwf   0x3c, 0x0                ; 1f0a: 023c
    btfsc   0x03, 0x0                ; 1f0b: 1803
    retlw   0x02                     ; 1f0c: 3402
    bsf     0x0a, 0x4                ; 1f0d: 160a
    bsf     0x0a, 0x3                ; 1f0e: 158a
    call    0x06d8                   ; 1f0f: 26d8
    movlw   0x03                     ; 1f10: 3003
    movwf   0x71                     ; 1f11: 00f1
    movf    0x3c, 0x0                ; 1f12: 083c
    bsf     0x0a, 0x4                ; 1f13: 160a
    bsf     0x0a, 0x3                ; 1f14: 158a
    call    0x06e2                   ; 1f15: 26e2
    addlw   0x02                     ; 1f16: 3e02
    addlw   0xac                     ; 1f17: 3eac
    movwf   0x04                     ; 1f18: 0084
    bcf     0x03, 0x7                ; 1f19: 1383
    movf    0x3c, 0x0                ; 1f1a: 083c
    movwf   0x00                     ; 1f1b: 0080
    bsf     0x0a, 0x4                ; 1f1c: 160a
    bsf     0x0a, 0x3                ; 1f1d: 158a
    call    0x06ac                   ; 1f1e: 26ac
    bsf     0x0a, 0x4                ; 1f1f: 160a
    bsf     0x0a, 0x3                ; 1f20: 158a
    retlw   0x00                     ; 1f21: 3400
    clrf    0x03                     ; 1f22: 0183
    movwf   0x4b                     ; 1f23: 00cb
    movlw   0x05                     ; 1f24: 3005
    subwf   0x4a, 0x0                ; 1f25: 024a
    movlw   0x01                     ; 1f26: 3001
    btfsc   0x03, 0x0                ; 1f27: 1803
    return                           ; 1f28: 0008
    subwf   0x4b, 0x0                ; 1f29: 024b
    btfsc   0x03, 0x0                ; 1f2a: 1803
    retlw   0x02                     ; 1f2b: 3402
    bsf     0x0a, 0x4                ; 1f2c: 160a
    bsf     0x0a, 0x3                ; 1f2d: 158a
    call    0x06d8                   ; 1f2e: 26d8
    movlw   0x05                     ; 1f2f: 3005
    movwf   0x71                     ; 1f30: 00f1
    movf    0x4b, 0x0                ; 1f31: 084b
    bsf     0x0a, 0x4                ; 1f32: 160a
    bsf     0x0a, 0x3                ; 1f33: 158a
    call    0x06e2                   ; 1f34: 26e2
    addlw   0x02                     ; 1f35: 3e02
    addlw   0xa7                     ; 1f36: 3ea7
    movwf   0x04                     ; 1f37: 0084
    bcf     0x03, 0x7                ; 1f38: 1383
    movf    0x4a, 0x0                ; 1f39: 084a
    movwf   0x00                     ; 1f3a: 0080
    bsf     0x0a, 0x4                ; 1f3b: 160a
    bsf     0x0a, 0x3                ; 1f3c: 158a
    call    0x06ac                   ; 1f3d: 26ac
    bsf     0x0a, 0x4                ; 1f3e: 160a
    bsf     0x0a, 0x3                ; 1f3f: 158a
    retlw   0x00                     ; 1f40: 3400
    clrf    0x03                     ; 1f41: 0183
    movwf   0x4a                     ; 1f42: 00ca
    movlw   0x05                     ; 1f43: 3005
    subwf   0x4a, 0x0                ; 1f44: 024a
    btfss   0x03, 0x0                ; 1f45: 1c03
    goto    0x074a                   ; 1f46: 2f4a
    clrf    0x70                     ; 1f47: 01f0
    clrf    0x71                     ; 1f48: 01f1
    return                           ; 1f49: 0008
    bsf     0x0a, 0x4                ; 1f4a: 160a
    bsf     0x0a, 0x3                ; 1f4b: 158a
    call    0x06d8                   ; 1f4c: 26d8
    movf    0x4a, 0x0                ; 1f4d: 084a
    addwf   0x4a, 0x0                ; 1f4e: 074a
    addlw   0xb5                     ; 1f4f: 3eb5
    movwf   0x04                     ; 1f50: 0084
    bcf     0x03, 0x7                ; 1f51: 1383
    movf    0x00, 0x0                ; 1f52: 0800
    movwf   0x4b                     ; 1f53: 00cb
    incf    0x04, 0x1                ; 1f54: 0a84
    movf    0x00, 0x0                ; 1f55: 0800
    movwf   0x4c                     ; 1f56: 00cc
    bsf     0x0a, 0x4                ; 1f57: 160a
    bsf     0x0a, 0x3                ; 1f58: 158a
    call    0x06ac                   ; 1f59: 26ac
    bsf     0x0a, 0x4                ; 1f5a: 160a
    bsf     0x0a, 0x3                ; 1f5b: 158a
    movf    0x4c, 0x0                ; 1f5c: 084c
    movwf   0x71                     ; 1f5d: 00f1
    movf    0x4b, 0x0                ; 1f5e: 084b
    movwf   0x70                     ; 1f5f: 00f0
    return                           ; 1f60: 0008
    clrf    0x03                     ; 1f61: 0183
    movf    0x3d, 0x0                ; 1f62: 083d
    iorwf   0x3c, 0x0                ; 1f63: 043c
    btfsc   0x03, 0x2                ; 1f64: 1903
    goto    0x0778                   ; 1f65: 2f78
    movf    0x3c, 0x0                ; 1f66: 083c
    movwf   0x4d                     ; 1f67: 00cd
    movf    0x3d, 0x0                ; 1f68: 083d
    movwf   0x4e                     ; 1f69: 00ce
    movlw   0x05                     ; 1f6a: 3005
    movwf   0x4f                     ; 1f6b: 00cf
    movlw   0x03                     ; 1f6c: 3003
    movwf   0x50                     ; 1f6d: 00d0
    bsf     0x0a, 0x4                ; 1f6e: 160a
    bsf     0x0a, 0x3                ; 1f6f: 158a
    call    0x05fe                   ; 1f70: 25fe
    bsf     0x0a, 0x4                ; 1f71: 160a
    bsf     0x0a, 0x3                ; 1f72: 158a
    movwf   0x70                     ; 1f73: 00f0
    clrf    0x71                     ; 1f74: 01f1
    iorwf   0x71, 0x0                ; 1f75: 0471
    btfsc   0x03, 0x2                ; 1f76: 1903
    return                           ; 1f77: 0008
    bsf     0x0a, 0x4                ; 1f78: 160a
    bsf     0x0a, 0x3                ; 1f79: 158a
    call    0x06d8                   ; 1f7a: 26d8
    bsf     0x0a, 0x4                ; 1f7b: 160a
    bsf     0x0a, 0x3                ; 1f7c: 158a
    movf    0x3c, 0x0                ; 1f7d: 083c
    movwf   0x61                     ; 1f7e: 00e1
    movf    0x3d, 0x0                ; 1f7f: 083d
    movwf   0x62                     ; 1f80: 00e2
    bsf     0x0a, 0x4                ; 1f81: 160a
    bsf     0x0a, 0x3                ; 1f82: 158a
    goto    0x06ac                   ; 1f83: 2eac
    clrf    0x03                     ; 1f84: 0183
    movwf   0x3c                     ; 1f85: 00bc
    movf    0x3c, 0x0                ; 1f86: 083c
    movwf   0x3e                     ; 1f87: 00be
    movf    0x3d, 0x0                ; 1f88: 083d
    movwf   0x3f                     ; 1f89: 00bf
    movf    0x3c, 0x0                ; 1f8a: 083c
    movwf   0x3d                     ; 1f8b: 00bd
    goto    0x079f                   ; 1f8c: 2f9f
    movf    0x3f, 0x0                ; 1f8d: 083f
    movwf   0x67                     ; 1f8e: 00e7
    movf    0x3e, 0x0                ; 1f8f: 083e
    bcf     0x0a, 0x4                ; 1f90: 120a
    bcf     0x0a, 0x3                ; 1f91: 118a
    call    0x01e7                   ; 1f92: 21e7
    bsf     0x0a, 0x4                ; 1f93: 160a
    bsf     0x0a, 0x3                ; 1f94: 158a
    movwf   0x70                     ; 1f95: 00f0
    movf    0x3d, 0x0                ; 1f96: 083d
    movwf   0x04                     ; 1f97: 0084
    bcf     0x03, 0x7                ; 1f98: 1383
    movf    0x70, 0x0                ; 1f99: 0870
    movwf   0x00                     ; 1f9a: 0080
    incf    0x3d, 0x1                ; 1f9b: 0abd
    incf    0x3e, 0x1                ; 1f9c: 0abe
    btfsc   0x03, 0x2                ; 1f9d: 1903
    incf    0x3f, 0x1                ; 1f9e: 0abf
    movf    0x3e, 0x0                ; 1f9f: 083e
    btfsc   0x03, 0x2                ; 1fa0: 1903
    decf    0x3f, 0x1                ; 1fa1: 03bf
    decf    0x3e, 0x1                ; 1fa2: 03be
    incf    0x3e, 0x0                ; 1fa3: 0a3e
    btfsc   0x03, 0x2                ; 1fa4: 1903
    incf    0x3f, 0x0                ; 1fa5: 0a3f
    btfss   0x03, 0x2                ; 1fa6: 1d03
    goto    0x078d                   ; 1fa7: 2f8d
    movf    0x3c, 0x0                ; 1fa8: 083c
    return                           ; 1fa9: 0008
    clrf    0x03                     ; 1faa: 0183
    movwf   0x56                     ; 1fab: 00d6
    btfss   0x56, 0x0                ; 1fac: 1c56
    goto    0x07b0                   ; 1fad: 2fb0
    bcf     0x38, 0x3                ; 1fae: 11b8
    goto    0x07b1                   ; 1faf: 2fb1
    bsf     0x38, 0x3                ; 1fb0: 15b8
    btfss   0x56, 0x1                ; 1fb1: 1cd6
    goto    0x07b5                   ; 1fb2: 2fb5
    bcf     0x37, 0x0                ; 1fb3: 1037
    goto    0x07b6                   ; 1fb4: 2fb6
    bsf     0x37, 0x0                ; 1fb5: 1437
    btfss   0x56, 0x2                ; 1fb6: 1d56
    goto    0x07ba                   ; 1fb7: 2fba
    bcf     0x37, 0x1                ; 1fb8: 10b7
    goto    0x07bb                   ; 1fb9: 2fbb
    bsf     0x37, 0x1                ; 1fba: 14b7
    btfss   0x56, 0x3                ; 1fbb: 1dd6
    goto    0x07bf                   ; 1fbc: 2fbf
    bcf     0x37, 0x2                ; 1fbd: 1137
    goto    0x07c0                   ; 1fbe: 2fc0
    bsf     0x37, 0x2                ; 1fbf: 1537
    btfss   0x56, 0x4                ; 1fc0: 1e56
    goto    0x07c4                   ; 1fc1: 2fc4
    bcf     0x37, 0x3                ; 1fc2: 11b7
    goto    0x07c5                   ; 1fc3: 2fc5
    bsf     0x37, 0x3                ; 1fc4: 15b7
    btfss   0x56, 0x5                ; 1fc5: 1ed6
    goto    0x07c9                   ; 1fc6: 2fc9
    bcf     0x38, 0x0                ; 1fc7: 1038
    goto    0x07ca                   ; 1fc8: 2fca
    bsf     0x38, 0x0                ; 1fc9: 1438
    btfss   0x56, 0x6                ; 1fca: 1f56
    goto    0x07ce                   ; 1fcb: 2fce
    bcf     0x38, 0x1                ; 1fcc: 10b8
    goto    0x07cf                   ; 1fcd: 2fcf
    bsf     0x38, 0x1                ; 1fce: 14b8
    btfss   0x56, 0x7                ; 1fcf: 1fd6
    goto    0x07d3                   ; 1fd0: 2fd3
    bcf     0x38, 0x2                ; 1fd1: 1138
    return                           ; 1fd2: 0008
    bsf     0x38, 0x2                ; 1fd3: 1538
    return                           ; 1fd4: 0008
    clrf    0x03                     ; 1fd5: 0183
    movwf   0x56                     ; 1fd6: 00d6
    btfss   0x56, 0x0                ; 1fd7: 1c56
    goto    0x07db                   ; 1fd8: 2fdb
    bcf     0x38, 0x4                ; 1fd9: 1238
    goto    0x07dc                   ; 1fda: 2fdc
    bsf     0x38, 0x4                ; 1fdb: 1638
    btfss   0x56, 0x1                ; 1fdc: 1cd6
    goto    0x07e0                   ; 1fdd: 2fe0
    bcf     0x36, 0x3                ; 1fde: 11b6
    goto    0x07e1                   ; 1fdf: 2fe1
    bsf     0x36, 0x3                ; 1fe0: 15b6
    btfss   0x56, 0x2                ; 1fe1: 1d56
    goto    0x07e5                   ; 1fe2: 2fe5
    bcf     0x36, 0x2                ; 1fe3: 1136
    goto    0x07e6                   ; 1fe4: 2fe6
    bsf     0x36, 0x2                ; 1fe5: 1536
    btfss   0x56, 0x3                ; 1fe6: 1dd6
    goto    0x07ea                   ; 1fe7: 2fea
    bcf     0x36, 0x1                ; 1fe8: 10b6
    goto    0x07eb                   ; 1fe9: 2feb
    bsf     0x36, 0x1                ; 1fea: 14b6
    btfss   0x56, 0x4                ; 1feb: 1e56
    goto    0x07ef                   ; 1fec: 2fef
    bcf     0x36, 0x0                ; 1fed: 1036
    goto    0x07f0                   ; 1fee: 2ff0
    bsf     0x36, 0x0                ; 1fef: 1436
    btfss   0x56, 0x5                ; 1ff0: 1ed6
    goto    0x07f4                   ; 1ff1: 2ff4
    bcf     0x38, 0x7                ; 1ff2: 13b8
    goto    0x07f5                   ; 1ff3: 2ff5
    bsf     0x38, 0x7                ; 1ff4: 17b8
    btfss   0x56, 0x6                ; 1ff5: 1f56
    goto    0x07f9                   ; 1ff6: 2ff9
    bcf     0x38, 0x6                ; 1ff7: 1338
    goto    0x07fa                   ; 1ff8: 2ffa
    bsf     0x38, 0x6                ; 1ff9: 1738
    btfss   0x56, 0x7                ; 1ffa: 1fd6
    goto    0x07fe                   ; 1ffb: 2ffe
    bcf     0x38, 0x5                ; 1ffc: 12b8
    return                           ; 1ffd: 0008
    bsf     0x38, 0x5                ; 1ffe: 16b8
    return                           ; 1fff: 0008
    org 0x2000
    dw 0x007f, 0x007f, 0x007f, 0x007f
    __config 0x37ea
    org 0x2100
    de 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10, 0x03, 0x06, 0x5d, 0x70, 0x00, 0x00, 0x64, 0xc8
    de 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01
    de 0x27, 0x91, 0x17, 0x96, 0x01, 0x93, 0x69, 0x32, 0x06, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01, 0xff
    de 0x06, 0x10, 0x11, 0xff, 0xff, 0xff, 0x41, 0x20, 0x31, 0x37, 0x32, 0x20, 0x35, 0x34, 0x32, 0x20
    de 0x30, 0x30, 0x20, 0x32, 0x33, 0x20, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10, 0x03, 0x06, 0x5d, 0x70
    de 0x00, 0x00, 0x64, 0xc8, 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x02, 0x02, 0x01, 0x00, 0x3c, 0x02, 0x12, 0x10
    de 0x03, 0x06, 0x5d, 0x70, 0x00, 0x00, 0x64, 0xc8, 0x67, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    de 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    end
