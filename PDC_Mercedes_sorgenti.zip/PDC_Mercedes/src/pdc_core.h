#ifndef PDC_CORE_H
#define PDC_CORE_H
#include <stdint.h>

/* Recovered modules, not a complete replacement firmware. Addresses in comments
 * are PIC program WORD addresses. No physical distance unit is assumed. */
typedef struct {
    uint8_t header, data[4], size;
} PdcFrame;
typedef struct {
    uint8_t bytes[6], count, parity_error, framing_error;
} PdcReceiver;
enum { PDC_MORE=0, PDC_FRAME=1, PDC_BAD_FRAME=2 };
uint8_t pdc_even_parity(uint8_t byte);
uint8_t pdc_rx_byte(PdcReceiver *rx, uint8_t byte, uint8_t ninth,
                    uint8_t framing_error, PdcFrame *out);
void pdc_rx_reset(PdcReceiver *rx);

/* Names reflect storage/dispatch only. Physical interpretation still requires
 * tracing the display application at 0x08ce..0x0fff and measurements. */
typedef struct {
    uint8_t mode;                /* EEPROM[5], RAM 0x122 */
    uint8_t header;              /* 0x127 */
    uint8_t group2_byte;         /* 0x128 */
    uint8_t group3_byte;         /* 0x129 */
    uint8_t group3_pair[2];      /* 0x12b..0x12c */
    uint8_t group0_quad[4];      /* 0x12d..0x130 */
    uint8_t group3_quad[4];      /* 0x135..0x138 */
    uint8_t group1_quad[4];      /* 0x139..0x13c */
    uint8_t header_shadow;       /* 0x03d */
    uint8_t pwm_period;          /* PR2, 0x092; read by group 3 branches */
} PdcCommands;
uint8_t pdc_dispatch(PdcCommands *state, const PdcFrame *frame);

typedef struct { uint8_t b, c, d; } PdcPorts;
void pdc_led_bank_a(PdcPorts *shadow, uint8_t pattern); /* 0x1fd5 */
void pdc_led_bank_b(PdcPorts *shadow, uint8_t pattern); /* 0x1faa */
uint8_t pdc_led_bar(uint8_t level);                   /* table 0x1822 */
uint16_t pdc_buzzer_period(uint8_t index);            /* table 0x1801 */

typedef struct {
    PdcPorts shadow, ports;
    uint8_t flags, phase, duty_a, duty_b; /* flags=0x0ce, phase=0x0d1 */
} PdcDisplay;
void pdc_display_tick(PdcDisplay *display);          /* 0x003b..0x008c */

/* EEPROM read callback; no secret or host state. Returns 0 on a valid value,
 * 1 when index 5 has no majority: original enters its non-returning halt. */
typedef uint8_t (*PdcEepromRead)(uint8_t address);
uint8_t pdc_config_read(PdcEepromRead read_byte, uint8_t index, uint8_t *value);

typedef struct {
    PdcDisplay display;
    uint8_t brightness, trim_a, trim_b, limit;
    uint8_t sound_index, previous_sound, sound_flags, timer2_control;
    uint16_t countdown;
} PdcGroup0;
/* Recovered normal group-0 display/sound-request path, 0x08ce..0x0a18.
 * Not the sound waveform scheduler, ADC control or other header groups. */
void pdc_group0_apply(PdcGroup0 *s, const PdcCommands *commands);
#endif
