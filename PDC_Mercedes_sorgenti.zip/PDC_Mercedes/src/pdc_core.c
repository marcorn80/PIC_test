#include "pdc_core.h"

uint8_t pdc_even_parity(uint8_t value) /* 0x0421..0x0437 */
{
    value ^= value >> 4;
    value ^= value >> 2;
    value ^= value >> 1;
    return value & 1u;
}

void pdc_rx_reset(PdcReceiver *rx)
{
    rx->count = 0;
    rx->parity_error = 0;
    rx->framing_error = 0;
}

uint8_t pdc_rx_byte(PdcReceiver *rx, uint8_t byte, uint8_t ninth,
                    uint8_t framing_error, PdcFrame *out)
{
    uint8_t i, data_size, total, sum = 0;
    /* Extracted from 0x0438..0x04ca, with queue/scheduler removed.
     * Caller supplies RX9D corresponding to this byte, captured before RCREG.
     * The original ISR reads RX9D after RCREG: FIFO timing is not reproduced.
     * FERR is overwritten by the ISR, whereas parity is latched by the parser.
     * The six-tick gap reset in the original ISR must be handled by caller. */
    if (rx->count >= 6u) pdc_rx_reset(rx);
    rx->bytes[rx->count++] = byte;
    rx->parity_error |= (uint8_t)(pdc_even_parity(byte) != (ninth & 1u));
    rx->framing_error = (uint8_t)(framing_error != 0u);
    data_size = (uint8_t)((rx->bytes[0] >> 6) + 1u);
    total = (uint8_t)(data_size + 2u);
    if (rx->count != total) return PDC_MORE;
    for (i = 0; i < (uint8_t)(total - 1u); ++i)
        sum = (uint8_t)(sum + rx->bytes[i]);
    if (sum != byte || rx->parity_error || rx->framing_error) {
        pdc_rx_reset(rx);
        return PDC_BAD_FRAME;
    }
    out->header = rx->bytes[0];
    out->size = data_size;
    for (i = 0; i < 4u; ++i)
        out->data[i] = i < data_size ? rx->bytes[i+1u] : 0u;
    pdc_rx_reset(rx);
    return PDC_FRAME;
}

uint8_t pdc_dispatch(PdcCommands *s, const PdcFrame *f)
{
    uint8_t type, group, length, i;
    /* 0x021e..0x02f6. s->header is loaded by parser even if unsupported. */
    s->header = f->header;
    type = f->header & 15u;
    group = (f->header >> 4) & 3u;
    length = f->header >> 6;
    if (f->size != (uint8_t)(length + 1u)) return 0;
    if (s->mode != 2u && s->mode != 4u && s->mode != 6u) return 0;
    if (!((type == 1u) || (type >= 13u && type <= 15u) ||
          ((type == 2u || type == 3u) && s->mode == 2u) ||
          ((type == 4u || type == 5u) && s->mode == 4u) ||
          ((type == 6u || type == 7u) && s->mode == 6u))) return 0;
    switch (group) {
    case 0:
        if (length != 3u) return 0;
        for (i = 0; i < 4u; ++i) s->group0_quad[i] = f->data[i];
        return 1;
    case 1:
        if (length != 3u || type >= 8u) return 0;
        s->header_shadow = f->header;
        for (i = 0; i < 4u; ++i) s->group1_quad[i] = f->data[i];
        return 1;
    case 2:
        if (length != 0u || type >= 8u) return 0;
        s->group2_byte = f->data[0];
        return 1;
    default:
        if (type != 1u) return 0;
        switch (length) {
        case 0:
            s->header_shadow = s->pwm_period;
            s->group3_byte = f->data[0];
            return 1;
        case 1:
            s->group3_pair[0] = f->data[0];
            s->group3_pair[1] = f->data[1];
            return 1;
        case 3:
            s->header_shadow = s->pwm_period;
            for (i = 0; i < 4u; ++i) s->group3_quad[i] = f->data[i];
            return 1;
        default:
            return 0;
        }
    }
}

static uint8_t copy_inverted_bit(uint8_t output, uint8_t bit,
                                  uint8_t value, uint8_t source_bit)
{
    uint8_t mask = (uint8_t)(1u << bit);
    return (value & (1u << source_bit)) ? (uint8_t)(output & ~mask)
                                           : (uint8_t)(output | mask);
}

void pdc_led_bank_a(PdcPorts *s, uint8_t pattern)
{
    uint8_t i;
    /* Input bits 0..7 -> RD4, RB3, RB2, RB1, RB0, RD7, RD6, RD5. */
    s->d = copy_inverted_bit(s->d, 4, pattern, 0);
    for (i = 1; i <= 4u; ++i)
        s->b = copy_inverted_bit(s->b, (uint8_t)(4u-i), pattern, i);
    for (i = 5; i <= 7u; ++i)
        s->d = copy_inverted_bit(s->d, (uint8_t)(12u-i), pattern, i);
}

void pdc_led_bank_b(PdcPorts *s, uint8_t pattern)
{
    uint8_t i;
    /* Input bits 0..7 -> RD3, RC0, RC1, RC2, RC3, RD0, RD1, RD2. */
    s->d = copy_inverted_bit(s->d, 3, pattern, 0);
    for (i = 1; i <= 4u; ++i)
        s->c = copy_inverted_bit(s->c, (uint8_t)(i-1u), pattern, i);
    for (i = 5; i <= 7u; ++i)
        s->d = copy_inverted_bit(s->d, (uint8_t)(i-5u), pattern, i);
}

uint8_t pdc_led_bar(uint8_t level)
{
    static const uint8_t values[16] = {
        0,0,1,3,7,15,31,63,127,255,192,0,0,0,0,0
    };
    return level < 16u ? values[level] : 0u;
}

uint16_t pdc_buzzer_period(uint8_t index)
{
    /* These are firmware scheduler counts, not measured milliseconds. */
    static const uint16_t values[16] = {
        0,976,650,488,390,325,278,243,216,194,96,64,48,38,32,1100
    };
    return index < 16u ? values[index] : 0u;
}

void pdc_display_tick(PdcDisplay *s)
{
    if (s->flags & 1u) {
        if (s->phase == 0u && (s->duty_a != 0u || s->duty_b != 0u) &&
            (s->phase != s->duty_a || s->phase != s->duty_b)) {
            /* Branches in original retained although unreachable for this guard. */
            if (!s->duty_a) {
                s->shadow.b |= 15u; s->shadow.c |= 15u; s->shadow.d |= 0x99u;
            }
            if (!s->duty_b) s->shadow.d |= 0x66u;
            s->ports = s->shadow;
        }
        if (s->phase == s->duty_a) {
            s->ports.b |= 15u; s->ports.c |= 15u; s->ports.d |= 0x99u;
        }
        if (s->phase == s->duty_b) s->ports.d |= 0x66u;
        if (++s->phase == 10u) s->phase = 0;
    } else if (!(s->flags & 2u)) {
        s->shadow = s->ports;
        s->ports.b |= 15u; s->ports.c |= 15u; s->ports.d |= 0x99u;
    }
}

uint8_t pdc_config_read(PdcEepromRead read_byte, uint8_t index, uint8_t *value)
{
    static const uint8_t defaults[17] = {
        2,2,1,0,60,2,8,9,3,6,93,112,0,0,100,200,255
    };
    uint8_t a = read_byte(index);
    uint8_t b = read_byte((uint8_t)(index + 100u));
    uint8_t c;
    /* 0x0698..0x06da: first matching pair wins; no repair write. */
    if (a == b) { *value = a; return 0; }
    c = read_byte((uint8_t)(index + 200u));
    if (a == c) { *value = a; return 0; }
    if (b == c) { *value = b; return 0; }
    if (index == 5u) return 1;
    *value = index < 17u ? defaults[index] : 0u;
    return 0;
}

static uint8_t brightness_duty(uint8_t percent, uint8_t trim, uint8_t limit)
{
    uint8_t scale = (uint8_t)(10u - (uint8_t)(trim * 2u));
    uint8_t result;
    if (scale > 10u) scale = 10u;
    result = (uint8_t)(((uint16_t)percent * scale + 50u) / 100u);
    return result < limit ? result : limit;
}

void pdc_group0_apply(PdcGroup0 *s, const PdcCommands *c)
{
    uint8_t type = c->header & 15u, byte, a, b, sound, old;
    if (((c->header >> 4) & 3u) != 0u) return;
    if (c->mode != 2u && c->mode != 4u && c->mode != 6u) return;
    byte = c->group0_quad[c->mode == 2u ? 0 : 1];
    b = pdc_led_bar(byte & 15u);
    a = pdc_led_bar(byte >> 4);
    s->display.duty_b = brightness_duty(s->brightness, s->trim_a, s->limit);
    s->display.duty_a = brightness_duty(s->brightness, s->trim_b, s->limit);
    if (!(type == 14u && c->mode == 6u) &&
        !(type == 15u && c->mode == 4u)) {
        if (type == 1u || type == 2u || type == 4u || type == 6u || type >= 13u)
            pdc_led_bank_a(&s->display.shadow, a);
        if (type == 1u || type == 3u || type == 5u || type == 7u || type >= 13u)
            pdc_led_bank_b(&s->display.shadow, b);
        if (a == 0u && b == 0u && !(s->display.ports.d & 0x66u)) {
            pdc_led_bank_a(&s->display.shadow, 0);
            pdc_led_bank_b(&s->display.shadow, 0);
            s->display.ports = s->display.shadow;
            s->display.flags &= (uint8_t)~1u;
        } else s->display.flags |= 1u;
    }
    if ((c->mode == 4u && (type == 13u || type == 15u)) ||
        (c->mode == 6u && type == 14u)) sound = 0;
    else {
        byte = c->group0_quad[c->mode == 4u ? 3 : 2];
        a = byte & 15u; b = byte >> 4;
        sound = a > b ? a : b;
    }
    old = s->previous_sound;
    s->sound_index = sound;
    if (sound != 0u && !(s->timer2_control & 4u)) {
        s->timer2_control |= 4u;
        s->sound_flags = 0;
    }
    if (sound == 15u) s->sound_flags |= 0x40u;
    else s->sound_flags &= (uint8_t)~0x40u;
    if (sound != old && (sound != 0u || old == 0u)) {
        if (s->sound_flags & 8u) s->sound_flags |= 16u;
        else s->countdown = 0;
    }
    s->previous_sound = sound;
}
