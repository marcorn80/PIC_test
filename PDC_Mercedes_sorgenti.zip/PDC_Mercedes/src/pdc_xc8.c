/* Microchip XC8 integration modules. No main()/ISR: this is NOT a complete
 * firmware image. Compile as objects after selecting PIC16F917 in MPLAB X.
 * No native XC8 build or physical-board validation has been performed. */
#include <xc.h>
#include "pdc_xc8.h"

#pragma config FOSC = HS
#pragma config WDTE = ON
#pragma config PWRTE = ON
#pragma config MCLRE = ON
#pragma config CP = OFF
#pragma config CPD = OFF
#pragma config BOREN = ON
#pragma config IESO = ON
#pragma config FCMEN = OFF
#pragma config DEBUG = OFF

/* Original initialization 0x1484..0x1508, with interrupt enables held OFF.
 * Integrating this requires restoring the complete ISR, event queue,
 * transceiver startup (0x03fc), ADC tasks and application first.
 * Do not call this alone on a vehicle: it does not implement the controller. */
void pdc_hw_prepare_quiescent(void)
{
    INTCON = 0;
    PIE1 = 0;
    LCDCON &= (uint8_t)~0x93u;
    PORTA &= (uint8_t)~0x1au;
    PORTB = (uint8_t)((PORTB | 0x0fu) & ~0x10u);
    PORTC = (uint8_t)((PORTC | 0x0fu) & ~0x20u);
    PORTD = 0xff;
    TRISA = (uint8_t)((TRISA & ~0x1eu) | 0x21u);
    TRISB = 0x20;
    TRISC = 0x80;
    TRISD = 0;
    TRISE |= 7u;
    WPUB = 0;
    CCP1CON = 0;
    T2CON |= 2u;
    PR2 = 0x5a;
    CCPR1L = 0x47;
    OPTION_REG = (uint8_t)((OPTION_REG & ~0x2fu) | 0x85u);
    TMR0 = 0xed;
    SPBRG = 0x3f;
    TXSTA = (uint8_t)((TXSTA & ~0x10u) | 0x44u);
    RCSTA = (uint8_t)((RCSTA & ~0x08u) | 0xc0u);
    WDTCON = (uint8_t)((WDTCON & ~0x1eu) | 0x0au);
    ADCON1 = 0x50;
    ADCON0 = (uint8_t)((ADCON0 & ~0x61u) | 0x80u);
    ANSEL = (uint8_t)((ANSEL & ~0x0eu) | 0xf1u);
    EECON1 &= (uint8_t)~0x80u;
}

/* RX9D/FERR are sampled BEFORE reading RCREG. Deliberate FIFO-order improvement
 * over 0x00b2..0x00dc; wire timing equivalence to that ISR is not claimed. */
uint8_t pdc_hw_rx_poll(PdcReceiver *rx, PdcFrame *frame)
{
    uint8_t status, byte;
    if (RCSTA & 2u) {
        RCSTAbits.CREN = 0;
        RCSTAbits.CREN = 1;
        pdc_rx_reset(rx);
        return PDC_BAD_FRAME;
    }
    if (!PIR1bits.RCIF) return PDC_MORE;
    status = RCSTA;
    byte = RCREG;
    return pdc_rx_byte(rx, byte, status & 1u, status & 4u, frame);
}

/* Original EEPROM reads allow an in-progress write to finish; this lower-level
 * accessor has no original software timeout. Use only when writes are stopped. */
uint8_t pdc_hw_eeprom_read(uint8_t address)
{
    while (EECON1bits.WR) { CLRWDT(); }
    EEADR = address;
    EECON1bits.EEPGD = 0;
    EECON1bits.RD = 1;
    return EEDATA;
}
