#ifndef PDC_XC8_H
#define PDC_XC8_H
#include "pdc_core.h"
void pdc_hw_prepare_quiescent(void);
uint8_t pdc_hw_rx_poll(PdcReceiver *rx, PdcFrame *frame);
uint8_t pdc_hw_eeprom_read(uint8_t address);
#endif
