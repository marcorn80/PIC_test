from pathlib import Path
import ctypes as C
import json
import random
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from hexfile import read_hex, read_words
from pic14 import Pic14

ROOT = Path(__file__).resolve().parents[1]
words = read_words(ROOT/'firmware.hex')
rng = random.Random(917)
counts = {}

class Ports(C.Structure):
    _fields_ = [(x,C.c_uint8) for x in ('b','c','d')]
class Display(C.Structure):
    _fields_ = [('shadow',Ports),('ports',Ports)] + [(x,C.c_uint8) for x in ('flags','phase','duty_a','duty_b')]
class Commands(C.Structure):
    _fields_ = [('mode',C.c_uint8),('header',C.c_uint8),('group2_byte',C.c_uint8),('group3_byte',C.c_uint8),('group3_pair',C.c_uint8*2),('group0_quad',C.c_uint8*4),('group3_quad',C.c_uint8*4),('group1_quad',C.c_uint8*4),('header_shadow',C.c_uint8),('pwm_period',C.c_uint8)]
class Frame(C.Structure):
    _fields_ = [('header',C.c_uint8),('data',C.c_uint8*4),('size',C.c_uint8)]
class Rx(C.Structure):
    _fields_ = [('bytes',C.c_uint8*6),('count',C.c_uint8),('parity_error',C.c_uint8),('framing_error',C.c_uint8)]
class Group0(C.Structure):
    _fields_ = [('display',Display)]+[(x,C.c_uint8) for x in ('brightness','trim_a','trim_b','limit','sound_index','previous_sound','sound_flags','timer2_control')]+[('countdown',C.c_uint16)]

subprocess.run(['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-shared','-fPIC',str(ROOT/'src/pdc_core.c'),'-o',str(ROOT/'build/core.so')],check=True)
lib = C.CDLL(str(ROOT/'build/core.so'))
lib.pdc_even_parity.argtypes = [C.c_uint8]
lib.pdc_even_parity.restype = C.c_uint8
lib.pdc_dispatch.argtypes = [C.POINTER(Commands),C.POINTER(Frame)]
lib.pdc_dispatch.restype = C.c_uint8
lib.pdc_rx_byte.argtypes = [C.POINTER(Rx),C.c_uint8,C.c_uint8,C.c_uint8,C.POINTER(Frame)]
lib.pdc_rx_byte.restype = C.c_uint8
lib.pdc_display_tick.argtypes = [C.POINTER(Display)]
lib.pdc_group0_apply.argtypes = [C.POINTER(Group0),C.POINTER(Commands)]
for name in ('a','b'):
    getattr(lib,'pdc_led_bank_'+name).argtypes = [C.POINTER(Ports),C.c_uint8]
lib.pdc_led_bar.argtypes = [C.c_uint8]
lib.pdc_led_bar.restype = C.c_uint8
lib.pdc_buzzer_period.argtypes = [C.c_uint8]
lib.pdc_buzzer_period.restype = C.c_uint16
READ = C.CFUNCTYPE(C.c_uint8,C.c_uint8)
lib.pdc_config_read.argtypes = [READ,C.c_uint8,C.POINTER(C.c_uint8)]
lib.pdc_config_read.restype = C.c_uint8

# Complete program, raw user-ID words, config word and EEPROM must match exactly.
assert read_hex(ROOT/'firmware.hex') == read_hex(ROOT/'build/recovered.hex')
assert read_hex(ROOT/'firmware.hex') == read_hex(ROOT/'build/readable.hex')
counts['lossless_hex_bytes'] = len(read_hex(ROOT/'firmware.hex'))

for value in range(256):
    pic=Pic14(words); pic.ram[0x40]=value; pic.w=0x40
    result=pic.run(0x421)
    assert result == lib.pdc_even_parity(value) == value.bit_count()%2
counts['parity_differential'] = 256

for name,start,bank in [('a',0x1fd5,0x36),('b',0x1faa,0x37)]:
    for value in range(256):
        pic=Pic14(words)
        initial=[rng.randrange(256) for _ in range(3)]
        pic.ram[0x36:0x39]=bytes(initial); pic.w=value
        pic.run(start)
        state=Ports(*initial)
        getattr(lib,'pdc_led_bank_'+name)(C.byref(state),value)
        assert bytes(state)==pic.ram[0x36:0x39],(name,value)
counts['led_mapping_differential'] = 512

for level in range(16):
    assert lib.pdc_led_bar(level) == words[0x1822+level]&255
    period=(words[0x1801+2*level]&255)|((words[0x1802+2*level]&255)<<8)
    assert lib.pdc_buzzer_period(level)==period
counts['table_entries'] = 32

for mode in range(8):
    for header in range(256):
        initial=bytes(rng.randrange(256) for _ in range(C.sizeof(Commands)))
        s=Commands.from_buffer_copy(initial); s.mode=mode
        pic=Pic14(words)
        addresses=[0x122,0x127,0x128,0x129,0x12b,0x12c,*range(0x12d,0x131),*range(0x135,0x139),*range(0x139,0x13d),0x3d,0x92]
        for a,v in zip(addresses,bytes(s)): pic.ram[a]=v
        data=[rng.randrange(256) for _ in range(4)]
        frame=Frame(header,(C.c_uint8*4)(*data),(header>>6)+1)
        pic.ram[0x127]=header
        pic.ram[0x192:0x197]=bytes([header]+data)
        expected=pic.run(0x21e)
        actual=lib.pdc_dispatch(C.byref(s),C.byref(frame))
        assert actual==expected,('dispatch result',mode,hex(header),actual,expected)
        assert bytes(s)==bytes(pic.ram[a] for a in addresses),('dispatch state',mode,hex(header))
counts['command_dispatch_differential'] = 2048

for phase in range(10):
    for duty_a in range(11):
        for duty_b in range(11):
            for flags in (0,1,2,3):
                initial=[rng.randrange(256) for _ in range(6)]
                state=Display(Ports(*initial[:3]),Ports(*initial[3:]),flags,phase,duty_a,duty_b)
                pic=Pic14(words)
                pic.ram[0x36:0x39]=bytes(initial[:3]);pic.ram[6:9]=bytes(initial[3:])
                pic.ram[0xce]=flags;pic.ram[0xd1]=phase
                pic.ram[0xc0]=duty_a;pic.ram[0xbf]=duty_b
                pic.run(0x3a,stop=0x8d)
                lib.pdc_display_tick(C.byref(state))
                actual=bytes(state)
                expected=bytes(pic.ram[0x36:0x39]+pic.ram[6:9])+bytes([flags,pic.ram[0xd1],duty_a,duty_b])
                assert actual==expected,('display',phase,duty_a,duty_b,flags,actual.hex(),expected.hex())
counts['display_tick_differential'] = 4840

for index in range(17):
    for triple in [(2,2,2),(1,1,2),(1,2,1),(2,1,1),(1,2,3)]:
        eeprom=bytearray(rng.randrange(256) for _ in range(256))
        for address,value in zip((index,index+100,index+200),triple):eeprom[address]=value
        callback=READ(lambda a:eeprom[a]);out=C.c_uint8(0xa5)
        result=lib.pdc_config_read(callback,index,C.byref(out))
        pic=Pic14(words);pic.eeprom=eeprom;pic.w=index
        if index==5 and len(set(triple))==3:
            assert result==1
            try:pic.run(0x698,limit=2000)
            except RuntimeError:assert pic.pc in (0x1e04,0x1e05,0x1e06)
            else:raise AssertionError('Expected original halt')
        else:
            expected=pic.run(0x698)
            assert result==0 and out.value==expected,(index,triple,out.value,expected)
counts['eeprom_majority_differential'] = 85

# Whole-frame differential against original parser 0x0438, prefilled software
# RX queue. Does not validate the original interrupt's FIFO sampling order.
for header in range(256):
    size=(header>>6)+1
    data=[rng.randrange(256) for _ in range(size)]
    packet=[header]+data
    packet.append(sum(packet)&255)
    for fault in ('none','checksum','parity','framing'):
        wire=packet[:]
        if fault=='checksum':wire[-1]^=1
        pic=Pic14(words)
        # Queue 0x19c.., each character consists of data + ninth bit.
        for i,b in enumerate(wire):
            pic.ram[0x19c+2*i]=b
            pic.ram[0x19d+2*i]=lib.pdc_even_parity(b) ^ (fault=='parity' and i==1)
        pic.ram[0x3b]=len(wire)
        pic.ram[0x121]=1
        if fault=='framing':pic.ram[0xd8]|=16
        rx=Rx();frame=Frame()
        for i,b in enumerate(wire):
            result=lib.pdc_rx_byte(C.byref(rx),b,lib.pdc_even_parity(b)^(fault=='parity' and i==1),fault=='framing' and i==len(wire)-1,C.byref(frame))
            if i<len(wire)-1:assert result==0
        for _ in wire:pic.run(0x438)
        accepted=pic.ram[0x121]==0
        assert accepted==(result==1),(hex(header),fault,result,accepted)
        if accepted:
            assert frame.header==pic.ram[0x127]==header
            assert bytes(frame.data)[:size]==bytes(pic.ram[0x193:0x193+size])
counts['rx_frame_differential'] = 1024

for mode in (2,4,6):
    for kind in (1,mode,mode+1,13,14,15):
        for _ in range(64):
            p=Pic14(words)
            s=Group0()
            s.display.shadow=Ports(*(rng.randrange(256) for _ in range(3)))
            s.display.ports=Ports(*(rng.randrange(256) for _ in range(3)))
            s.display.flags=rng.randrange(256)
            s.display.phase=rng.randrange(10)
            s.brightness=rng.randrange(101)
            s.trim_a=rng.randrange(6);s.trim_b=rng.randrange(6);s.limit=rng.randrange(11)
            s.previous_sound=rng.randrange(16);s.sound_flags=rng.randrange(256)
            s.timer2_control=rng.randrange(16);s.countdown=rng.randrange(65536)
            c=Commands();c.mode=mode;c.header=0xc0|kind
            for i in range(4):c.group0_quad[i]=rng.randrange(256)
            p.ram[0x122]=mode;p.ram[0x127]=c.header
            p.ram[0x12d:0x131]=bytes(c.group0_quad)
            p.ram[0x36:0x39]=bytes(s.display.shadow);p.ram[6:9]=bytes(s.display.ports)
            p.ram[0xce]=s.display.flags;p.ram[0xd1]=s.display.phase
            p.ram[0x120]=s.brightness;p.ram[0x1b0]=s.trim_a;p.ram[0x1b1]=s.trim_b;p.ram[0xd9]=s.limit
            p.ram[0x1b4]=s.previous_sound;p.ram[0x1b2]=s.sound_flags
            p.ram[0x12]=s.timer2_control;p.ram[0xd6]=s.countdown&255;p.ram[0xd7]=s.countdown>>8
            p.run(0x8ce,limit=50000)
            lib.pdc_group0_apply(C.byref(s),C.byref(c))
            actual=[*bytes(s.display.shadow),*bytes(s.display.ports),s.display.flags,s.display.duty_a,s.display.duty_b,s.sound_index,s.previous_sound,s.sound_flags,s.timer2_control,s.countdown]
            expected=[*p.ram[0x36:0x39],*p.ram[6:9],p.ram[0xce],p.ram[0xc0],p.ram[0xbf],p.ram[0xd2],p.ram[0x1b4],p.ram[0x1b2],p.ram[0x12],p.ram[0xd6]|p.ram[0xd7]<<8]
            assert actual==expected,('group0',mode,kind,actual,expected)
counts['group0_application_differential'] = 1152
print(json.dumps(counts,indent=2))
(ROOT/'build/validation.json').write_text(json.dumps(counts,indent=2)+'\n')
