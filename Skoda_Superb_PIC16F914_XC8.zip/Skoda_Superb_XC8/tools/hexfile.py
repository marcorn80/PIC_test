from pathlib import Path

def read_hex(path):
    raw = Path(path).read_bytes()
    # The supplied file uses literal backslash-r/backslash-n separators.
    text = raw.decode('ascii').replace('\\r\\n', '\n')
    memory, base, eof = {}, 0, False
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        if eof or not line.startswith(':'):
            raise ValueError(f'Invalid record at line {number}')
        record = bytes.fromhex(line[1:])
        if len(record) < 5 or len(record) != record[0] + 5 or sum(record) & 255:
            raise ValueError(f'Bad length/checksum at line {number}')
        address = int.from_bytes(record[1:3], 'big')
        kind, data = record[3], record[4:-1]
        if kind == 0:
            for offset, value in enumerate(data):
                key = base + address + offset
                if key in memory:
                    raise ValueError(f'Overlapping records at {key:#x}')
                memory[key] = value
        elif kind == 4 and len(data) == 2:
            base = int.from_bytes(data, 'big') << 16
        elif kind == 2 and len(data) == 2:
            base = int.from_bytes(data, 'big') << 4
        elif kind == 1 and not data:
            eof = True
        else:
            raise ValueError(f'Unsupported record type {kind}')
    if not eof:
        raise ValueError('Missing EOF')
    return memory

def read_words(path):
    memory = read_hex(path)
    if any(a % 2 or a+1 not in memory for a in memory if a % 2 == 0):
        raise ValueError('Incomplete word')
    if any(a-1 not in memory for a in memory if a % 2):
        raise ValueError('Unpaired high byte')
    return {a//2: memory[a] | memory[a+1] << 8 for a in memory if not a % 2}
