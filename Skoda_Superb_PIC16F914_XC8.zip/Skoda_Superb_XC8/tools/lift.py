"""Translate only the original reachable arithmetic/render routines into C.
No target execution, instruction fetch loop or firmware interpreter in output.
Addresses and byte arithmetic are retained for auditing. SPI/ISR/main are C.
"""
from pathlib import Path
from hexfile import read_words
root=Path(__file__).resolve().parents[1];words=read_words(root/'firmware_original.hex')
entries={0x31:'signed_div',0x91:'multiply',0xa7:'divide_byte',0xb6:'multiply_byte',0xc5:'shift_right',0xcf:'shift_left',0xec:'clock',0x2c2:'temperature',0xb5d:'brightness'}
# Statically known PCLATH pages for local branches in these routines. The sole
# banking operations are selection for compiler/SFR access; renderer RAM is bank0.
def target(a,op):return (a&0x1800)|(op&0x7ff)
def successors(a):
 op=words[a]
 if op==8:return []
 if op&0x3800==0x2800:return [target(a,op)]
 if op&0x3800==0x2000:return [a+1]
 if op&0x3c00 in (0x1800,0x1c00) or op&0x3f00 in (0xb00,0xf00):return [a+1,a+2]
 return [a+1]
def discover(start):
 seen=set();todo=[start]
 while todo:
  a=todo.pop()
  if a in seen:continue
  assert a<0x1000
  seen.add(a);todo.extend(successors(a))
 return seen
funcs={a:discover(a) for a in entries}
def r(f):
 if f==0:return 'R[R[4]]'
 return f'R[0x{f:02x}]'
def bit(f,b):
 if f==3:
  assert b in (0,1,2,5,6,7)
  return {0:'carry',1:'dc',2:'zero',5:'0',6:'0',7:'0'}[b]
 return f'({r(f)} & 0x{1<<b:02x}u)'
def line(a):
 op=words[a];f=op&127;d=bool(op&128);k=op&255
 dest=r(f) if d else 'w';val=r(f)
 if op==8:return 'return;'
 if op==0:return ';'
 if op&0x3800==0x2800:return f'goto L{target(a,op):04x};'
 if op&0x3800==0x2000:
  t=op&0x7ff
  assert t in entries,(hex(a),hex(t))
  return f'core_{entries[t]}();'
 if op&0x3f80==0x80:return f'{r(f)} = w;'
 if op&0x3f80==0x180:return f'{r(f)} = 0; zero = 1;'
 if op&0x3000==0x1000:
  b=(op>>7)&7;kind=(op>>10)&3
  if f==10:return '; /* PCLATH handled by native C control flow */'
  if kind>=2:
   cond=bit(f,b)
   return f'if ({"!" if kind==2 else ""}({cond})) goto L{a+2:04x};'
  if f==3:
   if b in (5,6,7):return '; /* Original bank selection */'
   return f'{bit(f,b)} = {kind};'
  return f'{val} {"|=" if kind else "&="} 0x{(1<<b) if kind else 255^(1<<b):02x}u;'
 if op&0x3c00==0x3000:return f'w = 0x{k:02x};'
 if op&0x3f00 in (0x3800,0x3900,0x3a00):
  return f'w { {0x3800:"|=",0x3900:"&=",0x3a00:"^="}[op&0x3f00]} 0x{k:02x}; zero = (w == 0);'
 if op&0x3e00 in (0x3c00,0x3e00):
  if op&0x3e00==0x3c00:return f'tmp = (uint16_t)0x{k:02x} - w; carry = (0x{k:02x}u >= w); dc = ((0x{k:02x}u & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0);'
  return f'tmp = (uint16_t)w + 0x{k:02x}u; carry = (tmp > 255u); dc = ((w & 15u) + (0x{k:02x}u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0);'
 kind=(op>>8)&15
 if kind in (2,7):
  if kind==2:s=f'tmp = (uint16_t){val} - w; carry = ({val} >= w); dc = (({val} & 15u) >= (w & 15u));'
  else:s=f'tmp = (uint16_t){val} + w; carry = (tmp > 255u); dc = (({val} & 15u) + (w & 15u) > 15u);'
  return s+f' {dest} = (uint8_t)tmp; zero = ({dest} == 0);'
 expr={3:f'{val} - 1u',4:f'{val} | w',5:f'{val} & w',6:f'{val} ^ w',8:val,9:f'{val} ^ 255u',10:f'{val} + 1u',11:f'{val} - 1u',14:f'({val} >> 4) | ({val} << 4)',15:f'{val} + 1u'}
 if kind in (12,13):
  return f'tmp = {val}; {dest} = (uint8_t)((tmp {">> 1) | (carry << 7)" if kind==12 else "<< 1) | carry"}); carry = (uint8_t)((tmp {"& 1u" if kind==12 else ">> 7"}));'
 assert kind in expr,(hex(a),hex(op))
 s=f'{dest} = (uint8_t)({expr[kind]});'
 if kind in range(2,11):s+=f' zero = ({dest} == 0);'
 if kind in (11,15):s+=f' if ({dest} == 0) goto L{a+2:04x};'
 return s
out=['/* Generated from the supplied PIC16F914 HEX. Native C, not an emulator. */','#include "skoda.h"','uint8_t R[128];','static uint8_t w, carry, dc, zero;','static uint16_t tmp;']
for name in entries.values():out.append(f'void core_{name}(void);')
collapsed = 0
for start,seen in funcs.items():
    replacements = {}; omitted = set()
    for a in sorted(seen):
        if words[a] != 0x0863 or words.get(a+1)!=0x3e40 or words.get(a+2)!=0x0084 or words.get(a+3)!=0x3000: continue
        b = a+4
        if words.get(b)==0x1383: b+=1
        op=words.get(b,0)
        if op & 0x3c7f != 0x1800 or words.get(b+1)!=0x3001 or words.get(b+2)!=0x3a00 or words.get(b+3)!=0x1d03: continue
        yes=target(b+4,words[b+4]);no=target(b+5,words[b+5])
        yp=words[yes];np=words[no]
        if yp&0x3c00!=0x1400 or np != (yp & ~0x400) or words[yes+1]&0x3800!=0x2800:continue
        end=target(yes+1,words[yes+1]);register=yp&127;mask=1<<((yp>>7)&7);srcmask=1<<((op>>7)&7)
        replacements[a]=f'tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x{srcmask:02x}u) != 0); zero = !w; if (w) R[0x{register:02x}] |= 0x{mask:02x}u; else R[0x{register:02x}] &= 0x{255^mask:02x}u; goto L{end:04x};'
        omitted.update(range(a+1,no+1));collapsed+=1

    out.append(f'\n/* Original entry 0x{start:04x}, word addresses. Non-reentrant. */\nvoid core_{entries[start]}(void) {{')
    out.append(f'goto L{start:04x};')
    for a in sorted(seen):
     if a not in omitted:out.append(f'L{a:04x}: {replacements.get(a) or line(a)} /* {words[a]:04x} */')
    out.append('}')
(root/'src/render_lifted.c').write_text('\n'.join(out)+'\n')
print('Generated routines', {entries[a]:len(s) for a,s in funcs.items()})

print('Segment blocks collapsed:',collapsed)
