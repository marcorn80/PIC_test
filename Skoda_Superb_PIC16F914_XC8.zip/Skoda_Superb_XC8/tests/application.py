from pathlib import Path
import ctypes as C,subprocess,sys
root=Path(__file__).resolve().parents[1]
subprocess.run(['gcc','-std=c99','-O2','-shared','-fPIC',str(root/'src/skoda.c'),str(root/'src/render_lifted.c'),'-o',str(root/'build/application.so')],check=True)
l=C.CDLL(str(root/'build/application.so'));r=(C.c_uint8*128).in_dll(l,'R')
l.skoda_frame.argtypes=[C.c_uint16,C.POINTER(C.c_uint8),C.c_uint8]
def frame(id,hexbytes):
 d=bytes.fromhex(hexbytes);a=(C.c_uint8*len(d))(*d);l.skoda_frame(id,a,len(d))
l.skoda_init();assert not r[0x50];assert not any(r[0x56:0x62])
frame(0x65d,'00 00 00 00 00 C0 44 00')
frame(0x527,'00 00 00 00 00 96 00 00')
assert r[0x21]==0x44 and r[0x22]==0xc0 and r[0x51]==150
assert not any(r[0x56:0x62])
frame(0x575,'02 00 00 00 00 00 00 00');assert r[0x50]==1;assert any(r[0x56:0x62])
before=bytes(r[0x56:0x62]);frame(0x60e,'82 00 00 00 00 00 00 00');assert r[0x52]==0x82;assert before!=bytes(r[0x56:0x62])
frame(0x635,'32 00 80 00 00 00 00 00');assert r[0x53]==50 and r[0x54]==128 and r[0x26]==20
pwm=(r[0x15]<<2)|((r[0x17]>>4)&3)
assert 0<=pwm<=700
for _ in range(20):l.skoda_tick()
assert r[0x26]==0
for _ in range(134):l.skoda_tick()
assert r[0x21]&128 and r[0x51]==255
before=bytes(r);frame(0x65d,'00 00');assert bytes(r)==before
frame(0x575,'00 00 00 00 00 00 00 00');assert not r[0x50]
print('Application scenario passed: receive while off, enable, units, brightness, three timeouts, short DLC, disable; sample PWM',pwm)
