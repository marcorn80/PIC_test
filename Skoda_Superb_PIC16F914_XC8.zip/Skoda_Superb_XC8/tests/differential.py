from pathlib import Path
import sys,ctypes as C,subprocess,random,json
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'tests')]
from hexfile import read_words
from pic14 import Pic14
words=read_words(ROOT/'firmware_original.hex')
subprocess.run(['gcc','-std=c99','-O2','-shared','-fPIC',str(ROOT/'src/render_lifted.c'),'-o',str(ROOT/'build/core.so')],check=True)
lib=C.CDLL(str(ROOT/'build/core.so'));ram=(C.c_uint8*128).in_dll(lib,'R');rng=random.Random(914)
initial=bytearray(128)
initial[0x20:0x50]=bytes(words[a]&255 for a in range(0x72c,0x75c))
counts={}
for name,entry,count in [('clock',0xec,4096),('temperature',0x2c2,2048),('brightness',0xb5d,1024)]:
 for i in range(count):
  p=Pic14(words);p.ram[:128]=initial
  for a in [0x21,0x22,0x23,0x26,0x51,0x52,0x53,0x54,*range(0x56,0x62)]:p.ram[a]=rng.randrange(256)
  if name=='temperature':p.ram[0x51]=i%256;p.ram[0x23]=(i//256)%2;p.ram[0x52]=(i//512)%4
  if name=='clock':p.ram[0x21]=(i%64)*2|((i//64)%2);p.ram[0x22]=((i//128)%16)<<4;p.ram[0x52]=128 if i&2048 else 0
  # Native C's emulated SFR outputs are seeded exactly like the reference.
  p.ram[0x15]=rng.randrange(256);p.ram[0x17]=rng.randrange(256)
  ram[:]=p.ram[:128]
  p.run(entry,limit=100000)
  getattr(lib,'core_'+name)()
  checked=[*range(0x56,0x62)] if name!='brightness' else [0x15,0x17]
  assert all(ram[a]==p.ram[a] for a in checked),(name,i,[(hex(a),ram[a],p.ram[a]) for a in checked if ram[a]!=p.ram[a]])
 counts[name]=count
print(json.dumps(counts));(ROOT/'build/differential.json').write_text(json.dumps(counts,indent=2)+'\n')
