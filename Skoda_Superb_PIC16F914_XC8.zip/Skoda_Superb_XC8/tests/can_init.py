from pathlib import Path
import sys,re
root=Path(__file__).resolve().parents[1];sys.path[:0]=[str(root/'tools'),str(root/'tests')]
from hexfile import read_words
from pic14 import Pic14
class SpiReference(Pic14):
 def __init__(self,words):
  super().__init__(words);self.packet=[];self.packets=[];self.ram[8]=32
 def write(self,f,value):
  address=self.canonical(self.address(f));old=self.ram[8]
  super().write(f,value)
  if address==8:
   if old&32 and not value&32:self.packet=[]
   if not old&32 and value&32:self.packets.append(self.packet[:])
  if address==0x13:
   self.packet.append(value&255);self.ram[0x94]|=1
   self.ram[0x13]=128 if len(self.packet)==3 and self.packet[:2]==[3,14] else 0
w=read_words(root/'firmware_original.hex');p=SpiReference(w);p.run(0x936,stop=0xa6b,limit=100000)
original=[x[1:] for x in p.packets if x and x[0]==2]
source=(root/'src/main.c').read_text().split('pairs[][2]={')[1].split('};')[0]
pairs=[[int(a,0),int(b,0)] for a,b in re.findall(r'\{(0x[0-9a-f]+|\d+),(0x[0-9a-f]+|\d+)\}',source)]
assert original==[[15,128]]+pairs+[[15,96]],(original,pairs)
cnf={a:b for a,b in pairs};brp=cnf[42]&63
prop=(cnf[41]&7)+1;ph1=((cnf[41]>>3)&7)+1;ph2=(cnf[40]&7)+1
assert 8000000/(2*(brp+1)*(1+prop+ph1+ph2))==100000
print('MCP2515 init: all',len(original),'register writes match original instructions; bitrate 100000 bit/s')
