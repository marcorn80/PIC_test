"""Small instruction-level reference for bounded routine tests only.

No cycle-accurate peripherals, oscillator, watchdog, interrupts or LIN electrical
model. Runs the original instructions; does not load a native executable.
"""
class Pic14:
    def __init__(self, words):
        self.words = words
        self.ram = bytearray(512)
        self.w = 0
        self.pc = 0
        self.stack = []
        self.eeprom = bytearray(256)

    def canonical(self, address):
        low = address & 127
        if low in (2,3,4,10,11) or low >= 112:
            return low
        if address in (0x101,0x106):
            return address - 0x100
        if address in (0x181,0x186):
            return address - 0x100
        return address

    def address(self, f):
        if f == 0:
            return ((self.ram[3] & 128) << 1) | self.ram[4]
        return ((self.ram[3] & 96) << 2) | f

    def read(self, f):
        address = self.address(f)
        if f == 0 and not address & 127:
            return 0
        address = self.canonical(address)
        return self.pc & 255 if address == 2 else self.ram[address]

    def write(self, f, value):
        address = self.address(f)
        if f == 0 and not address & 127:
            return
        address = self.canonical(address)
        value &= 255
        if address == 2:
            self.pc = ((self.ram[10] & 31) << 8) | value
        else:
            self.ram[address] = value
        if address == 0x18c and value & 1:
            if value & 128:
                raise NotImplementedError('Program-memory read')
            self.ram[0x10c] = self.eeprom[self.ram[0x10d]]
            self.ram[address] &= ~1

    def flag(self, bit, on):
        self.ram[3] = (self.ram[3] & ~(1 << bit)) | (bool(on) << bit)

    def run(self, start, stop=0x2000, limit=20000):
        self.pc = start
        # Model the caller's page selection for this isolated entry point.
        self.ram[10] = (start >> 8) & 24
        self.stack = [stop]
        for _ in range(limit):
            if self.pc == stop:
                return self.w
            p = self.pc
            ins = self.words[p]
            self.pc = (self.pc + 1) & 0x1fff
            f, d, k = ins & 127, bool(ins & 128), ins & 255
            if ins == 0:
                continue
            if ins in (8,9):
                self.pc = self.stack.pop()
                if ins == 9: self.ram[11] |= 128
                continue
            if ins in (0x64,0x63):
                self.flag(3, True); self.flag(4, True)
                continue
            if ins & 0x3800 in (0x2000,0x2800):
                if ins & 0x3800 == 0x2000: self.stack.append(self.pc)
                self.pc = ((self.ram[10] & 24) << 8) | (ins & 0x7ff)
                continue
            if ins & 0x3f80 == 0x80:
                self.write(f, self.w)
                continue
            if ins == 0x100:
                self.w = 0; self.flag(2, True)
                continue
            if ins & 0x3f80 == 0x180:
                self.write(f, 0); self.flag(2, True)
                continue
            if ins & 0x3000 == 0x1000:
                bit, op = (ins >> 7) & 7, (ins >> 10) & 3
                value = self.read(f)
                if op == 0: self.write(f, value & ~(1 << bit))
                elif op == 1: self.write(f, value | (1 << bit))
                elif (op == 2 and not value & (1 << bit)) or (op == 3 and value & (1 << bit)):
                    self.pc = (self.pc + 1) & 0x1fff
                continue
            if ins & 0x3c00 == 0x3000:
                self.w = k
                continue
            if ins & 0x3c00 == 0x3400:
                self.w = k; self.pc = self.stack.pop()
                continue
            if ins & 0x3f00 in (0x3800,0x3900,0x3a00,0x3c00,0x3d00,0x3e00,0x3f00):
                op = ins & 0x3f00
                old = self.w
                if op == 0x3800: result = old | k
                elif op == 0x3900: result = old & k
                elif op == 0x3a00: result = old ^ k
                elif op in (0x3c00,0x3d00):
                    result = k - old
                    self.flag(0, result >= 0); self.flag(1, (k & 15) >= (old & 15))
                else:
                    result = old + k
                    self.flag(0, result > 255); self.flag(1, (old & 15)+(k & 15)>15)
                self.w = result & 255; self.flag(2, self.w == 0)
                continue
            op = (ins >> 8) & 15
            value, carry = self.read(f), self.ram[3] & 1
            if op == 2:
                result = value - self.w
                self.flag(0, result >= 0); self.flag(1, (value & 15) >= (self.w & 15))
            elif op == 3: result = value - 1
            elif op == 4: result = value | self.w
            elif op == 5: result = value & self.w
            elif op == 6: result = value ^ self.w
            elif op == 7:
                result = value + self.w
                self.flag(0, result > 255); self.flag(1, (value & 15)+(self.w & 15)>15)
            elif op == 8: result = value
            elif op == 9: result = value ^ 255
            elif op == 10: result = value + 1
            elif op == 11: result = value - 1
            elif op == 12:
                result = (value >> 1) | (carry << 7); self.flag(0, value & 1)
            elif op == 13:
                result = (value << 1) | carry; self.flag(0, value & 128)
            elif op == 14: result = (value >> 4) | (value << 4)
            elif op == 15: result = value + 1
            else: raise NotImplementedError(f'{p:04x}: {ins:04x}')
            result &= 255
            if d: self.write(f, result)
            else: self.w = result
            if op in range(2,11): self.flag(2, result == 0)
            if op in (11,15) and not result: self.pc = (self.pc+1) & 0x1fff
        raise RuntimeError(f'Instruction limit at PC={self.pc:04x}')
