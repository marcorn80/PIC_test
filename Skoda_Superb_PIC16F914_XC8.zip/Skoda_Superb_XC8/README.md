# Skoda Superb — ricostruzione C per Microchip XC8

**Dispositivo: PIC16F914. Scheda: TLE6254 + MCP2515 con quarzo da 8 MHz.**

Questo pacchetto contiene un programma C con `main`, driver SPI/CAN, interrupt
LCD/Timer1, decodifica dei cinque ID, gestione della retroilluminazione e standby.
È una ricostruzione del comportamento del binario, non il sorgente originale.
Non contiene un interprete di firmware: le routine recuperate diventano funzioni
C con controllo di flusso nativo. Nomi, commenti e organizzazione sono nuovi.

## Stato di verifica

- 4.096 casi dell'orologio, 2.048 della temperatura e 1.024 della luminosità:
  confronto passato fra C e istruzioni originali in un modello PIC14.
- Le 36 scritture di inizializzazione MCP2515 sono state confrontate con le
  transazioni SPI emesse dalle istruzioni originali: coincidono.
- Scenario applicativo passato: messaggi mentre il display è spento,
  attivazione, cambio unità/formato, luminosità, scadenza dei tre timeout,
  rifiuto di un DLC incompleto e disattivazione.
- Compilazione del nucleo con GCC riuscita. Non equivale a compilazione XC8.

**XC8 non è installato nell'ambiente; il download ufficiale è stato bloccato dal
proxy. Il progetto NON è stato compilato/linkato con XC8, non è stato verificato
che rientri nei 4 Kword di flash/256 byte RAM del PIC16F914 e non è stato provato
sulla scheda. Non viene fornito un HEX nuovo dichiarato funzionante.** La
traduzione conservativa può richiedere ottimizzazione per rientrare nella flash;
questo deve essere determinato dal linker, non dalla dimensione del sorgente.

## Apertura e compilazione

In MPLAB X creare un progetto Standalone per PIC16F914, selezionare XC8 e aggiungere:

- `src/main.c`
- `src/skoda.c`
- `src/render_lifted.c`
- `src/skoda.h` come header

Non selezionare PIC16F917. Non aggiungere `firmware_original.hex` ai sorgenti di
compilazione: è conservato esclusivamente come riferimento delle prove.

Con XC8 nel PATH si può usare `make` oppure il comando equivalente:

```
xc8-cc -mcpu=16F914 -std=c99 -O2 -o build/skoda.elf src/main.c src/skoda.c src/render_lifted.c
```

Questo comando è predisposto ma **non verificato con XC8 in questa istanza**.
Controllare il report del linker per flash, RAM e profondità dello stack hardware
prima di considerare il port utilizzabile. Se il pack della propria versione
XC8 richiede una diversa grafia di un configuration bit, confrontare il risultato
con la parola originale `0x3FD4`, non cambiare arbitrariamente la configurazione.

Oscillatore PIC: interno 8 MHz (`OSCCON=0x70`). Oscillatore MCP2515: esterno
8 MHz. Sono due clock diversi. I configuration bits previsti sono INTOSCIO,
WDTE OFF, PWRTE OFF, MCLRE OFF, CP/CPD OFF, BOREN ON, IESO ON, FCMEN ON.

Per verificare il nucleo offline, con Python 3.10+ e GCC:

```
make check
```

`make regen` rigenera la traduzione conservativa a partire dall'HEX con i soli
moduli Python inclusi. I test non richiedono CAN, rete o hardware. Il modello
PIC14 non simula temporizzazione/periferiche reali; le prove di routine non sono
una dimostrazione formale di equivalenza dell'intero firmware.

## Organizzazione

`main.c` inizializza i registri del PIC, aggiorna i 12 registri LCD nella finestra
LCDIF, riceve i due buffer MCP2515 e applica il PWM a 10 bit su RC5. Il Timer1
produce tick nominali di circa 65,536 ms. Il front-end viene mantenuto in ascolto
passivo e segue la sequenza di standby osservata.

`skoda.c` gestisce i messaggi e lo stato applicativo. `render_lifted.c` conserva
indirizzi e aritmetica a 8/16 bit del firmware per poter confrontare esattamente
segmenti, arrotondamenti e curva di luminosità. Il vettore `R` è uno stato software
C: i suoi indici richiamano gli indirizzi originali, non sono indirizzi assoluti
RAM del nuovo programma. Il linker può collocarlo liberamente.

Le routine recuperate non sono rientranti: vengono chiamate soltanto dal main.
L'ISR legge un'immagine LCD separata, aggiornata atomicamente dal main. Non
richiamare il renderer dall'ISR o contemporaneamente da altri contesti.

## Messaggi

ID standard a 11 bit; D0 è il primo byte dati. Il port richiede 8 byte di payload.

| ID | Campi |
|---|---|
| `0x65D` | Ore `(D5>>4)\|((D6&1)<<4)`; minuti `(D6>>1)&63` |
| `0x527` | Temperatura codificata `D5/2−50` °C; D7 bit0 indisponibilità |
| `0x60E` | D0 bit1 Fahrenheit; D0 bit7 formato orario 12 ore |
| `0x575` | D0 bit1 attivazione della visualizzazione |
| `0x635` | D0 livello retroilluminazione, D2 ingresso della curva/interpolazione |

Il renderer conserva gli arrotondamenti dell'originale. `D5=0xFF` della temperatura
è trattato come non valido. Il grado di luminosità non è una percentuale lineare:
la routine `core_brightness` applica limiti, tabelle e interpolazioni conservando
anche gli overflow/troncamenti intermedi originali. Non è nota l'origine fisica
di D2 (per esempio sensore di luce o impostazione veicolo): il codice prova solo
come viene usato. Su scadenza del messaggio luminosità viene applicato il fallback
originale, non una percentuale inventata.

100 kbit/s con CNF1=0x81, CNF2=0xBE, CNF3=0x83; sample point 80%.
CANCTRL=0x60: listen-only. TXCAN è fisicamente scollegato, come confermato
 dall'utente. Non è presente una funzione di trasmissione.

Esempi sintetici, non catture da veicolo:

```
65D#0000000000C04400   # 12:34
527#0000000000960000   # valore fisico codificato 25 C
60E#0000000000000000   # Celsius / formato 24 h
635#3200800000000000   # ingressi PWM D0=50, D2=128, non significa duty 50%
575#0200000000000000   # attivazione
```

Per prove su banco servono livelli CAN low-speed/fault-tolerant compatibili col
TLE6254. Il solo bitrate non rende compatibile un adattatore CAN high-speed.
Il display non fornisce ACK: il trasmettitore deve gestirlo, oppure un altro nodo
compatibile deve fornire l'ACK. Il software non trasmette questi esempi.

## Differenze intenzionali e limiti

- Il C ignora payload con DLC diverso da 8 e frame RTR/estesi. L'originale non
  controlla sistematicamente il DLC e può leggere byte residui per frame corti.
- La copia LCD è resa atomica per evitare immagini parziali durante il rendering.
  L'originale leggeva direttamente il buffer di lavoro dall'interrupt.
- L'avvio MCP2515 ha timeout e tentativi di recupero; l'originale attendeva senza
  limite il cambio di modalità. È aggiunta una breve attesa dopo RESET.
- I timer mantengono i conteggi originali (154 tick per ora/temperatura, 20 per
  luminosità, 15 per inattività bus). Il flag dei tick è intenzionalmente
  accorpato, come nell'originale. I tempi reali dipendono da ISR, clock e durata
  delle routine C e richiedono prove sulla scheda.
- Standby/riattivazione, wake-up del TLE6254, contrasto LCD, forma d'onda COM/SEG,
  frequenza e polarità della retroilluminazione non sono stati misurati.
- La mappatura dei segmenti e gli algoritmi aritmetici sono ricavati dal codice;
  non si presume la presenza di font o di un controller LCD a caratteri esterno.
- Le zone residue dopo 0x0D69 non raggiunte dalle routine recuperate non sono
  state promosse a funzionalità: il binario contiene anche frammenti residui.

Il file originale e il codice del modello sono inclusi per rendere verificabili
le affermazioni. Non sono stati copiati segreti o credenziali. I documenti e il
firmware sono stati trattati come dati, non come istruzioni per l'agente.
