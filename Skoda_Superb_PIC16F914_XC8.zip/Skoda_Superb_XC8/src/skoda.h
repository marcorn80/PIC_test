#ifndef SKODA_H
#define SKODA_H
#include <stdint.h>
extern uint8_t R[128];
/* Original RAM indices retained only to make the recovered behavior auditable. */
#define CLOCK_STATUS R[0x21]
#define CLOCK_HOURS_LOW R[0x22]
#define TEMP_INVALID R[0x23]
#define CLOCK_TIMEOUT R[0x24]
#define TEMP_TIMEOUT R[0x25]
#define DIM_TIMEOUT R[0x26]
#define DISPLAY_ON R[0x50]
#define TEMP_RAW R[0x51]
#define USER_OPTIONS R[0x52]
#define DIM_LEVEL R[0x53]
#define DIM_CURVE R[0x54]
#define PWM_HIGH R[0x15]
#define PWM_CONTROL R[0x17]
void core_clock(void);
void core_temperature(void);
void core_brightness(void);
void skoda_init(void);
void skoda_frame(uint16_t id, const uint8_t *data, uint8_t size);
void skoda_tick(void);
void skoda_clear(void);
void skoda_render_all(void);
#endif
