/* PIC16F914, Microchip XC8. Original board: TLE6254 + MCP2515 at 8 MHz.
 * TXCAN is physically unconnected; MCP2515 is kept in listen-only mode.
 * This is reconstructed C, not recovered original source. See README. */
#include <xc.h>
#include "skoda.h"
#define _XTAL_FREQ 8000000UL
#pragma config FOSC=INTOSCIO, WDTE=OFF, PWRTE=OFF, MCLRE=OFF
#pragma config CP=OFF, CPD=OFF, BOREN=ON, IESO=ON, FCMEN=ON

static volatile uint8_t tick_due, delay_counter;
static volatile uint8_t lcd_image[12];
static uint8_t rx[13];

void __interrupt() irq(void)
{
 if(PIE1bits.TMR1IE && PIR1bits.TMR1IF) {
  PIR1bits.TMR1IF=0;
  if(delay_counter)--delay_counter;
  tick_due=1;
 }
 if(PIE2bits.LCDIE && PIR2bits.LCDIF) {
  PIR2bits.LCDIF=0; LCDCONbits.WERR=0;
  LCDDATA0=lcd_image[0];LCDDATA1=lcd_image[1];LCDDATA2=lcd_image[2];
  LCDDATA3=lcd_image[3];LCDDATA4=lcd_image[4];LCDDATA5=lcd_image[5];
  LCDDATA6=lcd_image[6];LCDDATA7=lcd_image[7];LCDDATA8=lcd_image[8];
  LCDDATA9=lcd_image[9];LCDDATA10=lcd_image[10];LCDDATA11=lcd_image[11];
 }
}
static void publish(void)
{
 uint8_t i;
 INTCONbits.GIE=0;
 for(i=0;i<12u;++i)lcd_image[i]=R[0x56u+i];
 INTCONbits.GIE=1;
 /* 10-bit PWM on RC5, controls the board's backlight transistor. */
 CCPR1L=PWM_HIGH; CCP1CON=PWM_CONTROL;
}
static void wait_ticks(uint8_t n)
{
 delay_counter=n;
 while(delay_counter) { /* original waits for Timer1 interrupts */ }
}
static uint8_t spi(uint8_t b)
{
 SSPBUF=b;
 while(!SSPSTATbits.BF) { }
 return SSPBUF;
}
static void mcp_write(uint8_t address,uint8_t value)
{
 PORTDbits.RD5=0;spi(2);spi(address);spi(value);PORTDbits.RD5=1;
}
static uint8_t mcp_read(uint8_t address)
{
 uint8_t v;
 PORTDbits.RD5=0;spi(3);spi(address);v=spi(0);PORTDbits.RD5=1;return v;
}
static void mcp_modify(uint8_t address,uint8_t mask,uint8_t value)
{
 PORTDbits.RD5=0;spi(5);spi(address);spi(mask);spi(value);PORTDbits.RD5=1;
}
static void transceiver_normal(void) { PORTCbits.RC3=1;PORTDbits.RD1=1; }
static uint8_t mcp_start(void)
{
 uint8_t i;
 static const uint8_t pairs[][2]={
  {0x2a,0x81},{0x29,0xbe},{0x28,0x83}, /* 100 kbit/s with 8 MHz quartz */
  {0x20,0xfd},{0x21,0x60},{0x22,0},{0x23,0},
  {0,0xc4},{1,0x20},{2,0},{3,0},
  {4,0xc1},{5,0xc0},{6,0},{7,0},
  {0x24,0xff},{0x25,0xe0},{0x26,0},{0x27,0},
  {8,0xae},{9,0xa0},{0x0a,0},{0x0b,0},
  {0x10,0xcb},{0x11,0xa0},{0x12,0},{0x13,0},
  {0x14,0xa4},{0x15,0xe0},{0x16,0},{0x17,0},
  {0x60,0x20},{0x70,0x20},{0x2b,3}
 };
 PORTDbits.RD5=0;spi(0xc0);PORTDbits.RD5=1;
 __delay_ms(2);mcp_write(0x0f,0x80);
 for(i=0;i<100u;++i) {
  if((mcp_read(0x0e)&0xe0u)==0x80u)break;
  __delay_ms(1);
 }
 if(i==100u)return 0;
 for(i=0;i<(uint8_t)(sizeof(pairs)/sizeof(pairs[0]));++i)mcp_write(pairs[i][0],pairs[i][1]);
 mcp_write(0x0f,0x60); /* REQOP=011 listen-only; no transmission or ACK. */
 for(i=0;i<100u;++i) {
  if((mcp_read(0x0e)&0xe0u)==0x60u)return 1;
  __delay_ms(1);
 }
 return 0;
}
static void receive_buffer(uint8_t command)
{
 uint8_t i,dlc;uint16_t id;
 PORTDbits.RD5=0;spi(command);
 for(i=0;i<13u;++i)rx[i]=spi(0);
 PORTDbits.RD5=1;
 dlc=rx[4]&15u;
 /* Application compared full standard SID bytes; extended/RTR are not decoded. */
 if((rx[1]&8u)||(rx[4]&0x40u))return;
 id=((uint16_t)rx[0]<<3)|(rx[1]>>5);
 skoda_frame(id,&rx[5],dlc);
}
static void hardware_init(void)
{
 INTCON=0;PIE1=0;PIE2=0;OSCCON=0x70; /* PIC internal 8 MHz */
 TRISA=0x3f;TRISB=0xff;TRISC=0x87;TRISD=0x95;TRISE=0x0f;
 LCDSE0=0xbf;LCDSE1=0xf0;LCDSE2=0xf0;LCDPS=0xb1;LCDCON=0x93;
 PR2=255;CCPR1L=0;CCP1CON=12;T2CON=6;
 PORTDbits.RD5=1;SSPSTAT=0x40;SSPCON=0x20;
 T1CON=0x15; /* internal Fosc/4, prescale 1:2, overflow ~65.536 ms */
 PIE1bits.TMR1IE=1;PIE2bits.LCDIE=1;
 PORTDbits.RD3=1;transceiver_normal();
 INTCONbits.PEIE=1;INTCONbits.GIE=1;
}
static void idle_sequence(void)
{
 PWM_HIGH=0;DIM_LEVEL=0;skoda_clear();publish();
 PORTCbits.RC3=1;PORTDbits.RD1=0;wait_ticks(1);
 PORTCbits.RC3=0;PORTDbits.RD1=0;wait_ticks(2);
 PORTDbits.RD3=0;wait_ticks(20);
 DISPLAY_ON=0;CLOCK_STATUS=128;CLOCK_HOURS_LOW=0;TEMP_RAW=0;TEMP_INVALID=1;USER_OPTIONS=0;DIM_LEVEL=0;
 PORTDbits.RD3=1;transceiver_normal();
 /* Resets hardware filtering just as the original return to 0x0936. */
 while(!mcp_start()) { __delay_ms(100); }
 delay_counter=15;
}
void main(void)
{
 uint8_t flags;
 skoda_init();hardware_init();
 while(!mcp_start()) { __delay_ms(100); }
 delay_counter=15;
 for(;;) {
  /* Original main polls INT (RD4); LCD and Timer1 have their own ISRs. */
  if(!PORTDbits.RD4) {
   flags=mcp_read(0x2c);
   if(flags&1u) { receive_buffer(0x90);mcp_modify(0x2c,1,0); }
   if(flags&2u) { receive_buffer(0x94);mcp_modify(0x2c,2,0); }
   if(flags&0xfcu)mcp_write(0x2d,0);
   delay_counter=15;
   publish();
  }
  if(tick_due) {
   INTCONbits.GIE=0;tick_due=0;INTCONbits.GIE=1;
   skoda_tick();publish();
  }
  if(!delay_counter)idle_sequence();
 }
}
