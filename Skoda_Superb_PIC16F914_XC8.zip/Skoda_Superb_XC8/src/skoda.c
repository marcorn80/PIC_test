#include "skoda.h"
#include <string.h>
/* Bytes copied by the original startup from retlw table 0x072c..0x075b. */
static const uint8_t initial[48] = {
 15,128,0,1,154,154,20,0,30,70,90,244,0,1,0,60,
 0,141,0,187,1,211,0,32,0,60,0,60,0,60,0,60,
 126,48,109,121,51,91,95,112,127,123,119,31,78,61,79,71
};
void skoda_clear(void) { memset(&R[0x56],0,12); }
void skoda_render_all(void) { core_clock(); core_temperature(); }
void skoda_init(void)
{
 memset(R,0,128); memcpy(&R[0x20],initial,48);
 PWM_CONTROL=12;
 /* Original 0x0953..0x095f resets the values after power-up. */
 DISPLAY_ON=0; CLOCK_STATUS=128; CLOCK_HOURS_LOW=0;
 TEMP_RAW=0; TEMP_INVALID=1; USER_OPTIONS=0; DIM_LEVEL=0;
}
void skoda_frame(uint16_t id,const uint8_t *d,uint8_t size)
{
 uint8_t v;
 /* Deliberate bounds check: the original accessed stale bytes for short DLCs. */
 if(size!=8u)return;
 switch(id) {
 case 0x65d:
  if(CLOCK_HOURS_LOW!=(d[5]&0xf0u)||CLOCK_STATUS!=(d[6]&0x7fu)) {
   CLOCK_HOURS_LOW=d[5]&0xf0u; CLOCK_STATUS=d[6]&0x7fu;
   if(DISPLAY_ON)core_clock();
  }
  CLOCK_TIMEOUT=154;break;
 case 0x527:
  if(TEMP_RAW!=d[5]) { TEMP_RAW=d[5]; if(DISPLAY_ON)core_temperature(); }
  v=d[7]&1u;
  if(TEMP_INVALID!=v) { TEMP_INVALID=v; if(DISPLAY_ON)core_temperature(); }
  TEMP_TIMEOUT=154;break;
 case 0x635:
  if(DIM_LEVEL!=d[0]) { DIM_LEVEL=d[0]; if(DISPLAY_ON)core_brightness(); }
  if(DIM_CURVE!=d[2]) { DIM_CURVE=d[2]; if(DISPLAY_ON)core_brightness(); }
  DIM_TIMEOUT=20;break;
 case 0x60e:
  v=d[0]&0x82u;
  if(USER_OPTIONS!=v) { USER_OPTIONS=v; if(DISPLAY_ON)skoda_render_all(); }
  break;
 case 0x575:
  if(!(d[0]&2u))DISPLAY_ON=0;
  else if(!DISPLAY_ON) { DISPLAY_ON=1; skoda_render_all(); core_brightness(); }
  break;
 default:break;
 }
}
void skoda_tick(void)
{
 /* One coalesced Timer1 overflow flag, as the original RAM 0x55. */
 if(CLOCK_TIMEOUT && --CLOCK_TIMEOUT==0u) { CLOCK_STATUS|=128u; core_clock(); }
 if(TEMP_TIMEOUT && --TEMP_TIMEOUT==0u) { TEMP_RAW=255; core_temperature(); }
 if(DIM_TIMEOUT && --DIM_TIMEOUT==0u)core_brightness();
}
