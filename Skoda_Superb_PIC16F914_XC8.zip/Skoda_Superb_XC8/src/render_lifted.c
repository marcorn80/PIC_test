/* Generated from the supplied PIC16F914 HEX. Native C, not an emulator. */
#include "skoda.h"
uint8_t R[128];
static uint8_t w, carry, dc, zero;
static uint16_t tmp;
void core_signed_div(void);
void core_multiply(void);
void core_divide_byte(void);
void core_multiply_byte(void);
void core_shift_right(void);
void core_shift_left(void);
void core_clock(void);
void core_temperature(void);
void core_brightness(void);

/* Original entry 0x0031, word addresses. Non-reentrant. */
void core_signed_div(void) {
goto L0031;
L0031: w = 0x00; /* 3000 */
L0032: if (((R[0x70] & 0x80u))) goto L0034; /* 1ff0 */
L0033: goto L003a; /* 283a */
L0034: R[0x70] = (uint8_t)(R[0x70] ^ 255u); zero = (R[0x70] == 0); /* 09f0 */
L0035: R[0x77] = (uint8_t)(R[0x77] ^ 255u); zero = (R[0x77] == 0); /* 09f7 */
L0036: R[0x77] = (uint8_t)(R[0x77] + 1u); zero = (R[0x77] == 0); /* 0af7 */
L0037: if (!(zero)) goto L0039; /* 1903 */
L0038: R[0x70] = (uint8_t)(R[0x70] + 1u); zero = (R[0x70] == 0); /* 0af0 */
L0039: w = 0x01; /* 3001 */
L003a: if (((R[0x71] & 0x80u))) goto L003c; /* 1ff1 */
L003b: goto L0043; /* 2843 */
L003c: R[0x71] = (uint8_t)(R[0x71] ^ 255u); zero = (R[0x71] == 0); /* 09f1 */
L003d: R[0x75] = (uint8_t)(R[0x75] ^ 255u); zero = (R[0x75] == 0); /* 09f5 */
L003e: R[0x75] = (uint8_t)(R[0x75] + 1u); zero = (R[0x75] == 0); /* 0af5 */
L003f: if (!(zero)) goto L0041; /* 1903 */
L0040: R[0x71] = (uint8_t)(R[0x71] + 1u); zero = (R[0x71] == 0); /* 0af1 */
L0041: w ^= 0x01; zero = (w == 0); /* 3a01 */
L0042: w |= 0x02; zero = (w == 0); /* 3802 */
L0043: R[0x74] = w; /* 00f4 */
L0044: R[0x76] = 0; zero = 1; /* 01f6 */
L0045: R[0x72] = 0; zero = 1; /* 01f2 */
L0046: w = 0x11; /* 3011 */
L0047: R[0x73] = w; /* 00f3 */
L0048: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L0049: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df1 */
L004a: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L004b: R[0x73] = (uint8_t)(R[0x73] - 1u); zero = (R[0x73] == 0); /* 03f3 */
L004c: if (!(zero)) goto L004e; /* 1903 */
L004d: goto L0063; /* 2863 */
L004e: tmp = R[0x76]; R[0x76] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df6 */
L004f: tmp = R[0x72]; R[0x72] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df2 */
L0050: w = (uint8_t)(R[0x70]); zero = (w == 0); /* 0870 */
L0051: tmp = (uint16_t)R[0x72] - w; carry = (R[0x72] >= w); dc = ((R[0x72] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0272 */
L0052: if (!(zero)) goto L0054; /* 1903 */
L0053: goto L0057; /* 2857 */
L0054: if ((carry)) goto L0056; /* 1c03 */
L0055: goto L0048; /* 2848 */
L0056: goto L005b; /* 285b */
L0057: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0058: tmp = (uint16_t)R[0x76] - w; carry = (R[0x76] >= w); dc = ((R[0x76] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0276 */
L0059: if ((carry)) goto L005b; /* 1c03 */
L005a: goto L0048; /* 2848 */
L005b: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L005c: tmp = (uint16_t)R[0x76] - w; carry = (R[0x76] >= w); dc = ((R[0x76] & 15u) >= (w & 15u)); R[0x76] = (uint8_t)tmp; zero = (R[0x76] == 0); /* 02f6 */
L005d: if ((carry)) goto L005f; /* 1c03 */
L005e: R[0x72] = (uint8_t)(R[0x72] - 1u); zero = (R[0x72] == 0); /* 03f2 */
L005f: w = (uint8_t)(R[0x70]); zero = (w == 0); /* 0870 */
L0060: tmp = (uint16_t)R[0x72] - w; carry = (R[0x72] >= w); dc = ((R[0x72] & 15u) >= (w & 15u)); R[0x72] = (uint8_t)tmp; zero = (R[0x72] == 0); /* 02f2 */
L0061: carry = 1; /* 1403 */
L0062: goto L0048; /* 2848 */
L0063: if (((R[0x74] & 0x01u))) goto L0065; /* 1c74 */
L0064: goto L006a; /* 286a */
L0065: R[0x75] = (uint8_t)(R[0x75] ^ 255u); zero = (R[0x75] == 0); /* 09f5 */
L0066: R[0x71] = (uint8_t)(R[0x71] ^ 255u); zero = (R[0x71] == 0); /* 09f1 */
L0067: R[0x75] = (uint8_t)(R[0x75] + 1u); zero = (R[0x75] == 0); /* 0af5 */
L0068: if (!(zero)) goto L006a; /* 1903 */
L0069: R[0x71] = (uint8_t)(R[0x71] + 1u); zero = (R[0x71] == 0); /* 0af1 */
L006a: if (((R[0x74] & 0x02u))) goto L006c; /* 1cf4 */
L006b: return; /* 0008 */
L006c: R[0x76] = (uint8_t)(R[0x76] ^ 255u); zero = (R[0x76] == 0); /* 09f6 */
L006d: R[0x72] = (uint8_t)(R[0x72] ^ 255u); zero = (R[0x72] == 0); /* 09f2 */
L006e: R[0x76] = (uint8_t)(R[0x76] + 1u); zero = (R[0x76] == 0); /* 0af6 */
L006f: if (!(zero)) goto L0071; /* 1903 */
L0070: R[0x72] = (uint8_t)(R[0x72] + 1u); zero = (R[0x72] == 0); /* 0af2 */
L0071: return; /* 0008 */
}

/* Original entry 0x0091, word addresses. Non-reentrant. */
void core_multiply(void) {
goto L0091;
L0091: R[0x76] = 0; zero = 1; /* 01f6 */
L0092: R[0x72] = 0; zero = 1; /* 01f2 */
L0093: carry = 0; /* 1003 */
L0094: tmp = R[0x70]; R[0x70] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf0 */
L0095: tmp = R[0x77]; R[0x77] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf7 */
L0096: if (!(carry)) goto L0098; /* 1803 */
L0097: goto L009d; /* 289d */
L0098: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0099: w = (uint8_t)(R[0x70] | w); zero = (w == 0); /* 0470 */
L009a: if ((zero)) goto L009c; /* 1d03 */
L009b: goto L00a3; /* 28a3 */
L009c: return; /* 0008 */
L009d: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L009e: tmp = (uint16_t)R[0x76] + w; carry = (tmp > 255u); dc = ((R[0x76] & 15u) + (w & 15u) > 15u); R[0x76] = (uint8_t)tmp; zero = (R[0x76] == 0); /* 07f6 */
L009f: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L00a0: if (!(carry)) goto L00a2; /* 1803 */
L00a1: R[0x72] = (uint8_t)(R[0x72] + 1u); zero = (R[0x72] == 0); /* 0af2 */
L00a2: tmp = (uint16_t)R[0x72] + w; carry = (tmp > 255u); dc = ((R[0x72] & 15u) + (w & 15u) > 15u); R[0x72] = (uint8_t)tmp; zero = (R[0x72] == 0); /* 07f2 */
L00a3: carry = 0; /* 1003 */
L00a4: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L00a5: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df1 */
L00a6: goto L0093; /* 2893 */
}

/* Original entry 0x00a7, word addresses. Non-reentrant. */
void core_divide_byte(void) {
goto L00a7;
L00a7: R[0x77] = 0; zero = 1; /* 01f7 */
L00a8: w = 0x09; /* 3009 */
L00a9: R[0x70] = w; /* 00f0 */
L00aa: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L00ab: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L00ac: R[0x70] = (uint8_t)(R[0x70] - 1u); zero = (R[0x70] == 0); /* 03f0 */
L00ad: if (!(zero)) goto L00af; /* 1903 */
L00ae: goto L00b4; /* 28b4 */
L00af: tmp = R[0x77]; R[0x77] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df7 */
L00b0: tmp = (uint16_t)R[0x77] - w; carry = (R[0x77] >= w); dc = ((R[0x77] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0277 */
L00b1: if (!(carry)) goto L00b3; /* 1803 */
L00b2: R[0x77] = w; /* 00f7 */
L00b3: goto L00aa; /* 28aa */
L00b4: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L00b5: return; /* 0008 */
}

/* Original entry 0x00b6, word addresses. Non-reentrant. */
void core_multiply_byte(void) {
goto L00b6;
L00b6: w = 0x00; /* 3000 */
L00b7: carry = 0; /* 1003 */
L00b8: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf1 */
L00b9: if (!(carry)) goto L00bb; /* 1803 */
L00ba: goto L00c1; /* 28c1 */
L00bb: R[0x71] = (uint8_t)(R[0x71]); zero = (R[0x71] == 0); /* 08f1 */
L00bc: if (!(zero)) goto L00be; /* 1903 */
L00bd: return; /* 0008 */
L00be: carry = 0; /* 1003 */
L00bf: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L00c0: goto L00b7; /* 28b7 */
L00c1: tmp = (uint16_t)R[0x75] + w; carry = (tmp > 255u); dc = ((R[0x75] & 15u) + (w & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 0775 */
L00c2: carry = 0; /* 1003 */
L00c3: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L00c4: goto L00b7; /* 28b7 */
}

/* Original entry 0x00c5, word addresses. Non-reentrant. */
void core_shift_right(void) {
goto L00c5;
L00c5: R[0x77] = (uint8_t)(R[0x77] + 1u); zero = (R[0x77] == 0); /* 0af7 */
L00c6: R[0x77] = (uint8_t)(R[0x77] - 1u); if (R[0x77] == 0) goto L00c8; /* 0bf7 */
L00c7: goto L00c9; /* 28c9 */
L00c8: return; /* 0008 */
L00c9: carry = 0; /* 1003 */
L00ca: if (!((R[0x71] & 0x80u))) goto L00cc; /* 1bf1 */
L00cb: carry = 1; /* 1403 */
L00cc: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf1 */
L00cd: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf5 */
L00ce: goto L00c6; /* 28c6 */
}

/* Original entry 0x00cf, word addresses. Non-reentrant. */
void core_shift_left(void) {
goto L00cf;
L00cf: R[0x77] = (uint8_t)(R[0x77] + 1u); zero = (R[0x77] == 0); /* 0af7 */
L00d0: R[0x77] = (uint8_t)(R[0x77] - 1u); if (R[0x77] == 0) goto L00d2; /* 0bf7 */
L00d1: goto L00d3; /* 28d3 */
L00d2: return; /* 0008 */
L00d3: carry = 0; /* 1003 */
L00d4: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L00d5: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df1 */
L00d6: goto L00d0; /* 28d0 */
}

/* Original entry 0x00ec, word addresses. Non-reentrant. */
void core_clock(void) {
goto L00ec;
L00ec: if (!((R[0x21] & 0x80u))) goto L00ee; /* 1ba1 */
L00ed: goto L00ef; /* 28ef */
L00ee: goto L010c; /* 290c */
L00ef: R[0x57] &= 0xdfu; /* 12d7 */
L00f0: R[0x5a] &= 0xdfu; /* 12da */
L00f1: R[0x5d] &= 0xdfu; /* 12dd */
L00f2: R[0x60] &= 0xbfu; /* 1360 */
L00f3: R[0x5d] &= 0xbfu; /* 135d */
L00f4: R[0x57] &= 0xbfu; /* 1357 */
L00f5: R[0x5a] |= 0x40u; /* 175a */
L00f6: R[0x56] &= 0x7fu; /* 13d6 */
L00f7: R[0x59] &= 0x7fu; /* 13d9 */
L00f8: R[0x5c] &= 0x7fu; /* 13dc */
L00f9: R[0x60] &= 0xefu; /* 1260 */
L00fa: R[0x5d] &= 0xefu; /* 125d */
L00fb: R[0x57] &= 0xefu; /* 1257 */
L00fc: R[0x5a] |= 0x10u; /* 165a */
L00fd: R[0x56] &= 0xefu; /* 1256 */
L00fe: R[0x59] &= 0xefu; /* 1259 */
L00ff: R[0x5c] &= 0xefu; /* 125c */
L0100: R[0x60] &= 0x7fu; /* 13e0 */
L0101: R[0x5d] &= 0x7fu; /* 13dd */
L0102: R[0x57] &= 0x7fu; /* 13d7 */
L0103: R[0x5a] |= 0x80u; /* 17da */
L0104: R[0x58] &= 0xdfu; /* 12d8 */
L0105: R[0x5b] &= 0xdfu; /* 12db */
L0106: R[0x5e] &= 0xdfu; /* 12de */
L0107: R[0x5f] &= 0xdfu; /* 12df */
L0108: R[0x5c] &= 0xdfu; /* 12dc */
L0109: R[0x56] &= 0xdfu; /* 12d6 */
L010a: R[0x59] |= 0x20u; /* 16d9 */
L010b: goto L02c1; /* 2ac1 */
L010c: w = (uint8_t)(R[0x22]); zero = (w == 0); /* 0822 */
L010d: R[0x75] = w; /* 00f5 */
L010e: w = (uint8_t)((R[0x75] >> 4) | (R[0x75] << 4)); /* 0e75 */
L010f: w &= 0x0f; zero = (w == 0); /* 390f */
L0110: R[0x64] = w; /* 00e4 */
L0111: if (!((R[0x21] & 0x01u))) goto L0113; /* 1821 */
L0112: goto L0114; /* 2914 */
L0113: goto L0115; /* 2915 */
L0114: R[0x64] |= 0x10u; /* 1664 */
L0115: if (!((R[0x52] & 0x80u))) goto L0117; /* 1bd2 */
L0116: goto L0118; /* 2918 */
L0117: goto L011f; /* 291f */
L0118: w = 0x0d; /* 300d */
L0119: tmp = (uint16_t)R[0x64] - w; carry = (R[0x64] >= w); dc = ((R[0x64] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0264 */
L011a: if (!(carry)) goto L011c; /* 1803 */
L011b: goto L011d; /* 291d */
L011c: goto L011f; /* 291f */
L011d: w = 0xf4; /* 30f4 */
L011e: tmp = (uint16_t)R[0x64] + w; carry = (tmp > 255u); dc = ((R[0x64] & 15u) + (w & 15u) > 15u); R[0x64] = (uint8_t)tmp; zero = (R[0x64] == 0); /* 07e4 */
L011f: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0120: R[0x75] = w; /* 00f5 */
L0121: w = 0x0a; /* 300a */
L0122: R[0x71] = w; /* 00f1 */
L0123: ; /* PCLATH handled by native C control flow */ /* 118a */
L0124: core_divide_byte(); /* 20a7 */
L0125: R[0x63] = w; /* 00e3 */
L0126: R[0x63] = (uint8_t)(R[0x63]); zero = (R[0x63] == 0); /* 08e3 */
L0127: ; /* PCLATH handled by native C control flow */ /* 118a */
L0128: if (!(zero)) goto L012a; /* 1903 */
L0129: goto L012b; /* 292b */
L012a: goto L0133; /* 2933 */
L012b: R[0x57] &= 0xdfu; /* 12d7 */
L012c: R[0x5a] &= 0xdfu; /* 12da */
L012d: R[0x5d] &= 0xdfu; /* 12dd */
L012e: R[0x60] &= 0xbfu; /* 1360 */
L012f: R[0x5d] &= 0xbfu; /* 135d */
L0130: R[0x57] &= 0xbfu; /* 1357 */
L0131: R[0x5a] &= 0xbfu; /* 135a */
L0132: goto L018f; /* 298f */
L0133: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x40u) != 0); zero = !w; if (w) R[0x57] |= 0x20u; else R[0x57] &= 0xdfu; goto L0141; /* 0863 */
L0141: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x5a] |= 0x20u; else R[0x5a] &= 0xdfu; goto L014e; /* 0863 */
L014e: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5d] |= 0x20u; else R[0x5d] &= 0xdfu; goto L015b; /* 0863 */
L015b: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x60] |= 0x40u; else R[0x60] &= 0xbfu; goto L0168; /* 0863 */
L0168: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5d] |= 0x40u; else R[0x5d] &= 0xbfu; goto L0175; /* 0863 */
L0175: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x57] |= 0x40u; else R[0x57] &= 0xbfu; goto L0182; /* 0863 */
L0182: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5a] |= 0x40u; else R[0x5a] &= 0xbfu; goto L018f; /* 0863 */
L018f: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0190: R[0x75] = w; /* 00f5 */
L0191: w = 0x0a; /* 300a */
L0192: R[0x71] = w; /* 00f1 */
L0193: ; /* PCLATH handled by native C control flow */ /* 118a */
L0194: core_divide_byte(); /* 20a7 */
L0195: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0196: R[0x63] = w; /* 00e3 */
L0197: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0198: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0199: R[0x04] = w; /* 0084 */
L019a: w = 0x00; /* 3000 */
L019b: ; /* Original bank selection */ /* 1383 */
L019c: if (!((R[R[4]] & 0x40u))) goto L019e; /* 1b00 */
L019d: w = 0x01; /* 3001 */
L019e: w ^= 0x00; zero = (w == 0); /* 3a00 */
L019f: ; /* PCLATH handled by native C control flow */ /* 118a */
L01a0: if ((zero)) goto L01a2; /* 1d03 */
L01a1: goto L01a3; /* 29a3 */
L01a2: goto L01a5; /* 29a5 */
L01a3: R[0x56] |= 0x80u; /* 17d6 */
L01a4: goto L01a6; /* 29a6 */
L01a5: R[0x56] &= 0x7fu; /* 13d6 */
L01a6: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x59] |= 0x80u; else R[0x59] &= 0x7fu; goto L01b3; /* 0863 */
L01b3: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5c] |= 0x80u; else R[0x5c] &= 0x7fu; goto L01c0; /* 0863 */
L01c0: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x60] |= 0x10u; else R[0x60] &= 0xefu; goto L01cd; /* 0863 */
L01cd: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5d] |= 0x10u; else R[0x5d] &= 0xefu; goto L01da; /* 0863 */
L01da: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x57] |= 0x10u; else R[0x57] &= 0xefu; goto L01e7; /* 0863 */
L01e7: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5a] |= 0x10u; else R[0x5a] &= 0xefu; goto L01f4; /* 0863 */
L01f4: R[0x5f] |= 0x80u; /* 17df */
L01f5: w = (uint8_t)(R[0x21]); zero = (w == 0); /* 0821 */
L01f6: R[0x75] = w; /* 00f5 */
L01f7: carry = 0; /* 1003 */
L01f8: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp >> 1) | (carry << 7)); carry = (uint8_t)((tmp & 1u)); /* 0cf5 */
L01f9: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L01fa: R[0x64] = w; /* 00e4 */
L01fb: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L01fc: w = 0x0a; /* 300a */
L01fd: R[0x71] = w; /* 00f1 */
L01fe: ; /* PCLATH handled by native C control flow */ /* 118a */
L01ff: core_divide_byte(); /* 20a7 */
L0200: R[0x63] = w; /* 00e3 */
L0201: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0202: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0203: R[0x04] = w; /* 0084 */
L0204: w = 0x00; /* 3000 */
L0205: if (!((R[R[4]] & 0x40u))) goto L0207; /* 1b00 */
L0206: w = 0x01; /* 3001 */
L0207: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0208: ; /* PCLATH handled by native C control flow */ /* 118a */
L0209: if ((zero)) goto L020b; /* 1d03 */
L020a: goto L020c; /* 2a0c */
L020b: goto L020e; /* 2a0e */
L020c: R[0x56] |= 0x10u; /* 1656 */
L020d: goto L020f; /* 2a0f */
L020e: R[0x56] &= 0xefu; /* 1256 */
L020f: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x59] |= 0x10u; else R[0x59] &= 0xefu; goto L021c; /* 0863 */
L021c: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5c] |= 0x10u; else R[0x5c] &= 0xefu; goto L0229; /* 0863 */
L0229: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x60] |= 0x80u; else R[0x60] &= 0x7fu; goto L0236; /* 0863 */
L0236: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5d] |= 0x80u; else R[0x5d] &= 0x7fu; goto L0243; /* 0863 */
L0243: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x57] |= 0x80u; else R[0x57] &= 0x7fu; goto L0250; /* 0863 */
L0250: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5a] |= 0x80u; else R[0x5a] &= 0x7fu; goto L025d; /* 0863 */
L025d: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L025e: R[0x75] = w; /* 00f5 */
L025f: w = 0x0a; /* 300a */
L0260: R[0x71] = w; /* 00f1 */
L0261: ; /* PCLATH handled by native C control flow */ /* 118a */
L0262: core_divide_byte(); /* 20a7 */
L0263: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0264: R[0x63] = w; /* 00e3 */
L0265: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0266: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0267: R[0x04] = w; /* 0084 */
L0268: w = 0x00; /* 3000 */
L0269: if (!((R[R[4]] & 0x40u))) goto L026b; /* 1b00 */
L026a: w = 0x01; /* 3001 */
L026b: w ^= 0x00; zero = (w == 0); /* 3a00 */
L026c: ; /* PCLATH handled by native C control flow */ /* 118a */
L026d: if ((zero)) goto L026f; /* 1d03 */
L026e: goto L0270; /* 2a70 */
L026f: goto L0272; /* 2a72 */
L0270: R[0x58] |= 0x20u; /* 16d8 */
L0271: goto L0273; /* 2a73 */
L0272: R[0x58] &= 0xdfu; /* 12d8 */
L0273: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x5b] |= 0x20u; else R[0x5b] &= 0xdfu; goto L0280; /* 0863 */
L0280: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5e] |= 0x20u; else R[0x5e] &= 0xdfu; goto L028d; /* 0863 */
L028d: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x5f] |= 0x20u; else R[0x5f] &= 0xdfu; goto L029a; /* 0863 */
L029a: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5c] |= 0x20u; else R[0x5c] &= 0xdfu; goto L02a7; /* 0863 */
L02a7: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x56] |= 0x20u; else R[0x56] &= 0xdfu; goto L02b4; /* 0863 */
L02b4: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x59] |= 0x20u; else R[0x59] &= 0xdfu; goto L02c1; /* 0863 */
L02c1: return; /* 0008 */
}

/* Original entry 0x02c2, word addresses. Non-reentrant. */
void core_temperature(void) {
goto L02c2;
L02c2: R[0x58] |= 0x10u; /* 1658 */
L02c3: R[0x23] = (uint8_t)(R[0x23]); zero = (R[0x23] == 0); /* 08a3 */
L02c4: if (!(zero)) goto L02c6; /* 1903 */
L02c5: goto L02c7; /* 2ac7 */
L02c6: goto L02cc; /* 2acc */
L02c7: w = 0xff; /* 30ff */
L02c8: w = (uint8_t)(R[0x51] ^ w); zero = (w == 0); /* 0651 */
L02c9: if (!(zero)) goto L02cb; /* 1903 */
L02ca: goto L02cc; /* 2acc */
L02cb: goto L02ed; /* 2aed */
L02cc: R[0x61] &= 0xdfu; /* 12e1 */
L02cd: R[0x58] &= 0x7fu; /* 13d8 */
L02ce: R[0x5b] &= 0x7fu; /* 13db */
L02cf: R[0x5e] &= 0x7fu; /* 13de */
L02d0: R[0x61] &= 0xbfu; /* 1361 */
L02d1: R[0x5e] &= 0xbfu; /* 135e */
L02d2: R[0x58] &= 0xbfu; /* 1358 */
L02d3: R[0x5b] |= 0x40u; /* 175b */
L02d4: R[0x56] &= 0xfbu; /* 1156 */
L02d5: R[0x59] &= 0xfbu; /* 1159 */
L02d6: R[0x5c] &= 0xfbu; /* 115c */
L02d7: R[0x5f] &= 0xf7u; /* 11df */
L02d8: R[0x5c] &= 0xf7u; /* 11dc */
L02d9: R[0x56] &= 0xf7u; /* 11d6 */
L02da: R[0x59] |= 0x08u; /* 15d9 */
L02db: if (((R[0x52] & 0x02u))) goto L02dd; /* 1cd2 */
L02dc: goto L02de; /* 2ade */
L02dd: goto L02e2; /* 2ae2 */
L02de: R[0x5f] |= 0x04u; /* 155f */
L02df: R[0x5e] |= 0x10u; /* 165e */
L02e0: R[0x61] &= 0xefu; /* 1261 */
L02e1: goto L02e5; /* 2ae5 */
L02e2: R[0x5f] &= 0xfbu; /* 115f */
L02e3: R[0x5e] &= 0xefu; /* 125e */
L02e4: R[0x61] |= 0x10u; /* 1661 */
L02e5: R[0x56] &= 0xfeu; /* 1056 */
L02e6: R[0x59] &= 0xfeu; /* 1059 */
L02e7: R[0x5c] &= 0xfeu; /* 105c */
L02e8: R[0x5f] &= 0xfdu; /* 10df */
L02e9: R[0x5c] &= 0xfdu; /* 10dc */
L02ea: R[0x56] &= 0xfdu; /* 10d6 */
L02eb: R[0x59] |= 0x02u; /* 14d9 */
L02ec: goto L0698; /* 2e98 */
L02ed: w = 0x00; /* 3000 */
L02ee: R[0x64] = w; /* 00e4 */
L02ef: w = (uint8_t)(R[0x51]); zero = (w == 0); /* 0851 */
L02f0: R[0x65] = w; /* 00e5 */
L02f1: if (!((R[0x52] & 0x02u))) goto L02f3; /* 18d2 */
L02f2: goto L02f4; /* 2af4 */
L02f3: goto L04e3; /* 2ce3 */
L02f4: R[0x5e] &= 0xefu; /* 125e */
L02f5: R[0x61] |= 0x10u; /* 1661 */
L02f6: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L02f7: R[0x71] = w; /* 00f1 */
L02f8: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L02f9: R[0x75] = w; /* 00f5 */
L02fa: R[0x70] = 0; zero = 1; /* 01f0 */
L02fb: w = 0x09; /* 3009 */
L02fc: R[0x77] = w; /* 00f7 */
L02fd: ; /* PCLATH handled by native C control flow */ /* 118a */
L02fe: core_multiply(); /* 2091 */
L02ff: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0300: R[0x64] = w; /* 00e4 */
L0301: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0302: R[0x65] = w; /* 00e5 */
L0303: w = 0x05; /* 3005 */
L0304: tmp = (uint16_t)R[0x65] + w; carry = (tmp > 255u); dc = ((R[0x65] & 15u) + (w & 15u) > 15u); R[0x65] = (uint8_t)tmp; zero = (R[0x65] == 0); /* 07e5 */
L0305: if (!(carry)) goto L0307; /* 1803 */
L0306: R[0x64] = (uint8_t)(R[0x64] + 1u); zero = (R[0x64] == 0); /* 0ae4 */
L0307: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0308: R[0x71] = w; /* 00f1 */
L0309: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L030a: R[0x75] = w; /* 00f5 */
L030b: R[0x70] = 0; zero = 1; /* 01f0 */
L030c: w = 0x0a; /* 300a */
L030d: R[0x77] = w; /* 00f7 */
L030e: core_signed_div(); /* 2031 */
L030f: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0310: R[0x64] = w; /* 00e4 */
L0311: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0312: R[0x65] = w; /* 00e5 */
L0313: w = 0xc6; /* 30c6 */
L0314: tmp = (uint16_t)R[0x65] + w; carry = (tmp > 255u); dc = ((R[0x65] & 15u) + (w & 15u) > 15u); R[0x65] = (uint8_t)tmp; zero = (R[0x65] == 0); /* 07e5 */
L0315: if ((carry)) goto L0317; /* 1c03 */
L0316: R[0x64] = (uint8_t)(R[0x64] - 1u); zero = (R[0x64] == 0); /* 03e4 */
L0317: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0318: R[0x68] = w; /* 00e8 */
L0319: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L031a: R[0x69] = w; /* 00e9 */
L031b: R[0x61] &= 0xdfu; /* 12e1 */
L031c: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L031d: R[0x71] = w; /* 00f1 */
L031e: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L031f: R[0x75] = w; /* 00f5 */
L0320: w = 0xff; /* 30ff */
L0321: R[0x70] = w; /* 00f0 */
L0322: w = 0xf7; /* 30f7 */
L0323: R[0x77] = w; /* 00f7 */
L0324: w = 0x80; /* 3080 */
L0325: R[0x71] = (uint8_t)(R[0x71] ^ w); zero = (R[0x71] == 0); /* 06f1 */
L0326: w = (uint8_t)(R[0x70] ^ w); zero = (w == 0); /* 0670 */
L0327: tmp = (uint16_t)R[0x71] - w; carry = (R[0x71] >= w); dc = ((R[0x71] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0271 */
L0328: ; /* PCLATH handled by native C control flow */ /* 118a */
L0329: if (!(zero)) goto L032b; /* 1903 */
L032a: goto L032c; /* 2b2c */
L032b: goto L032e; /* 2b2e */
L032c: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L032d: tmp = (uint16_t)R[0x75] - w; carry = (R[0x75] >= w); dc = ((R[0x75] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0275 */
L032e: if ((carry)) goto L0330; /* 1c03 */
L032f: goto L0331; /* 2b31 */
L0330: goto L0339; /* 2b39 */
L0331: R[0x58] &= 0x7fu; /* 13d8 */
L0332: R[0x5b] &= 0x7fu; /* 13db */
L0333: R[0x5e] &= 0x7fu; /* 13de */
L0334: R[0x61] &= 0xbfu; /* 1361 */
L0335: R[0x5e] &= 0xbfu; /* 135e */
L0336: R[0x58] &= 0xbfu; /* 1358 */
L0337: R[0x5b] |= 0x40u; /* 175b */
L0338: goto L03be; /* 2bbe */
L0339: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L033a: R[0x71] = w; /* 00f1 */
L033b: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L033c: R[0x70] = 0; zero = 1; /* 01f0 */
L033d: w = 0x64; /* 3064 */
L033e: R[0x77] = w; /* 00f7 */
L033f: w = 0x80; /* 3080 */
L0340: R[0x71] = (uint8_t)(R[0x71] ^ w); zero = (R[0x71] == 0); /* 06f1 */
L0341: w = (uint8_t)(R[0x70] ^ w); zero = (w == 0); /* 0670 */
L0342: tmp = (uint16_t)R[0x71] - w; carry = (R[0x71] >= w); dc = ((R[0x71] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0271 */
L0343: if (!(zero)) goto L0345; /* 1903 */
L0344: goto L0346; /* 2b46 */
L0345: goto L0348; /* 2b48 */
L0346: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0347: tmp = (uint16_t)R[0x75] - w; carry = (R[0x75] >= w); dc = ((R[0x75] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0275 */
L0348: if ((carry)) goto L034a; /* 1c03 */
L0349: goto L034b; /* 2b4b */
L034a: goto L0353; /* 2b53 */
L034b: R[0x58] &= 0x7fu; /* 13d8 */
L034c: R[0x5b] &= 0x7fu; /* 13db */
L034d: R[0x5e] &= 0x7fu; /* 13de */
L034e: R[0x61] &= 0xbfu; /* 1361 */
L034f: R[0x5e] &= 0xbfu; /* 135e */
L0350: R[0x58] &= 0xbfu; /* 1358 */
L0351: R[0x5b] &= 0xbfu; /* 135b */
L0352: goto L03be; /* 2bbe */
L0353: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0354: R[0x71] = w; /* 00f1 */
L0355: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0356: R[0x75] = w; /* 00f5 */
L0357: R[0x70] = 0; zero = 1; /* 01f0 */
L0358: w = 0x64; /* 3064 */
L0359: ; /* PCLATH handled by native C control flow */ /* 118a */
L035a: core_signed_div(); /* 2031 */
L035b: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L035c: R[0x66] = w; /* 00e6 */
L035d: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L035e: R[0x67] = w; /* 00e7 */
L035f: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0360: R[0x63] = w; /* 00e3 */
L0361: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0362: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0363: R[0x04] = w; /* 0084 */
L0364: w = 0x00; /* 3000 */
L0365: ; /* Original bank selection */ /* 1383 */
L0366: if (!((R[R[4]] & 0x40u))) goto L0368; /* 1b00 */
L0367: w = 0x01; /* 3001 */
L0368: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0369: ; /* PCLATH handled by native C control flow */ /* 118a */
L036a: if ((zero)) goto L036c; /* 1d03 */
L036b: goto L036d; /* 2b6d */
L036c: goto L036f; /* 2b6f */
L036d: R[0x58] |= 0x80u; /* 17d8 */
L036e: goto L0370; /* 2b70 */
L036f: R[0x58] &= 0x7fu; /* 13d8 */
L0370: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x5b] |= 0x80u; else R[0x5b] &= 0x7fu; goto L037d; /* 0863 */
L037d: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5e] |= 0x80u; else R[0x5e] &= 0x7fu; goto L038a; /* 0863 */
L038a: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x61] |= 0x40u; else R[0x61] &= 0xbfu; goto L0397; /* 0863 */
L0397: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5e] |= 0x40u; else R[0x5e] &= 0xbfu; goto L03a4; /* 0863 */
L03a4: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x58] |= 0x40u; else R[0x58] &= 0xbfu; goto L03b1; /* 0863 */
L03b1: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5b] |= 0x40u; else R[0x5b] &= 0xbfu; goto L03be; /* 0863 */
L03be: if (!((R[0x64] & 0x80u))) goto L03c0; /* 1be4 */
L03bf: goto L03c1; /* 2bc1 */
L03c0: goto L03c8; /* 2bc8 */
L03c1: w = (uint8_t)(R[0x64] ^ 255u); zero = (w == 0); /* 0964 */
L03c2: R[0x64] = w; /* 00e4 */
L03c3: w = (uint8_t)(R[0x65] ^ 255u); zero = (w == 0); /* 0965 */
L03c4: R[0x65] = w; /* 00e5 */
L03c5: R[0x65] = (uint8_t)(R[0x65] + 1u); zero = (R[0x65] == 0); /* 0ae5 */
L03c6: if (!(zero)) goto L03c8; /* 1903 */
L03c7: R[0x64] = (uint8_t)(R[0x64] + 1u); zero = (R[0x64] == 0); /* 0ae4 */
L03c8: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L03c9: R[0x71] = w; /* 00f1 */
L03ca: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L03cb: R[0x75] = w; /* 00f5 */
L03cc: R[0x70] = 0; zero = 1; /* 01f0 */
L03cd: w = 0x64; /* 3064 */
L03ce: R[0x77] = w; /* 00f7 */
L03cf: ; /* PCLATH handled by native C control flow */ /* 118a */
L03d0: core_signed_div(); /* 2031 */
L03d1: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L03d2: R[0x64] = w; /* 00e4 */
L03d3: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L03d4: R[0x65] = w; /* 00e5 */
L03d5: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L03d6: R[0x71] = w; /* 00f1 */
L03d7: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L03d8: R[0x75] = w; /* 00f5 */
L03d9: R[0x70] = 0; zero = 1; /* 01f0 */
L03da: w = 0x0a; /* 300a */
L03db: R[0x77] = w; /* 00f7 */
L03dc: w = 0x80; /* 3080 */
L03dd: R[0x71] = (uint8_t)(R[0x71] ^ w); zero = (R[0x71] == 0); /* 06f1 */
L03de: w = (uint8_t)(R[0x70] ^ w); zero = (w == 0); /* 0670 */
L03df: tmp = (uint16_t)R[0x71] - w; carry = (R[0x71] >= w); dc = ((R[0x71] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0271 */
L03e0: ; /* PCLATH handled by native C control flow */ /* 118a */
L03e1: if (!(zero)) goto L03e3; /* 1903 */
L03e2: goto L03e4; /* 2be4 */
L03e3: goto L03e6; /* 2be6 */
L03e4: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L03e5: tmp = (uint16_t)R[0x75] - w; carry = (R[0x75] >= w); dc = ((R[0x75] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0275 */
L03e6: if ((carry)) goto L03e8; /* 1c03 */
L03e7: goto L03e9; /* 2be9 */
L03e8: goto L0409; /* 2c09 */
L03e9: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L03ea: R[0x71] = w; /* 00f1 */
L03eb: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L03ec: w = 0xff; /* 30ff */
L03ed: R[0x70] = w; /* 00f0 */
L03ee: w = 0xf7; /* 30f7 */
L03ef: R[0x77] = w; /* 00f7 */
L03f0: w = 0x80; /* 3080 */
L03f1: R[0x71] = (uint8_t)(R[0x71] ^ w); zero = (R[0x71] == 0); /* 06f1 */
L03f2: w = (uint8_t)(R[0x70] ^ w); zero = (w == 0); /* 0670 */
L03f3: tmp = (uint16_t)R[0x71] - w; carry = (R[0x71] >= w); dc = ((R[0x71] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0271 */
L03f4: if (!(zero)) goto L03f6; /* 1903 */
L03f5: goto L03f7; /* 2bf7 */
L03f6: goto L03f9; /* 2bf9 */
L03f7: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L03f8: tmp = (uint16_t)R[0x75] - w; carry = (R[0x75] >= w); dc = ((R[0x75] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0275 */
L03f9: if (!(carry)) goto L03fb; /* 1803 */
L03fa: goto L03fc; /* 2bfc */
L03fb: goto L0409; /* 2c09 */
L03fc: R[0x56] &= 0xfbu; /* 1156 */
L03fd: R[0x59] &= 0xfbu; /* 1159 */
L03fe: R[0x5c] &= 0xfbu; /* 115c */
L03ff: R[0x5f] &= 0xf7u; /* 11df */
L0400: R[0x5c] &= 0xf7u; /* 11dc */
L0401: R[0x56] &= 0xf7u; /* 11d6 */
L0402: if (!((R[0x68] & 0x80u))) goto L0404; /* 1be8 */
L0403: goto L0405; /* 2c05 */
L0404: goto L0407; /* 2c07 */
L0405: R[0x59] |= 0x08u; /* 15d9 */
L0406: goto L0475; /* 2c75 */
L0407: R[0x59] &= 0xf7u; /* 11d9 */
L0408: goto L0475; /* 2c75 */
L0409: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L040a: R[0x71] = w; /* 00f1 */
L040b: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L040c: R[0x75] = w; /* 00f5 */
L040d: R[0x70] = 0; zero = 1; /* 01f0 */
L040e: w = 0x0a; /* 300a */
L040f: R[0x77] = w; /* 00f7 */
L0410: ; /* PCLATH handled by native C control flow */ /* 118a */
L0411: core_signed_div(); /* 2031 */
L0412: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0413: R[0x66] = w; /* 00e6 */
L0414: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0415: R[0x67] = w; /* 00e7 */
L0416: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0417: R[0x63] = w; /* 00e3 */
L0418: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0419: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L041a: R[0x04] = w; /* 0084 */
L041b: w = 0x00; /* 3000 */
L041c: ; /* Original bank selection */ /* 1383 */
L041d: if (!((R[R[4]] & 0x40u))) goto L041f; /* 1b00 */
L041e: w = 0x01; /* 3001 */
L041f: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0420: ; /* PCLATH handled by native C control flow */ /* 118a */
L0421: if ((zero)) goto L0423; /* 1d03 */
L0422: goto L0424; /* 2c24 */
L0423: goto L0426; /* 2c26 */
L0424: R[0x56] |= 0x04u; /* 1556 */
L0425: goto L0427; /* 2c27 */
L0426: R[0x56] &= 0xfbu; /* 1156 */
L0427: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x59] |= 0x04u; else R[0x59] &= 0xfbu; goto L0434; /* 0863 */
L0434: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5c] |= 0x04u; else R[0x5c] &= 0xfbu; goto L0441; /* 0863 */
L0441: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x5f] |= 0x08u; else R[0x5f] &= 0xf7u; goto L044e; /* 0863 */
L044e: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5c] |= 0x08u; else R[0x5c] &= 0xf7u; goto L045b; /* 0863 */
L045b: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x56] |= 0x08u; else R[0x56] &= 0xf7u; goto L0468; /* 0863 */
L0468: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x59] |= 0x08u; else R[0x59] &= 0xf7u; goto L0475; /* 0863 */
L0475: R[0x5f] &= 0xfbu; /* 115f */
L0476: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0477: R[0x71] = w; /* 00f1 */
L0478: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0479: R[0x75] = w; /* 00f5 */
L047a: R[0x70] = 0; zero = 1; /* 01f0 */
L047b: w = 0x0a; /* 300a */
L047c: R[0x77] = w; /* 00f7 */
L047d: ; /* PCLATH handled by native C control flow */ /* 118a */
L047e: core_signed_div(); /* 2031 */
L047f: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0480: R[0x66] = w; /* 00e6 */
L0481: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0482: R[0x67] = w; /* 00e7 */
L0483: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0484: R[0x63] = w; /* 00e3 */
L0485: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0486: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0487: R[0x04] = w; /* 0084 */
L0488: w = 0x00; /* 3000 */
L0489: ; /* Original bank selection */ /* 1383 */
L048a: if (!((R[R[4]] & 0x40u))) goto L048c; /* 1b00 */
L048b: w = 0x01; /* 3001 */
L048c: w ^= 0x00; zero = (w == 0); /* 3a00 */
L048d: ; /* PCLATH handled by native C control flow */ /* 118a */
L048e: if ((zero)) goto L0490; /* 1d03 */
L048f: goto L0491; /* 2c91 */
L0490: goto L0493; /* 2c93 */
L0491: R[0x56] |= 0x01u; /* 1456 */
L0492: goto L0494; /* 2c94 */
L0493: R[0x56] &= 0xfeu; /* 1056 */
L0494: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x59] |= 0x01u; else R[0x59] &= 0xfeu; goto L04a1; /* 0863 */
L04a1: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5c] |= 0x01u; else R[0x5c] &= 0xfeu; goto L04ae; /* 0863 */
L04ae: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x5f] |= 0x02u; else R[0x5f] &= 0xfdu; goto L04bb; /* 0863 */
L04bb: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5c] |= 0x02u; else R[0x5c] &= 0xfdu; goto L04c8; /* 0863 */
L04c8: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x56] |= 0x02u; else R[0x56] &= 0xfdu; goto L04d5; /* 0863 */
L04d5: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x59] |= 0x02u; else R[0x59] &= 0xfdu; goto L0698; /* 0863 */
L04e2: goto L0698; /* 2e98 */
L04e3: R[0x5e] |= 0x10u; /* 165e */
L04e4: R[0x61] &= 0xefu; /* 1261 */
L04e5: w = 0x64; /* 3064 */
L04e6: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L04e7: if ((carry)) goto L04e9; /* 1c03 */
L04e8: goto L04ea; /* 2cea */
L04e9: goto L04ed; /* 2ced */
L04ea: R[0x65] = (uint8_t)(R[0x65] + 1u); zero = (R[0x65] == 0); /* 0ae5 */
L04eb: if (!(zero)) goto L04ed; /* 1903 */
L04ec: R[0x64] = (uint8_t)(R[0x64] + 1u); zero = (R[0x64] == 0); /* 0ae4 */
L04ed: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L04ee: R[0x71] = w; /* 00f1 */
L04ef: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L04f0: R[0x75] = w; /* 00f5 */
L04f1: R[0x70] = 0; zero = 1; /* 01f0 */
L04f2: w = 0x02; /* 3002 */
L04f3: R[0x77] = w; /* 00f7 */
L04f4: ; /* PCLATH handled by native C control flow */ /* 118a */
L04f5: core_signed_div(); /* 2031 */
L04f6: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L04f7: R[0x64] = w; /* 00e4 */
L04f8: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L04f9: R[0x65] = w; /* 00e5 */
L04fa: w = 0xce; /* 30ce */
L04fb: tmp = (uint16_t)R[0x65] + w; carry = (tmp > 255u); dc = ((R[0x65] & 15u) + (w & 15u) > 15u); R[0x65] = (uint8_t)tmp; zero = (R[0x65] == 0); /* 07e5 */
L04fc: if ((carry)) goto L04fe; /* 1c03 */
L04fd: R[0x64] = (uint8_t)(R[0x64] - 1u); zero = (R[0x64] == 0); /* 03e4 */
L04fe: w = 0x51; /* 3051 */
L04ff: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L0500: ; /* PCLATH handled by native C control flow */ /* 118a */
L0501: if ((carry)) goto L0503; /* 1c03 */
L0502: goto L0504; /* 2d04 */
L0503: goto L0506; /* 2d06 */
L0504: R[0x61] |= 0x20u; /* 16e1 */
L0505: goto L0507; /* 2d07 */
L0506: R[0x61] &= 0xdfu; /* 12e1 */
L0507: w = 0x51; /* 3051 */
L0508: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L0509: if ((carry)) goto L050b; /* 1c03 */
L050a: goto L050c; /* 2d0c */
L050b: goto L057c; /* 2d7c */
L050c: w = (uint8_t)(R[0x64] ^ 255u); zero = (w == 0); /* 0964 */
L050d: R[0x71] = w; /* 00f1 */
L050e: w = (uint8_t)(R[0x65] ^ 255u); zero = (w == 0); /* 0965 */
L050f: R[0x75] = w; /* 00f5 */
L0510: R[0x75] = (uint8_t)(R[0x75] + 1u); zero = (R[0x75] == 0); /* 0af5 */
L0511: if (!(zero)) goto L0513; /* 1903 */
L0512: R[0x71] = (uint8_t)(R[0x71] + 1u); zero = (R[0x71] == 0); /* 0af1 */
L0513: R[0x70] = 0; zero = 1; /* 01f0 */
L0514: w = 0x0a; /* 300a */
L0515: R[0x77] = w; /* 00f7 */
L0516: ; /* PCLATH handled by native C control flow */ /* 118a */
L0517: core_signed_div(); /* 2031 */
L0518: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0519: R[0x66] = w; /* 00e6 */
L051a: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L051b: R[0x67] = w; /* 00e7 */
L051c: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L051d: R[0x63] = w; /* 00e3 */
L051e: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L051f: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L0520: R[0x04] = w; /* 0084 */
L0521: w = 0x00; /* 3000 */
L0522: ; /* Original bank selection */ /* 1383 */
L0523: if (!((R[R[4]] & 0x40u))) goto L0525; /* 1b00 */
L0524: w = 0x01; /* 3001 */
L0525: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0526: ; /* PCLATH handled by native C control flow */ /* 118a */
L0527: if ((zero)) goto L0529; /* 1d03 */
L0528: goto L052a; /* 2d2a */
L0529: goto L052c; /* 2d2c */
L052a: R[0x58] |= 0x80u; /* 17d8 */
L052b: goto L052d; /* 2d2d */
L052c: R[0x58] &= 0x7fu; /* 13d8 */
L052d: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x5b] |= 0x80u; else R[0x5b] &= 0x7fu; goto L053a; /* 0863 */
L053a: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5e] |= 0x80u; else R[0x5e] &= 0x7fu; goto L0547; /* 0863 */
L0547: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x61] |= 0x40u; else R[0x61] &= 0xbfu; goto L0554; /* 0863 */
L0554: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5e] |= 0x40u; else R[0x5e] &= 0xbfu; goto L0561; /* 0863 */
L0561: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x58] |= 0x40u; else R[0x58] &= 0xbfu; goto L056e; /* 0863 */
L056e: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5b] |= 0x40u; else R[0x5b] &= 0xbfu; goto L0602; /* 0863 */
L057b: goto L0602; /* 2e02 */
L057c: w = 0x64; /* 3064 */
L057d: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L057e: if ((carry)) goto L0580; /* 1c03 */
L057f: goto L0581; /* 2d81 */
L0580: goto L0589; /* 2d89 */
L0581: R[0x58] &= 0x7fu; /* 13d8 */
L0582: R[0x5b] &= 0x7fu; /* 13db */
L0583: R[0x5e] &= 0x7fu; /* 13de */
L0584: R[0x61] &= 0xbfu; /* 1361 */
L0585: R[0x5e] &= 0xbfu; /* 135e */
L0586: R[0x58] &= 0xbfu; /* 1358 */
L0587: R[0x5b] |= 0x40u; /* 175b */
L0588: goto L0602; /* 2e02 */
L0589: w = 0x78; /* 3078 */
L058a: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L058b: if ((carry)) goto L058d; /* 1c03 */
L058c: goto L058e; /* 2d8e */
L058d: goto L0596; /* 2d96 */
L058e: R[0x58] &= 0x7fu; /* 13d8 */
L058f: R[0x5b] &= 0x7fu; /* 13db */
L0590: R[0x5e] &= 0x7fu; /* 13de */
L0591: R[0x61] &= 0xbfu; /* 1361 */
L0592: R[0x5e] &= 0xbfu; /* 135e */
L0593: R[0x58] &= 0xbfu; /* 1358 */
L0594: R[0x5b] &= 0xbfu; /* 135b */
L0595: goto L0602; /* 2e02 */
L0596: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0597: R[0x71] = w; /* 00f1 */
L0598: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0599: R[0x75] = w; /* 00f5 */
L059a: R[0x70] = 0; zero = 1; /* 01f0 */
L059b: w = 0x0a; /* 300a */
L059c: R[0x77] = w; /* 00f7 */
L059d: ; /* PCLATH handled by native C control flow */ /* 118a */
L059e: core_signed_div(); /* 2031 */
L059f: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L05a0: R[0x66] = w; /* 00e6 */
L05a1: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L05a2: R[0x67] = w; /* 00e7 */
L05a3: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L05a4: R[0x63] = w; /* 00e3 */
L05a5: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L05a6: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L05a7: R[0x04] = w; /* 0084 */
L05a8: w = 0x00; /* 3000 */
L05a9: ; /* Original bank selection */ /* 1383 */
L05aa: if (!((R[R[4]] & 0x40u))) goto L05ac; /* 1b00 */
L05ab: w = 0x01; /* 3001 */
L05ac: w ^= 0x00; zero = (w == 0); /* 3a00 */
L05ad: ; /* PCLATH handled by native C control flow */ /* 118a */
L05ae: if ((zero)) goto L05b0; /* 1d03 */
L05af: goto L05b1; /* 2db1 */
L05b0: goto L05b3; /* 2db3 */
L05b1: R[0x58] |= 0x80u; /* 17d8 */
L05b2: goto L05b4; /* 2db4 */
L05b3: R[0x58] &= 0x7fu; /* 13d8 */
L05b4: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x5b] |= 0x80u; else R[0x5b] &= 0x7fu; goto L05c1; /* 0863 */
L05c1: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5e] |= 0x80u; else R[0x5e] &= 0x7fu; goto L05ce; /* 0863 */
L05ce: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x61] |= 0x40u; else R[0x61] &= 0xbfu; goto L05db; /* 0863 */
L05db: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5e] |= 0x40u; else R[0x5e] &= 0xbfu; goto L05e8; /* 0863 */
L05e8: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x58] |= 0x40u; else R[0x58] &= 0xbfu; goto L05f5; /* 0863 */
L05f5: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x5b] |= 0x40u; else R[0x5b] &= 0xbfu; goto L0602; /* 0863 */
L0602: w = 0x64; /* 3064 */
L0603: tmp = (uint16_t)R[0x51] - w; carry = (R[0x51] >= w); dc = ((R[0x51] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0251 */
L0604: ; /* 0000 */
L0605: ; /* 0000 */
L0606: if ((carry)) goto L0608; /* 1c03 */
L0607: goto L0609; /* 2e09 */
L0608: goto L061d; /* 2e1d */
L0609: w = (uint8_t)(R[0x64] ^ 255u); zero = (w == 0); /* 0964 */
L060a: R[0x71] = w; /* 00f1 */
L060b: w = (uint8_t)(R[0x65] ^ 255u); zero = (w == 0); /* 0965 */
L060c: R[0x75] = w; /* 00f5 */
L060d: R[0x75] = (uint8_t)(R[0x75] + 1u); zero = (R[0x75] == 0); /* 0af5 */
L060e: if (!(zero)) goto L0610; /* 1903 */
L060f: R[0x71] = (uint8_t)(R[0x71] + 1u); zero = (R[0x71] == 0); /* 0af1 */
L0610: R[0x70] = 0; zero = 1; /* 01f0 */
L0611: w = 0x0a; /* 300a */
L0612: R[0x77] = w; /* 00f7 */
L0613: ; /* PCLATH handled by native C control flow */ /* 118a */
L0614: core_signed_div(); /* 2031 */
L0615: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0616: R[0x66] = w; /* 00e6 */
L0617: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0618: R[0x67] = w; /* 00e7 */
L0619: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L061a: R[0x63] = w; /* 00e3 */
L061b: ; /* PCLATH handled by native C control flow */ /* 118a */
L061c: goto L062c; /* 2e2c */
L061d: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L061e: R[0x71] = w; /* 00f1 */
L061f: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0620: R[0x75] = w; /* 00f5 */
L0621: R[0x70] = 0; zero = 1; /* 01f0 */
L0622: w = 0x0a; /* 300a */
L0623: R[0x77] = w; /* 00f7 */
L0624: ; /* PCLATH handled by native C control flow */ /* 118a */
L0625: core_signed_div(); /* 2031 */
L0626: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0627: R[0x66] = w; /* 00e6 */
L0628: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0629: R[0x67] = w; /* 00e7 */
L062a: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L062b: R[0x63] = w; /* 00e3 */
L062c: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L062d: tmp = (uint16_t)w + 0x40u; carry = (tmp > 255u); dc = ((w & 15u) + (0x40u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e40 */
L062e: R[0x04] = w; /* 0084 */
L062f: w = 0x00; /* 3000 */
L0630: ; /* Original bank selection */ /* 1383 */
L0631: if (!((R[R[4]] & 0x40u))) goto L0633; /* 1b00 */
L0632: w = 0x01; /* 3001 */
L0633: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0634: ; /* PCLATH handled by native C control flow */ /* 118a */
L0635: if ((zero)) goto L0637; /* 1d03 */
L0636: goto L0638; /* 2e38 */
L0637: goto L063a; /* 2e3a */
L0638: R[0x56] |= 0x04u; /* 1556 */
L0639: goto L063b; /* 2e3b */
L063a: R[0x56] &= 0xfbu; /* 1156 */
L063b: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x20u) != 0); zero = !w; if (w) R[0x59] |= 0x04u; else R[0x59] &= 0xfbu; goto L0648; /* 0863 */
L0648: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x10u) != 0); zero = !w; if (w) R[0x5c] |= 0x04u; else R[0x5c] &= 0xfbu; goto L0655; /* 0863 */
L0655: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x08u) != 0); zero = !w; if (w) R[0x5f] |= 0x08u; else R[0x5f] &= 0xf7u; goto L0662; /* 0863 */
L0662: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x04u) != 0); zero = !w; if (w) R[0x5c] |= 0x08u; else R[0x5c] &= 0xf7u; goto L066f; /* 0863 */
L066f: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x02u) != 0); zero = !w; if (w) R[0x56] |= 0x08u; else R[0x56] &= 0xf7u; goto L067c; /* 0863 */
L067c: tmp = (uint16_t)R[0x63] + 0x40u; carry = (tmp > 255u); dc = 0; R[4] = (uint8_t)tmp; w = ((R[R[4]] & 0x01u) != 0); zero = !w; if (w) R[0x59] |= 0x08u; else R[0x59] &= 0xf7u; goto L0689; /* 0863 */
L0689: R[0x5f] |= 0x04u; /* 155f */
L068a: if (!((R[0x51] & 0x01u))) goto L068c; /* 1851 */
L068b: goto L068d; /* 2e8d */
L068c: goto L0691; /* 2e91 */
L068d: R[0x59] &= 0xfeu; /* 1059 */
L068e: R[0x5c] &= 0xfdu; /* 10dc */
L068f: R[0x59] |= 0x02u; /* 14d9 */
L0690: goto L0694; /* 2e94 */
L0691: R[0x59] |= 0x01u; /* 1459 */
L0692: R[0x5c] |= 0x02u; /* 14dc */
L0693: R[0x59] &= 0xfdu; /* 10d9 */
L0694: R[0x56] |= 0x01u; /* 1456 */
L0695: R[0x5c] |= 0x01u; /* 145c */
L0696: R[0x5f] |= 0x02u; /* 14df */
L0697: R[0x56] |= 0x02u; /* 14d6 */
L0698: return; /* 0008 */
}

/* Original entry 0x0b5d, word addresses. Non-reentrant. */
void core_brightness(void) {
goto L0b5d;
L0b5d: w = 0xfe; /* 30fe */
L0b5e: tmp = (uint16_t)R[0x54] - w; carry = (R[0x54] >= w); dc = ((R[0x54] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0254 */
L0b5f: if (!(carry)) goto L0b61; /* 1803 */
L0b60: goto L0b62; /* 2b62 */
L0b61: goto L0b65; /* 2b65 */
L0b62: w = 0x0a; /* 300a */
L0b63: R[0x66] = w; /* 00e6 */
L0b64: goto L0b6f; /* 2b6f */
L0b65: w = 0x0a; /* 300a */
L0b66: tmp = (uint16_t)R[0x54] - w; carry = (R[0x54] >= w); dc = ((R[0x54] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0254 */
L0b67: if ((carry)) goto L0b69; /* 1c03 */
L0b68: goto L0b6a; /* 2b6a */
L0b69: goto L0b6d; /* 2b6d */
L0b6a: w = 0x0a; /* 300a */
L0b6b: R[0x66] = w; /* 00e6 */
L0b6c: goto L0b6f; /* 2b6f */
L0b6d: w = (uint8_t)(R[0x54]); zero = (w == 0); /* 0854 */
L0b6e: R[0x66] = w; /* 00e6 */
L0b6f: w = 0xf6; /* 30f6 */
L0b70: tmp = (uint16_t)R[0x66] + w; carry = (tmp > 255u); dc = ((R[0x66] & 15u) + (w & 15u) > 15u); R[0x66] = (uint8_t)tmp; zero = (R[0x66] == 0); /* 07e6 */
L0b71: w = 0x04; /* 3004 */
L0b72: R[0x69] = w; /* 00e9 */
L0b73: goto L0b75; /* 2b75 */
L0b74: R[0x69] = (uint8_t)(R[0x69] - 1u); zero = (R[0x69] == 0); /* 03e9 */
L0b75: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0b76: tmp = (uint16_t)w + 0x27u; carry = (tmp > 255u); dc = ((w & 15u) + (0x27u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e27 */
L0b77: R[0x04] = w; /* 0084 */
L0b78: ; /* Original bank selection */ /* 1383 */
L0b79: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0b7a: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0b7b: if ((carry)) goto L0b7d; /* 1c03 */
L0b7c: goto L0b7e; /* 2b7e */
L0b7d: goto L0b82; /* 2b82 */
L0b7e: R[0x69] = (uint8_t)(R[0x69]); zero = (R[0x69] == 0); /* 08e9 */
L0b7f: if (!(zero)) goto L0b81; /* 1903 */
L0b80: goto L0b82; /* 2b82 */
L0b81: goto L0b74; /* 2b74 */
L0b82: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0b83: tmp = (uint16_t)w + 0x01u; carry = (tmp > 255u); dc = ((w & 15u) + (0x01u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e01 */
L0b84: tmp = (uint16_t)w + 0x27u; carry = (tmp > 255u); dc = ((w & 15u) + (0x27u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e27 */
L0b85: R[0x04] = w; /* 0084 */
L0b86: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0b87: R[0x6d] = w; /* 00ed */
L0b88: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0b89: tmp = (uint16_t)w + 0x27u; carry = (tmp > 255u); dc = ((w & 15u) + (0x27u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e27 */
L0b8a: R[0x04] = w; /* 0084 */
L0b8b: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0b8c: tmp = (uint16_t)R[0x6d] - w; carry = (R[0x6d] >= w); dc = ((R[0x6d] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 026d */
L0b8d: R[0x6d] = w; /* 00ed */
L0b8e: R[0x53] = (uint8_t)(R[0x53]); zero = (R[0x53] == 0); /* 08d3 */
L0b8f: if (!(zero)) goto L0b91; /* 1903 */
L0b90: goto L0b92; /* 2b92 */
L0b91: goto L0b95; /* 2b95 */
L0b92: w = 0x64; /* 3064 */
L0b93: R[0x6a] = w; /* 00ea */
L0b94: goto L0ba7; /* 2ba7 */
L0b95: if (((R[0x53] & 0x80u))) goto L0b97; /* 1fd3 */
L0b96: goto L0b98; /* 2b98 */
L0b97: goto L0ba2; /* 2ba2 */
L0b98: w = 0x14; /* 3014 */
L0b99: tmp = (uint16_t)R[0x53] - w; carry = (R[0x53] >= w); dc = ((R[0x53] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0253 */
L0b9a: if (!(carry)) goto L0b9c; /* 1803 */
L0b9b: goto L0b9d; /* 2b9d */
L0b9c: goto L0ba2; /* 2ba2 */
L0b9d: w = 0x65; /* 3065 */
L0b9e: tmp = (uint16_t)R[0x53] - w; carry = (R[0x53] >= w); dc = ((R[0x53] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0253 */
L0b9f: if (!(carry)) goto L0ba1; /* 1803 */
L0ba0: goto L0ba2; /* 2ba2 */
L0ba1: goto L0ba5; /* 2ba5 */
L0ba2: w = 0x14; /* 3014 */
L0ba3: R[0x6a] = w; /* 00ea */
L0ba4: goto L0ba7; /* 2ba7 */
L0ba5: w = (uint8_t)(R[0x53]); zero = (w == 0); /* 0853 */
L0ba6: R[0x6a] = w; /* 00ea */
L0ba7: R[0x26] = (uint8_t)(R[0x26]); zero = (R[0x26] == 0); /* 08a6 */
L0ba8: if (!(zero)) goto L0baa; /* 1903 */
L0ba9: goto L0bab; /* 2bab */
L0baa: goto L0bad; /* 2bad */
L0bab: w = 0x64; /* 3064 */
L0bac: R[0x6a] = w; /* 00ea */
L0bad: w = 0xec; /* 30ec */
L0bae: tmp = (uint16_t)R[0x6a] + w; carry = (tmp > 255u); dc = ((R[0x6a] & 15u) + (w & 15u) > 15u); R[0x6a] = (uint8_t)tmp; zero = (R[0x6a] == 0); /* 07ea */
L0baf: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0bb0: tmp = (uint16_t)w + 0x27u; carry = (tmp > 255u); dc = ((w & 15u) + (0x27u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e27 */
L0bb1: R[0x04] = w; /* 0084 */
L0bb2: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0bb3: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0bb4: R[0x66] = w; /* 00e6 */
L0bb5: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0bb6: tmp = (uint16_t)w + 0x01u; carry = (tmp > 255u); dc = ((w & 15u) + (0x01u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e01 */
L0bb7: R[0x75] = w; /* 00f5 */
L0bb8: w = 0x02; /* 3002 */
L0bb9: R[0x71] = w; /* 00f1 */
L0bba: ; /* PCLATH handled by native C control flow */ /* 118a */
L0bbb: core_multiply_byte(); /* 20b6 */
L0bbc: tmp = (uint16_t)w + 0x2cu; carry = (tmp > 255u); dc = ((w & 15u) + (0x2cu & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e2c */
L0bbd: R[0x04] = w; /* 0084 */
L0bbe: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0bbf: R[0x71] = w; /* 00f1 */
L0bc0: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0bc1: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0bc2: R[0x75] = w; /* 00f5 */
L0bc3: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0bc4: R[0x6b] = w; /* 00eb */
L0bc5: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0bc6: R[0x6c] = w; /* 00ec */
L0bc7: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0bc8: R[0x75] = w; /* 00f5 */
L0bc9: w = 0x02; /* 3002 */
L0bca: R[0x71] = w; /* 00f1 */
L0bcb: core_multiply_byte(); /* 20b6 */
L0bcc: tmp = (uint16_t)w + 0x2cu; carry = (tmp > 255u); dc = ((w & 15u) + (0x2cu & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e2c */
L0bcd: R[0x04] = w; /* 0084 */
L0bce: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0bcf: R[0x71] = w; /* 00f1 */
L0bd0: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0bd1: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0bd2: R[0x75] = w; /* 00f5 */
L0bd3: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0bd4: tmp = (uint16_t)R[0x6c] - w; carry = (R[0x6c] >= w); dc = ((R[0x6c] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 026c */
L0bd5: R[0x6c] = w; /* 00ec */
L0bd6: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0bd7: if ((carry)) goto L0bd9; /* 1c03 */
L0bd8: tmp = (uint16_t)w + 0x01u; carry = (tmp > 255u); dc = ((w & 15u) + (0x01u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e01 */
L0bd9: tmp = (uint16_t)R[0x6b] - w; carry = (R[0x6b] >= w); dc = ((R[0x6b] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 026b */
L0bda: R[0x6b] = w; /* 00eb */
L0bdb: w = 0x00; /* 3000 */
L0bdc: R[0x67] = w; /* 00e7 */
L0bdd: w = (uint8_t)(R[0x66]); zero = (w == 0); /* 0866 */
L0bde: R[0x68] = w; /* 00e8 */
L0bdf: w = 0x80; /* 3080 */
L0be0: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0be1: ; /* PCLATH handled by native C control flow */ /* 158a */
L0be2: if (!(carry)) goto L0be4; /* 1803 */
L0be3: goto L0be5; /* 2be5 */
L0be4: goto L0bf3; /* 2bf3 */
L0be5: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0be6: R[0x71] = w; /* 00f1 */
L0be7: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0be8: R[0x75] = w; /* 00f5 */
L0be9: w = 0x02; /* 3002 */
L0bea: R[0x77] = w; /* 00f7 */
L0beb: ; /* PCLATH handled by native C control flow */ /* 118a */
L0bec: core_shift_right(); /* 20c5 */
L0bed: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0bee: R[0x67] = w; /* 00e7 */
L0bef: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0bf0: R[0x68] = w; /* 00e8 */
L0bf1: ; /* PCLATH handled by native C control flow */ /* 158a */
L0bf2: goto L0c04; /* 2c04 */
L0bf3: w = 0x40; /* 3040 */
L0bf4: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0bf5: if (!(carry)) goto L0bf7; /* 1803 */
L0bf6: goto L0bf8; /* 2bf8 */
L0bf7: goto L0c04; /* 2c04 */
L0bf8: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0bf9: R[0x71] = w; /* 00f1 */
L0bfa: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0bfb: R[0x75] = w; /* 00f5 */
L0bfc: w = 0x01; /* 3001 */
L0bfd: R[0x77] = w; /* 00f7 */
L0bfe: ; /* PCLATH handled by native C control flow */ /* 118a */
L0bff: core_shift_right(); /* 20c5 */
L0c00: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c01: R[0x67] = w; /* 00e7 */
L0c02: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c03: R[0x68] = w; /* 00e8 */
L0c04: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0c05: R[0x71] = w; /* 00f1 */
L0c06: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0c07: R[0x75] = w; /* 00f5 */
L0c08: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0c09: R[0x70] = w; /* 00f0 */
L0c0a: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0c0b: R[0x77] = w; /* 00f7 */
L0c0c: ; /* PCLATH handled by native C control flow */ /* 118a */
L0c0d: core_multiply(); /* 2091 */
L0c0e: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0c0f: R[0x6b] = w; /* 00eb */
L0c10: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0c11: R[0x6c] = w; /* 00ec */
L0c12: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0c13: R[0x71] = w; /* 00f1 */
L0c14: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0c15: R[0x75] = w; /* 00f5 */
L0c16: w = (uint8_t)(R[0x6d]); zero = (w == 0); /* 086d */
L0c17: R[0x77] = w; /* 00f7 */
L0c18: R[0x70] = 0; zero = 1; /* 01f0 */
L0c19: core_signed_div(); /* 2031 */
L0c1a: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c1b: R[0x6b] = w; /* 00eb */
L0c1c: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c1d: R[0x6c] = w; /* 00ec */
L0c1e: w = 0x80; /* 3080 */
L0c1f: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0c20: ; /* PCLATH handled by native C control flow */ /* 158a */
L0c21: if (!(carry)) goto L0c23; /* 1803 */
L0c22: goto L0c24; /* 2c24 */
L0c23: goto L0c32; /* 2c32 */
L0c24: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0c25: R[0x71] = w; /* 00f1 */
L0c26: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0c27: R[0x75] = w; /* 00f5 */
L0c28: w = 0x02; /* 3002 */
L0c29: R[0x77] = w; /* 00f7 */
L0c2a: ; /* PCLATH handled by native C control flow */ /* 118a */
L0c2b: core_shift_left(); /* 20cf */
L0c2c: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c2d: R[0x6b] = w; /* 00eb */
L0c2e: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c2f: R[0x6c] = w; /* 00ec */
L0c30: ; /* PCLATH handled by native C control flow */ /* 158a */
L0c31: goto L0c42; /* 2c42 */
L0c32: w = 0x40; /* 3040 */
L0c33: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0c34: if (!(carry)) goto L0c36; /* 1803 */
L0c35: goto L0c37; /* 2c37 */
L0c36: goto L0c42; /* 2c42 */
L0c37: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0c38: R[0x71] = w; /* 00f1 */
L0c39: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0c3a: R[0x75] = w; /* 00f5 */
L0c3b: carry = 0; /* 1003 */
L0c3c: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L0c3d: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df1 */
L0c3e: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c3f: R[0x6b] = w; /* 00eb */
L0c40: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c41: R[0x6c] = w; /* 00ec */
L0c42: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0c43: R[0x75] = w; /* 00f5 */
L0c44: w = 0x02; /* 3002 */
L0c45: R[0x71] = w; /* 00f1 */
L0c46: ; /* PCLATH handled by native C control flow */ /* 118a */
L0c47: core_multiply_byte(); /* 20b6 */
L0c48: tmp = (uint16_t)w + 0x2cu; carry = (tmp > 255u); dc = ((w & 15u) + (0x2cu & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e2c */
L0c49: R[0x04] = w; /* 0084 */
L0c4a: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c4b: R[0x71] = w; /* 00f1 */
L0c4c: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0c4d: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c4e: R[0x75] = w; /* 00f5 */
L0c4f: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c50: tmp = (uint16_t)R[0x6c] + w; carry = (tmp > 255u); dc = ((R[0x6c] & 15u) + (w & 15u) > 15u); R[0x6c] = (uint8_t)tmp; zero = (R[0x6c] == 0); /* 07ec */
L0c51: if (!(carry)) goto L0c53; /* 1803 */
L0c52: R[0x6b] = (uint8_t)(R[0x6b] + 1u); zero = (R[0x6b] == 0); /* 0aeb */
L0c53: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c54: tmp = (uint16_t)R[0x6b] + w; carry = (tmp > 255u); dc = ((R[0x6b] & 15u) + (w & 15u) > 15u); R[0x6b] = (uint8_t)tmp; zero = (R[0x6b] == 0); /* 07eb */
L0c55: w = 0x00; /* 3000 */
L0c56: R[0x67] = w; /* 00e7 */
L0c57: w = (uint8_t)(R[0x6a]); zero = (w == 0); /* 086a */
L0c58: R[0x68] = w; /* 00e8 */
L0c59: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0c5a: R[0x71] = w; /* 00f1 */
L0c5b: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0c5c: R[0x75] = w; /* 00f5 */
L0c5d: R[0x65] = w; /* 00e5 */
L0c5e: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c5f: R[0x63] = w; /* 00e3 */
L0c60: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c61: R[0x64] = w; /* 00e4 */
L0c62: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0c63: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0c64: R[0x75] = w; /* 00f5 */
L0c65: w = 0x02; /* 3002 */
L0c66: R[0x71] = w; /* 00f1 */
L0c67: core_multiply_byte(); /* 20b6 */
L0c68: tmp = (uint16_t)w + 0x36u; carry = (tmp > 255u); dc = ((w & 15u) + (0x36u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e36 */
L0c69: R[0x04] = w; /* 0084 */
L0c6a: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c6b: R[0x70] = w; /* 00f0 */
L0c6c: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0c6d: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c6e: R[0x77] = w; /* 00f7 */
L0c6f: R[0x65] = w; /* 00e5 */
L0c70: w = (uint8_t)(R[0x63]); zero = (w == 0); /* 0863 */
L0c71: R[0x71] = w; /* 00f1 */
L0c72: w = (uint8_t)(R[0x64]); zero = (w == 0); /* 0864 */
L0c73: R[0x75] = w; /* 00f5 */
L0c74: w = (uint8_t)(R[0x65]); zero = (w == 0); /* 0865 */
L0c75: core_multiply(); /* 2091 */
L0c76: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0c77: R[0x67] = w; /* 00e7 */
L0c78: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0c79: R[0x68] = w; /* 00e8 */
L0c7a: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0c7b: R[0x71] = w; /* 00f1 */
L0c7c: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0c7d: R[0x75] = w; /* 00f5 */
L0c7e: R[0x70] = 0; zero = 1; /* 01f0 */
L0c7f: w = 0x50; /* 3050 */
L0c80: R[0x77] = w; /* 00f7 */
L0c81: core_signed_div(); /* 2031 */
L0c82: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c83: R[0x67] = w; /* 00e7 */
L0c84: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c85: R[0x68] = w; /* 00e8 */
L0c86: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0c87: tmp = (uint16_t)R[0x6c] + w; carry = (tmp > 255u); dc = ((R[0x6c] & 15u) + (w & 15u) > 15u); R[0x6c] = (uint8_t)tmp; zero = (R[0x6c] == 0); /* 07ec */
L0c88: if (!(carry)) goto L0c8a; /* 1803 */
L0c89: R[0x6b] = (uint8_t)(R[0x6b] + 1u); zero = (R[0x6b] == 0); /* 0aeb */
L0c8a: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0c8b: tmp = (uint16_t)R[0x6b] + w; carry = (tmp > 255u); dc = ((R[0x6b] & 15u) + (w & 15u) > 15u); R[0x6b] = (uint8_t)tmp; zero = (R[0x6b] == 0); /* 07eb */
L0c8c: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0c8d: tmp = (uint16_t)w + 0x01u; carry = (tmp > 255u); dc = ((w & 15u) + (0x01u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e01 */
L0c8e: R[0x75] = w; /* 00f5 */
L0c8f: w = 0x02; /* 3002 */
L0c90: R[0x71] = w; /* 00f1 */
L0c91: core_multiply_byte(); /* 20b6 */
L0c92: tmp = (uint16_t)w + 0x36u; carry = (tmp > 255u); dc = ((w & 15u) + (0x36u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e36 */
L0c93: R[0x04] = w; /* 0084 */
L0c94: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c95: R[0x71] = w; /* 00f1 */
L0c96: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0c97: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0c98: R[0x75] = w; /* 00f5 */
L0c99: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0c9a: R[0x67] = w; /* 00e7 */
L0c9b: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0c9c: R[0x68] = w; /* 00e8 */
L0c9d: w = (uint8_t)(R[0x69]); zero = (w == 0); /* 0869 */
L0c9e: R[0x75] = w; /* 00f5 */
L0c9f: w = 0x02; /* 3002 */
L0ca0: R[0x71] = w; /* 00f1 */
L0ca1: core_multiply_byte(); /* 20b6 */
L0ca2: tmp = (uint16_t)w + 0x36u; carry = (tmp > 255u); dc = ((w & 15u) + (0x36u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e36 */
L0ca3: R[0x04] = w; /* 0084 */
L0ca4: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0ca5: R[0x71] = w; /* 00f1 */
L0ca6: R[0x04] = (uint8_t)(R[0x04] + 1u); zero = (R[0x04] == 0); /* 0a84 */
L0ca7: w = (uint8_t)(R[R[4]]); zero = (w == 0); /* 0800 */
L0ca8: R[0x75] = w; /* 00f5 */
L0ca9: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0caa: tmp = (uint16_t)R[0x68] - w; carry = (R[0x68] >= w); dc = ((R[0x68] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0268 */
L0cab: R[0x68] = w; /* 00e8 */
L0cac: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0cad: if ((carry)) goto L0caf; /* 1c03 */
L0cae: tmp = (uint16_t)w + 0x01u; carry = (tmp > 255u); dc = ((w & 15u) + (0x01u & 15u) > 15u); w = (uint8_t)tmp; zero = (w == 0); /* 3e01 */
L0caf: tmp = (uint16_t)R[0x67] - w; carry = (R[0x67] >= w); dc = ((R[0x67] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0267 */
L0cb0: R[0x67] = w; /* 00e7 */
L0cb1: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0cb2: R[0x71] = w; /* 00f1 */
L0cb3: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0cb4: R[0x75] = w; /* 00f5 */
L0cb5: w = (uint8_t)(R[0x6a]); zero = (w == 0); /* 086a */
L0cb6: R[0x77] = w; /* 00f7 */
L0cb7: R[0x70] = 0; zero = 1; /* 01f0 */
L0cb8: core_multiply(); /* 2091 */
L0cb9: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0cba: R[0x67] = w; /* 00e7 */
L0cbb: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0cbc: R[0x68] = w; /* 00e8 */
L0cbd: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0cbe: R[0x71] = w; /* 00f1 */
L0cbf: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0cc0: R[0x75] = w; /* 00f5 */
L0cc1: R[0x70] = 0; zero = 1; /* 01f0 */
L0cc2: w = 0x50; /* 3050 */
L0cc3: R[0x77] = w; /* 00f7 */
L0cc4: core_signed_div(); /* 2031 */
L0cc5: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0cc6: R[0x67] = w; /* 00e7 */
L0cc7: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0cc8: R[0x68] = w; /* 00e8 */
L0cc9: w = 0x80; /* 3080 */
L0cca: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0ccb: ; /* PCLATH handled by native C control flow */ /* 158a */
L0ccc: if (!(carry)) goto L0cce; /* 1803 */
L0ccd: goto L0ccf; /* 2ccf */
L0cce: goto L0cdd; /* 2cdd */
L0ccf: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0cd0: R[0x71] = w; /* 00f1 */
L0cd1: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0cd2: R[0x75] = w; /* 00f5 */
L0cd3: w = 0x02; /* 3002 */
L0cd4: R[0x77] = w; /* 00f7 */
L0cd5: ; /* PCLATH handled by native C control flow */ /* 118a */
L0cd6: core_shift_right(); /* 20c5 */
L0cd7: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0cd8: R[0x67] = w; /* 00e7 */
L0cd9: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0cda: R[0x68] = w; /* 00e8 */
L0cdb: ; /* PCLATH handled by native C control flow */ /* 158a */
L0cdc: goto L0cee; /* 2cee */
L0cdd: w = 0x40; /* 3040 */
L0cde: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0cdf: if (!(carry)) goto L0ce1; /* 1803 */
L0ce0: goto L0ce2; /* 2ce2 */
L0ce1: goto L0cee; /* 2cee */
L0ce2: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0ce3: R[0x71] = w; /* 00f1 */
L0ce4: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0ce5: R[0x75] = w; /* 00f5 */
L0ce6: w = 0x01; /* 3001 */
L0ce7: R[0x77] = w; /* 00f7 */
L0ce8: ; /* PCLATH handled by native C control flow */ /* 118a */
L0ce9: core_shift_right(); /* 20c5 */
L0cea: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0ceb: R[0x67] = w; /* 00e7 */
L0cec: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0ced: R[0x68] = w; /* 00e8 */
L0cee: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0cef: R[0x71] = w; /* 00f1 */
L0cf0: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0cf1: R[0x75] = w; /* 00f5 */
L0cf2: w = (uint8_t)(R[0x66]); zero = (w == 0); /* 0866 */
L0cf3: R[0x77] = w; /* 00f7 */
L0cf4: R[0x70] = 0; zero = 1; /* 01f0 */
L0cf5: ; /* PCLATH handled by native C control flow */ /* 118a */
L0cf6: core_multiply(); /* 2091 */
L0cf7: w = (uint8_t)(R[0x72]); zero = (w == 0); /* 0872 */
L0cf8: R[0x67] = w; /* 00e7 */
L0cf9: w = (uint8_t)(R[0x76]); zero = (w == 0); /* 0876 */
L0cfa: R[0x68] = w; /* 00e8 */
L0cfb: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0cfc: R[0x71] = w; /* 00f1 */
L0cfd: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0cfe: R[0x75] = w; /* 00f5 */
L0cff: w = (uint8_t)(R[0x6d]); zero = (w == 0); /* 086d */
L0d00: R[0x77] = w; /* 00f7 */
L0d01: R[0x70] = 0; zero = 1; /* 01f0 */
L0d02: core_signed_div(); /* 2031 */
L0d03: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0d04: R[0x67] = w; /* 00e7 */
L0d05: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0d06: R[0x68] = w; /* 00e8 */
L0d07: w = 0x80; /* 3080 */
L0d08: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0d09: ; /* PCLATH handled by native C control flow */ /* 158a */
L0d0a: if (!(carry)) goto L0d0c; /* 1803 */
L0d0b: goto L0d0d; /* 2d0d */
L0d0c: goto L0d1b; /* 2d1b */
L0d0d: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0d0e: R[0x71] = w; /* 00f1 */
L0d0f: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0d10: R[0x75] = w; /* 00f5 */
L0d11: w = 0x02; /* 3002 */
L0d12: R[0x77] = w; /* 00f7 */
L0d13: ; /* PCLATH handled by native C control flow */ /* 118a */
L0d14: core_shift_left(); /* 20cf */
L0d15: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0d16: R[0x67] = w; /* 00e7 */
L0d17: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0d18: R[0x68] = w; /* 00e8 */
L0d19: ; /* PCLATH handled by native C control flow */ /* 158a */
L0d1a: goto L0d2b; /* 2d2b */
L0d1b: w = 0x40; /* 3040 */
L0d1c: tmp = (uint16_t)R[0x66] - w; carry = (R[0x66] >= w); dc = ((R[0x66] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0266 */
L0d1d: if (!(carry)) goto L0d1f; /* 1803 */
L0d1e: goto L0d20; /* 2d20 */
L0d1f: goto L0d2b; /* 2d2b */
L0d20: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0d21: R[0x71] = w; /* 00f1 */
L0d22: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0d23: R[0x75] = w; /* 00f5 */
L0d24: carry = 0; /* 1003 */
L0d25: tmp = R[0x75]; R[0x75] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df5 */
L0d26: tmp = R[0x71]; R[0x71] = (uint8_t)((tmp << 1) | carry); carry = (uint8_t)((tmp >> 7)); /* 0df1 */
L0d27: w = (uint8_t)(R[0x71]); zero = (w == 0); /* 0871 */
L0d28: R[0x67] = w; /* 00e7 */
L0d29: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0d2a: R[0x68] = w; /* 00e8 */
L0d2b: w = (uint8_t)(R[0x68]); zero = (w == 0); /* 0868 */
L0d2c: tmp = (uint16_t)R[0x6c] + w; carry = (tmp > 255u); dc = ((R[0x6c] & 15u) + (w & 15u) > 15u); R[0x6c] = (uint8_t)tmp; zero = (R[0x6c] == 0); /* 07ec */
L0d2d: if (!(carry)) goto L0d2f; /* 1803 */
L0d2e: R[0x6b] = (uint8_t)(R[0x6b] + 1u); zero = (R[0x6b] == 0); /* 0aeb */
L0d2f: w = (uint8_t)(R[0x67]); zero = (w == 0); /* 0867 */
L0d30: tmp = (uint16_t)R[0x6b] + w; carry = (tmp > 255u); dc = ((R[0x6b] & 15u) + (w & 15u) > 15u); R[0x6b] = (uint8_t)tmp; zero = (R[0x6b] == 0); /* 07eb */
L0d31: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0d32: R[0x71] = w; /* 00f1 */
L0d33: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0d34: R[0x75] = w; /* 00f5 */
L0d35: w = 0x02; /* 3002 */
L0d36: R[0x70] = w; /* 00f0 */
L0d37: w = 0xbd; /* 30bd */
L0d38: R[0x77] = w; /* 00f7 */
L0d39: w = 0x80; /* 3080 */
L0d3a: R[0x71] = (uint8_t)(R[0x71] ^ w); zero = (R[0x71] == 0); /* 06f1 */
L0d3b: w = (uint8_t)(R[0x70] ^ w); zero = (w == 0); /* 0670 */
L0d3c: tmp = (uint16_t)R[0x71] - w; carry = (R[0x71] >= w); dc = ((R[0x71] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0271 */
L0d3d: if (!(zero)) goto L0d3f; /* 1903 */
L0d3e: goto L0d40; /* 2d40 */
L0d3f: goto L0d42; /* 2d42 */
L0d40: w = (uint8_t)(R[0x77]); zero = (w == 0); /* 0877 */
L0d41: tmp = (uint16_t)R[0x75] - w; carry = (R[0x75] >= w); dc = ((R[0x75] & 15u) >= (w & 15u)); w = (uint8_t)tmp; zero = (w == 0); /* 0275 */
L0d42: if (!(carry)) goto L0d44; /* 1803 */
L0d43: goto L0d45; /* 2d45 */
L0d44: goto L0d49; /* 2d49 */
L0d45: w = 0x02; /* 3002 */
L0d46: R[0x6b] = w; /* 00eb */
L0d47: w = 0xbc; /* 30bc */
L0d48: R[0x6c] = w; /* 00ec */
L0d49: w = (uint8_t)(R[0x6b]); zero = (w == 0); /* 086b */
L0d4a: R[0x71] = w; /* 00f1 */
L0d4b: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0d4c: R[0x75] = w; /* 00f5 */
L0d4d: w = 0x02; /* 3002 */
L0d4e: R[0x77] = w; /* 00f7 */
L0d4f: ; /* PCLATH handled by native C control flow */ /* 118a */
L0d50: core_shift_right(); /* 20c5 */
L0d51: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0d52: w = (uint8_t)(R[0x75]); zero = (w == 0); /* 0875 */
L0d53: R[0x6a] = w; /* 00ea */
L0d54: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0d55: w &= 0x02; zero = (w == 0); /* 3902 */
L0d56: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0d57: ; /* PCLATH handled by native C control flow */ /* 158a */
L0d58: if ((zero)) goto L0d5a; /* 1d03 */
L0d59: goto L0d5b; /* 2d5b */
L0d5a: goto L0d5d; /* 2d5d */
L0d5b: R[0x17] |= 0x20u; /* 1697 */
L0d5c: goto L0d5e; /* 2d5e */
L0d5d: R[0x17] &= 0xdfu; /* 1297 */
L0d5e: w = (uint8_t)(R[0x6c]); zero = (w == 0); /* 086c */
L0d5f: w &= 0x01; zero = (w == 0); /* 3901 */
L0d60: w ^= 0x00; zero = (w == 0); /* 3a00 */
L0d61: if ((zero)) goto L0d63; /* 1d03 */
L0d62: goto L0d64; /* 2d64 */
L0d63: goto L0d66; /* 2d66 */
L0d64: R[0x17] |= 0x10u; /* 1617 */
L0d65: goto L0d67; /* 2d67 */
L0d66: R[0x17] &= 0xefu; /* 1217 */
L0d67: w = (uint8_t)(R[0x6a]); zero = (w == 0); /* 086a */
L0d68: R[0x15] = w; /* 0095 */
L0d69: return; /* 0008 */
}
